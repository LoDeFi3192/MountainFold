package com.mountainfold.app

import com.mountainfold.app.core.engine.CopilotEngine
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.Symptom
import com.mountainfold.app.core.train.BaristaTitle
import com.mountainfold.app.core.train.Breakdown
import com.mountainfold.app.core.train.BrewSignal
import com.mountainfold.app.core.train.DialInGenerator
import com.mountainfold.app.core.train.EventKind
import com.mountainfold.app.core.train.ExamCategory
import com.mountainfold.app.core.train.ExtractionSim
import com.mountainfold.app.core.train.ExtractionSim.FilterInput
import com.mountainfold.app.core.train.ExtractionSim.ShotInput
import com.mountainfold.app.core.train.Recommendation
import com.mountainfold.app.core.train.SimKind
import com.mountainfold.app.core.train.Skill
import com.mountainfold.app.core.train.SkillTree
import com.mountainfold.app.core.train.TrainContent
import com.mountainfold.app.core.train.TrainEvent
import com.mountainfold.app.core.train.TrainProgress
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import kotlin.random.Random

private fun loadContent(): TrainContent =
    Json { ignoreUnknownKeys = true }.decodeFromString(TrainContent.serializer(), File("src/main/assets/train/content.json").readText())

class TrainContentTest {
    private val content = loadContent()

    @Test fun shipsTheWholeCurriculum() {
        assertEquals(26, content.lessons.size)
        assertEquals(26, content.lessons.map { it.id }.toSet().size)
        // Levels 1 to 8 teach, level 9 is earned through exams.
        for (level in 1..8) assertTrue("level $level has lessons", content.lessonsByLevel[level].orEmpty().isNotEmpty())
        assertEquals(Skill.entries.toSet(), content.lessons.map { it.skill }.toSet())
        for (lesson in content.lessons) {
            assertTrue(lesson.id, lesson.blocks.size >= 3 && lesson.objectives.isNotEmpty() && lesson.questions.size >= 3)
            for (q in lesson.questions + content.bank) {
                assertEquals(q.id, 0, q.correct)
                assertTrue(q.id, q.options.size in 3..4)
                for (lang in listOf("en", "fr", "es")) assertTrue(q.id, q.prompt[lang].isNotBlank() && q.why[lang].isNotBlank())
            }
        }
    }

    /** No lesson is passive: each one teaches, then validates, and most add a simulation or a real brew. */
    @Test fun lessonsAreInteractive() {
        assertTrue(content.lessons.count { it.sim != SimKind.NONE } >= 10)
        assertTrue(content.lessons.count { it.brewTask != null } >= 15)
        // Beyond the quiz every lesson ends with, at least four in five add a simulation or a real brew.
        assertTrue(content.lessons.count { it.sim != SimKind.NONE || it.brewTask != null } >= 20)
    }

    @Test fun everyExamCategoryHasEnoughQuestions() {
        for (c in ExamCategory.entries.filter { it != ExamCategory.TROUBLESHOOTING }) {
            val n = content.lessons.filter { it.skill in c.skills }.sumOf { it.questions.size } + content.bank.count { it.skill in c.skills }
            assertTrue("$c has $n questions", n >= 10)
        }
    }

    /** Copilot and brew patterns must always point at a lesson that exists. */
    @Test fun copilotAndBrewPatternsMapToRealLessons() {
        for (s in Symptom.entries) for (espresso in listOf(false, true)) {
            assertNotNull("$s", content.lesson(TrainProgress.lessonFor(s, espresso)))
        }
        val inputs = listOf(
            CopilotEngine.BrewInput(BrewMethod.V60, 15.0, 250.0, 92.0, 165, 180, "22"),
            CopilotEngine.BrewInput(BrewMethod.ESPRESSO, 18.0, 36.0, 93.0, 20, 28, "8"),
        )
        for (input in inputs) for (s in Symptom.entries) {
            val d = CopilotEngine.diagnose(input.copy(roastAgeDays = if (s == Symptom.FLAT) 70 else null), setOf(s))!!
            assertNotNull("$s ${input.method}", content.lesson(TrainProgress.lessonFor(d, input.method.isEspresso)))
        }
    }
}

class ExtractionSimTest {
    private val base = ExtractionSim.filter(FilterInput())

    @Test fun defaultRecipeIsBalanced() {
        assertEquals(ExtractionSim.Zone.BALANCED, base.zone)
        assertEquals(ExtractionSim.Strength.BALANCED, base.strength)
        assertEquals(180, base.timeS)
        assertFalse(base.uneven)
    }

    @Test fun finerIsSlowerAndExtractsMoreUntilTheBedChokes() {
        val finer = ExtractionSim.filter(FilterInput(grind = 70))
        assertTrue(finer.timeS > base.timeS && finer.extractionPct > base.extractionPct)
        val coarse = ExtractionSim.filter(FilterInput(grind = 20))
        assertTrue(coarse.timeS < base.timeS)
        assertEquals(ExtractionSim.Zone.UNDER, coarse.zone)
        val choked = ExtractionSim.filter(FilterInput(grind = 100))
        val edge = ExtractionSim.filter(FilterInput(grind = ExtractionSim.CHOKE_POINT))
        assertTrue(choked.uneven && choked.extractionPct < edge.extractionPct && choked.timeS > edge.timeS)
    }

    @Test fun temperatureAndAgitationRaiseExtraction() {
        assertTrue(ExtractionSim.filter(FilterInput(tempC = 97.0)).extractionPct > base.extractionPct)
        assertTrue(ExtractionSim.filter(FilterInput(tempC = 87.0)).extractionPct < base.extractionPct)
        assertTrue(ExtractionSim.filter(FilterInput(agitation = 2)).extractionPct > base.extractionPct)
    }

    /** The lesson's key idea: a longer ratio is weaker yet more extracted. */
    @Test fun ratioMovesStrengthAndExtractionInOppositeDirections() {
        val longer = ExtractionSim.filter(FilterInput(waterG = 300.0))
        assertTrue(longer.tdsPct < base.tdsPct && longer.extractionPct > base.extractionPct)
        val strongUnder = ExtractionSim.filter(FilterInput(grind = 25, doseG = 22.0, waterG = 250.0, tempC = 88.0))
        assertEquals(ExtractionSim.Zone.UNDER, strongUnder.zone)
        assertEquals(ExtractionSim.Strength.STRONG, strongUnder.strength)
    }

    @Test fun espressoShot() {
        val shot = ExtractionSim.shot(ShotInput())
        assertEquals(28, shot.timeS)
        assertEquals(ExtractionSim.Zone.BALANCED, shot.zone)
        assertTrue(ExtractionSim.shot(ShotInput(grind = 30)).timeS < 25)
        assertTrue(ExtractionSim.shot(ShotInput(yieldG = 50.0)).let { it.extractionPct > shot.extractionPct && it.tdsPct < shot.tdsPct })
        val channeled = ExtractionSim.shot(ShotInput(channeling = true))
        assertTrue(channeled.uneven && channeled.timeS < shot.timeS && channeled.extractionPct < shot.extractionPct)
    }

    @Test fun extractionYieldFormulaAndMilkPhases() {
        assertEquals(19.95, ExtractionSim.extractionYield(15.0, 220.0, 1.36)!!, 0.01)
        assertNull(ExtractionSim.extractionYield(0.0, 220.0, 1.36))
        assertEquals(ExtractionSim.MilkPhase.STRETCH, ExtractionSim.milkPhase(20))
        assertEquals(ExtractionSim.MilkPhase.ROLL, ExtractionSim.milkPhase(45))
        assertEquals(ExtractionSim.MilkPhase.READY, ExtractionSim.milkPhase(60))
        assertEquals(ExtractionSim.MilkPhase.TOO_HOT, ExtractionSim.milkPhase(75))
    }
}

class DialInGeneratorTest {
    /** Over many scenarios: the right answer is the Copilot's, and no wrong answer is defensible. */
    @Test fun scenariosAgreeWithTheCopilotAndHaveCleanDistractors() {
        val random = Random(42)
        repeat(600) { n ->
            val s = DialInGenerator.generate(random, espresso = n % 2 == 0)
            assertEquals(4, s.options.size)
            assertEquals(4, s.options.toSet().size)
            assertEquals(CopilotEngine.diagnose(s.input, setOf(s.symptom))!!.change, s.correct)
            assertTrue("${s.symptom}: ${s.correct}", s.correct in DialInGenerator.acceptable(s.symptom))
            for (wrong in s.options.drop(1)) assertFalse("${s.symptom}: $wrong", wrong in DialInGenerator.acceptable(s.symptom))
        }
    }

    @Test fun sessionsAreVariedAndRepeatableBySeed() {
        val a = DialInGenerator.session(Random(7), espresso = false, count = 5)
        val b = DialInGenerator.session(Random(7), espresso = false, count = 5)
        assertEquals(5, a.size)
        assertEquals(a.map { it.symptom to it.options }, b.map { it.symptom to it.options })
        assertEquals(5, a.map { "${it.symptom}/${it.correct}" }.toSet().size)
        assertTrue(a.none { it.input.method.isEspresso })
        assertTrue(DialInGenerator.session(Random(7), espresso = true, count = 5).all { it.input.method.isEspresso })
    }

    /** The example from the brief: 18 g in, 36 g out, 18 seconds, very sour. Answer: grind finer. */
    @Test fun briefExample() {
        val s = DialInGenerator.build(Random(1), CopilotEngine.BrewInput(BrewMethod.ESPRESSO, 18.0, 36.0, 93.0, 18, 28, ""), Symptom.SOUR)
        assertEquals(CopilotEngine.ChangeKind.GRIND_FINER, s.correct)
    }
}

class TrainProgressTest {
    private val content = loadContent()
    private val byLevel = content.lessonsByLevel
    private val day = 86_400_000L
    private fun at(d: Long) = d * day + 3_600_000L
    private fun lesson(id: String, d: Long, passed: Boolean = true, breakdown: String = "") =
        TrainEvent(at(d), EventKind.LESSON, id, if (passed) 3 else 1, 3, if (passed) 75 else 0, passed, breakdown)

    @Test fun emptyHistoryIsATrainee() {
        val p = TrainProgress.compute(emptyList(), byLevel, today = 100)
        assertEquals(0, p.xp); assertEquals(0, p.streak); assertEquals(0, p.percent)
        assertEquals(1, p.currentLevel); assertEquals(BaristaTitle.TRAINEE, p.title)
        assertTrue(p.levels[0].unlocked); assertFalse(p.levels[1].unlocked)
        assertTrue(p.scores.all { it.percent == null })
        assertFalse(p.dailyDone)
    }

    @Test fun levelsUnlockInOrderFromValidatedWork() {
        val level1 = byLevel[1]!!.map { lesson(it, 100) }
        val p1 = TrainProgress.compute(level1.dropLast(1), byLevel, 100)
        assertEquals(1, p1.currentLevel); assertFalse(p1.levels[1].unlocked)
        val p2 = TrainProgress.compute(level1, byLevel, 100)
        assertEquals(2, p2.currentLevel); assertEquals(1, p2.levelsComplete)
        assertEquals(BaristaTitle.JUNIOR, p2.title); assertTrue(p2.levels[1].unlocked)
        // A failed attempt validates nothing.
        val failed = TrainProgress.compute(listOf(lesson("ratio", 100, passed = false)), byLevel, 100)
        assertFalse("ratio" in failed.validated)
    }

    @Test fun testingOutValidatesAWholeLevelAndGatesNeedPractice() {
        val tests = (1..4).map { TrainEvent(at(100), EventKind.LEVEL_TEST, SkillTree.levelRef(it), 5, 6, 50, true) }
        val p = TrainProgress.compute(tests, byLevel, 100)
        assertTrue(p.validated.containsAll(byLevel[1]!! + byLevel[4]!!))
        // Level 4 also asks for a real dial-in session.
        assertEquals(3, p.levelsComplete); assertEquals(4, p.currentLevel)
        val withDialIn = tests + TrainEvent(at(100), EventKind.DIAL_IN, SkillTree.DIAL_IN_FILTER, 4, 5, 25, true)
        assertEquals(4, TrainProgress.compute(withDialIn, byLevel, 100).levelsComplete)
        assertEquals(BaristaTitle.BARISTA, TrainProgress.compute(withDialIn, byLevel, 100).title)
    }

    @Test fun passMarksAndXp() {
        assertTrue(TrainProgress.passed(EventKind.LESSON, 2, 3)); assertFalse(TrainProgress.passed(EventKind.LESSON, 1, 3))
        assertTrue(TrainProgress.passed(EventKind.DIAL_IN, 4, 5)); assertFalse(TrainProgress.passed(EventKind.DIAL_IN, 3, 5))
        assertTrue(TrainProgress.passed(EventKind.EXAM, 7, 10)); assertFalse(TrainProgress.passed(EventKind.EXAM, 6, 10))
        assertEquals(75, TrainProgress.xpFor(EventKind.LESSON, true, firstValidation = true))
        assertEquals(25, TrainProgress.xpFor(EventKind.LESSON, true, firstValidation = false))
        assertEquals(0, TrainProgress.xpFor(EventKind.LESSON, false, firstValidation = true))
        assertEquals(100, TrainProgress.xpFor(EventKind.BREW_CHALLENGE, true, false))
        assertEquals(20, TrainProgress.xpFor(EventKind.TASTING_LOG, true, false))
        assertEquals(250, TrainProgress.xpFor(EventKind.STREAK_BONUS, true, false))
    }

    @Test fun streakCountsConsecutiveDays() {
        val events = listOf(98L, 99L, 100L).map { lesson("ratio", it) }
        assertEquals(3, TrainProgress.compute(events, byLevel, 100).streak)
        assertEquals(3, TrainProgress.compute(events, byLevel, 101).streak)   // still alive the next morning
        assertEquals(0, TrainProgress.compute(events, byLevel, 102).streak)   // broken after a missed day
        assertEquals(1, TrainProgress.compute(listOf(lesson("ratio", 96), lesson("ratio", 100)), byLevel, 100).streak)
    }

    @Test fun skillScoresComeFromRecentAnswersOnly() {
        val enc = Breakdown.encode(listOf(Skill.ESPRESSO to true, Skill.ESPRESSO to false, Skill.SENSORY to true))
        assertEquals(listOf(Triple(Skill.ESPRESSO, 1, 2), Triple(Skill.SENSORY, 1, 1)), Breakdown.decode(enc))
        val old = (1..10).map { TrainEvent(at(it.toLong()), EventKind.EXAM, "ESPRESSO", 0, 3, 0, false, "ESPRESSO:0/3") }
        val recent = (11..20).map { TrainEvent(at(it.toLong()), EventKind.EXAM, "ESPRESSO", 3, 3, 0, true, "ESPRESSO:3/3") }
        val scores = TrainProgress.scores(old + recent).associateBy { it.skill }
        assertEquals(100, scores[Skill.ESPRESSO]!!.percent)   // the last 30 answers are all correct
        assertNull(scores[Skill.MILK]!!.percent)
        assertEquals(50, TrainProgress.scores(listOf(lesson("x", 1, breakdown = "MILK:1/2"))).first { it.skill == Skill.MILK }.percent)
    }

    @Test fun repeatedFaultInRealBrewsBecomesATrainingOpportunity() {
        fun brew(i: Long, vararg s: Symptom, espresso: Boolean = false) = BrewSignal(i, espresso, s.toSet())
        assertNull(TrainProgress.opportunity(listOf(brew(1, Symptom.SOUR), brew(2, Symptom.SOUR), brew(3))))
        val o = TrainProgress.opportunity(listOf(brew(1, Symptom.SOUR), brew(2, Symptom.SOUR), brew(3, Symptom.BITTER), brew(4, Symptom.SOUR)))!!
        assertEquals(Symptom.SOUR, o.symptom); assertEquals(3, o.count); assertEquals("extraction", o.lessonId)
        val shots = (1L..3L).map { brew(it, Symptom.SOUR, espresso = true) }
        assertEquals("espresso_grind_time", TrainProgress.opportunity(shots)!!.lessonId)
    }

    @Test fun recommendationsPutBrewPatternsAndWeakSkillsFirst() {
        val empty = TrainProgress.compute(emptyList(), byLevel, 100)
        val first = TrainProgress.recommendations(empty, content.lessons, null, prefersEspresso = false)
        assertEquals(3, first.size)
        assertEquals(Recommendation.LessonRec(byLevel[1]!!.first(), Recommendation.Reason.NEXT_STEP), first.first())

        val opportunity = TrainProgress.opportunity((1L..3L).map { BrewSignal(it, false, setOf(Symptom.SOUR)) })
        val withPattern = TrainProgress.recommendations(empty, content.lessons, opportunity, false)
        assertEquals(Recommendation.LessonRec("extraction", Recommendation.Reason.BREW_PATTERN), withPattern.first())

        val weakEspresso = TrainProgress.compute(listOf(TrainEvent(at(100), EventKind.EXAM, "ESPRESSO", 2, 6, 0, false, "ESPRESSO:2/6")), byLevel, 100)
        val recs = TrainProgress.recommendations(weakEspresso, content.lessons, null, false)
        assertEquals(Recommendation.Reason.WEAK_SKILL, recs.first().reason)
        assertEquals(Skill.ESPRESSO, content.lesson((recs.first() as Recommendation.LessonRec).lessonId)!!.skill)
        assertEquals(recs.size, recs.toSet().size)
    }
}
