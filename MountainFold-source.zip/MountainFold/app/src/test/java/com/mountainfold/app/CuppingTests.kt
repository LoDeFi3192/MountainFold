package com.mountainfold.app

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.mountainfold.app.core.cupping.CuppingCatalog
import com.mountainfold.app.core.cupping.CuppingCsv
import com.mountainfold.app.core.cupping.CuppingFormat
import com.mountainfold.app.core.cupping.CuppingTimer
import com.mountainfold.app.core.cupping.FlavorWheel
import com.mountainfold.app.data.Repository
import com.mountainfold.app.data.db.AppDatabase
import com.mountainfold.app.data.db.CuppingCoffee
import com.mountainfold.app.data.db.CuppingSession
import com.mountainfold.app.data.db.LabRecipe
import com.mountainfold.app.data.prefs.SettingsStore
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

/** Pure rules of the Toulouse Cupping port, checked against the behaviour of the original web app. */
class CuppingLogicTest {

    @Test
    fun sixMinuteTimerRingsAtTheCrustThenAtTheEnd() {
        var now = 0L
        val t = CuppingTimer { now }
        t.start(6)
        assertEquals(360, t.state.remainingS)
        assertEquals(CuppingTimer.Phase.CRUST, t.state.phase)
        now = 239_900
        assertTrue(t.tick().isEmpty())
        assertEquals(121, t.state.remainingS)
        now = 240_000
        assertEquals(listOf(CuppingTimer.Alert.CRUST), t.tick())
        assertEquals(CuppingTimer.Phase.TASTE, t.state.phase)
        now = 250_000
        assertTrue("the crust rings once", t.tick().isEmpty())
        now = 360_000
        assertEquals(listOf(CuppingTimer.Alert.FINISHED), t.tick())
        assertFalse(t.state.running)
        assertEquals(CuppingTimer.Phase.FINISHED, t.state.phase)
        assertEquals(1f, t.state.progress, 0f)
        assertTrue(t.tick().isEmpty())
    }

    @Test
    fun fourMinuteTimerHasNoCrustAlertAndPausesExactly() {
        var now = 0L
        val t = CuppingTimer { now }
        assertEquals(CuppingTimer.Phase.PAUSED, t.state.phase)
        t.start(4)
        assertEquals(CuppingTimer.Phase.TASTE, t.state.phase)
        now = 100_000
        t.tick()
        t.togglePause()
        assertFalse(t.state.running)
        assertEquals(140, t.state.remainingS)
        now = 500_000 // time on pause does not count
        assertTrue(t.tick().isEmpty())
        t.togglePause()
        now = 639_000
        assertTrue(t.tick().isEmpty())
        assertEquals(1, t.state.remainingS)
        now = 640_000
        assertEquals(listOf(CuppingTimer.Alert.FINISHED), t.tick())
        t.togglePause()
        assertFalse("resuming at zero does nothing", t.state.running)
        t.reset()
        assertEquals(240, t.state.remainingS)
        assertFalse(t.state.running)
        assertEquals(CuppingTimer.Phase.PAUSED, t.state.phase)
    }

    @Test
    fun catalogMatchesTheOriginal() {
        val items = CuppingCatalog.AROMA_CATEGORIES.flatMap { it.items }
        assertEquals(6, CuppingCatalog.AROMA_CATEGORIES.size)
        assertEquals(44, items.size)
        assertEquals(items.size, items.map { it.key }.toSet().size)
        assertTrue("every aroma has its own colour", items.all { it.key in CuppingCatalog.ITEM_COLOR_OVERRIDES })
        assertEquals("Lemon", CuppingCatalog.label("Citron", "en"))
        assertEquals("Limón", CuppingCatalog.label("Citron", "es"))
        assertEquals("Citron", CuppingCatalog.label("Citron", "fr"))
        assertEquals("Washed", CuppingCatalog.label("Lavé", "en"))
        assertEquals("unknown", CuppingCatalog.label("unknown", "en"))
        assertEquals(0xFF1E1B18, CuppingCatalog.contrastOn(0xFFF5E452))
        assertEquals(0xFFFFFFFF, CuppingCatalog.contrastOn(0xFF462920))
        assertEquals(0xFFE72D37, CuppingCatalog.noteColor("Cerise"))
        assertNull(CuppingCatalog.noteColor("nope"))
        assertEquals(listOf(16, 15, 14, 12, 10, 16), CuppingCatalog.LabMethod.entries.map { it.defaultRatio })
        assertEquals(5, CuppingCatalog.PROCESSING_METHODS.size)
        assertEquals(8, CuppingCatalog.BODY_TYPES.size)
    }

    @Test
    fun wheelPicksTheSliceUnderThePointer() {
        val step = FlavorWheel.step
        assertEquals(360f / 44, step, 1e-4f)
        assertEquals("Citron", FlavorWheel.slices[FlavorWheel.activeIndex(0f)].key)
        assertEquals("Orange", FlavorWheel.slices[FlavorWheel.activeIndex(-step * 1.5f)].key)
        assertEquals("Noisette grillée", FlavorWheel.slices[FlavorWheel.activeIndex(step * 0.5f)].key)
        assertEquals(FlavorWheel.activeIndex(10f), FlavorWheel.activeIndex(370f))
        for (i in listOf(0, 7, 20, 43)) {
            for (pointer in listOf(0f, 270f)) {
                val r = FlavorWheel.rotationFor(i, 1234f, pointer)
                assertEquals(i, FlavorWheel.activeIndex(r, pointer))
                assertTrue(kotlin.math.abs(r - 1234f) <= 180f + step)
            }
        }
        assertEquals(20f, FlavorWheel.delta(350f, 10f), 1e-4f)
        assertEquals(-20f, FlavorWheel.delta(10f, 350f), 1e-4f)
    }

    @Test
    fun numbersPrintLikeTheOriginal() {
        assertEquals("8.00", CuppingFormat.fixed2(8.0))
        assertEquals("8.13", CuppingFormat.fixed2(8.125))
        assertEquals("8", CuppingFormat.jsNumber(8.0))
        assertEquals("8.25", CuppingFormat.jsNumber(8.25))
        assertEquals("03:15", CuppingFormat.clock(195))
        assertEquals("120:00", CuppingFormat.clock(7200))
        assertEquals(320, CuppingFormat.water(20.0, 16.0))
        assertEquals(248, CuppingFormat.water(15.5, 16.0))
        assertEquals(0.0, CuppingFormat.parse("")!!, 0.0)
        assertEquals(1.5, CuppingFormat.parse("1,5")!!, 0.0)
        assertNull(CuppingFormat.parse("abc"))
    }

    @Test
    fun scoreAndNotesFollowTheOriginalRules() {
        val c = CuppingCoffee(
            id = "a", fragranceScore = 8.5, flavorScore = 8.25, aftertasteScore = 7.75, acidityScore = 8.0, bodyScore = 7.5, balanceScore = 8.0,
            fragranceNotes = listOf("Citron", "Miel"), flavorNotes = listOf("Miel", "Cacao"),
        )
        assertEquals(8.0, c.finalScore, 1e-9)
        assertEquals(listOf("Citron", "Miel", "Cacao"), c.uniqueNotes)
    }

    @Test
    fun csvHasTheOriginalColumnsAndEscapesText() {
        val a = CuppingCoffee(
            id = "a", name = "Guji \"lot 7\"", isFavorite = true, process = "Lavé", fragranceScore = 8.25, fragranceNotes = listOf("Citron"),
            flavorNotes = listOf("Citron", "Miel"), comments = "Clean, sweet",
        )
        val b = CuppingCoffee(id = "b", name = "Huila")
        val headers = listOf("Nom du café", "Fav", "Procédé / Process", "Score", "Notes", "Fragrance / Arôme", "Saveur", "Arrière-goût", "Acidité", "Corps", "Équilibre", "Commentaires")
        val csv = CuppingCsv.build(listOf(a, b), headers, "Oui", "Non") { CuppingCatalog.label(it, "fr") }
        val lines = csv.split('\n')
        assertEquals(3, lines.size)
        assertEquals(headers.joinToString(","), lines[0])
        assertEquals("\"Guji \"\"lot 7\"\"\",Oui,Lavé,8.04,\"Citron, Miel\",8.25,8,8,8,8,8,\"Clean, sweet\"", lines[1])
        assertEquals("\"Huila\",Non,,8.00,\"\",8,8,8,8,8,8,\"\"", lines[2])
        val en = CuppingCsv.build(listOf(a), headers, "Yes", "No") { CuppingCatalog.label(it, "en") }
        assertTrue(en.contains("Yes,Washed,8.04,\"Lemon, Honey\""))
    }
}

/** Storage of sessions, coffees and Lab recipes, and their trip through a backup file. */
@RunWith(AndroidJUnit4::class)
@Config(sdk = [35])
class CuppingDataTest {
    @Test
    fun sessionsSaveCascadeAndSurviveABackup() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
        val repo = Repository(db, SettingsStore(context))
        val s1 = CuppingSession(id = "s1", createdAt = 1, name = "Morning", location = "Labo", dateIso = "2026-10-13", originNotes = "Ethiopia")
        val s2 = CuppingSession(id = "s2", createdAt = 2, name = "Evening", dateIso = "2026-10-14")
        repo.saveCuppingSession(
            s1,
            listOf(
                CuppingCoffee(id = "c1", name = "Guji", fragranceNotes = listOf("Citron", "Jasmin"), isLocked = true, isFavorite = true),
                CuppingCoffee(id = "c2", name = "Huila", flavorScore = 9.25),
            ),
        )
        repo.saveCuppingSession(s2, listOf(CuppingCoffee(id = "c3", name = "Kenya")))
        repo.saveLabRecipe(LabRecipe(id = "r1", timestamp = 3, method = "chemex", coffeeWeight = 30.0, ratio = 15.0, waterWeight = 450, grindSize = "Sel fin", totalTime = 245, rating = 8.5, notes = "Floral"))

        val loaded = repo.cuppingCoffeesOf("s1")
        assertEquals(listOf("Guji", "Huila"), loaded.map { it.name })
        assertEquals(listOf(0, 1), loaded.map { it.position })
        assertEquals(listOf("Citron", "Jasmin"), loaded[0].fragranceNotes)
        assertTrue(loaded[0].isLocked && loaded[0].isFavorite)

        // Removing a coffee in the UI and saving removes it from the table.
        repo.saveCuppingSession(s1, listOf(loaded[1]))
        assertEquals(listOf("Huila"), repo.cuppingCoffeesOf("s1").map { it.name })
        assertEquals("s2", repo.latestCuppingSession()!!.id)

        val json = repo.exportJson()
        assertTrue(json.contains("\"cuppingSessions\"") && json.contains("\"labRecipes\""))

        repo.deleteCuppingSession("s2")
        assertTrue("coffees go with their session", repo.cuppingCoffeesOf("s2").isEmpty())

        repo.importJson(json)
        assertEquals(setOf("s1", "s2"), db.cupping().allSessions().map { it.id }.toSet())
        assertEquals(listOf("Kenya"), repo.cuppingCoffeesOf("s2").map { it.name })
        assertEquals(9.25, repo.cuppingCoffeesOf("s1").single().flavorScore, 0.0)
        val lab = db.cupping().allLab().single()
        assertEquals(450, lab.waterWeight)
        assertEquals("Sel fin", lab.grindSize)
        assertEquals("Labo", repo.cuppingSession("s1")!!.location)

        // A backup made before 1.2.0 has no cupping data and still imports.
        repo.importJson("""{"app":"MountainFold","version":1,"coffees":[],"recipes":[],"brews":[]}""")
        assertTrue(db.cupping().allSessions().isEmpty() && db.cupping().allLab().isEmpty())

        repo.importJson(json)
        repo.resetAll()
        assertTrue(db.cupping().allSessions().isEmpty() && db.cupping().allCoffees().isEmpty() && db.cupping().allLab().isEmpty())
        db.close()
    }
}
