package com.mountainfold.app

import com.mountainfold.app.core.engine.TimerEngine
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.BrewStep
import com.mountainfold.app.core.model.SessionRecipe
import com.mountainfold.app.core.model.StepType
import com.mountainfold.app.core.weight.ManualWeightProvider
import com.mountainfold.app.data.session.BrewFeedback
import com.mountainfold.app.data.session.BrewSessionManager
import com.mountainfold.app.data.session.PersistedSession
import com.mountainfold.app.data.session.SessionPersistence
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.cancel
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runCurrent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class BrewSessionManagerTest {
    private var mono = 5_000L
    private var wall = 1_700_000_000_000L
    private val events = mutableListOf<String>()
    private var autoStop = false

    private val recipe = SessionRecipe(
        recipeId = 1, name = "Classic V60", method = BrewMethod.V60, doseG = 15.0, waterG = 250.0, tempC = 93.0,
        steps = listOf(
            BrewStep("Bloom", StepType.BLOOM, 0, 45.0), BrewStep("Pour 1", StepType.POUR, 45, 120.0),
            BrewStep("Pour 2", StepType.POUR, 80, 190.0), BrewStep("Final", StepType.POUR, 130, 250.0),
        ),
        targetTimeS = 180,
    )

    private val feedback = object : BrewFeedback {
        override fun onStep(step: BrewStep, index: Int, recipe: SessionRecipe) { events += "step:${step.label}" }
        override fun onTarget(recipe: SessionRecipe) { events += "target" }
    }

    private class MemoryPersistence : SessionPersistence {
        var saved: PersistedSession? = null
        override fun save(snapshot: PersistedSession?) { saved = snapshot }
        override fun load(): PersistedSession? = saved
    }

    private fun advance(seconds: Int) { mono += seconds * 1000L; wall += seconds * 1000L }

    private fun manager(scope: TestScope, persistence: SessionPersistence? = null) = BrewSessionManager(
        scope = scope, timer = TimerEngine { mono }, weight = ManualWeightProvider(), feedback = feedback,
        autoStopAtTarget = { autoStop }, persistence = persistence, wallClock = { wall },
    )

    @Test fun stepsFollowTheClockAndFireFeedbackOnce() {
        val scope = TestScope(StandardTestDispatcher())
        val m = manager(scope)
        m.load(recipe); m.start(); scope.runCurrent()
        advance(50); m.tick(); m.tick()
        assertEquals(1, m.currentStepIndex())
        advance(40); m.tick()
        assertEquals(2, m.currentStepIndex())
        advance(100); m.tick(); m.tick()
        assertEquals(listOf("step:Pour 1", "step:Pour 2", "step:Final", "target"), events)
        assertTrue(m.state.value.targetReached)
        assertFalse(m.state.value.finished)
        scope.cancel()
    }

    @Test fun nextStepAndPlusTenReshapeTheSchedule() {
        val scope = TestScope(StandardTestDispatcher())
        val m = manager(scope)
        m.load(recipe); m.start(); scope.runCurrent()
        advance(30); m.nextStep()
        assertEquals(1, m.currentStepIndex())
        assertEquals(listOf(0, 30, 65, 115), m.state.value.recipe!!.steps.map { it.startS })
        assertEquals(165, m.state.value.recipe!!.targetTimeS)
        m.extend(10)
        assertEquals(listOf(0, 30, 75, 125), m.state.value.recipe!!.steps.map { it.startS })
        m.reset()
        assertEquals(recipe, m.state.value.recipe)
        assertEquals(0, m.timer.elapsedMs())
        scope.cancel()
    }

    @Test fun autoStopFinishesAtTarget() {
        autoStop = true
        val scope = TestScope(StandardTestDispatcher())
        val m = manager(scope)
        m.load(recipe); m.start(); scope.runCurrent()
        advance(181); m.tick()
        assertTrue(m.state.value.finished)
        assertFalse(m.timer.state.value.running)
        assertEquals(181_000, m.timer.elapsedMs())
        scope.cancel()
    }

    @Test fun adjustRescalesStepTargets() {
        val scope = TestScope(StandardTestDispatcher())
        val m = manager(scope)
        m.load(recipe); m.adjust(30.0, 500.0)
        assertEquals(listOf(90.0, 240.0, 380.0, 500.0), m.state.value.recipe!!.steps.map { it.targetWaterG })
        scope.cancel()
    }

    /** Process death in the middle of a brew: the next process resumes with the right time, step and weight. */
    @Test fun runningBrewSurvivesProcessDeath() {
        val store = MemoryPersistence()
        val scope1 = TestScope(StandardTestDispatcher())
        val first = manager(scope1, store)
        first.load(recipe); first.start(); scope1.runCurrent()
        advance(50); first.addWater(120.0); first.setNotes("fast bloom")
        scope1.cancel()

        advance(40)          // process is gone for 40 s of real time
        mono = 77L           // and the monotonic clock of the new process is unrelated

        val scope2 = TestScope(StandardTestDispatcher())
        val second = manager(scope2, store)
        assertTrue(second.timer.state.value.running)
        assertEquals(90_000, second.timer.elapsedMs())
        assertEquals(2, second.currentStepIndex())
        assertEquals(120.0, second.weight.weightG.value, 0.0)
        assertEquals("fast bloom", second.state.value.notes)
        scope2.cancel()
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class AbandonedBrewTest {
    @Test fun brewForgottenOvernightComesBackPaused() {
        var wall = 1_700_000_000_000L
        var mono = 0L
        val store = object : SessionPersistence {
            var saved: PersistedSession? = null
            override fun save(snapshot: PersistedSession?) { saved = snapshot }
            override fun load(): PersistedSession? = saved
        }
        val recipe = SessionRecipe(name = "V60", method = BrewMethod.V60, doseG = 15.0, waterG = 250.0, targetTimeS = 180)
        fun make(scope: TestScope) = BrewSessionManager(
            scope, TimerEngine { mono }, ManualWeightProvider(), object : BrewFeedback {}, { false }, store, { wall },
        )
        val s1 = TestScope(StandardTestDispatcher())
        val first = make(s1)
        first.load(recipe); first.start(); mono += 60_000; wall += 60_000; first.addWater(100.0)
        s1.cancel()
        wall += 9 * 3_600_000L
        val s2 = TestScope(StandardTestDispatcher())
        val second = make(s2)
        assertFalse(second.timer.state.value.running)
        assertEquals(60_000, second.timer.elapsedMs())
        assertEquals(recipe.name, second.state.value.recipe!!.name)
        s2.cancel()
    }
}
