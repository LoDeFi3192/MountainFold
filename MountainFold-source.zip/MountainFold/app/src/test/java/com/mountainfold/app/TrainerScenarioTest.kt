package com.mountainfold.app

import android.content.res.Configuration
import android.os.Looper
import androidx.activity.compose.LocalActivityResultRegistryOwner
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.github.takahirom.roborazzi.captureRoboImage
import com.mountainfold.app.core.fold.FoldState
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.fold.Posture
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.Symptom
import com.mountainfold.app.core.model.ThemeMode
import com.mountainfold.app.core.train.BaristaTitle
import com.mountainfold.app.core.train.EventKind
import com.mountainfold.app.core.train.ExamCategory
import com.mountainfold.app.data.db.Brew
import com.mountainfold.app.data.db.Coffee
import com.mountainfold.app.data.prefs.LanguageStore
import com.mountainfold.app.ui.CoffeeDraft
import com.mountainfold.app.ui.MainViewModel
import com.mountainfold.app.ui.MountainFoldRoot
import com.mountainfold.app.ui.Overlay
import com.mountainfold.app.ui.Tab
import com.mountainfold.app.ui.TrainScreen
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowSystemClock
import java.io.File
import java.time.Duration
import java.util.Locale
import kotlin.random.Random

/**
 * Drives the Barista Trainer inside the real app: lesson, simulation, quiz, dial-in, exam,
 * the brew challenge loop and the Copilot link, across Closed, Open and Flex.
 */
@RunWith(AndroidJUnit4::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [35], qualifiers = "w1000dp-h1100dp-xhdpi")
class TrainerScenarioTest {
    @get:Rule val rule = createComposeRule()

    private data class Device(val w: Int, val h: Int, val posture: Posture, val hinge: HingeInfo? = null)

    private val closed = Device(384, 880, Posture.CLOSED)
    private val open = Device(880, 980, Posture.OPEN, HingeInfo(880, 0, 880, 1960, vertical = true, halfOpened = false))
    private val flex = Device(880, 980, Posture.FLEX, HingeInfo(0, 980, 1760, 980, vertical = false, halfOpened = true))

    private var device by mutableStateOf(closed)
    private var language by mutableStateOf("en")
    private val shots = File("build/shots").apply { mkdirs() }

    private fun idle() {
        shadowOf(Looper.getMainLooper()).idle()
        rule.mainClock.advanceTimeBy(600)
        rule.waitForIdle()
    }

    private fun await(what: String, condition: () -> Boolean) {
        val end = System.currentTimeMillis() + 20_000
        while (!condition()) {
            idle()
            Thread.sleep(20)
            check(System.currentTimeMillis() < end) { "Timed out waiting for $what" }
        }
        idle()
    }

    private fun shot(name: String) {
        idle()
        rule.onNodeWithTag("device").captureRoboImage(File(shots, "$name.png").path)
    }

    private fun text(t: String) = rule.onAllNodesWithText(t, substring = true, ignoreCase = true).fetchSemanticsNodes().isNotEmpty()

    @Test
    fun trainerWorksInEveryPostureAndFeedsOnRealBrews() {
        val app = ApplicationProvider.getApplicationContext<MountainFoldApp>()
        val vm = MainViewModel(app)
        val session = vm.session
        fun progress() = vm.progressOf(vm.trainEvents.value)
        fun kinds() = vm.trainEvents.value.map { it.kind }

        /** Answers the running quiz. [wrongAt] lists question indexes to miss on purpose. */
        fun answerAll(wrongAt: Set<Int> = emptySet()) {
            while (true) {
                val run = vm.quiz!!
                val item = run.current
                vm.answer(if (run.index in wrongAt) (item.correct + 1) % item.options.size else item.correct)
                idle()
                val last = run.isLast
                vm.nextQuestion()
                if (last) break
            }
        }

        rule.setContent {
            val base = LocalContext.current
            val registryOwner = checkNotNull(LocalActivityResultRegistryOwner.current)
            val localized = remember(language) {
                val config = Configuration(base.resources.configuration)
                config.setLocale(Locale.forLanguageTag(language))
                base.createConfigurationContext(config)
            }
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.align(Alignment.TopStart).requiredSize(device.w.dp, device.h.dp).testTag("device")) {
                    CompositionLocalProvider(LocalContext provides localized, LocalActivityResultRegistryOwner provides registryOwner) {
                        MountainFoldRoot(vm, foldState = { FoldState(device.posture, device.hinge) })
                    }
                }
            }
        }

        await("settings") { vm.settings.value != null }
        vm.setSettings { it.copy(dynamicColor = false) }
        vm.completeOnboarding(listOf(BrewMethod.V60, BrewMethod.ESPRESSO), "Comandante C40")
        await("onboarding") { vm.settings.value!!.onboarded && session.state.value.recipe != null && vm.recipes.value.size == 10 }
        vm.newCoffee()
        vm.coffeeDraft = CoffeeDraft(Coffee(name = "Ethiopia Guji", country = "Ethiopia", process = "Washed"))
        vm.saveCoffeeDraft()
        await("coffee") { vm.coffees.value.size == 1 }
        assertEquals(26, vm.train.lessons.size)

        // ---- Train home: a trainee with nothing done ---------------------------------------------
        vm.selectTab(Tab.TRAIN)
        shot("t01_closed_train_home")
        assertTrue(text("Barista Trainer") && text("Build better coffee skills"))
        assertEquals(1, progress().currentLevel)
        assertEquals(BaristaTitle.TRAINEE, progress().title)
        device = open
        shot("t02_open_train_home")

        // ---- Daily challenge (CLOSED = quick quiz) -------------------------------------------------
        device = closed
        vm.startDaily()
        assertEquals(1, vm.quiz!!.items.size)
        shot("t03_closed_daily_question")
        vm.answer(vm.quiz!!.current.correct)
        shot("t04_closed_daily_feedback")
        assertTrue(text("Correct."))
        vm.nextQuestion()
        await("daily saved") { EventKind.DAILY.name in kinds() }
        assertTrue(progress().dailyDone)
        assertEquals(25, progress().xp)
        assertEquals(1, progress().streak)
        shot("t05_closed_daily_result")
        vm.closeResult()
        assertEquals(TrainScreen.Home, vm.trainScreen)

        // ---- Lesson with a simulation, across postures ----------------------------------------------
        vm.openLesson("ratio")
        shot("t06_closed_lesson_theory")
        assertTrue(text("Brew ratio"))
        repeat(3) { vm.lessonPage(1) }
        assertEquals(3, vm.lessonRun!!.page)
        vm.filterSim = vm.filterSim.copy(waterG = 300.0)
        shot("t07_closed_lesson_sim")
        device = flex
        idle()
        assertEquals("the page survives the posture change", 3, vm.lessonRun!!.page)
        assertEquals(300.0, vm.filterSim.waterG, 0.0)
        shot("t08_flex_lesson_sim")
        vm.lessonPage(-3)
        shot("t09_flex_lesson_theory")
        device = open
        vm.filterSim = vm.filterSim.copy(waterG = 250.0, grind = 95)
        shot("t10_open_lesson")
        assertTrue(text("The bed choked"))

        // ---- Validation quiz: OPEN -> FLEX -> CLOSED -> OPEN mid-question ----------------------------
        vm.startLessonQuiz("ratio")
        shot("t11_open_lesson_quiz")
        val first = vm.quiz!!
        vm.answer(first.current.correct)
        device = flex
        idle()
        assertEquals(first.current.correct, vm.quiz!!.selected)
        assertEquals(0, vm.quiz!!.index)
        shot("t12_flex_quiz_feedback")
        device = closed
        shot("t13_closed_quiz_feedback")
        device = open
        vm.nextQuestion()
        answerAll()
        await("lesson saved") { EventKind.LESSON.name in kinds() }
        assertTrue("ratio" in progress().validated)
        assertEquals(25 + 75, progress().xp)
        assertTrue(vm.quizResult!!.lessonValidated)
        shot("t14_open_lesson_result")
        assertTrue(text("Brew challenge"))

        // ---- LEARN -> BREW -> TASTE -> LOG: the brew challenge -------------------------------------
        vm.acceptBrewChallenge("ratio")
        await("challenge pending") { vm.settings.value!!.pendingBrewChallenge == "ratio" }
        assertEquals(Tab.BREW, vm.tab)
        session.start()
        ShadowSystemClock.advanceBy(Duration.ofSeconds(175)); idle()
        session.finish()
        await("log sheet") { vm.overlays.lastOrNull() == Overlay.LogBrew && vm.logDraft != null }
        vm.logDraft = vm.logDraft!!.copy(rating = 4, sweetness = 4, balance = 4)
        vm.saveLog()
        await("challenge recorded") { EventKind.BREW_CHALLENGE.name in kinds() && EventKind.TASTING_LOG.name in kinds() }
        await("challenge cleared") { vm.settings.value!!.pendingBrewChallenge == null }
        assertEquals(25 + 75 + 100 + 20, progress().xp)

        // ---- Testing out of level 1, then the tree --------------------------------------------------
        vm.selectTab(Tab.TRAIN)
        vm.startLevelTest(1)
        assertEquals(6, vm.quiz!!.items.size)
        answerAll(wrongAt = setOf(2))
        await("level test saved") { EventKind.LEVEL_TEST.name in kinds() }
        vm.closeResult()
        assertEquals(2, progress().currentLevel)
        assertEquals(BaristaTitle.JUNIOR, progress().title)
        vm.openTrain(TrainScreen.Tree)
        shot("t15_open_skill_tree")
        device = closed
        shot("t16_closed_skill_tree")
        vm.back()
        vm.openTrain(TrainScreen.School)
        shot("t17_closed_school")
        vm.back()

        // ---- Dial-in session on the training desk (FLEX) ----------------------------------------------
        device = flex
        vm.startDialIn(espresso = true, random = Random(11))
        assertEquals(5, vm.quiz!!.items.size)
        assertTrue(vm.quiz!!.current.facts.isNotEmpty())
        shot("t18_flex_dialin_question")
        vm.answer((vm.quiz!!.current.correct + 1) % 4)
        shot("t19_flex_dialin_wrong")
        assertTrue(text("Not this time"))
        vm.nextQuestion()
        answerAll()
        await("dial-in saved") { EventKind.DIAL_IN.name in kinds() }
        assertEquals(4, vm.quizResult!!.correct)
        assertTrue(vm.quizResult!!.passed)
        device = closed
        shot("t20_closed_dialin_result")
        vm.closeResult()

        // ---- Timed exam ends by itself when the clock runs out -----------------------------------------
        device = open
        vm.startExam(ExamCategory.TROUBLESHOOTING)
        assertEquals(10, vm.quiz!!.items.size)
        assertEquals(300, vm.quiz!!.timeLimitS)
        vm.answer(vm.quiz!!.current.correct); vm.nextQuestion()
        vm.answer(vm.quiz!!.current.correct)
        shot("t21_open_exam")
        ShadowSystemClock.advanceBy(Duration.ofSeconds(301))
        await("exam timeout") { vm.quizResult != null }
        await("exam saved") { EventKind.EXAM.name in kinds() }
        assertEquals(2, vm.quizResult!!.correct)
        assertFalse(vm.quizResult!!.passed)
        shot("t22_open_exam_result")
        vm.closeResult()

        // ---- Extraction lab ------------------------------------------------------------------------------
        vm.openTrain(TrainScreen.Lab)
        vm.labEspresso = true
        vm.shotSim = vm.shotSim.copy(channeling = true)
        shot("t23_open_lab")
        device = flex
        shot("t24_flex_lab")
        device = closed
        shot("t25_closed_lab")
        vm.back()

        // ---- Real brews create a training opportunity; Copilot links to the lesson --------------------
        assertNull(vm.opportunityOf(vm.brews.value))
        val repo = app.container.repository
        runBlocking {
            repeat(3) { i ->
                repo.saveBrew(Brew(coffeeName = "Ethiopia Guji", recipeName = "Classic V60", method = "V60", doseG = 20.0, waterG = 320.0, tempC = 94.0,
                    timeMs = 168_000, targetTimeS = 180, rating = 2, symptoms = Symptom.SOUR.name, createdAt = System.currentTimeMillis() + 10_000 + i))
            }
        }
        await("brews") { vm.brews.value.size == 4 }
        val opportunity = vm.opportunityOf(vm.brews.value)
        assertNotNull(opportunity)
        assertEquals("extraction", opportunity!!.lessonId)
        shot("t26_closed_train_home_opportunity")
        assertTrue(text("Training opportunity"))
        vm.selectTab(Tab.HOME)
        shot("t27_closed_home_opportunity")
        vm.diagnoseBrew(vm.brews.value.first())
        device = open
        shot("t28_open_diagnose_train_now")
        assertTrue(text("Train now"))
        vm.openLesson("temperature")
        assertEquals(Tab.TRAIN, vm.tab)
        assertTrue(vm.overlays.isEmpty())

        // ---- History, home with scores, French, dark ------------------------------------------------------
        vm.selectTab(Tab.TRAIN)
        vm.openTrain(TrainScreen.History)
        shot("t29_open_train_history")
        vm.back()
        shot("t30_open_train_home_progress")
        assertNotNull(progress().scores.first { it.skill.name == "ESPRESSO" }.percent)
        LanguageStore.set(app, "fr")   // what the in-app language setting does
        language = "fr"
        vm.openLesson("grind_size")
        shot("t31_open_lesson_fr")
        assertTrue(text("La taille de mouture"))
        device = closed
        vm.startLessonQuiz("grind_size")
        shot("t32_closed_quiz_fr")
        vm.back(); vm.back()
        LanguageStore.set(app, "en")
        language = "en"
        vm.setSettings { it.copy(themeMode = ThemeMode.DARK) }
        await("dark") { vm.settings.value!!.themeMode == ThemeMode.DARK }
        shot("t33_closed_train_home_dark")
        device = flex
        vm.startDialIn(espresso = false, random = Random(5))
        shot("t34_flex_dialin_dark")
        vm.back()

        // ---- Training history travels with the backup ------------------------------------------------------
        val count = vm.trainEvents.value.size
        val json = runBlocking { repo.exportJson() }
        assertTrue(json.contains("\"training\""))
        vm.resetData()
        await("reset") { vm.trainEvents.value.isEmpty() && vm.settings.value?.onboarded == false }
        runBlocking { repo.importJson(json) }
        await("restore") { vm.trainEvents.value.size == count }
        assertTrue("ratio" in progress().validated)
    }
}
