package com.mountainfold.app

import android.content.res.Configuration
import android.os.Looper
import androidx.activity.compose.LocalActivityResultRegistryOwner
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.github.takahirom.roborazzi.captureRoboImage
import com.mountainfold.app.core.fold.FoldState
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.fold.Posture
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.FlexLayout
import com.mountainfold.app.core.model.Symptom
import com.mountainfold.app.core.model.ThemeMode
import com.mountainfold.app.data.db.Coffee
import com.mountainfold.app.ui.CoffeeDraft
import com.mountainfold.app.ui.MainViewModel
import com.mountainfold.app.ui.MountainFoldRoot
import com.mountainfold.app.ui.Overlay
import com.mountainfold.app.ui.Pane
import com.mountainfold.app.ui.Tab
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowSystemClock
import java.io.File
import java.time.Duration
import java.util.Locale

/**
 * Drives the real app (ViewModel, Room, DataStore, session manager) through the three postures
 * on the JVM and renders each screen. It asserts the promise that matters most:
 * OPEN -> FLEX -> OPEN during a running brew keeps timer, step, weight and drafts intact.
 */
@RunWith(AndroidJUnit4::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [35], qualifiers = "w1000dp-h1100dp-xhdpi")
class PostureScenarioTest {
    @get:Rule val rule = createComposeRule()

    private data class Device(val name: String, val w: Int, val h: Int, val posture: Posture, val hinge: HingeInfo? = null)

    // Density is 2, so hinge pixels are dp x 2. Sizes approximate a book-style foldable.
    private val closed = Device("closed", 384, 880, Posture.CLOSED)
    private val open = Device("open", 880, 980, Posture.OPEN, HingeInfo(880, 0, 880, 1960, vertical = true, halfOpened = false))
    private val flex = Device("flex", 880, 980, Posture.FLEX, HingeInfo(0, 980, 1760, 980, vertical = false, halfOpened = true))
    private val closedLandscape = Device("closed_landscape", 880, 384, Posture.CLOSED)

    private var device by mutableStateOf(closed)
    private var fontScale by mutableFloatStateOf(1f)
    private var language by mutableStateOf("en")
    private val shots = File("build/shots").apply { mkdirs() }

    private fun idle() {
        shadowOf(Looper.getMainLooper()).idle()
        rule.mainClock.advanceTimeBy(400)
        rule.waitForIdle()
    }

    private fun await(what: String, condition: () -> Boolean) {
        val end = System.currentTimeMillis() + 20_000
        while (!condition()) {
            idle()
            Thread.sleep(20)
            check(System.currentTimeMillis() < end) { "Timed out waiting for $what" }
        }
        idle()
    }

    private fun shot(name: String) {
        idle()
        rule.onNodeWithTag("device").captureRoboImage(File(shots, "$name.png").path)
    }

    private fun passTime(seconds: Long) {
        ShadowSystemClock.advanceBy(Duration.ofSeconds(seconds))
        idle()
    }

    private fun text(t: String) = rule.onAllNodesWithText(t, substring = true, ignoreCase = true).fetchSemanticsNodes().isNotEmpty()

    @Test
    fun brewSurvivesEveryPostureChange() {
        val app = ApplicationProvider.getApplicationContext<MountainFoldApp>()
        val vm = MainViewModel(app)
        val session = vm.session

        rule.setContent {
            val base = LocalContext.current
            val registryOwner = checkNotNull(LocalActivityResultRegistryOwner.current)
            val localized = remember(language) {
                val config = Configuration(base.resources.configuration)
                config.setLocale(Locale.forLanguageTag(language))
                base.createConfigurationContext(config)
            }
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.align(Alignment.TopStart).requiredSize(device.w.dp, device.h.dp).testTag("device")) {
                    CompositionLocalProvider(
                        LocalDensity provides Density(LocalDensity.current.density, fontScale),
                        LocalContext provides localized,
                        LocalActivityResultRegistryOwner provides registryOwner,
                    ) {
                        MountainFoldRoot(vm, foldState = { FoldState(device.posture, device.hinge) })
                    }
                }
            }
        }

        // ---- Onboarding -------------------------------------------------------------------
        await("settings") { vm.settings.value != null }
        assertFalse(vm.settings.value!!.onboarded)
        shot("01_onboarding_closed")
        vm.setSettings { it.copy(dynamicColor = false) }
        vm.completeOnboarding(listOf(BrewMethod.V60, BrewMethod.ESPRESSO), "Comandante C40")
        await("onboarding") { vm.settings.value!!.onboarded && session.state.value.recipe != null && vm.recipes.value.size == 10 }
        assertEquals(BrewMethod.V60, session.state.value.recipe!!.method)
        assertEquals(1, vm.grinders.value.size)

        vm.newCoffee()
        vm.coffeeDraft = CoffeeDraft(
            Coffee(name = "Ethiopia Guji", country = "Ethiopia", region = "Guji", process = "Washed", variety = "Heirloom",
                altitude = "2100 m", roaster = "Local roaster", tastingNotes = "Jasmine, peach, bergamot", roastLevel = "Light",
                roastDateEpochDay = java.time.LocalDate.now().toEpochDay() - 12)
        )
        vm.saveCoffeeDraft()
        await("coffee") { vm.coffees.value.size == 1 && session.state.value.recipe?.coffeeName == "Ethiopia Guji" }

        // ---- CLOSED: quick assistant --------------------------------------------------------
        vm.selectTab(Tab.HOME)
        shot("02_closed_home")
        assertTrue(text("Ethiopia Guji"))
        vm.selectTab(Tab.BREW)
        shot("03_closed_brew_idle")
        assertTrue(text("Ready when you are."))

        session.start()
        passTime(50)
        assertEquals(1, session.currentStepIndex())
        assertTrue("timer keeps running", session.timer.state.value.running)
        shot("04_closed_brew_running")
        assertTrue(text("Pour 1"))

        // ---- CLOSED -> OPEN while brewing --------------------------------------------------
        val beforeOpen = session.timer.elapsedMs()
        device = open
        idle()
        assertTrue(session.timer.state.value.running)
        assertTrue(session.timer.elapsedMs() in beforeOpen..beforeOpen + 3_000)
        assertEquals(1, session.currentStepIndex())
        shot("05_open_brew_running")

        session.addWater(120.0)
        passTime(40)
        assertEquals(2, session.currentStepIndex())

        // ---- OPEN -> FLEX -> OPEN while brewing ----------------------------------------------
        val beforeFlex = session.timer.elapsedMs()
        val recipeBefore = session.state.value.recipe
        device = flex
        idle()
        assertTrue(session.timer.state.value.running)
        assertEquals(2, session.currentStepIndex())
        assertEquals(120.0, session.weight.weightG.value, 0.0)
        assertTrue(text("Pour 2"))
        for (layout in FlexLayout.entries) {
            vm.setSettings { it.copy(flexLayout = layout) }
            await("flex layout $layout") { vm.settings.value!!.flexLayout == layout }
            shot("06_flex_${layout.name.lowercase()}")
        }
        vm.setSettings { it.copy(flexLayout = FlexLayout.BREW) }
        await("flex layout reset") { vm.settings.value!!.flexLayout == FlexLayout.BREW }
        device = open
        idle()
        assertTrue(session.timer.state.value.running)
        assertTrue(session.timer.elapsedMs() in beforeFlex..beforeFlex + 6_000)
        assertEquals(2, session.currentStepIndex())
        assertEquals(recipeBefore, session.state.value.recipe)
        assertEquals(120.0, session.weight.weightG.value, 0.0)
        shot("07_open_brew_after_flex")

        // ---- Finish, log, history ----------------------------------------------------------------
        passTime(75)
        session.addWater(130.0)
        session.finish()
        await("log sheet") { vm.overlays.lastOrNull() == Overlay.LogBrew && vm.logDraft != null }
        assertFalse(session.timer.state.value.running)
        vm.logDraft = vm.logDraft!!.copy(rating = 3, acidity = 4, sweetness = 2, body = 2, balance = 2, clarity = 4, symptoms = setOf(Symptom.SOUR), grind = "22", notes = "Bright but thin.")
        shot("08_open_log")
        device = closed
        shot("09_closed_log")
        assertEquals("draft survives the posture change", 3, vm.logDraft!!.rating)
        device = open
        vm.saveLog()
        await("brew saved") { vm.brews.value.size == 1 && vm.tab == Tab.HISTORY }
        val brew = vm.brews.value.first()
        assertEquals(250.0, brew.waterG, 0.0)
        assertEquals("22", brew.grind)
        assertEquals("Comandante C40", brew.grinderName)
        assertTrue(brew.timeMs >= 165_000)
        shot("10_open_history")

        // ---- Copilot ---------------------------------------------------------------------------
        vm.diagnoseBrew(brew)
        shot("11_open_diagnose")
        assertTrue(text("under-extracted"))
        device = closed
        shot("12_closed_diagnose")
        val diagnosis = vm.diagnosis()
        assertNotNull(diagnosis)
        vm.saveSuggestion(diagnosis!!)
        await("suggestion saved") { vm.recipes.value.size == 11 }

        // ---- Library, editor draft across postures -----------------------------------------------
        device = open
        vm.selectTab(Tab.RECIPES)
        val v60 = vm.recipes.value.first { it.name == "Classic V60" }
        vm.recipePane = Pane.View(v60.id)
        shot("13_open_recipes")
        vm.editRecipe(v60)
        vm.recipeDraft = vm.recipeDraft!!.copy(name = "House V60, lighter")
        shot("14_open_recipe_editor")
        device = flex
        idle()
        device = closed
        shot("15_closed_recipe_editor")
        assertEquals("House V60, lighter", vm.recipeDraft!!.name)
        vm.closeRecipePane()
        shot("16_closed_recipes")
        device = open
        vm.selectTab(Tab.COFFEE)
        vm.coffeePane = Pane.View(vm.coffees.value.first().id)
        shot("17_open_coffee")
        vm.selectTab(Tab.HOME)
        shot("18_open_home")

        // ---- Tools -----------------------------------------------------------------------------
        vm.open(Overlay.Calculator); shot("19_open_calculator")
        device = closed; shot("20_closed_calculator")
        vm.compare = vm.compare.copy(brews = false, aId = v60.id, bId = vm.recipes.value.first { it.name.contains("adjusted") }.id)
        vm.open(Overlay.Compare); shot("21_closed_cmp")
        device = open; shot("22_open_cmp")
        vm.open(Overlay.GrindAdvisor); shot("23_open_grind")
        vm.open(Overlay.Settings); shot("24_open_settings")
        device = closed; shot("25_closed_settings")
        vm.selectTab(Tab.HISTORY); shot("26_closed_history")

        // ---- Espresso mode ------------------------------------------------------------------------
        vm.brew(vm.recipes.value.first { it.method == BrewMethod.ESPRESSO.name })
        await("espresso loaded") { session.state.value.recipe?.method == BrewMethod.ESPRESSO }
        session.start(); passTime(14); session.addWater(17.0)
        shot("27_closed_espresso")
        device = open; shot("28_open_espresso")
        device = flex; shot("29_flex_espresso_shot")
        session.pause()

        // ---- Dark theme ------------------------------------------------------------------------
        vm.setSettings { it.copy(themeMode = ThemeMode.DARK) }
        await("dark") { vm.settings.value!!.themeMode == ThemeMode.DARK }
        vm.brew(v60)
        vm.confirmReplace()
        await("v60 loaded") { session.state.value.recipe?.method == BrewMethod.V60 }
        session.start(); passTime(95); session.addWater(150.0)
        shot("30_flex_brew_dark")
        device = open; shot("31_open_brew_dark")
        device = closed; shot("32_closed_brew_dark")
        vm.selectTab(Tab.HOME); shot("33_closed_home_dark")

        // ---- Large text, landscape cover screen, French ---------------------------------------
        vm.selectTab(Tab.BREW)
        fontScale = 1.5f; shot("34_closed_brew_font_150")
        device = flex; shot("35_flex_brew_font_150")
        fontScale = 1f
        device = closedLandscape; shot("36_closed_landscape_brew")
        device = closed
        language = "fr"
        vm.selectTab(Tab.HOME); shot("37_closed_home_fr")
        vm.open(Overlay.Settings); shot("38_closed_settings_fr")
        assertTrue(text("Réglages"))
        language = "es"
        vm.back(); vm.selectTab(Tab.BREW); shot("39_closed_brew_es")
        assertTrue(text("Siguiente paso"))
        language = "en"
        session.reset()

        // ---- Backup round trip, then reset -------------------------------------------------------
        val repo = app.container.repository
        val json = runBlocking { repo.exportJson() }
        assertTrue(json.contains("Ethiopia Guji") && json.contains("House").not())
        vm.deleteBrew(brew)
        await("brew deleted") { vm.brews.value.isEmpty() }
        runBlocking { repo.importJson(json) }
        await("restore") { vm.brews.value.size == 1 && vm.recipes.value.size == 11 && vm.coffees.value.size == 1 }
        assertEquals(brew, vm.brews.value.first())
        assertTrue(runCatching { runBlocking { repo.importJson("{\"app\":\"Other\"}") } }.isFailure)
        assertEquals("a bad file must not wipe data", 1, vm.brews.value.size)

        vm.resetData()
        await("reset") { vm.settings.value?.onboarded == false && vm.recipes.value.isEmpty() }
        assertEquals(null, session.state.value.recipe)
        shot("40_onboarding_after_reset_dark_off")
    }
}
