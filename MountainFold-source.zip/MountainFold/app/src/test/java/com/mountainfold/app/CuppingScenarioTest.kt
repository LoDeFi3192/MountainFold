package com.mountainfold.app

import android.content.res.Configuration
import android.os.Looper
import androidx.activity.compose.LocalActivityResultRegistryOwner
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.ExperimentalTestApi
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithContentDescription
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performCustomAccessibilityActionWithLabel
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performSemanticsAction
import androidx.compose.ui.test.performTextReplacement
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.github.takahirom.roborazzi.captureRoboImage
import com.mountainfold.app.core.cupping.CuppingCatalog
import com.mountainfold.app.core.cupping.CuppingCsv
import com.mountainfold.app.core.cupping.CuppingTimer
import com.mountainfold.app.core.cupping.FlavorWheel
import com.mountainfold.app.core.fold.FoldState
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.fold.Posture
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.Palette
import com.mountainfold.app.core.model.ThemeMode
import com.mountainfold.app.data.prefs.LanguageStore
import com.mountainfold.app.service.CuppingPdf
import com.mountainfold.app.ui.MainViewModel
import com.mountainfold.app.ui.MountainFoldRoot
import com.mountainfold.app.ui.Tab
import com.mountainfold.app.ui.cupping.CupScreen
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowSystemClock
import java.io.File
import java.time.Duration
import java.util.Locale

/**
 * Runs a full Toulouse Cupping session inside the app, in French, across Closed, Open and Flex:
 * scoring, aromas, validation, timer, flavor wheel, summary and exports, Brewing Lab, invite, archive.
 */
@RunWith(AndroidJUnit4::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
// French device locale too, so menus and dialogs (separate windows) render in French like the screens.
@Config(sdk = [35], qualifiers = "fr-w1000dp-h1100dp-xhdpi")
class CuppingScenarioTest {
    @get:Rule val rule = createComposeRule()

    private data class Device(val w: Int, val h: Int, val posture: Posture, val hinge: HingeInfo? = null)

    private val closed = Device(384, 880, Posture.CLOSED)
    private val open = Device(880, 980, Posture.OPEN, HingeInfo(880, 0, 880, 1960, vertical = true, halfOpened = false))
    private val flex = Device(880, 980, Posture.FLEX, HingeInfo(0, 980, 1760, 980, vertical = false, halfOpened = true))

    private var device by mutableStateOf(closed)
    private val shots = File("build/shots").apply { mkdirs() }

    private fun idle() {
        shadowOf(Looper.getMainLooper()).idle()
        rule.mainClock.advanceTimeBy(600)
        rule.waitForIdle()
    }

    private fun await(what: String, condition: () -> Boolean) {
        val end = System.currentTimeMillis() + 20_000
        while (!condition()) {
            idle()
            Thread.sleep(20)
            check(System.currentTimeMillis() < end) { "Timed out waiting for $what" }
        }
        idle()
    }

    private fun shot(name: String) {
        idle()
        rule.onNodeWithTag("device").captureRoboImage(File(shots, "$name.png").path)
    }

    private fun text(t: String) = rule.onAllNodesWithText(t, substring = true, ignoreCase = true).fetchSemanticsNodes().isNotEmpty()

    /** Scrolls a node into view and triggers its click action. The floating score bar can sit on top of it. */
    private fun tap(label: String) {
        rule.onNodeWithText(label).performScrollTo().performSemanticsAction(SemanticsActions.OnClick)
        idle()
    }

    private fun pass(seconds: Long) {
        ShadowSystemClock.advanceBy(Duration.ofSeconds(seconds))
        idle()
    }

    @OptIn(ExperimentalTestApi::class)
    @Test
    fun aFullCuppingSessionAcrossPostures() {
        val app = ApplicationProvider.getApplicationContext<MountainFoldApp>()
        LanguageStore.set(app, "fr")
        val vm = MainViewModel(app)
        val cup = vm.cup
        val repo = app.container.repository

        rule.setContent {
            val base = LocalContext.current
            val registryOwner = checkNotNull(LocalActivityResultRegistryOwner.current)
            val localized = remember {
                val config = Configuration(base.resources.configuration)
                config.setLocale(Locale.forLanguageTag("fr"))
                base.createConfigurationContext(config)
            }
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.align(Alignment.TopStart).requiredSize(device.w.dp, device.h.dp).testTag("device")) {
                    CompositionLocalProvider(LocalContext provides localized, LocalActivityResultRegistryOwner provides registryOwner) {
                        MountainFoldRoot(vm, foldState = { FoldState(device.posture, device.hinge) })
                    }
                }
            }
        }

        await("settings") { vm.settings.value != null }
        vm.setSettings { it.copy(dynamicColor = false, palette = Palette.TOULOUSE, themeMode = ThemeMode.DARK) }
        vm.completeOnboarding(listOf(BrewMethod.V60), "")
        await("onboarding") { vm.settings.value!!.onboarded && vm.settings.value!!.palette == Palette.TOULOUSE }
        await("cupping session") { cup.session != null && cup.coffees.size == 1 }
        assertEquals("Nouveau Café", cup.active!!.name)
        val firstSession = cup.session!!.id

        // ---- Closed: the phone layout of the original -----------------------------------------------
        vm.selectTab(Tab.CUPPING)
        shot("c01_closed_cupping")
        assertTrue(text("Toulouse Cupping") && text("Fragrance / Arôme") && text("Voir le Tableau"))

        cup.edit { it.copy(name = "Ethiopia Guji") }
        rule.onAllNodesWithContentDescription("Afficher le détail")[0].performClick(); idle()
        tap("Fruité")
        tap("Citron")
        tap("Pêche")
        assertEquals(listOf("Citron", "Pêche"), cup.active!!.fragranceNotes)
        rule.onAllNodesWithContentDescription("Score")[0].performSemanticsAction(SemanticsActions.SetProgress) { it(8.8f) }; idle()
        assertEquals("snaps to quarter points", 8.75, cup.active!!.fragranceScore, 0.0)
        rule.onNodeWithText("Fragrance / Arôme").performScrollTo(); idle()
        shot("c02_closed_fragrance_notes")
        tap("Lavé")
        assertEquals("Lavé", cup.active!!.process)
        cup.edit {
            it.copy(
                flavorScore = 8.5, flavorNotes = listOf("Jasmin", "Citron", "Miel"), acidityScore = 8.25, acidityType = "Citrique",
                acidityIntensity = "Forte", bodyType = "Rond", balanceScore = 8.25, comments = "Bergamote, finale longue.",
            )
        }
        rule.onNodeWithContentDescription("Favori").performClick(); idle()
        assertTrue(cup.active!!.isFavorite)

        rule.onNodeWithText("+ Nouveau").performClick(); idle()
        assertEquals(2, cup.coffees.size)
        assertEquals("Café 2", cup.active!!.name)
        cup.edit { it.copy(name = "Colombia Huila", fragranceScore = 7.75, flavorScore = 7.5, process = "Honey", flavorNotes = listOf("Caramel", "Chocolat au lait")) }
        rule.onNodeWithText("Valider").performClick(); idle()
        assertTrue(cup.active!!.isLocked)
        cup.edit { it.copy(flavorScore = 6.0) }
        assertEquals("a validated coffee ignores edits", 7.5, cup.active!!.flavorScore, 0.0)
        cup.toggleFavorite()
        assertTrue("the heart still works when validated", cup.active!!.isFavorite)
        cup.toggleFavorite()
        shot("c03_closed_validated")
        assertTrue(text("Validé") && text("Modifier"))

        cup.addCoffee()
        cup.edit {
            it.copy(
                name = "Kenya Nyeri", fragranceScore = 9.0, flavorScore = 9.0, aftertasteScore = 8.75, balanceScore = 8.5, process = "Lavé",
                fragranceNotes = listOf("Pamplemousse", "Framboise"), flavorNotes = listOf("Cassonade"),
            )
        }
        cup.select(0)
        await("saved to the database") { runBlocking { repo.cuppingCoffeesOf(firstSession).map { it.name } } == listOf("Ethiopia Guji", "Colombia Huila", "Kenya Nyeri") }

        // ---- Session info page ---------------------------------------------------------------------
        cup.screen = CupScreen.INFO
        cup.updateSession { it.copy(location = "Labo Toulouse", originNotes = "Éthiopie, Colombie, Kenya", roasterNotes = "La Claque", importerNotes = "Belco") }
        shot("c04_closed_session_info")
        assertTrue(text("Lieu de dégustation") && text("Labo Toulouse"))
        rule.onNodeWithText("Valider").performClick(); idle()
        assertEquals(CupScreen.MAIN, cup.screen)

        // ---- Cupping timer: 6 minutes, crust at 4, across postures ---------------------------------------
        rule.onNodeWithContentDescription("Chronomètre").performClick(); idle()
        rule.onNodeWithText("6 min").performClick(); idle()
        pass(30)
        assertEquals(330, cup.timerState.remainingS)
        assertEquals(CuppingTimer.Phase.CRUST, cup.timerState.phase)
        shot("c05_closed_timer")
        cup.timerOpen = false
        rule.onNodeWithContentDescription("Menu cupping").performClick(); idle()
        shot("c06_closed_menu")
        assertTrue(text("Roue des Saveurs") && text("Mode Brewing") && text("Inviter / QR Code") && text("Sessions précédentes"))
        cup.menuOpen = false

        device = open
        shot("c07_open_workstation")
        assertTrue(text("Ethiopia Guji") && text("Kenya Nyeri") && text("Labo Toulouse"))
        pass(210)
        assertEquals("crust passed while unfolded", CuppingTimer.Phase.TASTE, cup.timerState.phase)

        device = flex
        shot("c08_flex_cupping_desk")
        assertTrue(text("GOÛT"))
        pass(121)
        assertEquals(CuppingTimer.Phase.FINISHED, cup.timerState.phase)
        assertFalse(cup.timerState.running)
        assertEquals("scores survive every posture change", 8.75, cup.coffees[0].fragranceScore, 0.0)

        // ---- Flavor wheel ------------------------------------------------------------------------------
        cup.screen = CupScreen.WHEEL
        cup.wheelRotation = FlavorWheel.rotationFor(17, 0f, 270f)
        shot("c09_flex_wheel_dial")
        assertEquals("Lavande", FlavorWheel.slices[FlavorWheel.activeIndex(cup.wheelRotation, 270f)].key)
        assertTrue(text("Lavande"))
        device = closed
        cup.wheelRotation = FlavorWheel.rotationFor(22, 0f, 0f)
        shot("c10_closed_wheel")
        assertTrue(text("Clou de girofle"))
        rule.onNodeWithContentDescription("Roue des saveurs", substring = true).performCustomAccessibilityActionWithLabel("Arôme suivant"); idle()
        assertEquals("Muscade", FlavorWheel.slices[FlavorWheel.activeIndex(cup.wheelRotation, 0f)].key)
        device = open
        shot("c11_open_wheel")

        // ---- Summary table and exports ------------------------------------------------------------------
        cup.screen = CupScreen.SUMMARY
        shot("c12_open_summary_table")
        assertTrue(text("Profil Aromatique") && text("8.29"))
        device = closed
        shot("c13_closed_summary_cards")
        val headers = listOf("Nom du café", "Fav", "Procédé / Process", "Score", "Notes", "Fragrance / Arôme", "Saveur", "Arrière-goût", "Acidité", "Corps", "Équilibre", "Commentaires")
        val csv = CuppingCsv.build(cup.coffees, headers, "Oui", "Non") { CuppingCatalog.label(it, "fr") }
        assertTrue(csv.lines()[1].startsWith("\"Ethiopia Guji\",Oui,Lavé,8.29,\"Citron, Pêche, Jasmin, Miel\",8.75,8.5,8,8.25,8,8.25"))
        // PdfDocument has no native side under Robolectric: check the layout and draw the page into a bitmap
        // with the very same drawing code the PDF uses.
        val plan = CuppingPdf.plan(
            cup.coffees,
            CuppingPdf.Texts("Rapport de Dégustation", "Toulouse Cupping App - Date: 13/10/2026", "Lieu: Labo Toulouse", "Origine(s): Éthiopie, Colombie, Kenya | Torréfacteur: La Claque", headers.take(4) + "Profil Sensoriel" + headers.subList(5, 11)) { i, n -> "Page $i / $n" },
        ) { CuppingCatalog.label(it, "fr") }
        assertEquals(1, plan.pageCount)
        assertEquals(listOf("Ethiopia Guji", "♥", "Lavé", "8.29"), plan.rows[0].take(4))
        File(shots, "c13b_pdf_report_page1.png").outputStream().use { CuppingPdf.preview(plan, 0).compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
        val many = CuppingPdf.plan(List(40) { i -> cup.coffees[i % 3].copy(id = "x$i", name = "Lot ${i + 1}") }, plan.texts) { it }
        assertTrue("long sessions flow onto more pages", many.pageCount > 1)
        assertEquals(40, many.rows.size)

        // ---- Brewing Lab -----------------------------------------------------------------------------------
        cup.screen = CupScreen.LAB
        idle()
        rule.onNodeWithText("Chemex").performClick(); idle()
        assertEquals("15", cup.lab.ratio)
        rule.onNodeWithContentDescription("Café (g)").performTextReplacement("30"); idle()
        assertEquals(450, cup.lab.water)
        assertTrue(text("450g"))
        tap("Démarrer")
        pass(185)
        tap("Pause")
        assertEquals(185, cup.labSeconds)
        cup.lab = cup.lab.copy(grind = "Sel fin", rating = 8.5, notes = "Floral, très propre.")
        shot("c14_closed_lab")
        tap("💾 Enregistrer")
        await("lab recipe") { cup.labRecipes.value.size == 1 }
        assertEquals(450, cup.labRecipes.value.single().waterWeight)
        assertEquals(185, cup.labRecipes.value.single().totalTime)
        cup.pickMethod("moka")
        tap("📂 Historique de recettes")
        shot("c15_closed_lab_history")
        rule.onNodeWithText("Chemex").performClick(); idle()
        assertEquals("loading keeps the saved ratio", "15", cup.lab.ratio)
        assertEquals("chemex", cup.lab.method)
        device = flex
        shot("c16_flex_lab_desk")
        device = open
        shot("c17_open_lab")

        // ---- Invite QR, light theme -----------------------------------------------------------------------
        device = closed
        cup.screen = CupScreen.MAIN
        cup.inviteOpen = true
        shot("c18_closed_invite")
        assertTrue(text("Flashez ce code") && text("us-west1.run.app"))
        cup.inviteOpen = false
        vm.setSettings { it.copy(themeMode = ThemeMode.LIGHT) }
        await("light") { vm.settings.value!!.themeMode == ThemeMode.LIGHT }
        shot("c19_closed_light")

        // ---- New session keeps the old one in the archive ----------------------------------------------------
        cup.confirmNewSession = true
        idle()
        assertTrue(text("reste dans Sessions précédentes"))
        cup.newSession()
        await("new session") { cup.session!!.id != firstSession && cup.screen == CupScreen.INFO }
        assertEquals(1, cup.coffees.size)
        cup.screen = CupScreen.SESSIONS
        await("archive") { cup.sessions.value.size == 2 }
        shot("c20_closed_sessions")
        cup.openSession(firstSession)
        await("old session back") { cup.session!!.id == firstSession }
        assertEquals(listOf("Ethiopia Guji", "Colombia Huila", "Kenya Nyeri"), cup.coffees.map { it.name })
        assertEquals(listOf("Citron", "Pêche"), cup.coffees[0].fragranceNotes)
        assertTrue(cup.coffees[1].isLocked)
        assertEquals("Labo Toulouse", cup.session!!.location)

        // ---- Launcher shortcut and back gesture ---------------------------------------------------------------
        vm.selectTab(Tab.HOME)
        vm.cuppingShortcut()
        idle()
        assertEquals(Tab.CUPPING, vm.tab)
        assertTrue(text("Raccourci détecté"))
        cup.shortcutPrompt = false
        cup.screen = CupScreen.SUMMARY
        vm.back()
        assertEquals(CupScreen.MAIN, cup.screen)
        vm.back()
        assertEquals(Tab.HOME, vm.tab)
        assertNotEquals(0, cup.sessions.value.size)
    }
}
