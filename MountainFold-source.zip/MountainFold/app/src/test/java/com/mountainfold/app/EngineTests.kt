package com.mountainfold.app

import com.mountainfold.app.core.engine.CoffeeEngine
import com.mountainfold.app.core.engine.CoffeeEngine.Solve
import com.mountainfold.app.core.engine.CopilotEngine
import com.mountainfold.app.core.engine.CopilotEngine.ChangeKind
import com.mountainfold.app.core.engine.StepSchedule
import com.mountainfold.app.core.engine.TimerEngine
import com.mountainfold.app.core.fold.FoldStateResolver
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.fold.Posture
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.BrewStep
import com.mountainfold.app.core.model.LayoutOverride
import com.mountainfold.app.core.model.StepType
import com.mountainfold.app.core.model.Symptom
import com.mountainfold.app.core.voice.VoiceCommand
import com.mountainfold.app.core.voice.VoiceCommandParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CoffeeEngineTest {
    @Test fun ratioIsWaterOverCoffee() {
        assertEquals(16.666, CoffeeEngine.ratio(250.0, 15.0)!!, 0.001)
        assertEquals("1:16.7", CoffeeEngine.formatRatio(CoffeeEngine.ratio(250.0, 15.0)))
        assertEquals("1:2", CoffeeEngine.formatRatio(CoffeeEngine.ratio(36.0, 18.0)))
        assertNull(CoffeeEngine.ratio(250.0, 0.0))
    }

    @Test fun solvesEachDirection() {
        assertEquals(250.5, CoffeeEngine.solve(Solve.WATER, 15.0, null, 16.7)!!.waterG, 0.001)
        assertEquals(15.0, CoffeeEngine.solve(Solve.COFFEE, null, 240.0, 16.0)!!.doseG, 0.001)
        assertEquals(2.0, CoffeeEngine.solve(Solve.RATIO, 18.0, 36.0, null)!!.ratio, 0.001)
        assertNull(CoffeeEngine.solve(Solve.WATER, 0.0, null, 16.0))
        assertNull(CoffeeEngine.solve(Solve.RATIO, 18.0, null, null))
    }

    @Test fun clockFormattingAndParsing() {
        assertEquals("02:45", CoffeeEngine.formatClock(165))
        assertEquals("16:00:00", CoffeeEngine.formatClock(57600))
        assertEquals("28.4", CoffeeEngine.formatTenths(28_449))
        assertEquals(185, CoffeeEngine.parseClock("3:05"))
        assertEquals(28, CoffeeEngine.parseClock("28"))
        assertEquals(3720, CoffeeEngine.parseClock("1:02:00"))
        assertNull(CoffeeEngine.parseClock("a:b"))
        assertEquals(15.5, CoffeeEngine.parseNumber("15,5")!!, 0.0)
    }

    @Test fun unitsRoundTrip() {
        assertEquals(15.0, CoffeeEngine.ozToG(CoffeeEngine.gToOz(15.0)), 1e-9)
        assertEquals(199.4, CoffeeEngine.cToF(93.0), 1e-9)
        assertEquals(93.0, CoffeeEngine.fToC(199.4), 1e-9)
    }

    @Test fun stepsScaleWithWater() {
        val steps = listOf(BrewStep("Bloom", StepType.BLOOM, 0, 45.0), BrewStep("Pour", StepType.POUR, 45, 250.0), BrewStep("Wait", StepType.WAIT, 90))
        val scaled = CoffeeEngine.scaleSteps(steps, 250.0, 500.0)
        assertEquals(listOf(90.0, 500.0, null), scaled.map { it.targetWaterG })
        assertEquals(steps, CoffeeEngine.scaleSteps(steps, 250.0, 250.0))
    }

    @Test fun beverageEstimate() {
        assertEquals(220.0, CoffeeEngine.beverageEstimate(250.0, 15.0, BrewMethod.V60), 0.0)
        assertEquals(36.0, CoffeeEngine.beverageEstimate(36.0, 18.0, BrewMethod.ESPRESSO), 0.0)
    }
}

class TimerEngineTest {
    private var now = 1_000L
    private val timer = TimerEngine { now }

    @Test fun countsOnlyWhileRunning() {
        assertEquals(0, timer.elapsedMs())
        timer.start(); now += 42_000
        assertEquals(42_000, timer.elapsedMs())
        timer.pause(); now += 10_000
        assertEquals(42_000, timer.elapsedMs())
        timer.start(); now += 3_000
        assertEquals(45_000, timer.elapsedMs())
        assertTrue(timer.state.value.hasStarted)
    }

    @Test fun doubleStartDoesNotResetTheClock() {
        timer.start(); now += 5_000; timer.start(); now += 5_000
        assertEquals(10_000, timer.elapsedMs())
    }

    @Test fun lapsAndReset() {
        timer.start(); now += 45_000; timer.lap(); now += 35_000; timer.lap()
        assertEquals(listOf(45_000L, 80_000L), timer.state.value.laps)
        timer.reset()
        assertEquals(0, timer.elapsedMs())
        assertFalse(timer.state.value.hasStarted)
    }

    @Test fun restoreAddsTimeSpentWhileProcessWasDead() {
        timer.restore(accumulatedMs = 60_000, running = true, laps = emptyList(), extraMs = 15_000)
        now += 5_000
        assertEquals(80_000, timer.elapsedMs())
        timer.restore(accumulatedMs = 60_000, running = false, laps = emptyList(), extraMs = 15_000)
        now += 5_000
        assertEquals(60_000, timer.elapsedMs())
    }
}

class StepScheduleTest {
    private val steps = listOf(
        BrewStep("Bloom", StepType.BLOOM, 0, 45.0), BrewStep("Pour 1", StepType.POUR, 45, 120.0),
        BrewStep("Pour 2", StepType.POUR, 80, 190.0), BrewStep("Final", StepType.POUR, 130, 250.0),
    )

    @Test fun findsActiveStep() {
        assertEquals(0, StepSchedule.indexAt(steps, 0.0))
        assertEquals(0, StepSchedule.indexAt(steps, 44.9))
        assertEquals(1, StepSchedule.indexAt(steps, 45.0))
        assertEquals(3, StepSchedule.indexAt(steps, 500.0))
        assertEquals(-1, StepSchedule.indexAt(emptyList(), 10.0))
        assertEquals(80, StepSchedule.endOf(steps, 1, 180))
        assertEquals(180, StepSchedule.endOf(steps, 3, 180))
        assertEquals(190.0, StepSchedule.targetWaterAt(steps, 2)!!, 0.0)
    }

    @Test fun plusTenSecondsPushesLaterStepsOnly() {
        val (out, target) = StepSchedule.extendCurrent(steps, 50.0, 180, 10)
        assertEquals(listOf(0, 45, 90, 140), out.map { it.startS })
        assertEquals(190, target)
    }

    @Test fun nextStepSlidesScheduleToNow() {
        val (out, target) = StepSchedule.advanceNow(steps, 30.0, 180)!!
        assertEquals(listOf(0, 30, 65, 115), out.map { it.startS })
        assertEquals(165, target)
        assertEquals(1, StepSchedule.indexAt(out, 30.0))
        assertNull(StepSchedule.advanceNow(steps, 140.0, 180))
    }
}

class CopilotEngineTest {
    private val v60Steps = listOf(BrewStep("Bloom", StepType.BLOOM, 0, 45.0), BrewStep("Pour", StepType.POUR, 45, 250.0))
    private fun filter(temp: Double? = 92.0, time: Int? = 165, target: Int = 165, grind: String = "medium-fine") =
        CopilotEngine.BrewInput(BrewMethod.V60, 15.0, 250.0, temp, time, target, grind, v60Steps)
    private fun shot(yieldG: Double = 36.0, time: Int? = 28, temp: Double? = 93.0, grind: String = "8") =
        CopilotEngine.BrewInput(BrewMethod.ESPRESSO, 18.0, yieldG, temp, time, 28, grind)

    /** The example from the product brief: sour V60 at 92 °C becomes 94 °C, nothing else is touched. */
    @Test fun sourFilterRaisesTemperatureOnly() {
        val d = CopilotEngine.diagnose(filter(), setOf(Symptom.SOUR))!!
        assertEquals(CopilotEngine.Cause.UNDER_EXTRACTION, d.cause)
        assertEquals(ChangeKind.TEMP_UP, d.change)
        assertEquals(94.0, d.suggestion.tempC!!, 0.0)
        assertEquals(15.0, d.suggestion.doseG, 0.0)
        assertEquals(250.0, d.suggestion.waterG, 0.0)
        assertEquals("medium-fine", d.suggestion.grind)
    }

    @Test fun sourAndFastGoesFiner() {
        val d = CopilotEngine.diagnose(filter(time = 130, target = 180), setOf(Symptom.SOUR))!!
        assertEquals(ChangeKind.GRIND_FINER, d.change)
        assertFalse(d.grindStepped)
        assertTrue(d.timeIsEstimate)
        assertEquals(200, d.suggestion.targetTimeS)
    }

    @Test fun numericGrindIsStepped() {
        val d = CopilotEngine.diagnose(filter(time = 240, target = 180, grind = "22"), setOf(Symptom.BITTER))!!
        assertEquals(ChangeKind.GRIND_COARSER, d.change)
        assertTrue(d.grindStepped)
        assertEquals("23", d.suggestion.grind)
        assertEquals("22", CopilotEngine.adjustGrind("22.5", true))
        assertEquals("21", CopilotEngine.adjustGrind("22", true))
        assertEquals("3", CopilotEngine.adjustGrind("2.5", false))
        assertNull(CopilotEngine.adjustGrind("medium", true))
    }

    @Test fun sourPlusBitterMeansUnevenAndLongerBloom() {
        val d = CopilotEngine.diagnose(filter(), setOf(Symptom.SOUR, Symptom.BITTER))!!
        assertEquals(Symptom.HOLLOW, d.symptom)
        assertEquals(ChangeKind.BLOOM_LONGER, d.change)
        assertEquals(listOf(0, 60), d.suggestion.steps.map { it.startS })
        assertEquals(180, d.suggestion.targetTimeS)
    }

    @Test fun espressoRules() {
        assertEquals(ChangeKind.GRIND_FINER, CopilotEngine.diagnose(shot(time = 19), setOf(Symptom.SOUR))!!.change)
        val longer = CopilotEngine.diagnose(shot(yieldG = 30.0), setOf(Symptom.SOUR))!!
        assertEquals(ChangeKind.YIELD_UP, longer.change)
        assertEquals(34.0, longer.suggestion.waterG, 0.0)
        assertEquals(ChangeKind.GRIND_COARSER, CopilotEngine.diagnose(shot(time = 40), setOf(Symptom.BITTER))!!.change)
        assertEquals(ChangeKind.PUCK_PREP, CopilotEngine.diagnose(shot(), setOf(Symptom.ASTRINGENT))!!.change)
        assertFalse(CopilotEngine.diagnose(shot(), setOf(Symptom.ASTRINGENT))!!.recipeChanged)
    }

    @Test fun staleCoffeeIsNotFixedWithSettings() {
        val d = CopilotEngine.diagnose(filter().copy(roastAgeDays = 70), setOf(Symptom.FLAT))!!
        assertEquals(CopilotEngine.Cause.STALE_COFFEE, d.cause)
        assertFalse(d.recipeChanged)
    }

    /** Core rule of the copilot: whatever the symptom and method, at most one recipe variable moves. */
    @Test fun neverChangesMoreThanOneVariable() {
        val inputs = listOf(filter(), filter(temp = 96.0, time = 240, grind = "20"), filter(temp = null, time = null), shot(), shot(yieldG = 45.0, time = 35, temp = null))
        for (input in inputs) for (s in Symptom.entries) {
            val d = CopilotEngine.diagnose(input, setOf(s))
            assertNotNull("$s on ${input.method}", d)
            val sg = d!!.suggestion
            val changed = listOf(sg.doseG != input.doseG, sg.waterG != input.waterG, sg.tempC != input.tempC, sg.grind != input.grind, sg.steps != input.steps).count { it }
            assertTrue("$s on ${input.method} changed $changed variables", changed <= 1)
            assertTrue(d.variables.isNotEmpty())
        }
        assertNull(CopilotEngine.diagnose(filter(), emptySet()))
    }
}

class FoldStateResolverTest {
    private val flatHinge = HingeInfo(880, 0, 880, 1900, vertical = true, halfOpened = false)
    private val tabletop = HingeInfo(0, 950, 1760, 950, vertical = false, halfOpened = true)

    @Test fun coverScreenIsClosed() {
        assertEquals(Posture.CLOSED, FoldStateResolver.resolve(384f, 870f, null, LayoutOverride.AUTO).posture)
        // Cover screen in landscape is wide but far too short to be a workstation.
        assertEquals(Posture.CLOSED, FoldStateResolver.resolve(870f, 384f, null, LayoutOverride.AUTO).posture)
    }

    @Test fun innerScreenIsOpenAndHalfFoldIsFlex() {
        assertEquals(Posture.OPEN, FoldStateResolver.resolve(840f, 950f, flatHinge, LayoutOverride.AUTO).posture)
        assertEquals(Posture.OPEN, FoldStateResolver.resolve(840f, 950f, null, LayoutOverride.AUTO).posture)
        val flex = FoldStateResolver.resolve(840f, 950f, tabletop, LayoutOverride.AUTO)
        assertEquals(Posture.FLEX, flex.posture)
        assertEquals(tabletop, flex.hinge)
    }

    @Test fun overrideWins() {
        assertEquals(Posture.FLEX, FoldStateResolver.resolve(384f, 870f, null, LayoutOverride.FLEX).posture)
        assertEquals(Posture.CLOSED, FoldStateResolver.resolve(840f, 950f, tabletop, LayoutOverride.CLOSED).posture)
    }
}

class VoiceCommandParserTest {
    @Test fun parsesTheCommandsFromTheBrief() {
        assertEquals(VoiceCommand.Start, VoiceCommandParser.parse("Start timer"))
        assertEquals(VoiceCommand.Pause, VoiceCommandParser.parse("Pause"))
        assertEquals(VoiceCommand.AddWater(50.0), VoiceCommandParser.parse("Add 50 grams"))
        assertEquals(VoiceCommand.NextStep, VoiceCommandParser.parse("Next step"))
        assertEquals(VoiceCommand.Reset, VoiceCommandParser.parse("Reset"))
        assertEquals(VoiceCommand.AskRatio, VoiceCommandParser.parse("What's my ratio?"))
        assertEquals(VoiceCommand.AddWater(37.5), VoiceCommandParser.parse("ajoute 37,5 grammes"))
        assertEquals(VoiceCommand.NextStep, VoiceCommandParser.parse("étape suivante"))
        assertEquals(VoiceCommand.Start, VoiceCommandParser.parse("démarre"))
        assertEquals(VoiceCommand.NextStep, VoiceCommandParser.parse("siguiente paso"))
        assertEquals(VoiceCommand.Unknown, VoiceCommandParser.parse("tell me a joke"))
    }
}
