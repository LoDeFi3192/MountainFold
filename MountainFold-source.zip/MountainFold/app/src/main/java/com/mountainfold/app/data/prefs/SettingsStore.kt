package com.mountainfold.app.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.FlexLayout
import com.mountainfold.app.core.model.LayoutOverride
import com.mountainfold.app.core.model.Palette
import com.mountainfold.app.core.model.TempUnit
import com.mountainfold.app.core.model.ThemeMode
import com.mountainfold.app.core.model.WeightUnit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class Settings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val palette: Palette = Palette.COFFEE,
    val defaultMethod: BrewMethod = BrewMethod.V60,
    val defaultDoseG: Double = 15.0,
    val autoStopAtTarget: Boolean = false,
    val haptics: Boolean = true,
    val sounds: Boolean = false,
    val keepAwake: Boolean = true,
    val weightUnit: WeightUnit = WeightUnit.G,
    val tempUnit: TempUnit = TempUnit.C,
    val layoutOverride: LayoutOverride = LayoutOverride.AUTO,
    val flexLayout: FlexLayout = FlexLayout.BREW,
    val waterStepG: Double = 50.0,
    val onboarded: Boolean = false,
    val currentCoffeeId: Long? = null,
    val lastRecipeId: Long? = null,
    val defaultGrinderId: Long? = null,
    val preferredMethods: List<BrewMethod> = emptyList(),
    /** Lesson whose real-brew follow up is waiting for the next logged brew. */
    val pendingBrewChallenge: String? = null,
    /** Toulouse Cupping session currently on the table. */
    val cuppingSessionId: String? = null,
    /** Address encoded in the cupping invite QR code. */
    val cuppingInviteUrl: String = com.mountainfold.app.core.cupping.CuppingCatalog.DEFAULT_INVITE_URL,
)

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore("settings")

/** Preferences live in DataStore as one JSON document, which keeps backup and restore trivial. */
class SettingsStore(private val context: Context) {
    private val key = stringPreferencesKey("settings_json")
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; coerceInputValues = true }

    val settings: Flow<Settings> = context.dataStore.data
        .catch { emit(androidx.datastore.preferences.core.emptyPreferences()) }
        .map { prefs -> decode(prefs[key]) }

    private fun decode(raw: String?): Settings =
        if (raw == null) Settings() else runCatching { json.decodeFromString<Settings>(raw) }.getOrDefault(Settings())

    suspend fun update(transform: (Settings) -> Settings) {
        context.dataStore.edit { prefs ->
            prefs[key] = json.encodeToString(Settings.serializer(), transform(decode(prefs[key])))
        }
    }

    suspend fun replace(settings: Settings) = update { settings }
}

/** Language is read before the first frame, so it sits in SharedPreferences for a synchronous read. */
object LanguageStore {
    const val SYSTEM = "system"
    val supported = listOf("en", "fr", "es")
    private const val FILE = "language"
    private const val KEY = "lang"

    fun get(context: Context): String =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY, SYSTEM) ?: SYSTEM

    fun set(context: Context, lang: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY, lang).commit()
    }

    /** Wraps a base context so resources resolve in the chosen language. */
    fun wrap(base: Context): Context {
        val lang = get(base)
        if (lang == SYSTEM || lang !in supported) return base
        val config = android.content.res.Configuration(base.resources.configuration)
        config.setLocale(java.util.Locale.forLanguageTag(lang))
        return base.createConfigurationContext(config)
    }
}
