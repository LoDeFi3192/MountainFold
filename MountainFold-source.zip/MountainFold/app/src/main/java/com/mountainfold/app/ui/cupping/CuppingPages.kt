package com.mountainfold.app.ui.cupping

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mountainfold.app.R
import com.mountainfold.app.core.cupping.CuppingCatalog
import com.mountainfold.app.core.cupping.CuppingCsv
import com.mountainfold.app.core.cupping.CuppingFormat
import com.mountainfold.app.data.db.CuppingCoffee
import com.mountainfold.app.data.db.LabRecipe
import com.mountainfold.app.service.CuppingPdf
import com.mountainfold.app.ui.MainViewModel
import com.mountainfold.app.ui.theme.TimerStyle
import java.time.LocalDate

private val Heart = Color(0xFFEF4444)

// ---------------------------------------------------------------------------------------------
// Summary table and exports
// ---------------------------------------------------------------------------------------------

@Composable
fun SummaryPage(vm: MainViewModel, wide: Boolean) {
    val cup = vm.cup
    val s = cup.session ?: return
    val coffees = cup.coffees
    val lang = rememberCupLang()
    val context = LocalContext.current
    var pending by remember { mutableStateOf<ByteArray?>(null) }
    val saveCsv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        val bytes = pending
        if (uri != null && bytes != null) vm.writeCuppingFile(uri, bytes)
    }
    val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val bytes = pending
        if (uri != null && bytes != null) vm.writeCuppingFile(uri, bytes)
    }

    val name = stringResource(R.string.cup_coffee_name)
    val fav = stringResource(R.string.cup_fav)
    val process = stringResource(R.string.cup_process)
    val score = stringResource(R.string.cup_score)
    val fragrance = stringResource(R.string.cup_fragrance)
    val flavor = stringResource(R.string.cup_flavor)
    val aftertaste = stringResource(R.string.cup_aftertaste)
    val acidity = stringResource(R.string.cup_acidity)
    val body = stringResource(R.string.cup_body)
    val balance = stringResource(R.string.cup_balance)
    val csvHeaders = listOf(
        name, fav, process, score, stringResource(R.string.cup_notes_col), fragrance, flavor, aftertaste, acidity, body, balance,
        stringResource(R.string.cup_comments),
    )
    val pdfHeaders = listOf(name, fav, process, score, stringResource(R.string.cup_sensory_profile), fragrance, flavor, aftertaste, acidity, body, balance)
    val yes = stringResource(R.string.cup_yes)
    val no = stringResource(R.string.cup_no)
    val dateLabel = stringResource(R.string.cup_date)
    val shownDate = cupDate(s.dateIso)
    val title = stringResource(R.string.cup_report_title)
    val subtitle = stringResource(R.string.cup_report_line, dateLabel, shownDate)
    val locationLine = if (s.location.isNotBlank()) stringResource(R.string.cup_location) + ": " + s.location else null
    val origins = stringResource(R.string.cup_origins)
    val roaster = stringResource(R.string.cup_roaster)
    val meta = listOfNotNull(
        s.originNotes.takeIf { it.isNotBlank() }?.let { "$origins: $it" },
        s.roasterNotes.takeIf { it.isNotBlank() }?.let { "$roaster: $it" },
    ).joinToString(" | ").ifEmpty { null }
    val pageLabel = stringResource(R.string.cup_page_of, 0, 0)
    val pageTemplate = remember(pageLabel) { context.resources }

    fun pdfPlan(): CuppingPdf.Plan = CuppingPdf.plan(
        coffees,
        CuppingPdf.Texts(title, subtitle, locationLine, meta, pdfHeaders) { i, n -> pageTemplate.getString(R.string.cup_page_of, i, n) },
    ) { CuppingCatalog.label(it, lang) }

    Column(Modifier.fillMaxSize()) {
        PageHeader(stringResource(R.string.cup_summary)) { cup.screen = CupScreen.MAIN }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            if (wide) SummaryTable(coffees, lang) else coffees.forEach { SummaryCard(it, lang) }
            Spacer(Modifier.height(32.dp))
            val buttons: @Composable (Modifier) -> Unit = { m ->
                OutlinedButton(onClick = {
                    pending = ("﻿" + CuppingCsv.build(coffees, csvHeaders, yes, no) { CuppingCatalog.label(it, lang) }).toByteArray(Charsets.UTF_8)
                    runCatching { saveCsv.launch("cupping_session_${LocalDate.now()}.csv") }
                }, modifier = m) { Text("📥 " + stringResource(R.string.cup_csv)) }
                FilledTonalButton(onClick = {
                    runCatching {
                        val plan = pdfPlan()
                        CuppingPdf.print(context, "cupping_rapport_${LocalDate.now()}", CuppingPdf.render(plan), plan.pageCount)
                    }
                }, modifier = m) { Text("🖨️ " + stringResource(R.string.cup_print)) }
                Button(onClick = {
                    pending = runCatching { CuppingPdf.render(pdfPlan()) }.getOrNull()
                    runCatching { savePdf.launch("cupping_rapport_${LocalDate.now()}.pdf") }
                }, modifier = m) {
                    Icon(TcIcons.Printer, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.cup_pdf))
                }
            }
            if (wide) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)) { buttons(Modifier) }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) { buttons(Modifier.fillMaxWidth()) }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SummaryCard(c: CuppingCoffee, lang: String) {
    val colors = MaterialTheme.colorScheme
    Surface(
        color = colors.surfaceContainerLow,
        shape = RoundedCornerShape(16.dp),
        shadowElevation = 1.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, colors.outline.copy(alpha = 0.1f)),
        modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
    ) {
        Column {
            Row(Modifier.fillMaxWidth().background(colors.surfaceContainerHigh).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                if (c.isFavorite) {
                    Icon(TcIcons.HeartFilled, contentDescription = stringResource(R.string.cup_favorite), tint = Heart, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                }
                Text(c.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End) {
                    Text(stringResource(R.string.cup_score).uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = colors.onSurfaceVariant)
                    Text(CuppingFormat.fixed2(c.finalScore), style = MaterialTheme.typography.headlineSmall.copy(fontFeatureSettings = "tnum"), color = colors.primary)
                }
            }
            HorizontalDivider(color = colors.outline.copy(alpha = 0.1f))
            val cells = listOf(
                stringResource(R.string.cup_fragrance) to c.fragranceScore, stringResource(R.string.cup_flavor) to c.flavorScore,
                stringResource(R.string.cup_acidity) to c.acidityScore, stringResource(R.string.cup_body) to c.bodyScore,
                stringResource(R.string.cup_aftertaste) to c.aftertasteScore, stringResource(R.string.cup_balance) to c.balanceScore,
            )
            Column(Modifier.fillMaxWidth().background(colors.surfaceContainerLow).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                cells.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { (l, v) ->
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(l.uppercase(), fontSize = 10.sp, color = colors.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(CuppingFormat.jsNumber(v), style = MaterialTheme.typography.titleMedium, color = colors.onSurface)
                            }
                        }
                    }
                }
            }
            HorizontalDivider(color = colors.outline.copy(alpha = 0.1f))
            Column(Modifier.fillMaxWidth().background(colors.surface).padding(16.dp)) {
                if (c.process.isNotEmpty()) {
                    Row(Modifier.padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.cup_process) + ":", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = colors.onSurfaceVariant)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            CuppingCatalog.label(c.process, lang), style = MaterialTheme.typography.labelSmall, color = colors.primary,
                            modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(colors.primary.copy(alpha = 0.1f)).padding(horizontal = 8.dp, vertical = 2.dp),
                        )
                    }
                }
                NoteTags(c.uniqueNotes, lang)
                if (c.comments.isNotBlank()) {
                    Text(
                        "\"${c.comments}\"",
                        style = MaterialTheme.typography.bodyMedium.copy(fontStyle = FontStyle.Italic),
                        color = colors.onSurfaceVariant.copy(alpha = 0.8f),
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun NoteTags(notes: List<String>, lang: String, modifier: Modifier = Modifier) {
    if (notes.isEmpty()) return
    val colors = MaterialTheme.colorScheme
    FlowRow(modifier, horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        notes.forEach { n ->
            Text(
                CuppingCatalog.label(n, lang),
                style = MaterialTheme.typography.labelSmall,
                color = colors.onSurfaceVariant,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(colors.surfaceContainerHighest)
                    .border(1.dp, colors.outline.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 2.dp),
            )
        }
    }
}

/** Desktop table of the original: sticky name column, horizontal scroll for the rest. */
@Composable
private fun SummaryTable(coffees: List<CuppingCoffee>, lang: String) {
    val colors = MaterialTheme.colorScheme
    val h = rememberScrollState()
    val nameW = 170.dp
    val cols: List<Pair<String, Dp>> = listOf(
        stringResource(R.string.cup_fav) to 56.dp,
        stringResource(R.string.cup_process) to 120.dp,
        stringResource(R.string.cup_score) to 88.dp,
        stringResource(R.string.cup_aroma_profile) to 260.dp,
        stringResource(R.string.cup_fragrance) to 124.dp,
        stringResource(R.string.cup_flavor) to 124.dp,
        stringResource(R.string.cup_aftertaste) to 124.dp,
        stringResource(R.string.cup_acidity) to 124.dp,
        stringResource(R.string.cup_body) to 124.dp,
        stringResource(R.string.cup_balance) to 124.dp,
    )
    Surface(
        color = colors.surfaceContainerLow,
        shape = RoundedCornerShape(12.dp),
        shadowElevation = 3.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, colors.outline.copy(alpha = 0.1f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.horizontalScroll(h)) {
            Row(Modifier.height(IntrinsicSize.Min).background(colors.surfaceContainerHigh)) {
                StickyCell(nameW, h.value, colors.surfaceContainerHigh) {
                    Text(stringResource(R.string.cup_coffee_name).uppercase(), style = MaterialTheme.typography.labelMedium, color = colors.onSurface)
                }
                cols.forEachIndexed { i, (label, w) ->
                    Box(Modifier.width(w).fillMaxHeight().padding(horizontal = 12.dp, vertical = 12.dp), contentAlignment = if (i == 3) Alignment.CenterStart else Alignment.Center) {
                        Text(label.uppercase(), style = MaterialTheme.typography.labelMedium, color = colors.onSurface, textAlign = if (i == 3) TextAlign.Start else TextAlign.Center)
                    }
                }
            }
            HorizontalDivider(Modifier.width(nameW + cols.fold(0.dp) { a, c -> a + c.second }), color = colors.outline.copy(alpha = 0.1f))
            coffees.forEach { c ->
                Row(Modifier.height(IntrinsicSize.Min).background(colors.surface)) {
                    StickyCell(nameW, h.value, colors.surface) {
                        Text(c.name, style = MaterialTheme.typography.titleSmall, color = colors.onSurface, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    Cell(cols[0].second) { if (c.isFavorite) Icon(TcIcons.HeartFilled, contentDescription = stringResource(R.string.cup_favorite), tint = Heart, modifier = Modifier.size(20.dp)) }
                    Cell(cols[1].second) { Text(c.process.ifEmpty { "-" }.let { if (it == "-") it else CuppingCatalog.label(it, lang) }, style = MaterialTheme.typography.bodySmall) }
                    Box(Modifier.width(cols[2].second).fillMaxHeight().background(colors.primary.copy(alpha = 0.06f)), contentAlignment = Alignment.Center) {
                        Text(CuppingFormat.fixed2(c.finalScore), style = MaterialTheme.typography.titleSmall.copy(fontFeatureSettings = "tnum"), color = colors.primary)
                    }
                    Box(Modifier.width(cols[3].second).fillMaxHeight().padding(horizontal = 12.dp, vertical = 10.dp), contentAlignment = Alignment.CenterStart) {
                        NoteTags(c.uniqueNotes, lang)
                    }
                    listOf(c.fragranceScore, c.flavorScore, c.aftertasteScore, c.acidityScore, c.bodyScore, c.balanceScore).forEachIndexed { i, v ->
                        Cell(cols[4 + i].second) { Text(CuppingFormat.jsNumber(v), style = MaterialTheme.typography.bodyMedium, color = colors.onSurface) }
                    }
                }
                HorizontalDivider(Modifier.width(nameW + cols.fold(0.dp) { a, col -> a + col.second }), color = colors.outline.copy(alpha = 0.1f))
            }
        }
    }
}

@Composable
private fun StickyCell(width: Dp, scroll: Int, bg: Color, content: @Composable () -> Unit) {
    Box(
        Modifier
            .zIndex(1f)
            .graphicsLayer { translationX = scroll.toFloat() }
            .width(width)
            .fillMaxHeight()
            .background(bg)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.CenterStart,
    ) { content() }
}

@Composable
private fun Cell(width: Dp, content: @Composable () -> Unit) {
    Box(Modifier.width(width).fillMaxHeight().padding(8.dp), contentAlignment = Alignment.Center) { content() }
}

// ---------------------------------------------------------------------------------------------
// Brewing Lab
// ---------------------------------------------------------------------------------------------

private fun labIcon(id: String) = when (CuppingCatalog.LabMethod.of(id)) {
    CuppingCatalog.LabMethod.CHEMEX -> TcIcons.Chemex
    CuppingCatalog.LabMethod.AEROPRESS -> TcIcons.Aeropress
    CuppingCatalog.LabMethod.FRENCH_PRESS -> TcIcons.FrenchPress
    CuppingCatalog.LabMethod.MOKA -> TcIcons.Moka
    else -> TcIcons.V60
}

@Composable
private fun LabTitle(vm: MainViewModel) {
    Row(Modifier.fillMaxWidth().padding(bottom = 24.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("☕ " + stringResource(R.string.cup_brewing_lab), style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
        OutlinedButton(onClick = { vm.cup.screen = CupScreen.MAIN }) { Text(stringResource(R.string.back)) }
    }
}

@Composable
fun LabForm(vm: MainViewModel, lang: String, showHistoryButton: Boolean, desk: Boolean = false) {
    val cup = vm.cup
    val d = cup.lab
    val colors = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        if (!desk && showHistoryButton) LabTitle(vm)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(vertical = 8.dp), modifier = Modifier.padding(bottom = 16.dp)) {
            items(CuppingCatalog.LabMethod.entries) { m ->
                val on = d.method == m.id
                Surface(
                    color = if (on) colors.primary else colors.surfaceContainerHigh,
                    contentColor = if (on) colors.onPrimary else colors.onSurfaceVariant,
                    shape = RoundedCornerShape(16.dp),
                    shadowElevation = if (on) 3.dp else 0.dp,
                    modifier = Modifier.scale(if (on) 1.05f else 1f).clip(RoundedCornerShape(16.dp)).clickable(role = Role.RadioButton) { cup.pickMethod(m.id) },
                ) {
                    Column(Modifier.widthIn(min = 80.dp).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(labIcon(m.id), contentDescription = null, modifier = Modifier.size(32.dp))
                        Spacer(Modifier.height(8.dp))
                        Text(CuppingCatalog.labMethodName(m.id, lang), style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
        }
        TcCard {
            TcSectionTitle(stringResource(R.string.cup_recipe), null)
            Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(bottom = 16.dp)) {
                LabNumber(stringResource(R.string.cup_coffee_weight), d.coffee, Modifier.weight(1f)) { v -> cup.lab = cup.lab.copy(coffee = v) }
                Text("×", style = MaterialTheme.typography.headlineSmall, color = colors.onSurface.copy(alpha = 0.5f), modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp))
                LabNumber(stringResource(R.string.cup_ratio), d.ratio, Modifier.weight(1f)) { v -> cup.lab = cup.lab.copy(ratio = v) }
            }
            if (!desk) WaterBox(d.water)
            Text(stringResource(R.string.cup_grind_size), style = MaterialTheme.typography.labelMedium, color = colors.onSurfaceVariant, modifier = Modifier.padding(top = 16.dp, bottom = 4.dp))
            OutlinedTextField(
                value = d.grind, onValueChange = { v -> cup.lab = cup.lab.copy(grind = v) }, singleLine = true,
                placeholder = { Text(stringResource(R.string.cup_grind_placeholder)) },
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (!desk) {
            TcCard {
                LabStopwatch(cup, 57.sp)
            }
        }
        TcCard {
            TcSectionTitle(stringResource(R.string.cup_cup_result), TcIcons.Comment)
            TcSlider(stringResource(R.string.cup_global_rating), d.rating, { v -> cup.lab = cup.lab.copy(rating = v) }, min = 1.0, max = 10.0, step = 0.5)
            OutlinedTextField(
                value = d.notes, onValueChange = { v -> cup.lab = cup.lab.copy(notes = v) }, minLines = 4,
                placeholder = { Text(stringResource(R.string.cup_notes_placeholder)) },
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = colors.surfaceContainerHighest, focusedContainerColor = colors.surfaceContainerHighest),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(bottom = 24.dp)) {
            if (showHistoryButton) {
                FilledTonalButton(onClick = { cup.labHistory = true }, modifier = Modifier.weight(1f)) { Text("📂 " + stringResource(R.string.cup_history), maxLines = 1) }
            }
            Button(onClick = { cup.saveLab(); vm.say(R.string.cup_saved) }, modifier = Modifier.weight(1f)) { Text("💾 " + stringResource(R.string.save), maxLines = 1) }
        }
    }
}

@Composable
private fun LabNumber(label: String, value: String, modifier: Modifier, onChange: (String) -> Unit) {
    val colors = MaterialTheme.colorScheme
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = colors.onSurfaceVariant, modifier = Modifier.padding(bottom = 4.dp))
        OutlinedTextField(
            value = value,
            onValueChange = { v -> onChange(v.filter { it.isDigit() || it == '.' || it == ',' }) },
            singleLine = true,
            textStyle = MaterialTheme.typography.headlineSmall.copy(textAlign = TextAlign.Center, fontWeight = FontWeight.Bold),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = colors.surfaceContainerHighest, focusedContainerColor = colors.surfaceContainerHighest),
            modifier = Modifier.fillMaxWidth().semantics { contentDescription = label },
        )
    }
}

@Composable
private fun WaterBox(water: Int, big: Boolean = false) {
    val colors = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(colors.secondaryContainer).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(stringResource(R.string.cup_water_required), style = MaterialTheme.typography.labelLarge, color = colors.onSecondaryContainer)
        Text(
            "${water}g",
            style = MaterialTheme.typography.displayMedium.copy(fontSize = if (big) 64.sp else 45.sp, fontFeatureSettings = "tnum"),
            color = colors.primary,
        )
    }
}

@Composable
private fun LabStopwatch(cup: CuppingController, size: androidx.compose.ui.unit.TextUnit) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            CuppingFormat.clock(cup.labSeconds),
            style = TimerStyle.copy(fontSize = size, lineHeight = size),
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(bottom = 16.dp),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            if (cup.labRunning) {
                OutlinedButton(onClick = cup::toggleLabTimer, modifier = Modifier.width(128.dp)) { Text(stringResource(R.string.pause)) }
            } else {
                Button(onClick = cup::toggleLabTimer, modifier = Modifier.width(128.dp)) { Text(stringResource(R.string.start)) }
            }
            FilledTonalButton(onClick = cup::resetLabTimer) { Text(stringResource(R.string.cup_reset)) }
        }
    }
}

/** Flex top half of the Lab: water to pour and the stopwatch, readable from the counter. */
@Composable
fun LabDeskTop(vm: MainViewModel, lang: String) {
    val cup = vm.cup
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val clock = (maxHeight.value * 0.32f).coerceIn(40f, 120f).sp
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 12.dp)) {
                    Icon(labIcon(cup.lab.method), contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(CuppingCatalog.labMethodName(cup.lab.method, lang), style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    OutlinedButton(onClick = { cup.screen = CupScreen.MAIN }) { Text(stringResource(R.string.back)) }
                }
                WaterBox(cup.lab.water, big = true)
            }
            Box(Modifier.weight(1f)) { LabStopwatch(cup, clock) }
        }
    }
}

@Composable
fun LabHistoryPane(vm: MainViewModel, lang: String, standalone: Boolean) {
    val cup = vm.cup
    val recipes by cup.labRecipes.collectAsStateWithLifecycle()
    val colors = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        if (standalone) LabTitle(vm)
        Text(stringResource(R.string.cup_history), style = MaterialTheme.typography.titleMedium, color = colors.onSurface, modifier = Modifier.padding(bottom = 16.dp))
        if (recipes.isEmpty()) {
            Text(stringResource(R.string.cup_no_recipes), style = MaterialTheme.typography.bodyMedium.copy(fontStyle = FontStyle.Italic), color = colors.onSurfaceVariant.copy(alpha = 0.6f))
        }
        recipes.forEach { r -> LabCard(cup, r, lang) }
        if (!standalone) {
            FilledTonalButton(onClick = { cup.labHistory = false }, modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) { Text(stringResource(R.string.cup_close_history)) }
        }
    }
}

@Composable
private fun LabCard(cup: CuppingController, r: LabRecipe, lang: String) {
    val colors = MaterialTheme.colorScheme
    Surface(
        color = colors.surfaceContainerLow, shape = RoundedCornerShape(16.dp), shadowElevation = 1.dp,
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(16.dp)).clickable { cup.loadLab(r) },
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(CuppingCatalog.labMethodName(r.method, lang), style = MaterialTheme.typography.titleMedium, color = colors.primary)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            CuppingFormat.jsNumber(r.rating) + "/10",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = colors.primary,
                            modifier = Modifier.clip(CircleShape).background(colors.primary.copy(alpha = 0.1f)).padding(horizontal = 8.dp, vertical = 2.dp),
                        )
                    }
                    Text(cupDate(r.timestamp), style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant)
                }
                IconButton(onClick = { cup.pendingDeleteRecipe = r }) {
                    Icon(TcIcons.DeleteSession, contentDescription = stringResource(R.string.cup_confirm_delete_recipe), tint = colors.error, modifier = Modifier.size(20.dp))
                }
            }
            Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row {
                    Text("☕ ${CuppingFormat.jsNumber(r.coffeeWeight)}g", style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant, modifier = Modifier.weight(1f))
                    Text("💧 ${r.waterWeight}g (1:${CuppingFormat.jsNumber(r.ratio)})", style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant, modifier = Modifier.weight(1f))
                }
                Row {
                    Text("⏱️ ${CuppingFormat.clock(r.totalTime)}", style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant, modifier = Modifier.weight(1f))
                    Text("⚙️ ${r.grindSize.ifBlank { "-" }}", style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            if (r.notes.isNotBlank()) {
                HorizontalDivider(Modifier.padding(top = 8.dp), color = colors.outline.copy(alpha = 0.1f))
                Text(
                    "\"${r.notes}\"",
                    style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic),
                    color = colors.onSurface.copy(alpha = 0.8f),
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
    }
}
