package com.mountainfold.app.core.weight

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Source of the weight on the scale. The MVP ships [ManualWeightProvider].
 * A Bluetooth LE scale only needs to implement this interface and set [isLive] to true.
 */
interface WeightProvider {
    val weightG: StateFlow<Double>
    /** True when readings come from hardware and manual edits should be hidden. */
    val isLive: Boolean
    fun set(grams: Double)
    fun add(deltaG: Double)
    fun tare()
}

class ManualWeightProvider : WeightProvider {
    private val _weight = MutableStateFlow(0.0)
    override val weightG: StateFlow<Double> = _weight.asStateFlow()
    override val isLive: Boolean = false
    override fun set(grams: Double) { _weight.value = grams.coerceAtLeast(0.0) }
    override fun add(deltaG: Double) { _weight.value = (_weight.value + deltaG).coerceAtLeast(0.0) }
    override fun tare() { _weight.value = 0.0 }
}
