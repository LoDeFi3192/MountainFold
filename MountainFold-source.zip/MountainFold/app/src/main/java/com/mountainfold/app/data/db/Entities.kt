package com.mountainfold.app.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "coffees")
data class Coffee(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String = "",
    val origin: String = "",
    val country: String = "",
    val region: String = "",
    val producer: String = "",
    val variety: String = "",
    val process: String = "",
    val altitude: String = "",
    val roaster: String = "",
    /** Days since 1970-01-01, local date. */
    val roastDateEpochDay: Long? = null,
    val tastingNotes: String = "",
    val roastLevel: String = "",
    val photoPath: String? = null,
    val createdAt: Long = 0,
)

@Serializable
@Entity(tableName = "recipes")
data class Recipe(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String = "",
    val method: String = "V60",
    val coffeeId: Long? = null,
    val doseG: Double = 15.0,
    /** Brew water for filter methods, yield in the cup for espresso. */
    val waterG: Double = 250.0,
    val tempC: Double? = 93.0,
    val grind: String = "",
    val pressureBar: Double? = null,
    val targetTimeS: Int = 180,
    /** JSON list of BrewStep. */
    val stepsJson: String = "[]",
    val notes: String = "",
    val favorite: Boolean = false,
    val createdAt: Long = 0,
    val updatedAt: Long = 0,
)

@Serializable
@Entity(tableName = "brews")
data class Brew(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val coffeeId: Long? = null,
    val recipeId: Long? = null,
    val coffeeName: String = "",
    val recipeName: String = "",
    val method: String = "V60",
    val doseG: Double = 0.0,
    val waterG: Double = 0.0,
    val tempC: Double? = null,
    val grind: String = "",
    val grinderId: Long? = null,
    val grinderName: String = "",
    val pressureBar: Double? = null,
    val timeMs: Long = 0,
    val targetTimeS: Int = 0,
    val notes: String = "",
    val rating: Int = 0,
    val acidity: Int = 0,
    val sweetness: Int = 0,
    val body: Int = 0,
    val balance: Int = 0,
    val clarity: Int = 0,
    /** Comma separated Symptom names. */
    val symptoms: String = "",
    val stepsJson: String = "[]",
    val createdAt: Long = 0,
)

@Serializable
@Entity(tableName = "grinders")
data class Grinder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String = "",
    val notes: String = "",
)

/** One training activity. Levels, XP and skill scores are all derived from these rows. */
@Serializable
@Entity(tableName = "training_events")
data class TrainingEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long = 0,
    /** EventKind name. */
    val kind: String = "",
    /** Lesson id, "filter" / "espresso", exam category, "level:N" or "day:N". */
    val refId: String = "",
    /** Primary Skill name, or empty when the activity mixes skills. */
    val skill: String = "",
    val correct: Int = 0,
    val total: Int = 0,
    val durationS: Int = 0,
    val xp: Int = 0,
    val passed: Boolean = false,
    /** Per-skill results, "EXTRACTION:3/4;ESPRESSO:1/2". */
    val breakdown: String = "",
)
