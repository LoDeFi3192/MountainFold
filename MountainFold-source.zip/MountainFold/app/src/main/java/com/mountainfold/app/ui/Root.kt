package com.mountainfold.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.Coffee
import androidx.compose.material.icons.rounded.CoffeeMaker
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Terrain
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mountainfold.app.R
import com.mountainfold.app.core.fold.FoldState
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.fold.Posture
import com.mountainfold.app.core.model.LayoutOverride
import com.mountainfold.app.data.prefs.Settings
import com.mountainfold.app.ui.components.ConfirmDialog
import com.mountainfold.app.ui.components.NavLabel
import com.mountainfold.app.ui.screens.BrewScreen
import com.mountainfold.app.ui.screens.CalculatorScreen
import com.mountainfold.app.ui.screens.CoffeeScreen
import com.mountainfold.app.ui.screens.CompareScreen
import com.mountainfold.app.ui.screens.DiagnoseScreen
import com.mountainfold.app.ui.screens.FlexCompanion
import com.mountainfold.app.ui.screens.GrindAdvisorScreen
import com.mountainfold.app.ui.screens.HistoryScreen
import com.mountainfold.app.ui.screens.HomeScreen
import com.mountainfold.app.ui.screens.LogBrewScreen
import com.mountainfold.app.ui.screens.OnboardingScreen
import com.mountainfold.app.ui.screens.RecipesScreen
import com.mountainfold.app.ui.screens.SettingsScreen
import com.mountainfold.app.ui.screens.TrainDesk
import com.mountainfold.app.ui.screens.TrainScreen as TrainTab
import com.mountainfold.app.ui.screens.isTrainDesk
import com.mountainfold.app.ui.screens.reducedMotion
import com.mountainfold.app.ui.theme.MountainFoldTheme
import com.mountainfold.app.ui.cupping.CuppingDesk
import com.mountainfold.app.ui.cupping.CuppingTab
import com.mountainfold.app.ui.cupping.TcIcons
import com.mountainfold.app.ui.cupping.cupHidesBar
import com.mountainfold.app.ui.cupping.isCupDesk

private enum class LayoutKind { COMPANION, TRAIN_DESK, CUP_DESK, WIDE, COMPACT }

/**
 * Root of the UI. Chooses one of three layouts from the posture.
 * No screen state lives below this point that a layout swap could destroy:
 * the brew session is application-scoped and drafts sit in the ViewModel.
 */
@Composable
fun MountainFoldRoot(
    vm: MainViewModel,
    foldState: @Composable (LayoutOverride) -> FoldState,
    requestNotifications: () -> Unit = {},
) {
    val loaded by vm.settings.collectAsStateWithLifecycle()
    val settings = loaded
    MountainFoldTheme(settings ?: Settings()) {
        Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
            when {
                settings == null -> Unit
                !settings.onboarded -> OnboardingScreen(vm)
                else -> App(vm, settings, foldState(settings.layoutOverride), requestNotifications)
            }
        }
    }
}

@Composable
private fun App(vm: MainViewModel, settings: Settings, fold: FoldState, requestNotifications: () -> Unit) {
    val session by vm.session.state.collectAsStateWithLifecycle()
    val timer by vm.session.timer.state.collectAsStateWithLifecycle()
    val view = LocalView.current
    val reduced = reducedMotion()
    val snackbar = remember { SnackbarHostState() }

    // Screen stays on only while a brew is running, then the phone behaves normally again.
    val cupTimerRunning = vm.cup.timerState.running
    DisposableEffect(timer.running, cupTimerRunning, settings.keepAwake) {
        view.keepScreenOn = (timer.running || cupTimerRunning) && settings.keepAwake
        onDispose { view.keepScreenOn = false }
    }
    LaunchedEffect(timer.running) { if (timer.running) requestNotifications() }
    LaunchedEffect(session.finished) { if (session.finished) vm.openLog() }
    LaunchedEffect(fold.posture) { if (fold.posture != Posture.FLEX) vm.flexBrowse = false }

    val message = vm.message
    val messageText = message?.let { if (it.arg != null) stringResource(it.resId, it.arg) else stringResource(it.resId) }
    LaunchedEffect(message) {
        if (messageText != null) {
            snackbar.showSnackbar(messageText)
            if (vm.message == message) vm.message = null
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val widthDp = maxWidth.value
        val landscape = maxWidth > maxHeight
        val flexFree = fold.posture == Posture.FLEX && vm.overlays.isEmpty()
        // In Flex the app is a desk: a training desk while a lesson or quiz is open, the brew companion otherwise.
        val trainDesk = flexFree && vm.tab == Tab.TRAIN && isTrainDesk(vm.trainScreen)
        // Cupping on a half-folded phone: timer on top, scores at hand on the bottom.
        val cupDesk = flexFree && vm.tab == Tab.CUPPING && isCupDesk(vm.cup.screen)
        val companion = flexFree && !vm.flexBrowse && vm.tab != Tab.TRAIN && vm.tab != Tab.CUPPING
        val wide = fold.posture == Posture.OPEN || (fold.posture == Posture.FLEX && widthDp >= 600f)
        val kind = when {
            trainDesk -> LayoutKind.TRAIN_DESK
            cupDesk -> LayoutKind.CUP_DESK
            companion -> LayoutKind.COMPANION
            wide -> LayoutKind.WIDE
            else -> LayoutKind.COMPACT
        }
        // In a half-folded tabletop posture the two-pane split would fight the horizontal hinge.
        val hinge = fold.hinge?.takeIf { it.vertical }

        BackHandler(enabled = !companion && vm.canGoBack(compact = !wide)) { vm.back() }

        AnimatedContent(
            targetState = kind,
            transitionSpec = {
                if (reduced) fadeIn(snap()) togetherWith fadeOut(snap())
                else fadeIn(tween(220, delayMillis = 60)) togetherWith fadeOut(tween(90))
            },
            label = "posture",
        ) { k ->
            when (k) {
                LayoutKind.COMPANION -> FlexCompanion(vm, settings, fold.hinge)
                LayoutKind.TRAIN_DESK -> TrainDesk(vm, settings, fold.hinge)
                LayoutKind.CUP_DESK -> CuppingDesk(vm, settings, fold.hinge)
                LayoutKind.WIDE -> WideScaffold(vm, settings, hinge, timer.running)
                LayoutKind.COMPACT -> CompactScaffold(vm, settings, landscape, timer.running)
            }
        }
        SnackbarHost(
            snackbar,
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = if (kind == LayoutKind.COMPACT && !landscape) 88.dp else 16.dp),
        )
    }

    vm.pendingReplace?.let { next ->
        ConfirmDialog(
            stringResource(R.string.replace_brew_title),
            stringResource(R.string.replace_brew_body, next.name),
            stringResource(R.string.replace),
            onConfirm = vm::confirmReplace,
            onDismiss = { vm.pendingReplace = null },
        )
    }
}

private fun tabIcon(t: Tab): ImageVector = when (t) {
    Tab.HOME -> Icons.Rounded.Home
    Tab.BREW -> Icons.Rounded.CoffeeMaker
    Tab.RECIPES -> Icons.AutoMirrored.Rounded.MenuBook
    Tab.COFFEE -> Icons.Rounded.Coffee
    Tab.CUPPING -> TcIcons.Wheel
    Tab.TRAIN -> Icons.Rounded.School
    Tab.HISTORY -> Icons.Rounded.History
}

@Composable
private fun tabLabel(t: Tab): String = stringResource(
    when (t) {
        Tab.HOME -> R.string.tab_home
        Tab.BREW -> R.string.tab_brew
        Tab.RECIPES -> R.string.tab_recipes
        Tab.COFFEE -> R.string.tab_coffee
        Tab.CUPPING -> R.string.tab_cupping
        Tab.TRAIN -> R.string.tab_train
        Tab.HISTORY -> R.string.tab_history
    }
)

@Composable
private fun TabIcon(t: Tab, running: Boolean) {
    if (t == Tab.BREW && running) {
        BadgedBox(badge = { Badge() }) { Icon(tabIcon(t), contentDescription = null) }
    } else {
        Icon(tabIcon(t), contentDescription = null)
    }
}

@Composable
private fun Content(vm: MainViewModel, settings: Settings, wide: Boolean, hinge: HingeInfo?) {
    when (vm.overlays.lastOrNull()) {
        Overlay.Calculator -> CalculatorScreen(vm, settings, wide, hinge)
        Overlay.Diagnose -> DiagnoseScreen(vm, settings, wide, hinge)
        Overlay.Compare -> CompareScreen(vm, settings, wide, hinge)
        Overlay.GrindAdvisor -> GrindAdvisorScreen(vm, settings, wide, hinge)
        Overlay.Settings -> SettingsScreen(vm, settings, wide, hinge)
        Overlay.LogBrew -> LogBrewScreen(vm, settings, wide, hinge)
        null -> when (vm.tab) {
            Tab.HOME -> HomeScreen(vm, settings, wide, hinge)
            Tab.BREW -> BrewScreen(vm, settings, wide, hinge)
            Tab.RECIPES -> RecipesScreen(vm, settings, wide, hinge)
            Tab.COFFEE -> CoffeeScreen(vm, settings, wide, hinge)
            Tab.CUPPING -> CuppingTab(vm, settings, wide, hinge)
            Tab.TRAIN -> TrainTab(vm, settings, wide, hinge)
            Tab.HISTORY -> HistoryScreen(vm, settings, wide, hinge)
        }
    }
}

@Composable
private fun Rail(vm: MainViewModel, running: Boolean) {
    BoxWithConstraints {
        // Seven tabs do not fit a landscape cover screen: drop the logo and let the rail scroll.
        val short = maxHeight < 560.dp
        NavigationRail(
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
            header = if (short) null else {
                { Icon(Icons.Rounded.Terrain, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(vertical = 12.dp).size(28.dp)) }
            },
        ) {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(if (short) 0.dp else 4.dp),
            ) {
                Tab.entries.forEach { t ->
                    NavigationRailItem(
                        selected = vm.tab == t && vm.overlays.isEmpty(),
                        onClick = { vm.selectTab(t) },
                        icon = { TabIcon(t, running) },
                        label = { NavLabel(tabLabel(t)) },
                        alwaysShowLabel = !short,
                    )
                }
            }
            IconButton(onClick = { vm.open(Overlay.Settings) }, modifier = Modifier.padding(bottom = 12.dp)) {
                Icon(Icons.Rounded.Settings, contentDescription = stringResource(R.string.settings))
            }
        }
    }
}

/** OPEN: navigation rail plus a two-pane workstation aligned on the hinge. */
@Composable
private fun WideScaffold(vm: MainViewModel, settings: Settings, hinge: HingeInfo?, running: Boolean) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            Rail(vm, running)
            Surface(color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxSize()) {
                Content(vm, settings, wide = true, hinge = hinge)
            }
        }
    }
}

/** CLOSED: one column and a compact bottom bar. In landscape the bar becomes a rail to save height. */
@Composable
private fun CompactScaffold(vm: MainViewModel, settings: Settings, landscape: Boolean, running: Boolean) {
    val editing = (vm.tab == Tab.RECIPES && vm.recipePane == Pane.Edit) || (vm.tab == Tab.COFFEE && vm.coffeePane == Pane.Edit)
    // A lesson or a quiz is a focused task: the bar steps aside until it is done.
    val training = vm.tab == Tab.TRAIN && vm.trainScreen.let { it is TrainScreen.LessonView || it == TrainScreen.Quiz || it == TrainScreen.Result }
    // The flavor wheel and the session form were full-screen pages in the original cupping app.
    val cupping = vm.tab == Tab.CUPPING && cupHidesBar(vm.cup.screen)
    val showBar = vm.overlays.isEmpty() && !editing && !training && !cupping
    if (landscape) {
        Row(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            if (showBar) Rail(vm, running)
            Box(Modifier.fillMaxSize()) { Content(vm, settings, wide = false, hinge = null) }
        }
        return
    }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (showBar) {
                NavigationBar {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = vm.tab == t,
                            onClick = { vm.selectTab(t) },
                            icon = { TabIcon(t, running) },
                            label = { NavLabel(tabLabel(t)) },
                            // Seven destinations: only the selected one keeps its label, as Material advises past five.
                            alwaysShowLabel = Tab.entries.size <= 5,
                        )
                    }
                }
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding).consumeWindowInsets(padding)) {
            Content(vm, settings, wide = false, hinge = null)
        }
    }
}
