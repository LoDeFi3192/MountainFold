package com.mountainfold.app.core.train

import com.mountainfold.app.core.engine.CoffeeEngine
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Teaching model of extraction. It reproduces directions and trade-offs, not a specific coffee:
 * finer, hotter, more agitation and more water raise extraction, ratio sets strength,
 * and past a point a fine grind chokes the bed and extraction falls.
 */
object ExtractionSim {
    enum class Zone { UNDER, BALANCED, OVER }
    enum class Strength { WEAK, BALANCED, STRONG }

    data class Result(
        val timeS: Int,
        val extractionPct: Double,
        val tdsPct: Double,
        val zone: Zone,
        val strength: Strength,
        /** True when part of the coffee is bypassed: choked bed or channeling. */
        val uneven: Boolean,
    )

    /** [grind] runs from 0 (coarse) to 100 (fine). [agitation] is 0 low, 1 medium, 2 high. */
    data class FilterInput(
        val grind: Int = 50,
        val doseG: Double = 15.0,
        val waterG: Double = 250.0,
        val tempC: Double = 93.0,
        val agitation: Int = 1,
    )

    data class ShotInput(
        val grind: Int = 50,
        val doseG: Double = 18.0,
        val yieldG: Double = 36.0,
        val tempC: Double = 93.0,
        val channeling: Boolean = false,
    )

    const val CHOKE_POINT = 85

    fun filter(i: FilterInput): Result {
        val dose = i.doseG.coerceAtLeast(1.0)
        val ratio = i.waterG / dose
        val choke = (i.grind - CHOKE_POINT).coerceAtLeast(0)
        var ey = 20.0 + 0.08 * (i.grind - 50) + 0.20 * (i.tempC - 93.0) + 0.9 * (i.agitation - 1) + 0.20 * (ratio - 16.67)
        ey -= 0.45 * choke
        ey = ey.coerceIn(10.0, 28.0)
        val time = 180.0 * (1.0 + 0.010 * (i.grind - 50)) * (i.waterG / 250.0).coerceAtLeast(0.2).pow(0.7) *
            (1.0 + 0.05 * (i.agitation - 1)) * (1.0 + 0.04 * choke)
        val beverage = (i.waterG - 2.0 * dose).coerceAtLeast(1.0)
        val tds = ey * dose / beverage
        return Result(
            timeS = time.roundToInt().coerceAtLeast(20),
            extractionPct = CoffeeEngine.round1(ey),
            tdsPct = CoffeeEngine.round2(tds),
            zone = zone(ey),
            strength = when {
                tds < 1.15 -> Strength.WEAK
                tds <= 1.45 -> Strength.BALANCED
                else -> Strength.STRONG
            },
            uneven = choke > 0,
        )
    }

    fun shot(i: ShotInput): Result {
        val dose = i.doseG.coerceAtLeast(1.0)
        val ratio = i.yieldG / dose
        var ey = 19.5 + 0.07 * (i.grind - 50) + 2.2 * (ratio - 2.0) + 0.25 * (i.tempC - 93.0)
        var time = 28.0 * (1.0 + 0.016 * (i.grind - 50)) * (i.yieldG / 36.0).coerceAtLeast(0.2).pow(0.9) * (dose / 18.0).pow(1.2)
        if (i.channeling) {
            ey -= 3.5
            time *= 0.72
        }
        ey = ey.coerceIn(8.0, 28.0)
        val tds = ey * dose / i.yieldG.coerceAtLeast(1.0)
        return Result(
            timeS = time.roundToInt().coerceAtLeast(5),
            extractionPct = CoffeeEngine.round1(ey),
            tdsPct = CoffeeEngine.round1(tds),
            zone = zone(ey),
            strength = when {
                tds < 8.0 -> Strength.WEAK
                tds <= 12.0 -> Strength.BALANCED
                else -> Strength.STRONG
            },
            uneven = i.channeling,
        )
    }

    private fun zone(ey: Double) = when {
        ey < 18.0 -> Zone.UNDER
        ey <= 22.0 -> Zone.BALANCED
        else -> Zone.OVER
    }

    /** EY % = beverage weight x TDS % / dose. Exact, not a model. */
    fun extractionYield(doseG: Double, beverageG: Double, tdsPct: Double): Double? =
        if (doseG > 0 && beverageG > 0 && tdsPct > 0) beverageG * tdsPct / doseG else null

    enum class MilkPhase { STRETCH, ROLL, READY, TOO_HOT }

    fun milkPhase(tempC: Int): MilkPhase = when {
        tempC < 37 -> MilkPhase.STRETCH
        tempC < 55 -> MilkPhase.ROLL
        tempC <= 65 -> MilkPhase.READY
        else -> MilkPhase.TOO_HOT
    }
}
