package com.mountainfold.app.core.engine

import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.BrewStep
import com.mountainfold.app.core.model.StepType
import com.mountainfold.app.core.model.Symptom
import kotlin.math.roundToInt

/**
 * Local, rule-based brewing assistant. No network, no model.
 * It follows one rule above all: change one variable at a time.
 */
object CopilotEngine {

    enum class Cause {
        UNDER_EXTRACTION, OVER_EXTRACTION, LOW_STRENGTH, HIGH_STRENGTH,
        UNEVEN_EXTRACTION, TOO_HOT, STALE_COFFEE, TOO_MANY_FINES, CHANNELING,
    }

    enum class Variable { GRIND, TEMPERATURE, DOSE, YIELD, RATIO, TIME, BLOOM, AGITATION, FRESHNESS, PUCK_PREP }

    enum class ChangeKind {
        GRIND_FINER, GRIND_COARSER, TEMP_UP, TEMP_DOWN, DOSE_UP, DOSE_DOWN,
        YIELD_UP, YIELD_DOWN, BLOOM_LONGER, AGITATE_LESS, PUCK_PREP, FRESHER_COFFEE,
    }

    data class BrewInput(
        val method: BrewMethod,
        val doseG: Double,
        val waterG: Double,
        val tempC: Double?,
        /** Measured brew time. Null when diagnosing a recipe that has not been timed. */
        val timeS: Int?,
        val targetTimeS: Int,
        val grind: String,
        val steps: List<BrewStep> = emptyList(),
        val roastAgeDays: Int? = null,
    )

    data class Suggestion(
        val doseG: Double,
        val waterG: Double,
        val tempC: Double?,
        val grind: String,
        val steps: List<BrewStep>,
        val targetTimeS: Int,
    )

    data class Diagnosis(
        val symptom: Symptom,
        val cause: Cause,
        val variables: List<Variable>,
        val change: ChangeKind,
        val suggestion: Suggestion,
        /** True when the recipe numbers changed. False for technique-only advice. */
        val recipeChanged: Boolean,
        /** True when the grind setting was a number and could be stepped. */
        val grindStepped: Boolean,
        /** True when the new time is a consequence to expect, not something to set. */
        val timeIsEstimate: Boolean,
    )

    private val priority = listOf(
        Symptom.ASTRINGENT, Symptom.DRY, Symptom.HARSH, Symptom.BITTER, Symptom.SOUR,
        Symptom.MUDDY, Symptom.HOLLOW, Symptom.FLAT, Symptom.WEAK, Symptom.STRONG,
    )

    /** Sour and bitter in the same cup points to uneven extraction, not to either extreme. */
    fun primarySymptom(symptoms: Set<Symptom>): Symptom? = when {
        symptoms.isEmpty() -> null
        Symptom.SOUR in symptoms && Symptom.BITTER in symptoms -> Symptom.HOLLOW
        else -> priority.first { it in symptoms }
    }

    fun diagnose(input: BrewInput, symptoms: Set<Symptom>): Diagnosis? {
        val symptom = primarySymptom(symptoms) ?: return null
        val (cause, variables, change) =
            if (input.method.isEspresso) espressoRule(input, symptom) else filterRule(input, symptom)
        return build(input, symptom, cause, variables, change)
    }

    private data class Rule(val cause: Cause, val variables: List<Variable>, val change: ChangeKind)

    private fun isShort(i: BrewInput) = i.timeS != null && i.timeS < i.targetTimeS * 0.9
    private fun isLong(i: BrewInput) = i.timeS != null && i.timeS > i.targetTimeS * 1.1
    private fun stale(i: BrewInput) = i.roastAgeDays != null && i.roastAgeDays > 45

    private fun filterRule(i: BrewInput, s: Symptom): Rule {
        val t = i.tempC
        return when (s) {
            Symptom.SOUR -> Rule(
                Cause.UNDER_EXTRACTION, listOf(Variable.GRIND, Variable.TEMPERATURE, Variable.TIME),
                when {
                    isShort(i) -> ChangeKind.GRIND_FINER
                    t != null && t < 94.0 -> ChangeKind.TEMP_UP
                    else -> ChangeKind.GRIND_FINER
                },
            )
            Symptom.BITTER -> Rule(
                Cause.OVER_EXTRACTION, listOf(Variable.GRIND, Variable.TEMPERATURE, Variable.TIME),
                when {
                    isLong(i) -> ChangeKind.GRIND_COARSER
                    t != null && t > 90.0 -> ChangeKind.TEMP_DOWN
                    else -> ChangeKind.GRIND_COARSER
                },
            )
            Symptom.WEAK -> Rule(Cause.LOW_STRENGTH, listOf(Variable.DOSE, Variable.RATIO), ChangeKind.DOSE_UP)
            Symptom.STRONG -> Rule(Cause.HIGH_STRENGTH, listOf(Variable.DOSE, Variable.RATIO), ChangeKind.DOSE_DOWN)
            Symptom.DRY -> Rule(Cause.OVER_EXTRACTION, listOf(Variable.GRIND, Variable.TEMPERATURE), ChangeKind.GRIND_COARSER)
            Symptom.ASTRINGENT -> Rule(
                Cause.CHANNELING, listOf(Variable.AGITATION, Variable.GRIND),
                if (isLong(i)) ChangeKind.GRIND_COARSER else ChangeKind.AGITATE_LESS,
            )
            Symptom.FLAT -> if (stale(i)) {
                Rule(Cause.STALE_COFFEE, listOf(Variable.FRESHNESS), ChangeKind.FRESHER_COFFEE)
            } else {
                Rule(
                    Cause.UNDER_EXTRACTION, listOf(Variable.TEMPERATURE, Variable.GRIND, Variable.FRESHNESS),
                    if (t != null && t < 96.0) ChangeKind.TEMP_UP else ChangeKind.GRIND_FINER,
                )
            }
            Symptom.HOLLOW -> Rule(
                Cause.UNEVEN_EXTRACTION, listOf(Variable.BLOOM, Variable.AGITATION, Variable.GRIND),
                if (hasBloom(i.steps)) ChangeKind.BLOOM_LONGER else ChangeKind.GRIND_FINER,
            )
            Symptom.HARSH -> Rule(
                Cause.TOO_HOT, listOf(Variable.TEMPERATURE, Variable.GRIND),
                if (t != null && t > 88.0) ChangeKind.TEMP_DOWN else ChangeKind.GRIND_COARSER,
            )
            Symptom.MUDDY -> Rule(Cause.TOO_MANY_FINES, listOf(Variable.GRIND, Variable.AGITATION), ChangeKind.GRIND_COARSER)
        }
    }

    private fun espressoRule(i: BrewInput, s: Symptom): Rule {
        val ratio = CoffeeEngine.ratio(i.waterG, i.doseG) ?: 2.0
        val t = i.tempC
        val time = i.timeS
        return when (s) {
            Symptom.SOUR -> Rule(
                Cause.UNDER_EXTRACTION, listOf(Variable.GRIND, Variable.YIELD, Variable.TEMPERATURE),
                when {
                    time != null && time < 25 -> ChangeKind.GRIND_FINER
                    ratio < 2.0 -> ChangeKind.YIELD_UP
                    t != null && t < 96.0 -> ChangeKind.TEMP_UP
                    else -> ChangeKind.GRIND_FINER
                },
            )
            Symptom.BITTER -> Rule(
                Cause.OVER_EXTRACTION, listOf(Variable.GRIND, Variable.YIELD, Variable.TEMPERATURE),
                when {
                    time != null && time > 32 -> ChangeKind.GRIND_COARSER
                    ratio > 2.2 -> ChangeKind.YIELD_DOWN
                    t != null && t > 88.0 -> ChangeKind.TEMP_DOWN
                    else -> ChangeKind.GRIND_COARSER
                },
            )
            Symptom.WEAK -> Rule(Cause.LOW_STRENGTH, listOf(Variable.YIELD, Variable.RATIO), ChangeKind.YIELD_DOWN)
            Symptom.STRONG -> Rule(Cause.HIGH_STRENGTH, listOf(Variable.YIELD, Variable.RATIO), ChangeKind.YIELD_UP)
            Symptom.DRY -> Rule(Cause.OVER_EXTRACTION, listOf(Variable.GRIND, Variable.YIELD), ChangeKind.GRIND_COARSER)
            Symptom.ASTRINGENT -> Rule(Cause.CHANNELING, listOf(Variable.PUCK_PREP, Variable.GRIND), ChangeKind.PUCK_PREP)
            Symptom.HOLLOW -> Rule(Cause.UNEVEN_EXTRACTION, listOf(Variable.PUCK_PREP, Variable.GRIND), ChangeKind.PUCK_PREP)
            Symptom.FLAT -> if (stale(i)) {
                Rule(Cause.STALE_COFFEE, listOf(Variable.FRESHNESS), ChangeKind.FRESHER_COFFEE)
            } else {
                Rule(
                    Cause.UNDER_EXTRACTION, listOf(Variable.TEMPERATURE, Variable.GRIND, Variable.FRESHNESS),
                    if (t != null && t < 96.0) ChangeKind.TEMP_UP else ChangeKind.GRIND_FINER,
                )
            }
            Symptom.HARSH -> Rule(
                Cause.TOO_HOT, listOf(Variable.TEMPERATURE, Variable.GRIND),
                if (t != null && t > 90.0) ChangeKind.TEMP_DOWN else ChangeKind.GRIND_COARSER,
            )
            Symptom.MUDDY -> Rule(Cause.TOO_MANY_FINES, listOf(Variable.GRIND, Variable.PUCK_PREP), ChangeKind.GRIND_COARSER)
        }
    }

    private fun hasBloom(steps: List<BrewStep>): Boolean {
        val i = steps.indexOfFirst { it.type == StepType.BLOOM }
        return i >= 0 && i < steps.lastIndex
    }

    private fun build(i: BrewInput, symptom: Symptom, cause: Cause, variables: List<Variable>, change: ChangeKind): Diagnosis {
        val espresso = i.method.isEspresso
        var dose = i.doseG
        var water = i.waterG
        var temp = i.tempC
        var grind = i.grind
        var steps = i.steps
        var target = i.targetTimeS
        var grindStepped = false
        var timeEstimate = false
        val tempStep = if (espresso) 1.0 else 2.0
        val doseStep = maxOf(1.0, (i.doseG * 0.07).roundToInt().toDouble())
        val yieldStep = maxOf(2.0, (i.doseG * 0.2).roundToInt().toDouble())

        when (change) {
            ChangeKind.GRIND_FINER, ChangeKind.GRIND_COARSER -> {
                val finer = change == ChangeKind.GRIND_FINER
                adjustGrind(i.grind, finer)?.let { grind = it; grindStepped = true }
                val delta = if (espresso) 3 else roundTo5((i.targetTimeS * 0.1)).coerceIn(5, 600)
                target = (i.targetTimeS + if (finer) delta else -delta).coerceAtLeast(5)
                timeEstimate = true
            }
            ChangeKind.TEMP_UP -> temp = temp?.let { (it + tempStep).coerceAtMost(96.0) }
            ChangeKind.TEMP_DOWN -> temp = temp?.let { (it - tempStep).coerceAtLeast(80.0) }
            ChangeKind.DOSE_UP -> dose = CoffeeEngine.round1(dose + doseStep)
            ChangeKind.DOSE_DOWN -> dose = CoffeeEngine.round1((dose - doseStep).coerceAtLeast(1.0))
            ChangeKind.YIELD_UP -> water = CoffeeEngine.round1(water + yieldStep)
            ChangeKind.YIELD_DOWN -> water = CoffeeEngine.round1((water - yieldStep).coerceAtLeast(dose))
            ChangeKind.BLOOM_LONGER -> {
                val b = steps.indexOfFirst { it.type == StepType.BLOOM }
                steps = steps.mapIndexed { idx, s -> if (idx > b) s.copy(startS = s.startS + 15) else s }
                target += 15
            }
            ChangeKind.AGITATE_LESS, ChangeKind.PUCK_PREP, ChangeKind.FRESHER_COFFEE -> Unit
        }
        val suggestion = Suggestion(dose, water, temp, grind, steps, target)
        val changed = dose != i.doseG || water != i.waterG || temp != i.tempC || grind != i.grind || steps != i.steps
        return Diagnosis(symptom, cause, variables, change, suggestion, changed, grindStepped, timeEstimate)
    }

    private fun roundTo5(v: Double): Int = ((v / 5.0).roundToInt() * 5)

    /**
     * Steps a numeric grind setting. Assumes a lower number is finer, which holds for most grinders.
     * Returns null for free-text settings such as "medium-fine".
     */
    fun adjustGrind(grind: String, finer: Boolean): String? {
        val v = CoffeeEngine.parseNumber(grind) ?: return null
        val step = if (v == v.toLong().toDouble()) 1.0 else 0.5
        val next = (if (finer) v - step else v + step).coerceAtLeast(0.0)
        return CoffeeEngine.formatNumber(next)
    }
}
