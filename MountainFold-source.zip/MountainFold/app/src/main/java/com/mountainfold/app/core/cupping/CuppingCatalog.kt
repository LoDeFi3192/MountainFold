package com.mountainfold.app.core.cupping

/**
 * Vocabulary of the Toulouse Cupping module, ported 1:1 from the original web app.
 * Keys stay in French, exactly as the original stored them, so exports and old data line up.
 * English and Spanish labels come from the original translation table.
 */
object CuppingCatalog {

    data class Term(val key: String, val en: String, val es: String) {
        fun label(lang: String): String = when (lang) {
            "en" -> en
            "es" -> es
            else -> key
        }
    }

    data class AromaCategory(val id: String, val name: Term, val color: Long, val items: List<Term>)

    private fun t(fr: String, en: String, es: String) = Term(fr, en, es)

    val AROMA_CATEGORIES: List<AromaCategory> = listOf(
        AromaCategory(
            "fruity", t("Fruité", "Fruity", "Frutal"), 0xFFCF3E53,
            listOf(
                t("Citron", "Lemon", "Limón"), t("Orange", "Orange", "Naranja"), t("Pamplemousse", "Grapefruit", "Pomelo"),
                t("Cerise", "Cherry", "Cereza"), t("Fraise", "Strawberry", "Fresa"), t("Framboise", "Raspberry", "Frambuesa"),
                t("Myrtille", "Blueberry", "Arándano"), t("Raisin", "Grape", "Uva"), t("Ananas", "Pineapple", "Piña"),
                t("Mangue", "Mango", "Mango"), t("Passion", "Passion Fruit", "Maracuyá"), t("Pêche", "Peach", "Melocotón"),
                t("Pomme verte", "Green Apple", "Manzana Verde"), t("Poire", "Pear", "Pera"),
            ),
        ),
        AromaCategory(
            "floral", t("Floral", "Floral", "Floral"), 0xFFE14684,
            listOf(
                t("Jasmin", "Jasmine", "Jazmín"), t("Rose", "Rose", "Rosa"), t("Fleur d'oranger", "Orange Blossom", "Azahar"),
                t("Lavande", "Lavender", "Lavanda"), t("Hibiscus", "Hibiscus", "Hibisco"), t("Violette", "Violet", "Violeta"),
                t("Camomille", "Chamomile", "Manzanilla"),
            ),
        ),
        AromaCategory(
            "spicy", t("Épicé", "Spicy", "Especiado"), 0xFFCC3D42,
            listOf(
                t("Cannelle", "Cinnamon", "Canela"), t("Clou de girofle", "Clove", "Clavo"), t("Muscade", "Nutmeg", "Nuez Moscada"),
                t("Poivre", "Pepper", "Pimienta"), t("Cardamome", "Cardamom", "Cardamomo"), t("Gingembre", "Ginger", "Jengibre"),
            ),
        ),
        AromaCategory(
            "nutty", t("Chocolat / Noix", "Nutty / Cocoa", "Frutos Secos / Cacao"), 0xFFB57B4E,
            listOf(
                t("Chocolat noir", "Dark Chocolate", "Choc. Negro"), t("Chocolat au lait", "Milk Chocolate", "Choc. con Leche"),
                t("Cacao", "Cocoa", "Cacao"), t("Noisette", "Hazelnut", "Avellana"), t("Amande", "Almond", "Almendra"),
                t("Noix", "Walnut", "Nuez"), t("Cacahuète", "Peanut", "Cacahuete"),
            ),
        ),
        AromaCategory(
            "sweet", t("Caramélisé", "Sweet", "Dulce"), 0xFFE48833,
            listOf(
                t("Caramel", "Caramel", "Caramelo"), t("Miel", "Honey", "Miel"), t("Cassonade", "Brown Sugar", "Azúcar Moreno"),
                t("Sirop d'érable", "Maple Syrup", "Jarabe de Arce"), t("Mélasse", "Molasses", "Melaza"),
            ),
        ),
        AromaCategory(
            "cereal", t("Céréales / Pain", "Roasted", "Tostado"), 0xFFDDAF61,
            listOf(
                t("Pain grillé", "Toast", "Pan Tostado"), t("Biscuit", "Biscuit", "Galleta"), t("Céréales", "Cereal", "Cereal"),
                t("Malt", "Malt", "Malta"), t("Noisette grillée", "Roasted Hazelnut", "Avellana Tostada"),
            ),
        ),
    )

    /** Per-note colours from the original, used on chips and on the flavor wheel. */
    val ITEM_COLOR_OVERRIDES: Map<String, Long> = mapOf(
        "Citron" to 0xFFF5E452, "Orange" to 0xFFF29635, "Pamplemousse" to 0xFFF27056,
        "Cerise" to 0xFFE72D37, "Fraise" to 0xFFEF474A, "Framboise" to 0xFFE52E6C, "Myrtille" to 0xFF6165A4,
        "Raisin" to 0xFFAEBF43, "Ananas" to 0xFFF8C739, "Mangue" to 0xFFF7941D, "Passion" to 0xFFF2CA1E,
        "Pêche" to 0xFFF3965E, "Pomme verte" to 0xFF64AC56, "Poire" to 0xFFC5B446,
        "Jasmin" to 0xFFF8F8F3, "Rose" to 0xFFEF8CA6, "Camomille" to 0xFFF5C656,
        "Fleur d'oranger" to 0xFFFCE6C9, "Lavande" to 0xFF907DC1, "Hibiscus" to 0xFFD44C6A, "Violette" to 0xFF7F5C9E,
        "Poivre" to 0xFF9D3235, "Cannelle" to 0xFFC46436, "Clou de girofle" to 0xFFA26947,
        "Muscade" to 0xFF8C6544, "Gingembre" to 0xFFD6B563, "Cardamome" to 0xFF999C63,
        "Chocolat noir" to 0xFF462920, "Chocolat au lait" to 0xFF694231, "Cacao" to 0xFF5D3C2E,
        "Noisette" to 0xFF9C7349, "Amande" to 0xFFC7A482, "Noix" to 0xFF7B6652, "Cacahuète" to 0xFFD3A45C,
        "Caramel" to 0xFFD17C2D, "Miel" to 0xFFEAA63F, "Sirop d'érable" to 0xFFAD5D2D,
        "Mélasse" to 0xFF5E2C22, "Cassonade" to 0xFFC66940,
        "Pain grillé" to 0xFF886A4C, "Biscuit" to 0xFFE7C888, "Céréales" to 0xFFD7B066,
        "Malt" to 0xFFD8AF67, "Noisette grillée" to 0xFFB0885D,
    )

    /** The original showed these four lists in French only. EN and ES labels are added here. */
    val PROCESSING_METHODS = listOf(
        t("Nature", "Natural", "Natural"), t("Honey", "Honey", "Honey"), t("Lavé", "Washed", "Lavado"),
        t("Anaérobie", "Anaerobic", "Anaeróbico"), t("Co-Fermenté", "Co-Fermented", "Co-Fermentado"),
    )
    val ACIDITY_TYPES = listOf(
        t("Citrique", "Citric", "Cítrica"), t("Malique", "Malic", "Málica"), t("Tartrique", "Tartaric", "Tartárica"), t("Acétique", "Acetic", "Acética"),
    )
    val ACIDITY_INTENSITIES = listOf(t("Faible", "Low", "Baja"), t("Moyenne", "Medium", "Media"), t("Forte", "High", "Alta"))
    val BODY_TYPES = listOf(
        t("Aqueux", "Watery", "Acuoso"), t("Léger", "Light", "Ligero"), t("Moyen", "Medium", "Medio"), t("Rond", "Round", "Redondo"),
        t("Crémeux", "Creamy", "Cremoso"), t("Sirupeux", "Syrupy", "Siruposo"), t("Velouté", "Velvety", "Aterciopelado"), t("Charnu", "Juicy", "Carnoso"),
    )

    private val terms: Map<String, Term> by lazy {
        (AROMA_CATEGORIES.flatMap { it.items + it.name } + PROCESSING_METHODS + ACIDITY_TYPES + ACIDITY_INTENSITIES + BODY_TYPES)
            .associateBy { it.key }
    }

    /** Label for a stored French key. Unknown keys come back unchanged, like the original. */
    fun label(key: String, lang: String): String = terms[key]?.label(lang) ?: key

    fun categoryOf(note: String): AromaCategory? = AROMA_CATEGORIES.firstOrNull { c -> c.items.any { it.key == note } }

    /** Colour of a note: its own override first, then its category. Null for unknown notes. */
    fun noteColor(note: String): Long? = ITEM_COLOR_OVERRIDES[note] ?: categoryOf(note)?.color

    /** Default fill of a selected chip without a colour of its own (#865328 in the original). */
    const val CHIP_DEFAULT: Long = 0xFF865328

    /** YIQ contrast rule from the original: dark text on light colours, white on dark ones. */
    fun contrastOn(argb: Long): Long {
        val r = (argb shr 16) and 0xFF
        val g = (argb shr 8) and 0xFF
        val b = argb and 0xFF
        val yiq = (r * 299 + g * 587 + b * 114) / 1000.0
        return if (yiq >= 128) 0xFF1E1B18 else 0xFFFFFFFF
    }

    /** Brewing Lab methods, default ratio applied when a method is picked. */
    enum class LabMethod(val id: String, val defaultRatio: Int) {
        V60("v60", 16), CHEMEX("chemex", 15), AEROPRESS("aeropress", 14), FRENCH_PRESS("french_press", 12), MOKA("moka", 10), KALITA("kalita", 16);

        companion object {
            fun of(id: String): LabMethod? = entries.firstOrNull { it.id == id }
        }
    }

    fun labMethodName(id: String, lang: String): String = when (LabMethod.of(id)) {
        LabMethod.V60 -> "V60"
        LabMethod.CHEMEX -> "Chemex"
        LabMethod.AEROPRESS -> "Aeropress"
        LabMethod.FRENCH_PRESS -> when (lang) { "en" -> "French Press"; "es" -> "Prensa"; else -> "Piston" }
        LabMethod.MOKA -> "Moka"
        LabMethod.KALITA -> "Kalita"
        null -> id.replaceFirstChar { it.uppercase() }
    }

    const val DEFAULT_INVITE_URL = "https://toulouse-cupping-v2-fini-696310574132.us-west1.run.app/"
}
