package com.mountainfold.app.ui

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mountainfold.app.MountainFoldApp
import com.mountainfold.app.R
import com.mountainfold.app.core.engine.CoffeeEngine
import com.mountainfold.app.core.engine.CopilotEngine
import com.mountainfold.app.core.engine.StepSchedule
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.BrewStep
import com.mountainfold.app.core.model.SessionRecipe
import com.mountainfold.app.core.model.StepType
import com.mountainfold.app.core.model.Symptom
import com.mountainfold.app.core.train.Breakdown
import com.mountainfold.app.core.train.BrewSignal
import com.mountainfold.app.core.train.DialInGenerator
import com.mountainfold.app.core.train.EventKind
import com.mountainfold.app.core.train.ExamCategory
import com.mountainfold.app.core.train.ExtractionSim
import com.mountainfold.app.core.train.Lesson
import com.mountainfold.app.core.train.Opportunity
import com.mountainfold.app.core.train.Progress
import com.mountainfold.app.core.train.Question
import com.mountainfold.app.core.train.Recommendation
import com.mountainfold.app.core.train.SimKind
import com.mountainfold.app.core.train.Skill
import com.mountainfold.app.core.train.SkillTree
import com.mountainfold.app.core.train.TrainContent
import com.mountainfold.app.core.train.TrainEvent
import com.mountainfold.app.core.train.TrainProgress
import com.mountainfold.app.core.voice.VoiceCommand
import com.mountainfold.app.core.voice.VoiceCommandParser
import com.mountainfold.app.data.StepsCodec
import com.mountainfold.app.data.db.Brew
import com.mountainfold.app.data.db.Coffee
import com.mountainfold.app.data.db.Grinder
import com.mountainfold.app.data.db.Recipe
import com.mountainfold.app.data.db.TrainingEvent
import com.mountainfold.app.data.prefs.LanguageStore
import com.mountainfold.app.data.prefs.Settings
import com.mountainfold.app.data.seed.SeedData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.os.SystemClock
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.random.Random
import java.util.UUID

enum class Tab { HOME, BREW, RECIPES, COFFEE, CUPPING, TRAIN, HISTORY }

sealed interface Overlay {
    data object Calculator : Overlay
    data object Diagnose : Overlay
    data object Compare : Overlay
    data object GrindAdvisor : Overlay
    data object Settings : Overlay
    data object LogBrew : Overlay
}

sealed interface Pane {
    data object None : Pane
    data class View(val id: Long) : Pane
    data object Edit : Pane
}

data class UiMessage(val resId: Int, val arg: String? = null, val nonce: Long = System.nanoTime())

data class StepDraft(
    val label: String = "",
    val type: StepType = StepType.POUR,
    val start: String = "0:00",
    val water: String = "",
    val note: String = "",
)

data class RecipeDraft(
    val id: Long = 0,
    val name: String = "",
    val method: BrewMethod = BrewMethod.V60,
    val coffeeId: Long? = null,
    val dose: String = "",
    val water: String = "",
    val ratio: String = "",
    val temp: String = "",
    val grind: String = "",
    val pressure: String = "",
    val targetTime: String = "",
    val steps: List<StepDraft> = emptyList(),
    val notes: String = "",
    val favorite: Boolean = false,
    val createdAt: Long = 0,
)

data class CoffeeDraft(val coffee: Coffee = Coffee())

data class LogDraft(
    val timeMs: Long = 0,
    val dose: String = "",
    val water: String = "",
    val temp: String = "",
    val grind: String = "",
    val grinderId: Long? = null,
    val rating: Int = 0,
    val acidity: Int = 0,
    val sweetness: Int = 0,
    val body: Int = 0,
    val balance: Int = 0,
    val clarity: Int = 0,
    val symptoms: Set<Symptom> = emptySet(),
    val notes: String = "",
)

data class CalcState(
    val espresso: Boolean = false,
    val solve: CoffeeEngine.Solve = CoffeeEngine.Solve.WATER,
    val dose: String = "15",
    val water: String = "250",
    val ratio: String = "16.7",
    val time: String = "",
    val temp: String = "",
)

data class DiagState(
    val title: String = "",
    val recipe: SessionRecipe? = null,
    val timeS: Int? = null,
    val roastAgeDays: Int? = null,
    val symptoms: Set<Symptom> = emptySet(),
)

data class CompareState(val brews: Boolean = false, val aId: Long? = null, val bId: Long? = null)

data class GrindFilter(val grinderId: Long? = null, val coffeeId: Long? = null, val method: BrewMethod? = null)

/**
 * One ViewModel for the whole app. Navigation, drafts and selections live here, above the
 * Closed / Open / Flex layouts, so swapping layouts on a posture change loses nothing.
 */
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val container = (app as MountainFoldApp).container
    private val repo = container.repository
    val session = container.session
    val settings: StateFlow<Settings?> = container.settings

    val coffees = repo.coffees.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val recipes = repo.recipes.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val brews = repo.brews.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val grinders = repo.grinders.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val ctx: Context get() = LanguageStore.wrap(getApplication())
    private val current: Settings get() = settings.value ?: Settings()
    fun units() = Units(current.weightUnit, current.tempUnit)

    // ---- navigation -------------------------------------------------------------------------
    var tab by mutableStateOf(Tab.HOME)
    val overlays = mutableStateListOf<Overlay>()
    var recipePane by mutableStateOf<Pane>(Pane.None)
    var coffeePane by mutableStateOf<Pane>(Pane.None)
    var historySel by mutableStateOf<Long?>(null)
    /** In Flex posture: true while the user browses the regular app instead of the companion. */
    var flexBrowse by mutableStateOf(false)
    var message by mutableStateOf<UiMessage?>(null)
    var pendingReplace by mutableStateOf<SessionRecipe?>(null)

    // ---- drafts -----------------------------------------------------------------------------
    var recipeDraft by mutableStateOf<RecipeDraft?>(null)
    var coffeeDraft by mutableStateOf<CoffeeDraft?>(null)
    var logDraft by mutableStateOf<LogDraft?>(null)
    var calc by mutableStateOf(CalcState())
    var diag by mutableStateOf(DiagState())
    var compare by mutableStateOf(CompareState())
    var grindFilter by mutableStateOf(GrindFilter())
    var recipeMethodFilter by mutableStateOf<BrewMethod?>(null)

    // ---- Toulouse Cupping ---------------------------------------------------------------------
    val cup = com.mountainfold.app.ui.cupping.CuppingController(
        repo = repo,
        settingsStore = container.settingsStore,
        settings = container.settings,
        uiScope = viewModelScope,
        ioScope = container.scope,
        text = { id, args -> ctx.getString(id, *args) },
        clock = { SystemClock.elapsedRealtime() },
        alerts = container.cuppingAlerts,
    )

    init {
        viewModelScope.launch {
            val s = container.settings.filterNotNull().first()
            if (s.onboarded) {
                repo.seedIfEmpty(ctx)
                ensureSession()
            }
        }
    }

    fun selectTab(t: Tab) {
        overlays.clear()
        if (t == tab) when (t) {
            Tab.RECIPES -> if (recipePane != Pane.Edit) recipePane = Pane.None
            Tab.COFFEE -> if (coffeePane != Pane.Edit) coffeePane = Pane.None
            Tab.HISTORY -> historySel = null
            Tab.TRAIN -> leaveTraining()
            Tab.CUPPING -> { cup.screen = com.mountainfold.app.ui.cupping.CupScreen.MAIN; cup.labHistory = false }
            else -> Unit
        }
        tab = t
    }

    fun open(overlay: Overlay) {
        overlays.remove(overlay)
        overlays.add(overlay)
    }

    /** True when there is something for the back gesture to close inside the app. */
    fun canGoBack(compact: Boolean): Boolean =
        overlays.isNotEmpty() || tab != Tab.HOME || flexBrowse ||
            (compact && (recipePane != Pane.None || coffeePane != Pane.None || historySel != null))

    fun back() {
        when {
            overlays.isNotEmpty() -> {
                val top = overlays.removeAt(overlays.lastIndex)
                if (top == Overlay.LogBrew) { session.cancelFinish(); logDraft = null }
            }
            tab == Tab.TRAIN && trainStack.isNotEmpty() -> trainBack()
            tab == Tab.CUPPING && cup.canGoBack() -> cup.back()
            tab == Tab.RECIPES && recipePane != Pane.None -> closeRecipePane()
            tab == Tab.COFFEE && coffeePane != Pane.None -> closeCoffeePane()
            tab == Tab.HISTORY && historySel != null -> historySel = null
            tab != Tab.HOME -> tab = Tab.HOME
            flexBrowse -> flexBrowse = false
        }
    }

    fun closeRecipePane() {
        val d = recipeDraft
        recipePane = if (recipePane == Pane.Edit && d != null && d.id != 0L) Pane.View(d.id) else Pane.None
        recipeDraft = null
    }

    fun closeCoffeePane() {
        val d = coffeeDraft
        coffeePane = if (coffeePane == Pane.Edit && d != null && d.coffee.id != 0L) Pane.View(d.coffee.id) else Pane.None
        coffeeDraft = null
    }

    fun say(resId: Int, arg: String? = null) { message = UiMessage(resId, arg) }

    // ---- settings ---------------------------------------------------------------------------
    fun setSettings(transform: (Settings) -> Settings) {
        viewModelScope.launch { container.settingsStore.update(transform) }
    }

    fun completeOnboarding(methods: List<BrewMethod>, grinder: String) {
        viewModelScope.launch {
            val grinderId = grinder.trim().takeIf { it.isNotEmpty() }?.let { repo.saveGrinder(Grinder(name = it)) }
            repo.seedIfEmpty(ctx, favorites = methods)
            container.settingsStore.update {
                it.copy(
                    onboarded = true,
                    preferredMethods = methods,
                    defaultMethod = methods.firstOrNull() ?: BrewMethod.V60,
                    defaultGrinderId = grinderId ?: it.defaultGrinderId,
                )
            }
            ensureSession(methods.firstOrNull())
        }
    }

    // ---- session ----------------------------------------------------------------------------
    private suspend fun ensureSession(preferred: BrewMethod? = null) {
        if (session.state.value.recipe != null) return
        val list = repo.recipes.first()
        val s = container.settings.filterNotNull().first()
        val method = preferred ?: s.defaultMethod
        val pick = list.firstOrNull { it.id == s.lastRecipeId }
            ?: list.firstOrNull { it.method == method.name }
            ?: list.firstOrNull()
            ?: return
        session.load(toSession(pick, repo.coffees.first(), s))
    }

    fun toSession(recipe: Recipe, coffeeList: List<Coffee> = coffees.value, s: Settings = current): SessionRecipe {
        val coffee = coffeeList.firstOrNull { it.id == (recipe.coffeeId ?: s.currentCoffeeId) }
        return SessionRecipe(
            recipeId = recipe.id.takeIf { it != 0L },
            name = recipe.name,
            method = BrewMethod.fromKey(recipe.method),
            coffeeId = coffee?.id,
            coffeeName = coffee?.name.orEmpty(),
            doseG = recipe.doseG,
            waterG = recipe.waterG,
            tempC = recipe.tempC,
            grind = recipe.grind,
            pressureBar = recipe.pressureBar,
            steps = StepsCodec.decode(recipe.stepsJson),
            targetTimeS = recipe.targetTimeS,
            notes = recipe.notes,
        )
    }

    /** Loads a recipe into the brew screen. Asks first when a brew is already in progress. */
    fun brew(recipe: SessionRecipe) {
        if (session.timer.state.value.hasStarted && !session.state.value.finished) {
            pendingReplace = recipe
        } else {
            loadSession(recipe)
        }
    }

    fun brew(recipe: Recipe) = brew(toSession(recipe))

    fun confirmReplace() {
        pendingReplace?.let { loadSession(it) }
        pendingReplace = null
    }

    private fun loadSession(recipe: SessionRecipe) {
        session.load(recipe)
        recipe.recipeId?.let { id -> setSettings { it.copy(lastRecipeId = id) } }
        overlays.clear()
        logDraft = null
        tab = Tab.BREW
    }

    fun brewAdHoc(method: BrewMethod, doseG: Double, waterG: Double, tempC: Double? = null) {
        val base = SeedData.defaultRecipe(ctx, method, doseG)
        val steps = CoffeeEngine.scaleSteps(StepsCodec.decode(base.stepsJson), base.waterG, waterG)
        brew(
            toSession(base.copy(name = ctx.getString(R.string.quick_brew_name, method.label), waterG = waterG, tempC = tempC ?: base.tempC))
                .copy(steps = steps)
        )
    }

    fun onVoice(text: String) {
        when (val cmd = VoiceCommandParser.parse(text)) {
            VoiceCommand.Start -> session.start()
            VoiceCommand.Pause -> session.pause()
            VoiceCommand.NextStep -> session.nextStep()
            VoiceCommand.Reset -> session.reset()
            is VoiceCommand.AddWater -> session.addWater(cmd.grams)
            VoiceCommand.AskRatio -> session.state.value.recipe?.let {
                say(R.string.voice_ratio, CoffeeEngine.formatRatio(CoffeeEngine.ratio(it.waterG, it.doseG)))
            }
            VoiceCommand.Unknown -> say(R.string.voice_unknown, text)
        }
    }

    // ---- brew log ---------------------------------------------------------------------------
    fun openLog() {
        val r = session.state.value.recipe ?: return
        if (logDraft == null) {
            val u = units()
            val poured = session.weight.weightG.value
            logDraft = LogDraft(
                timeMs = session.timer.elapsedMs(),
                dose = u.wValue(r.doseG),
                water = u.wValue(if (poured > 0.0) poured else r.waterG),
                temp = r.tempC?.let { u.tValue(it) }.orEmpty(),
                grind = r.grind,
                grinderId = current.defaultGrinderId,
                notes = session.state.value.notes,
            )
        }
        open(Overlay.LogBrew)
    }

    fun saveLog() {
        val d = logDraft ?: return
        val r = session.state.value.recipe ?: return
        val u = units()
        val grinder = grinders.value.firstOrNull { it.id == d.grinderId }
        val brew = Brew(
            coffeeId = r.coffeeId,
            recipeId = r.recipeId,
            coffeeName = r.coffeeName,
            recipeName = r.name,
            method = r.method.name,
            doseG = u.parseW(d.dose) ?: r.doseG,
            waterG = u.parseW(d.water) ?: r.waterG,
            tempC = u.parseT(d.temp),
            grind = d.grind.trim(),
            grinderId = grinder?.id,
            grinderName = grinder?.name.orEmpty(),
            pressureBar = r.pressureBar,
            timeMs = d.timeMs,
            targetTimeS = r.targetTimeS,
            notes = d.notes.trim(),
            rating = d.rating,
            acidity = d.acidity, sweetness = d.sweetness, body = d.body, balance = d.balance, clarity = d.clarity,
            symptoms = d.symptoms.joinToString(",") { it.name },
            stepsJson = StepsCodec.encode(r.steps),
        )
        viewModelScope.launch {
            val id = repo.saveBrew(brew)
            val challenge = recordBrewForTraining(id, brew)
            session.clearAfterLog()
            overlays.clear()
            logDraft = null
            tab = Tab.HISTORY
            historySel = id
            say(
                when {
                    challenge -> R.string.msg_brew_challenge_done
                    d.rating >= 4 -> R.string.msg_nice_extraction
                    else -> R.string.msg_brew_logged
                }
            )
        }
    }

    fun deleteBrew(b: Brew) {
        viewModelScope.launch { repo.deleteBrew(b) }
        if (historySel == b.id) historySel = null
    }

    fun brewAgain(b: Brew) = brew(brewToSession(b))

    fun brewToSession(b: Brew): SessionRecipe = SessionRecipe(
        recipeId = b.recipeId?.takeIf { id -> recipes.value.any { it.id == id } },
        name = b.recipeName.ifBlank { BrewMethod.fromKey(b.method).label },
        method = BrewMethod.fromKey(b.method),
        coffeeId = b.coffeeId?.takeIf { id -> coffees.value.any { it.id == id } },
        coffeeName = b.coffeeName,
        doseG = b.doseG,
        waterG = b.waterG,
        tempC = b.tempC,
        grind = b.grind,
        pressureBar = b.pressureBar,
        steps = StepsCodec.decode(b.stepsJson),
        targetTimeS = if (b.targetTimeS > 0) b.targetTimeS else (b.timeMs / 1000).toInt(),
    )

    // ---- recipes ----------------------------------------------------------------------------
    fun newRecipe(method: BrewMethod = current.defaultMethod, coffeeId: Long? = null) {
        val dose = if (method == current.defaultMethod) current.defaultDoseG else method.defaultDoseG
        recipeDraft = draftOf(SeedData.defaultRecipe(ctx, method, dose).copy(name = "", coffeeId = coffeeId))
        recipePane = Pane.Edit
        overlays.clear()
        tab = Tab.RECIPES
    }

    fun editRecipe(r: Recipe) {
        recipeDraft = draftOf(r)
        recipePane = Pane.Edit
    }

    fun draftOf(r: Recipe): RecipeDraft {
        val u = units()
        return RecipeDraft(
            id = r.id,
            name = r.name,
            method = BrewMethod.fromKey(r.method),
            coffeeId = r.coffeeId,
            dose = u.wValue(r.doseG),
            water = u.wValue(r.waterG),
            ratio = CoffeeEngine.ratio(r.waterG, r.doseG)?.let { CoffeeEngine.formatNumber(it) }.orEmpty(),
            temp = r.tempC?.let { u.tValue(it) }.orEmpty(),
            grind = r.grind,
            pressure = r.pressureBar?.let { CoffeeEngine.formatNumber(it) }.orEmpty(),
            targetTime = clockOrSeconds(r.targetTimeS, BrewMethod.fromKey(r.method)),
            steps = StepsCodec.decode(r.stepsJson).map {
                StepDraft(it.label, it.type, CoffeeEngine.formatClock(it.startS.toLong()), it.targetWaterG?.let(u::wValue).orEmpty(), it.note)
            },
            notes = r.notes,
            favorite = r.favorite,
            createdAt = r.createdAt,
        )
    }

    private fun clockOrSeconds(seconds: Int, method: BrewMethod): String =
        if (method.isEspresso) seconds.toString() else CoffeeEngine.formatClock(seconds.toLong())

    /** Replaces numbers and steps of the draft with the template of [method]. */
    fun applyTemplate(method: BrewMethod) {
        val d = recipeDraft ?: return
        val t = draftOf(SeedData.defaultRecipe(ctx, method))
        recipeDraft = t.copy(id = d.id, name = d.name, coffeeId = d.coffeeId, notes = d.notes, favorite = d.favorite, createdAt = d.createdAt)
    }

    fun recipeFromDraft(d: RecipeDraft): Recipe? {
        val u = units()
        val dose = u.parseW(d.dose)?.takeIf { it > 0 } ?: return null
        val water = u.parseW(d.water)?.takeIf { it > 0 } ?: return null
        val target = CoffeeEngine.parseClock(d.targetTime)?.takeIf { it > 0 } ?: return null
        val steps = StepSchedule.normalize(
            d.steps.filter { it.label.isNotBlank() }.map {
                BrewStep(it.label.trim(), it.type, CoffeeEngine.parseClock(it.start) ?: 0, u.parseW(it.water), it.note.trim())
            }
        )
        return Recipe(
            id = d.id,
            name = d.name.trim().ifEmpty { ctx.getString(R.string.seed_recipe_name, d.method.label) },
            method = d.method.name,
            coffeeId = d.coffeeId,
            doseG = dose,
            waterG = water,
            tempC = u.parseT(d.temp),
            grind = d.grind.trim(),
            pressureBar = CoffeeEngine.parseNumber(d.pressure),
            targetTimeS = target,
            stepsJson = StepsCodec.encode(steps),
            notes = d.notes.trim(),
            favorite = d.favorite,
            createdAt = d.createdAt,
        )
    }

    fun saveRecipeDraft() {
        val d = recipeDraft ?: return
        val r = recipeFromDraft(d) ?: run { say(R.string.msg_check_numbers); return }
        viewModelScope.launch {
            val id = repo.saveRecipe(r)
            recipeDraft = null
            recipePane = Pane.View(id)
            // Keep an idle brew screen in sync with the edited recipe.
            val s = session.state.value
            if (s.recipe?.recipeId == id && !session.timer.state.value.hasStarted) session.load(toSession(r.copy(id = id)))
            say(R.string.msg_recipe_saved)
        }
    }

    fun toggleFavorite(r: Recipe) { viewModelScope.launch { repo.saveRecipe(r.copy(favorite = !r.favorite)) } }

    fun duplicateRecipe(r: Recipe) {
        viewModelScope.launch {
            val id = repo.saveRecipe(r.copy(id = 0, name = ctx.getString(R.string.copy_name, r.name), favorite = false, createdAt = 0))
            recipePane = Pane.View(id)
        }
    }

    fun deleteRecipe(r: Recipe) {
        viewModelScope.launch { repo.deleteRecipe(r) }
        if (recipePane == Pane.View(r.id)) recipePane = Pane.None
    }

    // ---- coffees ----------------------------------------------------------------------------
    fun newCoffee() { coffeeDraft = CoffeeDraft(); coffeePane = Pane.Edit; overlays.clear(); tab = Tab.COFFEE }
    fun editCoffee(c: Coffee) { coffeeDraft = CoffeeDraft(c); coffeePane = Pane.Edit }

    fun saveCoffeeDraft() {
        val d = coffeeDraft ?: return
        if (d.coffee.name.isBlank()) { say(R.string.msg_name_required); return }
        viewModelScope.launch {
            val first = coffees.value.isEmpty()
            val id = repo.saveCoffee(d.coffee.copy(name = d.coffee.name.trim()))
            val saved = d.coffee.copy(id = id, name = d.coffee.name.trim())
            val loaded = session.state.value.recipe
            if (first || current.currentCoffeeId == null) {
                setCurrentCoffee(id, saved)
            } else if (loaded != null && loaded.coffeeId == id && !session.timer.state.value.hasStarted) {
                // Keep an idle brew screen in sync with a renamed coffee.
                session.load(loaded.copy(coffeeName = saved.name))
            }
            coffeeDraft = null
            coffeePane = Pane.View(id)
            say(R.string.msg_coffee_saved)
        }
    }

    fun deleteCoffee(c: Coffee) {
        viewModelScope.launch {
            repo.deleteCoffee(c)
            c.photoPath?.let { runCatching { File(it).delete() } }
            if (current.currentCoffeeId == c.id) container.settingsStore.update { it.copy(currentCoffeeId = null) }
        }
        if (coffeePane == Pane.View(c.id)) coffeePane = Pane.None
    }

    /**
     * Makes [id] the current coffee. [known] carries the row when it was saved a moment ago
     * and the observed list has not caught up yet.
     */
    fun setCurrentCoffee(id: Long?, known: Coffee? = null) {
        setSettings { it.copy(currentCoffeeId = id) }
        // An idle brew that is not tied to a specific coffee follows the current coffee.
        val r = session.state.value.recipe ?: return
        if (session.timer.state.value.hasStarted) return
        val linked = recipes.value.firstOrNull { it.id == r.recipeId }?.coffeeId
        if (linked == null) {
            val coffee = known ?: coffees.value.firstOrNull { it.id == id }
            session.load(r.copy(coffeeId = coffee?.id, coffeeName = coffee?.name.orEmpty()))
        }
    }

    /** Copies the picked image into app storage, downscaled, so the library never depends on the gallery. */
    fun attachPhoto(uri: Uri) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) {
                runCatching {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    app.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                    var sample = 1
                    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
                    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                    val bmp = app.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                        ?: return@runCatching null
                    val dir = File(app.filesDir, "photos").apply { mkdirs() }
                    val file = File(dir, "${UUID.randomUUID()}.jpg")
                    file.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 86, it) }
                    file.absolutePath
                }.getOrNull()
            }
            if (path == null) say(R.string.msg_photo_failed)
            else coffeeDraft = coffeeDraft?.let { it.copy(coffee = it.coffee.copy(photoPath = path)) }
        }
    }

    // ---- grinders ---------------------------------------------------------------------------
    fun addGrinder(name: String) {
        val n = name.trim()
        if (n.isEmpty()) return
        viewModelScope.launch {
            val id = repo.saveGrinder(Grinder(name = n))
            if (current.defaultGrinderId == null) container.settingsStore.update { it.copy(defaultGrinderId = id) }
        }
    }

    fun deleteGrinder(g: Grinder) {
        viewModelScope.launch {
            repo.deleteGrinder(g)
            if (current.defaultGrinderId == g.id) container.settingsStore.update { it.copy(defaultGrinderId = null) }
        }
        if (grindFilter.grinderId == g.id) grindFilter = grindFilter.copy(grinderId = null)
    }

    // ---- copilot ----------------------------------------------------------------------------
    private fun roastAge(coffeeId: Long?): Int? {
        val day = coffees.value.firstOrNull { it.id == coffeeId }?.roastDateEpochDay ?: return null
        return (java.time.LocalDate.now().toEpochDay() - day).toInt().takeIf { it >= 0 }
    }

    fun diagnoseBrew(b: Brew) {
        diag = DiagState(
            title = b.recipeName.ifBlank { BrewMethod.fromKey(b.method).label },
            recipe = brewToSession(b),
            timeS = (b.timeMs / 1000).toInt().takeIf { it > 0 },
            roastAgeDays = roastAge(b.coffeeId),
            symptoms = b.symptoms.split(',').mapNotNull { n -> Symptom.entries.firstOrNull { it.name == n } }.toSet(),
        )
        open(Overlay.Diagnose)
    }

    fun diagnoseRecipe(r: Recipe) {
        val s = toSession(r)
        diag = DiagState(title = r.name, recipe = s, timeS = null, roastAgeDays = roastAge(s.coffeeId))
        open(Overlay.Diagnose)
    }

    /** Opens the diagnosis on the most relevant subject: last brew, else the loaded recipe. */
    fun diagnoseLatest() {
        val last = brews.value.firstOrNull()
        val r = session.state.value.recipe
        when {
            last != null -> diagnoseBrew(last)
            r != null -> { diag = DiagState(title = r.name, recipe = r, roastAgeDays = roastAge(r.coffeeId)); open(Overlay.Diagnose) }
            else -> open(Overlay.Diagnose)
        }
    }

    fun diagnosis(): CopilotEngine.Diagnosis? {
        val r = diag.recipe ?: return null
        return CopilotEngine.diagnose(
            CopilotEngine.BrewInput(r.method, r.doseG, r.waterG, r.tempC, diag.timeS, r.targetTimeS, r.grind, r.steps, diag.roastAgeDays),
            diag.symptoms,
        )
    }

    fun suggestedSession(d: CopilotEngine.Diagnosis): SessionRecipe? {
        val r = diag.recipe ?: return null
        val s = d.suggestion
        return r.copy(doseG = s.doseG, waterG = s.waterG, tempC = s.tempC, grind = s.grind, steps = s.steps, targetTimeS = s.targetTimeS)
    }

    fun saveSuggestion(d: CopilotEngine.Diagnosis) {
        val s = suggestedSession(d) ?: return
        viewModelScope.launch {
            val id = repo.saveRecipe(
                Recipe(
                    name = ctx.getString(R.string.adjusted_name, s.name),
                    method = s.method.name,
                    coffeeId = recipes.value.firstOrNull { it.id == s.recipeId }?.coffeeId,
                    doseG = s.doseG, waterG = s.waterG, tempC = s.tempC, grind = s.grind,
                    pressureBar = s.pressureBar, targetTimeS = s.targetTimeS,
                    stepsJson = StepsCodec.encode(s.steps), notes = s.notes,
                )
            )
            overlays.clear()
            tab = Tab.RECIPES
            recipePane = Pane.View(id)
            say(R.string.msg_recipe_saved)
        }
    }

    // ---- backup -----------------------------------------------------------------------------
    fun exportTo(uri: Uri) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val text = repo.exportJson()
                    app.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(text.toByteArray()) }
                }.isSuccess
            }
            say(if (ok) R.string.msg_export_ok else R.string.msg_export_failed)
        }
    }

    fun importFrom(uri: Uri) {
        val app = getApplication<Application>()
        cup.cancelPendingSave()
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val text = app.contentResolver.openInputStream(uri)!!.use { it.readBytes().decodeToString() }
                    repo.importJson(text)
                }.isSuccess
            }
            if (ok) {
                session.unload()
                recipePane = Pane.None; coffeePane = Pane.None; historySel = null
                leaveTraining()
                ensureSession()
                cup.reload()
            }
            say(if (ok) R.string.msg_import_ok else R.string.msg_import_failed)
        }
    }

    fun resetData() {
        viewModelScope.launch {
            session.unload()
            recipePane = Pane.None; coffeePane = Pane.None; historySel = null
            recipeDraft = null; coffeeDraft = null; logDraft = null
            leaveTraining()
            overlays.clear()
            tab = Tab.HOME
            cup.cancelPendingSave()
            repo.resetAll()
            cup.reload()
        }
    }

    /** Writes a cupping export (CSV or PDF) to a file the user picked. */
    fun writeCuppingFile(uri: Uri, bytes: ByteArray) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching { app.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(bytes) } }.isSuccess
            }
            say(if (ok) R.string.cup_file_saved else R.string.cup_file_failed)
        }
    }

    /** Launcher shortcut: open the cupping tab and ask before starting a new session. */
    fun cuppingShortcut() {
        overlays.clear()
        tab = Tab.CUPPING
        cup.screen = com.mountainfold.app.ui.cupping.CupScreen.MAIN
        cup.shortcutPrompt = true
    }

    // ---- Barista Trainer ----------------------------------------------------------------------
    val train: TrainContent get() = container.trainContent.content
    val trainEvents = repo.training.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val trainStack = mutableStateListOf<TrainScreen>()
    val trainScreen: TrainScreen get() = trainStack.lastOrNull() ?: TrainScreen.Home
    var lessonRun by mutableStateOf<LessonRun?>(null)
    var quiz by mutableStateOf<QuizRun?>(null)
    var quizResult by mutableStateOf<QuizResult?>(null)
    var filterSim by mutableStateOf(ExtractionSim.FilterInput())
    var shotSim by mutableStateOf(ExtractionSim.ShotInput())
    var labEspresso by mutableStateOf(false)
    var yieldCalc by mutableStateOf(Triple("15", "220", "1.36"))
    var milkTemp by mutableStateOf(20)

    /** Language of the lesson content, following the app language. */
    val lang: String get() = ctx.resources.configuration.locales[0].language

    private fun today(): Long = LocalDate.now().toEpochDay()
    private fun dayOf(ms: Long): Long = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate().toEpochDay()

    private fun TrainingEvent.toCore() = TrainEvent(
        createdAt, EventKind.entries.firstOrNull { it.name == kind } ?: EventKind.LESSON, refId, correct, total, xp, passed, breakdown,
    )

    fun progressOf(events: List<TrainingEvent>): Progress =
        TrainProgress.compute(events.map { it.toCore() }, train.lessonsByLevel, today(), ::dayOf)

    fun opportunityOf(brewList: List<Brew>): Opportunity? = TrainProgress.opportunity(
        brewList.map { b ->
            BrewSignal(b.createdAt, BrewMethod.fromKey(b.method).isEspresso, b.symptoms.split(',').mapNotNull { n -> Symptom.entries.firstOrNull { it.name == n } }.toSet())
        }
    )

    private fun prefersEspresso(): Boolean {
        val list = brews.value
        return if (list.isEmpty()) current.defaultMethod.isEspresso else list.count { BrewMethod.fromKey(it.method).isEspresso } * 2 > list.size
    }

    fun recommendationsOf(progress: Progress, brewList: List<Brew>): List<Recommendation> =
        TrainProgress.recommendations(progress, train.lessons, opportunityOf(brewList), prefersEspresso())

    fun openTrain(screen: TrainScreen) {
        overlays.clear()
        tab = Tab.TRAIN
        trainStack.remove(screen)
        trainStack.add(screen)
    }

    fun openLesson(id: String) {
        if (train.lesson(id) == null) return
        overlays.clear()
        tab = Tab.TRAIN
        quiz = null
        quizResult = null
        trainStack.removeAll { it is TrainScreen.LessonView || it == TrainScreen.Quiz || it == TrainScreen.Result }
        lessonRun = LessonRun(id)
        trainStack.add(TrainScreen.LessonView(id))
    }

    fun start(rec: Recommendation) = when (rec) {
        is Recommendation.LessonRec -> openLesson(rec.lessonId)
        is Recommendation.DialInRec -> startDialIn(rec.espresso)
        is Recommendation.ExamRec -> startExam(rec.category)
    }

    private fun leaveTraining() {
        trainStack.clear()
        quiz = null
        quizResult = null
        lessonRun = null
    }

    private fun trainBack() {
        when (val top = trainStack.last()) {
            is TrainScreen.LessonView -> {
                val run = lessonRun
                if (run != null && run.page > 0) lessonRun = run.copy(page = run.page - 1)
                else { trainStack.removeAt(trainStack.lastIndex); lessonRun = null }
            }
            TrainScreen.Quiz -> { quiz = null; trainStack.removeAt(trainStack.lastIndex) }
            TrainScreen.Result -> closeResult()
            else -> trainStack.remove(top)
        }
    }

    /** Lesson pages on a compact screen: one per theory block, one for the simulation, one to validate. */
    fun lessonPageCount(lesson: Lesson): Int = lesson.blocks.size + (if (lesson.sim != SimKind.NONE) 1 else 0) + 1

    fun lessonPage(delta: Int) {
        val run = lessonRun ?: return
        val lesson = train.lesson(run.lessonId) ?: return
        lessonRun = run.copy(page = (run.page + delta).coerceIn(0, lessonPageCount(lesson) - 1))
    }

    // ---- building quizzes -------------------------------------------------------------------
    private fun item(q: Question, skill: Skill, random: Random): QuizItem {
        val order = q.options.indices.shuffled(random)
        return QuizItem(q.id, q.skill ?: skill, q.prompt[lang], emptyList(), order.map { q.options[it][lang] }, order.indexOf(q.correct), q.why[lang])
    }

    private fun item(s: DialInGenerator.Scenario, index: Int, random: Random): QuizItem {
        val u = units()
        val i = s.input
        val espresso = i.method.isEspresso
        val ratio = CoffeeEngine.formatRatio(CoffeeEngine.ratio(i.waterG, i.doseG))
        val facts = buildList {
            add(ctx.getString(R.string.method) to (if (i.method == BrewMethod.CUSTOM) ctx.getString(R.string.method_custom) else i.method.label))
            add(ctx.getString(R.string.dose) to u.w(i.doseG))
            add(ctx.getString(if (espresso) R.string.yield_label else R.string.water) to "${u.w(i.waterG)} · $ratio")
            i.tempC?.let { add(ctx.getString(R.string.temperature) to u.t(it)) }
            i.timeS?.let { t ->
                val time = if (espresso) "$t s" else CoffeeEngine.formatClock(t.toLong())
                val target = if (espresso) "${i.targetTimeS} s" else CoffeeEngine.formatClock(i.targetTimeS.toLong())
                add(ctx.getString(R.string.time) to ctx.getString(R.string.time_vs_target, time, target))
            }
            add(ctx.getString(R.string.taste) to ctx.getString(CopilotText.symptom(s.symptom)))
        }
        val order = s.options.indices.shuffled(random)
        return QuizItem(
            id = "dialin_$index",
            skill = s.skill,
            prompt = ctx.getString(R.string.dialin_prompt),
            facts = facts,
            options = order.map { ctx.getString(CopilotText.changeTitle(s.options[it])) },
            correct = order.indexOf(0),
            why = ctx.getString(CopilotText.cause(s.diagnosis.cause)) + " " + ctx.getString(CopilotText.changeWhy(s.diagnosis.change)),
        )
    }

    private fun launch(run: QuizRun) {
        if (run.items.isEmpty()) return
        overlays.clear()
        tab = Tab.TRAIN
        quizResult = null
        quiz = run.copy(startedAtMs = SystemClock.elapsedRealtime())
        trainStack.removeAll { it == TrainScreen.Quiz || it == TrainScreen.Result }
        trainStack.add(TrainScreen.Quiz)
    }

    fun startLessonQuiz(lessonId: String) {
        val lesson = train.lesson(lessonId) ?: return
        val random = Random(System.nanoTime())
        launch(QuizRun(EventKind.LESSON, lesson.id, lesson.title[lang], lesson.questions.map { item(it, lesson.skill, random) }, lessonId = lesson.id))
    }

    fun startDialIn(espresso: Boolean, random: Random = Random(System.nanoTime())) {
        val scenarios = DialInGenerator.session(random, espresso, 5)
        launch(
            QuizRun(
                EventKind.DIAL_IN, if (espresso) SkillTree.DIAL_IN_ESPRESSO else SkillTree.DIAL_IN_FILTER,
                ctx.getString(if (espresso) R.string.train_dialin_espresso else R.string.train_dialin_filter),
                scenarios.mapIndexed { i, s -> item(s, i, random) },
            )
        )
    }

    /** One question a day, the same all day. Seeded by the date. */
    fun startDaily() {
        val day = today()
        val random = Random(day)
        val single = if (random.nextInt(3) == 0 && train.bank.isNotEmpty()) {
            val q = train.bank.random(random)
            item(q, q.skill ?: Skill.EXTRACTION, random)
        } else {
            item(DialInGenerator.generate(random, random.nextInt(3) == 0), 0, random)
        }
        launch(QuizRun(EventKind.DAILY, SkillTree.dayRef(day), ctx.getString(R.string.train_daily), listOf(single)))
    }

    /** Short test over a whole level. Passing validates its lessons without reading them. */
    fun startLevelTest(level: Int) {
        val random = Random(System.nanoTime())
        val lessons = train.lessons.filter { it.level == level }
        val picked = lessons.flatMap { l -> l.questions.shuffled(random).take(2).map { item(it, l.skill, random) } }.shuffled(random).take(6)
        launch(QuizRun(EventKind.LEVEL_TEST, SkillTree.levelRef(level), ctx.getString(R.string.train_level_test, level), picked))
    }

    fun startExam(category: ExamCategory) {
        val random = Random(System.nanoTime())
        val items = if (category == ExamCategory.TROUBLESHOOTING) {
            DialInGenerator.session(random, null, 8).mapIndexed { i, s -> item(s, i, random) } +
                train.bank.filter { it.id in setOf("bank_bitter_dry", "bank_weak_bitter") }.map { item(it, it.skill ?: Skill.EXTRACTION, random) }
        } else {
            val fromLessons = train.lessons.filter { it.skill in category.skills }.flatMap { l -> l.questions.map { item(it, l.skill, random) } }
            val fromBank = train.bank.filter { it.skill in category.skills }.map { item(it, it.skill!!, random) }
            (fromLessons + fromBank).shuffled(random).take(10)
        }
        launch(
            QuizRun(
                EventKind.EXAM, category.name, ctx.getString(R.string.train_exam), items.shuffled(random),
                timeLimitS = items.size * 30,
            )
        )
    }

    // ---- answering --------------------------------------------------------------------------
    fun answer(option: Int) {
        val run = quiz ?: return
        if (run.instantFeedback && run.selected != null) return
        quiz = run.copy(answers = run.answers.toMutableList().also { it[run.index] = option })
    }

    fun nextQuestion() {
        val run = quiz ?: return
        if (run.isLast) finishQuiz() else quiz = run.copy(index = run.index + 1)
    }

    fun previousQuestion() {
        val run = quiz ?: return
        if (!run.instantFeedback && run.index > 0) quiz = run.copy(index = run.index - 1)
    }

    fun finishQuiz() {
        val run = quiz ?: return
        if (quizResult?.run === run) return
        val correct = run.correctCount
        val total = run.items.size
        val passed = TrainProgress.passed(run.kind, correct, total)
        val duration = ((SystemClock.elapsedRealtime() - run.startedAtMs) / 1000).toInt().coerceAtLeast(0)
        val results = run.items.mapIndexed { i, it -> it.skill to (run.answers[i] == it.correct) }
        val before = trainEvents.value
        val progressBefore = progressOf(before)
        val firstValidation = run.kind == EventKind.LESSON && run.refId !in progressBefore.validated
        val xp = TrainProgress.xpFor(run.kind, passed, firstValidation)
        val now = System.currentTimeMillis()
        val skills = results.map { it.first }.distinct()
        val event = TrainingEvent(
            createdAt = now, kind = run.kind.name, refId = run.refId, skill = skills.singleOrNull()?.name.orEmpty(),
            correct = correct, total = total, durationS = duration, xp = xp, passed = passed, breakdown = Breakdown.encode(results),
        )
        val bonus = streakBonus(before, now)
        val weak = results.groupBy { it.first }.filter { (_, v) -> v.count { it.second } * 10 < v.size * 7 }.keys.toList()
        val after = listOfNotNull(event, bonus)
        val progressAfter = progressOf(before + after)
        quizResult = QuizResult(
            run = run, correct = correct, total = total, passed = passed,
            xp = xp + (bonus?.xp ?: 0), durationS = duration, weak = weak,
            recommendations = recommendationsOf(progressAfter, brews.value)
                .filterNot { it is Recommendation.LessonRec && it.lessonId == run.lessonId && passed },
            streakBonus = bonus != null,
            lessonValidated = run.kind == EventKind.LESSON && passed,
        )
        trainStack.remove(TrainScreen.Quiz)
        trainStack.add(TrainScreen.Result)
        viewModelScope.launch { repo.saveTrainingEvents(after) }
    }

    /** A bonus on every seventh consecutive day, granted once, by the first activity of that day. */
    private fun streakBonus(before: List<TrainingEvent>, now: Long): TrainingEvent? {
        val day = dayOf(now)
        if (before.any { it.kind != EventKind.STREAK_BONUS.name && dayOf(it.createdAt) == day }) return null
        val streak = TrainProgress.streak(before.map { it.toCore() } + TrainEvent(now, EventKind.DAILY, ""), day, ::dayOf)
        if (streak == 0 || streak % 7 != 0) return null
        return TrainingEvent(
            createdAt = now + 1, kind = EventKind.STREAK_BONUS.name, refId = "streak:$day",
            xp = TrainProgress.xpFor(EventKind.STREAK_BONUS, true, false), passed = true,
        )
    }

    fun closeResult() {
        val lessonId = quizResult?.run?.lessonId
        quiz = null
        quizResult = null
        trainStack.remove(TrainScreen.Result)
        if (lessonId != null) {
            trainStack.removeAll { it is TrainScreen.LessonView }
            lessonRun = null
        }
    }

    /** LEARN to BREW: the lesson's real-brew task waits for the next logged brew. */
    fun acceptBrewChallenge(lessonId: String) {
        setSettings { it.copy(pendingBrewChallenge = lessonId) }
        closeResult()
        tab = Tab.BREW
        say(R.string.msg_brew_challenge_set)
    }

    fun cancelBrewChallenge() = setSettings { it.copy(pendingBrewChallenge = null) }

    /** BREW to LOG: a tasted, logged brew earns XP and completes a pending brew challenge. */
    private suspend fun recordBrewForTraining(brewId: Long, brew: Brew): Boolean {
        val now = System.currentTimeMillis()
        val events = mutableListOf<TrainingEvent>()
        val tasted = brew.rating > 0 || listOf(brew.acidity, brew.sweetness, brew.body, brew.balance, brew.clarity).any { it > 0 } || brew.symptoms.isNotBlank()
        val pending = current.pendingBrewChallenge
        val challenge = pending != null && tasted
        if (challenge) {
            val lesson = train.lesson(pending!!)
            events += TrainingEvent(
                createdAt = now, kind = EventKind.BREW_CHALLENGE.name, refId = pending, skill = lesson?.skill?.name.orEmpty(),
                xp = TrainProgress.xpFor(EventKind.BREW_CHALLENGE, true, false), passed = true,
            )
            container.settingsStore.update { it.copy(pendingBrewChallenge = null) }
        }
        if (tasted) {
            events += TrainingEvent(
                createdAt = now + 1, kind = EventKind.TASTING_LOG.name, refId = "brew:$brewId", skill = Skill.SENSORY.name,
                xp = TrainProgress.xpFor(EventKind.TASTING_LOG, true, false), passed = true,
            )
        }
        if (events.isNotEmpty()) {
            streakBonus(trainEvents.value, now)?.let { events += it }
            repo.saveTrainingEvents(events)
        }
        return challenge
    }
}
