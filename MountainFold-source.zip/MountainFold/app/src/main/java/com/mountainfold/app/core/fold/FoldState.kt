package com.mountainfold.app.core.fold

import com.mountainfold.app.core.model.LayoutOverride

/** CLOSED = quick assistant. OPEN = workstation. FLEX = brewing companion. */
enum class Posture { CLOSED, OPEN, FLEX }

/** Hinge position in window pixels. A zero-thickness hinge is normal on a single flexible panel. */
data class HingeInfo(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
    val vertical: Boolean,
    val halfOpened: Boolean,
)

data class FoldState(val posture: Posture, val hinge: HingeInfo? = null)

object FoldStateResolver {
    /** Smallest side an unfolded window needs before it is treated as a workstation. */
    const val OPEN_MIN_SIDE_DP = 520f
    const val OPEN_MIN_WIDTH_DP = 600f

    fun resolve(widthDp: Float, heightDp: Float, hinge: HingeInfo?, override: LayoutOverride): FoldState {
        val auto = when {
            hinge != null && hinge.halfOpened -> Posture.FLEX
            widthDp >= OPEN_MIN_WIDTH_DP && minOf(widthDp, heightDp) >= OPEN_MIN_SIDE_DP -> Posture.OPEN
            else -> Posture.CLOSED
        }
        val posture = when (override) {
            LayoutOverride.AUTO -> auto
            LayoutOverride.CLOSED -> Posture.CLOSED
            LayoutOverride.OPEN -> Posture.OPEN
            LayoutOverride.FLEX -> Posture.FLEX
        }
        return FoldState(posture, hinge)
    }
}
