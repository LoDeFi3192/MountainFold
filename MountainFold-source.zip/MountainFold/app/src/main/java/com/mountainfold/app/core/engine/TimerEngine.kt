package com.mountainfold.app.core.engine

import com.mountainfold.app.core.model.BrewStep
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Timer state. Elapsed time is always derived from a monotonic clock, never from UI frames,
 * so rotation, folding, backgrounding and dropped frames cannot drift it.
 */
data class TimerState(
    val running: Boolean = false,
    val accumulatedMs: Long = 0L,
    val startedAtMs: Long? = null,
    val laps: List<Long> = emptyList(),
) {
    fun elapsedMs(nowMs: Long): Long =
        accumulatedMs + if (running && startedAtMs != null) (nowMs - startedAtMs).coerceAtLeast(0L) else 0L

    val hasStarted: Boolean get() = running || accumulatedMs > 0L
}

class TimerEngine(private val clock: () -> Long) {
    private val _state = MutableStateFlow(TimerState())
    val state: StateFlow<TimerState> = _state.asStateFlow()

    fun now(): Long = clock()
    fun elapsedMs(): Long = _state.value.elapsedMs(clock())

    fun start() = _state.update { if (it.running) it else it.copy(running = true, startedAtMs = clock()) }

    fun pause() = _state.update {
        if (!it.running) it else it.copy(running = false, accumulatedMs = it.elapsedMs(clock()), startedAtMs = null)
    }

    fun toggle() = if (_state.value.running) pause() else start()

    fun reset() { _state.value = TimerState() }

    fun lap() = _state.update { it.copy(laps = it.laps + it.elapsedMs(clock())) }

    /** Restores a timer after process death. [extraMs] is the wall-clock time spent while the process was gone. */
    fun restore(accumulatedMs: Long, running: Boolean, laps: List<Long>, extraMs: Long = 0L) {
        _state.value = TimerState(
            running = running,
            accumulatedMs = accumulatedMs + if (running) extraMs.coerceAtLeast(0L) else 0L,
            startedAtMs = if (running) clock() else null,
            laps = laps,
        )
    }
}

/** Step maths on a time-ordered list of steps. Pure functions. */
object StepSchedule {

    /** Index of the step active at [elapsedS], or -1 when there is none. */
    fun indexAt(steps: List<BrewStep>, elapsedS: Double): Int {
        var idx = -1
        for (i in steps.indices) if (steps[i].startS <= elapsedS) idx = i else break
        return idx
    }

    fun endOf(steps: List<BrewStep>, index: Int, targetS: Int): Int =
        if (index in 0 until steps.lastIndex) steps[index + 1].startS else maxOf(targetS, steps.getOrNull(index)?.startS ?: 0)

    /** Cumulative water expected on the scale once step [index] is done. */
    fun targetWaterAt(steps: List<BrewStep>, index: Int): Double? {
        for (i in index.coerceAtMost(steps.lastIndex) downTo 0) steps[i].targetWaterG?.let { return it }
        return null
    }

    /** Makes the current step [deltaS] longer by pushing every later step. Returns steps and new target. */
    fun extendCurrent(steps: List<BrewStep>, elapsedS: Double, targetS: Int, deltaS: Int): Pair<List<BrewStep>, Int> {
        val idx = indexAt(steps, elapsedS)
        val out = steps.mapIndexed { i, s -> if (i > idx) s.copy(startS = s.startS + deltaS) else s }
        return out to targetS + deltaS
    }

    /**
     * Jumps to the next step right now by sliding the rest of the schedule.
     * Returns null when there is no further step.
     */
    fun advanceNow(steps: List<BrewStep>, elapsedS: Double, targetS: Int): Pair<List<BrewStep>, Int>? {
        val next = indexAt(steps, elapsedS) + 1
        if (next !in steps.indices) return null
        val delta = elapsedS.toInt() - steps[next].startS
        val out = steps.mapIndexed { i, s -> if (i >= next) s.copy(startS = s.startS + delta) else s }
        return out to (targetS + delta).coerceAtLeast(out.last().startS)
    }

    /** Keeps steps sorted and non-negative. */
    fun normalize(steps: List<BrewStep>): List<BrewStep> =
        steps.map { it.copy(startS = it.startS.coerceAtLeast(0)) }.sortedBy { it.startS }
}
