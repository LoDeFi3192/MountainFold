package com.mountainfold.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.mountainfold.app.data.prefs.LanguageStore
import com.mountainfold.app.ui.MainViewModel
import com.mountainfold.app.ui.MountainFoldRoot
import com.mountainfold.app.ui.fold.rememberFoldState

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private var askedForNotifications = false

    override fun attachBaseContext(newBase: Context) = super.attachBaseContext(LanguageStore.wrap(newBase))

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val notifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
        if (savedInstanceState == null) handleShortcut(intent)
        setContent {
            MountainFoldRoot(
                vm = vm,
                foldState = { override -> rememberFoldState(this, override) },
                requestNotifications = {
                    // Asked once, at the first brew, when the reason is obvious. The timer works either way.
                    if (Build.VERSION.SDK_INT >= 33 && !askedForNotifications &&
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) {
                        askedForNotifications = true
                        runCatching { notifications.launch(Manifest.permission.POST_NOTIFICATIONS) }
                    }
                },
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShortcut(intent)
    }

    override fun onStop() {
        super.onStop()
        // Cupping edits are written with a short delay. Do not let a swipe-away lose the last one.
        vm.cup.flushAsync()
    }

    /** Launcher shortcut, the native twin of the original ?action=new_session link. */
    private fun handleShortcut(intent: Intent?) {
        if (intent?.action == ACTION_NEW_CUPPING) {
            vm.cuppingShortcut()
            intent.action = null
        }
    }

    companion object {
        const val ACTION_NEW_CUPPING = "com.mountainfold.app.action.NEW_CUPPING_SESSION"
    }
}
