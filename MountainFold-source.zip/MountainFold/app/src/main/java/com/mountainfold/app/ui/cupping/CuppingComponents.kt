package com.mountainfold.app.ui.cupping

import android.view.HapticFeedbackConstants
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.disabled
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mountainfold.app.R
import com.mountainfold.app.core.cupping.CuppingCatalog
import com.mountainfold.app.core.cupping.CuppingFormat
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.ZoneId
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Haptics preference for the module's sliders. */
val LocalCupHaptics = staticCompositionLocalOf { true }

@Composable
fun ProvideCupHaptics(enabled: Boolean, content: @Composable () -> Unit) =
    CompositionLocalProvider(LocalCupHaptics provides enabled, content = content)

/** Language of the aroma vocabulary, matched to the language the UI is shown in. */
@Composable
fun rememberCupLang(): String {
    val l = cupLocale().language
    return if (l == "fr" || l == "es") l else "en"
}

/** Locale of the strings on screen. Follows the in-app language, not only the system one. */
@Composable
fun cupLocale(): Locale {
    LocalConfiguration.current
    return LocalContext.current.resources.configuration.locales[0]
}

/** Short date with a four digit year, like toLocaleDateString(). */
@Composable
fun cupDate(epochMs: Long): String {
    val locale = cupLocale()
    return remember(epochMs, locale) { shortDate(locale).format(Date(epochMs)) }
}

@Composable
fun cupDate(iso: String): String {
    val locale = cupLocale()
    return remember(iso, locale) {
        runCatching {
            val ms = LocalDate.parse(iso).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
            shortDate(locale).format(Date(ms))
        }.getOrDefault(iso)
    }
}

fun shortDate(locale: Locale): SimpleDateFormat {
    val base = (DateFormat.getDateInstance(DateFormat.SHORT, locale) as? SimpleDateFormat)?.toPattern() ?: "dd/MM/yyyy"
    val pattern = if (base.contains("yyyy")) base else base.replace(Regex("y+"), "yyyy")
    return SimpleDateFormat(pattern, locale)
}

fun Long.argb(): Color = Color(this.toInt())

/** M3 elevated card of the original: low container, 16 dp corners, 16 dp padding. */
@Composable
fun TcCard(modifier: Modifier = Modifier, padding: Dp = 16.dp, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        shape = RoundedCornerShape(16.dp),
        shadowElevation = 1.dp,
        modifier = modifier.fillMaxWidth().padding(bottom = 16.dp),
    ) {
        Column(Modifier.padding(padding), content = content)
    }
}

@Composable
fun TcSectionTitle(text: String, icon: ImageVector?, modifier: Modifier = Modifier) {
    Row(modifier.padding(bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(12.dp))
        }
        Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun TcLogo(size: Dp, modifier: Modifier = Modifier) {
    Image(TcIcons.AppLogo, contentDescription = null, modifier = modifier.size(size))
}

/**
 * The pill slider of the original: 44 dp track filled from the left, a dot per step,
 * a centre mark, value with two decimals. Tap or drag anywhere on the track.
 */
@Composable
fun TcSlider(
    label: String,
    value: Double,
    onChange: (Double) -> Unit,
    modifier: Modifier = Modifier,
    min: Double = 6.0,
    max: Double = 10.0,
    step: Double = 0.25,
    enabled: Boolean = true,
    centered: Boolean = true,
) {
    var dragging by remember { mutableStateOf(false) }
    val view = LocalView.current
    val haptics = LocalCupHaptics.current
    val current by rememberUpdatedState(value)
    val change by rememberUpdatedState(onChange)
    val colors = MaterialTheme.colorScheme
    fun snap(v: Double): Double {
        val steps = ((v - min) / step).roundToInt()
        return (min + steps * step).coerceIn(min, max)
    }
    fun setFrom(x: Float, width: Int) {
        if (width <= 0) return
        val v = snap(min + (x / width).coerceIn(0f, 1f) * (max - min))
        if (v != current) {
            if (haptics) view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            change(v)
        }
    }
    val fill = ((value - min) / (max - min)).toFloat().coerceIn(0f, 1f)
    val scale by animateFloatAsState(if (dragging) 1.02f else 1f, tween(300), label = "slider")
    val shown = CuppingFormat.fixed2(value)

    Column(modifier.fillMaxWidth().padding(top = 8.dp, bottom = 24.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp).padding(bottom = 8.dp), verticalAlignment = Alignment.Bottom) {
            Text(label, style = MaterialTheme.typography.labelLarge, color = if (dragging) colors.primary else colors.onSurface, modifier = Modifier.weight(1f))
            Text(
                shown,
                style = MaterialTheme.typography.titleMedium.copy(fontFeatureSettings = "tnum"),
                color = if (dragging) colors.primary else colors.onSurfaceVariant,
            )
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(44.dp)
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .clip(CircleShape)
                .background(colors.surfaceContainerHighest)
                .semantics {
                    contentDescription = label
                    stateDescription = shown
                    progressBarRangeInfo = ProgressBarRangeInfo(value.toFloat(), min.toFloat()..max.toFloat(), ((max - min) / step).roundToInt() - 1)
                    if (enabled) setProgress { v -> change(snap(v.toDouble())); true } else disabled()
                }
                .then(
                    if (!enabled) Modifier else Modifier
                        .pointerInput(min, max, step) { detectTapGestures { setFrom(it.x, size.width) } }
                        .pointerInput(min, max, step) {
                            detectHorizontalDragGestures(
                                onDragStart = { dragging = true; setFrom(it.x, size.width) },
                                onDragEnd = { dragging = false },
                                onDragCancel = { dragging = false },
                            ) { change, _ -> change.consume(); setFrom(change.position.x, size.width) }
                        }
                ),
        ) {
            Canvas(Modifier.fillMaxWidth().height(44.dp)) {
                drawRect(colors.primary.copy(alpha = 0.9f), size = Size(size.width * fill, size.height))
                val count = ((max - min) / step).roundToInt()
                if (count in 2..50) {
                    for (i in 1 until count) {
                        val pct = i.toFloat() / count
                        val c = if (pct <= fill) colors.onPrimary.copy(alpha = 0.3f) else colors.onSurfaceVariant.copy(alpha = 0.2f)
                        drawCircle(c, radius = 1.dp.toPx(), center = Offset(size.width * pct, size.height / 2f))
                    }
                }
                if (centered) {
                    drawLine(colors.surface.copy(alpha = 0.3f), Offset(size.width / 2f, 0f), Offset(size.width / 2f, size.height), strokeWidth = 2.dp.toPx())
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp).padding(top = 4.dp)) {
            val muted = colors.onSurfaceVariant.copy(alpha = 0.5f)
            Text(CuppingFormat.jsNumber(min), style = MaterialTheme.typography.labelSmall, color = muted, modifier = Modifier.weight(1f))
            Text(CuppingFormat.jsNumber(max), style = MaterialTheme.typography.labelSmall, color = muted)
        }
    }
}

/** Filter chip of the original: coloured when selected, check mark, optional dot and delete cross. */
@Composable
fun TcChip(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    color: Color? = null,
    enabled: Boolean = true,
    dot: Color? = null,
    deleteDescription: String? = null,
    onDelete: (() -> Unit)? = null,
    onClick: (() -> Unit)? = null,
) {
    val colors = MaterialTheme.colorScheme
    val bg = if (selected) (color ?: CuppingCatalog.CHIP_DEFAULT.argb()) else colors.surfaceContainerHigh
    val fg = if (selected) CuppingCatalog.contrastOn(bgArgb(bg)).argb() else colors.onSurfaceVariant
    val active = enabled && onClick != null
    Row(
        modifier
            .graphicsLayer { alpha = if (active) 1f else 0.6f }
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .then(if (selected) Modifier else Modifier.border(1.dp, colors.outlineVariant, RoundedCornerShape(8.dp)))
            .then(if (active) Modifier.clickable(role = Role.Checkbox, onClick = onClick!!) else Modifier)
            .semantics { if (onClick != null) stateDescription = if (selected) "✓" else "" }
            .defaultMinSize(minHeight = 36.dp)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (selected) {
            Icon(Icons.Rounded.Check, contentDescription = null, tint = fg, modifier = Modifier.padding(end = 6.dp).size(16.dp))
        } else if (dot != null) {
            Box(Modifier.padding(end = 8.dp).size(8.dp).clip(CircleShape).background(dot.copy(alpha = 0.8f)))
        }
        Text(label, style = MaterialTheme.typography.labelLarge, color = fg, maxLines = 1)
        if (onDelete != null && enabled) {
            Box(
                Modifier
                    .padding(start = 8.dp)
                    .size(24.dp)
                    .clip(CircleShape)
                    .clickable(onClickLabel = deleteDescription, role = Role.Button, onClick = onDelete)
                    .semantics { if (deleteDescription != null) contentDescription = deleteDescription },
                contentAlignment = Alignment.Center,
            ) { Text("×", color = fg, style = MaterialTheme.typography.titleMedium) }
        }
    }
}

private fun bgArgb(c: Color): Long {
    val r = (c.red * 255).roundToInt()
    val g = (c.green * 255).roundToInt()
    val b = (c.blue * 255).roundToInt()
    return (0xFFL shl 24) or (r.toLong() shl 16) or (g.toLong() shl 8) or b.toLong()
}

/** Card with a title, a score slider and a hidden detail block, as in the original form. */
@Composable
fun CollapsibleSection(
    title: String,
    icon: ImageVector,
    score: Double,
    onScore: (Double) -> Unit,
    enabled: Boolean,
    label: String,
    key: String,
    content: @Composable ColumnScope.() -> Unit,
) {
    var open by rememberSaveable(key) { mutableStateOf(false) }
    val turn by animateFloatAsState(if (open) 180f else 0f, tween(300), label = "chevron")
    TcCard {
        Row(Modifier.fillMaxWidth().padding(bottom = 0.dp), verticalAlignment = Alignment.CenterVertically) {
            TcSectionTitle(title, icon, Modifier.weight(1f).padding(top = 16.dp))
            IconButton(onClick = { open = !open }) {
                Icon(
                    Icons.Rounded.KeyboardArrowDown,
                    contentDescription = stringResource(if (open) R.string.cup_hide_details else R.string.cup_show_details),
                    modifier = Modifier.rotate(turn),
                )
            }
        }
        TcSlider(label, score, onScore, enabled = enabled)
        AnimatedVisibility(open, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            Column(Modifier.padding(top = 0.dp), content = content)
        }
    }
}

@Composable
fun SmallCapsLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier.padding(bottom = 12.dp),
    )
}

/** Single choice chips for process, acidity and body. Selecting again keeps the choice, like the original. */
@Composable
fun ChoiceChips(options: List<CuppingCatalog.Term>, value: String, enabled: Boolean, lang: String, onPick: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o ->
            TcChip(o.label(lang), selected = value == o.key, enabled = enabled, onClick = { onPick(o.key) })
        }
    }
}

/** Aroma picker: selected notes on top, then one accordion per category. Hidden while the coffee is validated. */
@Composable
fun AromaSelector(selected: List<String>, onChange: (List<String>) -> Unit, enabled: Boolean, lang: String, key: String) {
    var expanded by rememberSaveable(key) { mutableStateOf<String?>(null) }
    val colors = MaterialTheme.colorScheme
    fun toggle(note: String) {
        if (!enabled) return
        onChange(if (note in selected) selected - note else selected + note)
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        val any = selected.isNotEmpty()
        val borderColor = if (any) colors.primary.copy(alpha = 0.3f) else colors.outlineVariant.copy(alpha = 0.3f)
        FlowRow(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (any) colors.surfaceContainerHigh else colors.surfaceContainerLow)
                .drawBehind {
                    drawRoundRect(
                        borderColor,
                        cornerRadius = CornerRadius(12.dp.toPx()),
                        style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 4.dp.toPx()))),
                    )
                }
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (!any) {
                Text(
                    stringResource(R.string.cup_no_aroma),
                    style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic),
                    color = colors.onSurfaceVariant.copy(alpha = 0.7f),
                    modifier = Modifier.padding(vertical = 4.dp),
                )
            }
            selected.forEach { note ->
                val l = CuppingCatalog.label(note, lang)
                TcChip(
                    l, selected = true, color = CuppingCatalog.noteColor(note)?.argb(), enabled = enabled,
                    deleteDescription = stringResource(R.string.cup_remove_note, l), onDelete = { toggle(note) },
                )
            }
        }
        if (enabled) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                CuppingCatalog.AROMA_CATEGORIES.forEach { cat ->
                    val isOpen = expanded == cat.id
                    val count = cat.items.count { it.key in selected }
                    val turn by animateFloatAsState(if (isOpen) 180f else 0f, tween(300), label = "cat")
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .border(BorderStroke(1.dp, if (isOpen) colors.primary else colors.outlineVariant.copy(alpha = 0.3f)), RoundedCornerShape(12.dp))
                            .background(if (isOpen) colors.surfaceContainerHigh else colors.surfaceContainerLow),
                    ) {
                        Row(
                            Modifier.fillMaxWidth().clickable { expanded = if (isOpen) null else cat.id }.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(Modifier.size(12.dp).clip(CircleShape).background(cat.color.argb()))
                            Spacer(Modifier.width(12.dp))
                            Text(cat.name.label(lang), style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium), color = colors.onSurface, modifier = Modifier.weight(1f))
                            if (count > 0) {
                                Box(Modifier.clip(CircleShape).background(colors.primary).padding(horizontal = 8.dp, vertical = 2.dp)) {
                                    Text("$count", color = colors.onPrimary, style = MaterialTheme.typography.labelSmall)
                                }
                                Spacer(Modifier.width(12.dp))
                            }
                            Text("▼", color = colors.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.rotate(turn))
                        }
                        AnimatedVisibility(isOpen, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                            FlowRow(
                                Modifier.fillMaxWidth().background(colors.surfaceContainer).padding(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                cat.items.forEach { item ->
                                    val isSel = item.key in selected
                                    val c = CuppingCatalog.noteColor(item.key)?.argb()
                                    TcChip(item.label(lang), selected = isSel, color = c, dot = c, onClick = { toggle(item.key) })
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Underlined name field with a floating label, as at the top of the original coffee card. */
@Composable
fun FloatingLabelField(value: String, onValueChange: (String) -> Unit, label: String, enabled: Boolean, modifier: Modifier = Modifier) {
    var focused by remember { mutableStateOf(false) }
    val colors = MaterialTheme.colorScheme
    val floated = focused || value.isNotEmpty()
    Column(modifier) {
        Text(
            label,
            style = if (floated) MaterialTheme.typography.labelSmall else MaterialTheme.typography.bodyLarge,
            color = if (floated) colors.primary else colors.onSurfaceVariant,
            modifier = Modifier.padding(bottom = if (floated) 2.dp else 0.dp),
        )
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            enabled = enabled,
            singleLine = true,
            textStyle = MaterialTheme.typography.headlineSmall.copy(color = colors.onSurface),
            cursorBrush = SolidColor(colors.primary),
            modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused }.semantics { contentDescription = label },
            decorationBox = { inner ->
                Column {
                    Box(Modifier.padding(bottom = 4.dp)) { inner() }
                    Box(Modifier.fillMaxWidth().height(if (focused) 2.dp else 1.dp).background(if (focused) colors.primary else colors.outline))
                }
            },
        )
    }
}

/** The circular cupping countdown with its 4/6 minute presets, used by the dialog, the Flex desk and the Open pane. */
@Composable
fun TimerRing(progress: Float, sixMinute: Boolean, size: Dp, content: @Composable () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val unit = this.size.minDimension / 200f
            val stroke = 8f * unit
            val r = 90f * unit
            val topLeft = Offset(center.x - r, center.y - r)
            drawCircle(colors.surfaceContainerHigh, radius = r, style = Stroke(stroke))
            if (sixMinute) {
                // Crust mark at 4 of 6 minutes, two thirds of the way round from the top.
                val a = Math.toRadians(-90.0 + 240.0)
                val c = Math.cos(a).toFloat()
                val s = Math.sin(a).toFloat()
                drawLine(
                    colors.onSurfaceVariant.copy(alpha = 0.5f),
                    Offset(center.x + c * 90f * unit, center.y + s * 90f * unit),
                    Offset(center.x + c * 75f * unit, center.y + s * 75f * unit),
                    strokeWidth = 4f * unit,
                )
            }
            if (progress > 0f) {
                drawArc(
                    colors.primary, startAngle = -90f, sweepAngle = 360f * progress, useCenter = false,
                    topLeft = topLeft, size = Size(2 * r, 2 * r),
                    style = Stroke(stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round),
                )
            }
        }
        content()
    }
}
