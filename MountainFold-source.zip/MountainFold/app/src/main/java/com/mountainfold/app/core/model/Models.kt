package com.mountainfold.app.core.model

import kotlinx.serialization.Serializable

/** Brew methods supported out of the box. Values are sensible starting points, not rules. */
enum class BrewMethod(
    val label: String,
    val defaultRatio: Double,
    val defaultTempC: Double?,
    val defaultDoseG: Double,
    val defaultTimeS: Int,
) {
    V60("V60", 16.7, 93.0, 15.0, 180),
    AEROPRESS("AeroPress", 15.0, 90.0, 15.0, 120),
    CHEMEX("Chemex", 16.0, 94.0, 30.0, 270),
    FRENCH_PRESS("French Press", 15.0, 95.0, 30.0, 480),
    MOKA("Moka Pot", 10.0, null, 15.0, 240),
    ESPRESSO("Espresso", 2.0, 93.0, 18.0, 28),
    CLEVER("Clever Dripper", 16.0, 95.0, 18.0, 210),
    KALITA("Kalita Wave", 16.0, 93.0, 20.0, 210),
    ORIGAMI("Origami", 16.0, 93.0, 15.0, 165),
    COLD_BREW("Cold Brew", 8.0, null, 100.0, 57600),
    CUSTOM("Custom", 16.0, 93.0, 15.0, 180);

    val isEspresso: Boolean get() = this == ESPRESSO

    companion object {
        fun fromKey(key: String?): BrewMethod = entries.firstOrNull { it.name == key } ?: V60
    }
}

enum class StepType { BLOOM, POUR, WAIT, STIR, SWIRL, PRESS, DRAWDOWN, CUSTOM }

/**
 * One step of a recipe. [startS] is the moment the step begins, counted from brew start.
 * [targetWaterG] is the cumulative weight on the scale at the end of the step, when relevant.
 */
@Serializable
data class BrewStep(
    val label: String,
    val type: StepType = StepType.POUR,
    val startS: Int = 0,
    val targetWaterG: Double? = null,
    val note: String = "",
)

/** Frozen copy of a recipe used by an active brew, so edits to the library never disturb a running timer. */
@Serializable
data class SessionRecipe(
    val recipeId: Long? = null,
    val name: String,
    val method: BrewMethod,
    val coffeeId: Long? = null,
    val coffeeName: String = "",
    val doseG: Double,
    val waterG: Double,
    val tempC: Double? = null,
    val grind: String = "",
    val pressureBar: Double? = null,
    val steps: List<BrewStep> = emptyList(),
    val targetTimeS: Int,
    val notes: String = "",
)

enum class Symptom { SOUR, BITTER, WEAK, STRONG, DRY, ASTRINGENT, FLAT, HOLLOW, HARSH, MUDDY }

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class Palette { COFFEE, MOUNTAIN, FOREST, STONE, TOULOUSE }
enum class WeightUnit { G, OZ }
enum class TempUnit { C, F }
enum class LayoutOverride { AUTO, CLOSED, OPEN, FLEX }
enum class FlexLayout { BREW, TIMER, RECIPE, SCALE, SHOT }
