package com.mountainfold.app.ui.cupping

import android.graphics.Paint
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mountainfold.app.R
import com.mountainfold.app.core.cupping.CuppingCatalog
import com.mountainfold.app.core.cupping.FlavorWheel
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * The spinning flavor wheel. Drag to turn, it keeps spinning and slows down (x0.92 per frame),
 * like the original. [pointerDeg] is where the arrow sits: 0 on the right (Closed, Open), 270 on top (Flex dial).
 */
@Composable
fun WheelSurface(
    cup: CuppingController,
    center: Offset,
    radius: Float,
    pointerDeg: Float,
    lang: String,
    reduced: Boolean,
    modifier: Modifier = Modifier,
) {
    val scope = rememberCoroutineScope()
    val view = LocalView.current
    val haptics = LocalCupHaptics.current
    val holder = remember { object { var job: Job? = null; var last = 0f; var velocity = 0f } }
    val colors = MaterialTheme.colorScheme
    val active = FlavorWheel.activeIndex(cup.wheelRotation, pointerDeg)
    val slice = FlavorWheel.slices[active]
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(active) {
        if (first) first = false else if (haptics) view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    }
    val description = stringResource(R.string.cup_wheel_cd, slice.category.name.label(lang), CuppingCatalog.label(slice.key, lang))
    val next = stringResource(R.string.cup_next_aroma)
    val prev = stringResource(R.string.cup_prev_aroma)
    fun angleOf(p: Offset) = Math.toDegrees(atan2((p.y - center.y).toDouble(), (p.x - center.x).toDouble())).toFloat()

    Canvas(
        modifier
            .semantics {
                contentDescription = description
                customActions = listOf(
                    CustomAccessibilityAction(next) { cup.wheelRotation = FlavorWheel.rotationFor((active + 1) % FlavorWheel.slices.size, cup.wheelRotation, pointerDeg); true },
                    CustomAccessibilityAction(prev) { cup.wheelRotation = FlavorWheel.rotationFor((active - 1 + FlavorWheel.slices.size) % FlavorWheel.slices.size, cup.wheelRotation, pointerDeg); true },
                )
            }
            .pointerInput(center, radius) {
                detectDragGestures(
                    onDragStart = { p -> holder.job?.cancel(); holder.last = angleOf(p); holder.velocity = 0f },
                    onDragEnd = {
                        if (reduced) return@detectDragGestures
                        holder.job = scope.launch {
                            var v = holder.velocity
                            var lastT = 0L
                            while (abs(v) > 0.05f) {
                                withFrameNanos { t ->
                                    val frames = if (lastT == 0L) 1f else ((t - lastT) / 16_666_667f).coerceIn(0.25f, 4f)
                                    lastT = t
                                    cup.wheelRotation += v * frames
                                    v *= 0.92f.pow(frames)
                                }
                            }
                        }
                    },
                ) { change, _ ->
                    change.consume()
                    val a = angleOf(change.position)
                    val d = FlavorWheel.delta(holder.last, a)
                    cup.wheelRotation += d
                    holder.velocity = d
                    holder.last = a
                }
            },
    ) {
        val rot = cup.wheelRotation
        val stroke = radius * 0.004f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.DEFAULT_BOLD
            textSize = radius * 0.05f
            textAlign = Paint.Align.CENTER
        }
        val topLeft = Offset(center.x - radius, center.y - radius)
        val sz = Size(radius * 2, radius * 2)
        FlavorWheel.slices.forEach { s ->
            drawArc(s.color.argb(), s.startDeg + rot, s.endDeg - s.startDeg, true, topLeft, sz)
            drawArc(colors.surface, s.startDeg + rot, s.endDeg - s.startDeg, true, topLeft, sz, style = Stroke(stroke))
        }
        FlavorWheel.slices.forEach { s ->
            val a = s.midDeg + rot
            val rad = Math.toRadians(a.toDouble())
            val tx = center.x + radius * 0.7f * cos(rad).toFloat()
            val ty = center.y + radius * 0.7f * sin(rad).toFloat()
            paint.color = CuppingCatalog.contrastOn(s.color).toInt()
            // Labels on the left half are turned round so they never read upside down (matters on the Flex dial).
            val norm = ((a % 360f) + 360f) % 360f
            val textAngle = if (norm > 90f && norm < 270f) a + 180f else a
            rotate(textAngle, Offset(tx, ty)) {
                drawContext.canvas.nativeCanvas.drawText(CuppingCatalog.label(s.key, lang), tx, ty - (paint.ascent() + paint.descent()) / 2f, paint)
            }
        }
        drawCircle(colors.surfaceContainerHigh, radius * 0.2f, center)
        drawCircle(colors.primary, radius * 0.04f, center)

        // Pointer: a triangle whose tip touches the rim, and a faint line going outwards.
        val p = Math.toRadians(pointerDeg.toDouble())
        val dir = Offset(cos(p).toFloat(), sin(p).toFloat())
        val normal = Offset(-dir.y, dir.x)
        val tip = center + dir * (radius - 2.dp.toPx())
        val base = tip + dir * 25.dp.toPx()
        val half = 15.dp.toPx()
        val tri = Path().apply {
            moveTo(tip.x, tip.y)
            lineTo(base.x + normal.x * half, base.y + normal.y * half)
            lineTo(base.x - normal.x * half, base.y - normal.y * half)
            close()
        }
        drawPath(tri, colors.onSurface)
        drawLine(colors.onSurface.copy(alpha = 0.2f), base, base + dir * (size.width * 0.1f), strokeWidth = 2.dp.toPx())
    }
}

private operator fun Offset.times(f: Float) = Offset(x * f, y * f)

/** Category pill, aroma name in its own colour and the short colour bar. */
@Composable
fun WheelInfo(rotation: Float, pointerDeg: Float, lang: String, modifier: Modifier = Modifier, nameSize: TextUnit = 48.sp, alignEnd: Boolean = true) {
    val s = FlavorWheel.slices[FlavorWheel.activeIndex(rotation, pointerDeg)]
    val colors = MaterialTheme.colorScheme
    Column(modifier, horizontalAlignment = if (alignEnd) Alignment.End else Alignment.CenterHorizontally) {
        Text(
            s.category.name.label(lang).uppercase(),
            style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 2.sp),
            color = colors.onSurfaceVariant,
            modifier = Modifier
                .padding(bottom = 8.dp)
                .clip(CircleShape)
                .background(colors.surfaceContainerHigh)
                .border(1.dp, colors.outline.copy(alpha = 0.2f), CircleShape)
                .padding(horizontal = 16.dp, vertical = 4.dp),
        )
        Text(
            CuppingCatalog.label(s.key, lang),
            style = MaterialTheme.typography.displayMedium.copy(fontSize = nameSize, lineHeight = nameSize * 1.1f, fontWeight = FontWeight.Black),
            color = s.color.argb(),
            textAlign = if (alignEnd) TextAlign.End else TextAlign.Center,
        )
        Box(Modifier.padding(vertical = 24.dp).width(96.dp).height(8.dp).clip(CircleShape).background(colors.onSurface.copy(alpha = 0.1f))) {
            Box(Modifier.fillMaxWidth(0.6f).height(8.dp).clip(CircleShape).background(s.color.argb()))
        }
    }
}

/** Other aromas of the active family, shown beside the wheel on the big screen. */
@Composable
fun WheelSiblings(rotation: Float, pointerDeg: Float, lang: String, modifier: Modifier = Modifier, onPick: (Int) -> Unit = {}) {
    val s = FlavorWheel.slices[FlavorWheel.activeIndex(rotation, pointerDeg)]
    FlowRow(modifier, horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        s.category.items.forEach { item ->
            val c = (CuppingCatalog.ITEM_COLOR_OVERRIDES[item.key] ?: s.category.color).argb()
            TcChip(item.label(lang), selected = item.key == s.key, color = c, dot = c, onClick = { onPick(FlavorWheel.slices.indexOfFirst { it.key == item.key }) })
        }
    }
}

/** Soft fade from the wheel to the text side, as in the original. */
@Composable
fun WheelFade(modifier: Modifier = Modifier) {
    val surface = MaterialTheme.colorScheme.surface
    Box(
        modifier.background(
            androidx.compose.ui.graphics.Brush.horizontalGradient(0f to Color.Transparent, 0.5f to Color.Transparent, 1f to surface.copy(alpha = 0.9f)),
        ),
    )
}

/** Full-screen wheel: centre on the left edge, radius 36.5 % of the height, arrow on the right of the rim. */
@Composable
fun FlavorWheelFull(cup: CuppingController, lang: String, reduced: Boolean, onClose: () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        val h = constraints.maxHeight.toFloat()
        val w = constraints.maxWidth.toFloat()
        val r = minOf(0.365f * h, w * 0.9f)
        WheelSurface(cup, Offset(0f, h / 2f), r, 0f, lang, reduced, Modifier.fillMaxSize())
        WheelFade(Modifier.fillMaxSize())
        WheelInfo(
            cup.wheelRotation, 0f, lang,
            Modifier.align(Alignment.TopEnd).padding(top = 128.dp, end = 24.dp).fillMaxWidth(0.62f),
        )
        androidx.compose.material3.Button(onClick = onClose, modifier = Modifier.align(Alignment.TopEnd).padding(top = 24.dp, end = 24.dp)) {
            Text(stringResource(R.string.cup_close))
        }
    }
}

fun Color.argbInt(): Int = toArgb()
