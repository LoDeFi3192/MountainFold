package com.mountainfold.app.ui.components

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.TextAutoSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material3.LocalContentColor
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mountainfold.app.R
import com.mountainfold.app.core.engine.CoffeeEngine
import com.mountainfold.app.core.engine.StepSchedule
import com.mountainfold.app.core.engine.TimerState
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.BrewStep
import com.mountainfold.app.core.model.SessionRecipe
import com.mountainfold.app.data.session.BrewSessionManager
import com.mountainfold.app.data.session.SessionState
import com.mountainfold.app.ui.LocalUnits
import com.mountainfold.app.ui.theme.TimerStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun methodLabel(m: BrewMethod): String = if (m == BrewMethod.CUSTOM) stringResource(R.string.method_custom) else m.label

/** Everything a brew screen needs, derived once per tick from the session. */
class BrewUi(
    val recipe: SessionRecipe,
    val state: SessionState,
    val timer: TimerState,
    val elapsedMs: Long,
    val pouredG: Double,
) {
    val elapsedS: Double get() = elapsedMs / 1000.0
    val steps: List<BrewStep> get() = recipe.steps
    val espresso: Boolean get() = recipe.method.isEspresso
    val stepIndex: Int = StepSchedule.indexAt(steps, elapsedS)
    val step: BrewStep? = steps.getOrNull(stepIndex)
    val next: BrewStep? = steps.getOrNull(stepIndex + 1)
    val stepEndS: Int = StepSchedule.endOf(steps, stepIndex, recipe.targetTimeS)
    val stepRemainingS: Long = Math.ceil((stepEndS - elapsedS).coerceAtLeast(0.0)).toLong()
    val progress: Float =
        if (recipe.targetTimeS > 0) (elapsedS / recipe.targetTimeS).coerceIn(0.0, 1.0).toFloat() else 0f
    val targetWaterNow: Double = StepSchedule.targetWaterAt(steps, stepIndex.coerceAtLeast(0)) ?: recipe.waterG
    val ratio: Double? = CoffeeEngine.ratio(recipe.waterG, recipe.doseG)
    val liveRatio: Double? = if (pouredG > 0.0) CoffeeEngine.ratio(pouredG, recipe.doseG) else null
    val timeText: String =
        if (espresso) CoffeeEngine.formatTenths(elapsedMs) else CoffeeEngine.formatClock(elapsedMs / 1000)
    val targetText: String =
        if (espresso) "${recipe.targetTimeS} s" else CoffeeEngine.formatClock(recipe.targetTimeS.toLong())
    val running: Boolean get() = timer.running
    val started: Boolean get() = timer.hasStarted
}

/**
 * Elapsed time for display. The value is read from the engine's monotonic clock;
 * this loop only decides how often the screen repaints.
 */
@Composable
fun rememberBrewUi(session: BrewSessionManager): BrewUi? {
    val state by session.state.collectAsStateWithLifecycle()
    val timer by session.timer.state.collectAsStateWithLifecycle()
    val poured by session.weight.weightG.collectAsStateWithLifecycle()
    val recipe = state.recipe ?: return null
    val quantum = if (recipe.method.isEspresso) 100L else 200L
    var elapsed by remember { mutableLongStateOf(session.timer.elapsedMs()) }
    LaunchedEffect(timer, quantum) {
        elapsed = session.timer.elapsedMs()
        while (timer.running) {
            delay(quantum / 4)
            elapsed = session.timer.elapsedMs() / quantum * quantum
        }
    }
    val shown = if (timer.running) elapsed else timer.accumulatedMs
    return BrewUi(recipe, state, timer, shown, poured)
}

@Composable
fun TimerText(text: String, size: TextUnit, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.onSurface) {
    val label = stringResource(R.string.cd_timer, text)
    Text(
        text = text,
        style = TimerStyle.copy(fontSize = size, lineHeight = size),
        color = color,
        maxLines = 1,
        softWrap = false,
        modifier = modifier.semantics { contentDescription = label },
    )
}

/** Small label above a value. The basic building block for brew parameters. */
@Composable
fun Stat(label: String, value: String, modifier: Modifier = Modifier, valueStyle: TextStyle = MaterialTheme.typography.titleLarge) {
    Column(modifier) {
        Text(label.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        Text(value, style = valueStyle, color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = modifier.padding(top = 20.dp, bottom = 8.dp),
    )
}

@Composable
fun ScreenHeader(title: String, modifier: Modifier = Modifier, onBack: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    Row(modifier.fillMaxWidth().heightIn(min = 64.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = stringResource(R.string.back))
            }
        } else {
            Spacer(Modifier.width(16.dp))
        }
        Text(
            title,
            style = MaterialTheme.typography.headlineSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).padding(horizontal = 4.dp),
        )
        actions()
    }
}

/** Large, table-friendly action. Height is generous so it can be hit without holding the phone. */
@Composable
fun BigButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    primary: Boolean = false,
    enabled: Boolean = true,
    minHeight: Dp = 64.dp,
    /** Table-distance labels for Flex Mode. */
    large: Boolean = false,
) {
    val labelStyle = if (large) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.titleMedium
    val content: @Composable RowScope.() -> Unit = {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(if (large) 30.dp else 22.dp))
            Spacer(Modifier.width(if (large) 12.dp else 8.dp))
        }
        // The label shrinks before it truncates, so long translations and large text stay readable.
        BasicText(
            text = text,
            style = labelStyle.copy(color = LocalContentColor.current, textAlign = TextAlign.Center),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            autoSize = TextAutoSize.StepBased(minFontSize = 8.sp, maxFontSize = labelStyle.fontSize, stepSize = 0.5.sp),
            modifier = Modifier.weight(1f, fill = false),
        )
    }
    val m = modifier.defaultMinSize(minHeight = minHeight)
    val padding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
    if (primary) {
        Button(onClick, m, enabled = enabled, shape = MaterialTheme.shapes.large, contentPadding = padding, content = content)
    } else {
        FilledTonalButton(onClick, m, enabled = enabled, shape = MaterialTheme.shapes.large, contentPadding = padding, content = content)
    }
}

/** Navigation label that shrinks instead of clipping at large font scales or in long languages. */
@Composable
fun NavLabel(text: String) {
    BasicText(
        text = text,
        style = MaterialTheme.typography.labelMedium.copy(color = LocalContentColor.current, textAlign = TextAlign.Center),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        autoSize = TextAutoSize.StepBased(minFontSize = 7.sp, maxFontSize = MaterialTheme.typography.labelMedium.fontSize, stepSize = 0.5.sp),
        // Slots hand out unbounded width, so the cap is what lets the text size itself down.
        modifier = Modifier.widthIn(max = 70.dp),
    )
}

@Composable
fun NumField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    suffix: String? = null,
    isError: Boolean = false,
) {
    OutlinedTextField(
        value = value,
        onValueChange = { v -> onValueChange(v.filter { it.isDigit() || it == '.' || it == ',' || it == ':' }) },
        label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        suffix = suffix?.let { { Text(it) } },
        singleLine = true,
        isError = isError,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier,
    )
}

@Composable
fun TextFieldLine(value: String, onValueChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, singleLine: Boolean = true, minLines: Int = 1) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        singleLine = singleLine,
        minLines = minLines,
        modifier = modifier,
    )
}

@Composable
fun StepperButtons(onMinus: () -> Unit, onPlus: () -> Unit, minusLabel: String, plusLabel: String, modifier: Modifier = Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilledTonalIconButton(onClick = onMinus, modifier = Modifier.size(48.dp)) { Icon(Icons.Rounded.Remove, contentDescription = minusLabel) }
        FilledTonalIconButton(onClick = onPlus, modifier = Modifier.size(48.dp)) { Icon(Icons.Rounded.Add, contentDescription = plusLabel) }
    }
}

@Composable
fun StarRating(value: Int, modifier: Modifier = Modifier, onChange: ((Int) -> Unit)? = null, size: Dp = 40.dp) {
    val label = stringResource(R.string.cd_rating, value)
    Row(modifier.semantics { contentDescription = label }) {
        for (i in 1..5) {
            val filled = i <= value
            val icon = if (filled) Icons.Rounded.Star else Icons.Rounded.StarBorder
            val tint = if (filled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
            if (onChange != null) {
                IconButton(onClick = { onChange(if (value == i) i - 1 else i) }, modifier = Modifier.size(maxOf(size, 48.dp))) {
                    Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.8f))
                }
            } else {
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size))
            }
        }
    }
}

/** Five-level scale for one taste axis. Read-only when [onChange] is null. */
@Composable
fun LevelRow(label: String, value: Int, modifier: Modifier = Modifier, onChange: ((Int) -> Unit)? = null) {
    Row(modifier.fillMaxWidth().heightIn(min = if (onChange != null) 48.dp else 32.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Row(horizontalArrangement = Arrangement.spacedBy(if (onChange != null) 0.dp else 6.dp)) {
            for (i in 1..5) {
                val on = i <= value
                val color = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest
                if (onChange != null) {
                    val cd = "$label $i"
                    Box(
                        Modifier.size(48.dp).clip(CircleShape)
                            .clickable(role = Role.RadioButton) { onChange(if (value == i) i - 1 else i) }
                            .semantics { contentDescription = cd },
                        contentAlignment = Alignment.Center,
                    ) {
                        Box(Modifier.size(22.dp).clip(CircleShape).background(color))
                    }
                } else {
                    Box(Modifier.size(14.dp).clip(CircleShape).background(color))
                }
            }
        }
    }
}

/** Recipe steps as a timeline. The active step is lifted on a tonal surface. */
@Composable
fun StepList(steps: List<BrewStep>, currentIndex: Int, targetS: Int, modifier: Modifier = Modifier, showNotes: Boolean = true, started: Boolean = true) {
    val units = LocalUnits.current
    val clockStyle = TimerStyle.copy(fontSize = MaterialTheme.typography.titleMedium.fontSize, letterSpacing = TextUnit.Unspecified)
    Column(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        steps.forEachIndexed { i, s ->
            val active = started && i == currentIndex
            val done = started && i < currentIndex
            Surface(
                color = if (active) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                contentColor = when {
                    active -> MaterialTheme.colorScheme.onPrimaryContainer
                    done -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    else -> MaterialTheme.colorScheme.onSurface
                },
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.Top) {
                    Text(CoffeeEngine.formatClock(s.startS.toLong()), style = clockStyle, modifier = Modifier.width(72.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.label, style = MaterialTheme.typography.titleMedium)
                        if (showNotes && s.note.isNotBlank()) {
                            Text(s.note, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 2.dp))
                        }
                    }
                    s.targetWaterG?.let {
                        Text("→ ${units.w(it)}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        }
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text(
                CoffeeEngine.formatClock(targetS.toLong()),
                style = clockStyle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.width(72.dp),
            )
            Text(stringResource(R.string.target), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/**
 * Two panes split exactly on the hinge when there is one, otherwise by weight.
 * LEFT = KNOW, RIGHT = DO.
 */
@Composable
fun TwoPane(
    hinge: HingeInfo?,
    modifier: Modifier = Modifier,
    leftWeight: Float = 0.5f,
    left: @Composable () -> Unit,
    right: @Composable () -> Unit,
) {
    var originX by remember { mutableIntStateOf(0) }
    BoxWithConstraints(modifier.onGloballyPositioned { originX = it.positionInWindow().x.toInt() }) {
        val total = constraints.maxWidth
        val density = LocalDensity.current
        val split = hinge?.takeIf { it.vertical }?.let { h ->
            val l = h.left - originX
            if (l > total * 0.25f && l < total * 0.75f) l to (h.right - h.left).coerceAtLeast(0) else null
        }
        Row(Modifier.fillMaxSize()) {
            if (split != null) {
                Box(Modifier.width(with(density) { split.first.toDp() }).fillMaxHeight()) { left() }
                Spacer(Modifier.width(with(density) { split.second.toDp() }))
                Box(Modifier.weight(1f).fillMaxHeight()) { right() }
            } else {
                Box(Modifier.weight(leftWeight).fillMaxHeight()) { left() }
                Box(Modifier.weight(1f - leftWeight).fillMaxHeight()) { right() }
            }
        }
    }
}

/** Tabletop split: information above the hinge, controls below it. */
@Composable
fun FlexSplit(hinge: HingeInfo?, modifier: Modifier = Modifier, top: @Composable () -> Unit, bottom: @Composable () -> Unit) {
    if (hinge != null && hinge.vertical) {
        TwoPane(hinge, modifier, left = top, right = bottom)
        return
    }
    var originY by remember { mutableIntStateOf(0) }
    BoxWithConstraints(modifier.onGloballyPositioned { originY = it.positionInWindow().y.toInt() }) {
        val total = constraints.maxHeight
        val density = LocalDensity.current
        val split = hinge?.let { h ->
            val t = h.top - originY
            if (t > total * 0.25f && t < total * 0.75f) t to (h.bottom - h.top).coerceAtLeast(0) else null
        }
        Column(Modifier.fillMaxSize()) {
            if (split != null) {
                Box(Modifier.height(with(density) { split.first.toDp() }).fillMaxWidth()) { top() }
                Spacer(Modifier.height(with(density) { split.second.toDp() }))
                Box(Modifier.weight(1f).fillMaxWidth()) { bottom() }
            } else {
                Box(Modifier.weight(1f).fillMaxWidth()) { top() }
                Box(Modifier.weight(1f).fillMaxWidth()) { bottom() }
            }
        }
    }
}

@Composable
fun CoffeePhoto(path: String?, modifier: Modifier = Modifier, contentDescription: String? = null) {
    val bitmap by produceState<android.graphics.Bitmap?>(null, path) {
        value = if (path == null) null else withContext(Dispatchers.IO) {
            runCatching {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(path, bounds)
                var sample = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1200) sample *= 2
                BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
            }.getOrNull()
        }
    }
    Box(modifier.clip(MaterialTheme.shapes.medium).background(MaterialTheme.colorScheme.surfaceContainerHigh)) {
        bitmap?.let {
            Image(it.asImageBitmap(), contentDescription = contentDescription, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, body: String, modifier: Modifier = Modifier, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    Column(modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(4.dp))
        Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(16.dp))
            Button(onClick = onAction) { Text(actionLabel) }
        }
    }
}

@Composable
fun ConfirmDialog(title: String, body: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(body) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

/** A field that opens a menu. Used for method, coffee, grinder and step type. */
@Composable
fun <T> DropdownField(
    label: String,
    value: String,
    options: List<T>,
    optionLabel: @Composable (T) -> String,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            singleLine = true,
            label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            trailingIcon = { Icon(Icons.Rounded.ExpandMore, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
        )
        // Transparent layer so the whole field opens the menu and stays one target.
        Box(Modifier.matchParentSize().clip(MaterialTheme.shapes.extraSmall).clickable(role = Role.DropdownList) { open = true })
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o ->
                DropdownMenuItem(text = { Text(optionLabel(o)) }, onClick = { open = false; onSelect(o) })
            }
        }
    }
}

/** Plain row for lists. No card, just type on a quiet surface. */
@Composable
fun ListRow(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    selected: Boolean = false,
    leading: (@Composable () -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
    onClick: (() -> Unit)? = null,
) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent,
        shape = MaterialTheme.shapes.medium,
        modifier = modifier.fillMaxWidth().then(if (onClick != null) Modifier.clip(MaterialTheme.shapes.medium).clickable(onClick = onClick) else Modifier),
    ) {
        Row(Modifier.heightIn(min = 64.dp).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (leading != null) {
                leading()
                Spacer(Modifier.width(14.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (!subtitle.isNullOrBlank()) {
                    Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
            if (trailing != null) {
                Spacer(Modifier.width(8.dp))
                trailing()
            }
        }
    }
}

@Composable
fun ThinDivider(modifier: Modifier = Modifier) {
    HorizontalDivider(modifier, color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
}
