package com.mountainfold.app.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import com.mountainfold.app.core.model.Palette
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * Fallback colour system used when Dynamic Color is off or unavailable.
 * Tonal palettes are built in CIE LCh so that "tone" means perceptual lightness,
 * the same idea Material You uses. Presets stay deliberately quiet.
 */
object Palettes {

    private data class Seed(
        val primaryHue: Double, val primaryChroma: Double,
        val secondaryHue: Double, val secondaryChroma: Double,
        val tertiaryHue: Double, val tertiaryChroma: Double,
        val neutralHue: Double, val neutralChroma: Double,
    )

    private fun seed(p: Palette) = when (p) {
        Palette.COFFEE -> Seed(58.0, 40.0, 68.0, 16.0, 115.0, 26.0, 62.0, 6.0)
        Palette.MOUNTAIN -> Seed(255.0, 30.0, 245.0, 12.0, 60.0, 30.0, 255.0, 5.0)
        Palette.FOREST -> Seed(150.0, 34.0, 140.0, 13.0, 85.0, 28.0, 140.0, 5.0)
        Palette.STONE -> Seed(80.0, 9.0, 80.0, 6.0, 45.0, 22.0, 80.0, 3.0)
        Palette.TOULOUSE -> Seed(58.0, 40.0, 68.0, 16.0, 115.0, 26.0, 62.0, 6.0)
    }

    fun scheme(palette: Palette, dark: Boolean): ColorScheme {
        if (palette == Palette.TOULOUSE) return toulouse(dark)
        val s = seed(palette)
        fun p(t: Double) = lch(t, s.primaryChroma, s.primaryHue)
        fun sec(t: Double) = lch(t, s.secondaryChroma, s.secondaryHue)
        fun ter(t: Double) = lch(t, s.tertiaryChroma, s.tertiaryHue)
        fun n(t: Double) = lch(t, s.neutralChroma, s.neutralHue)
        fun nv(t: Double) = lch(t, s.neutralChroma * 2.0 + 2.0, s.neutralHue)
        fun err(t: Double) = lch(t, 60.0, 30.0)
        return if (!dark) lightColorScheme(
            primary = p(38.0), onPrimary = p(100.0), primaryContainer = p(90.0), onPrimaryContainer = p(14.0),
            secondary = sec(40.0), onSecondary = sec(100.0), secondaryContainer = sec(90.0), onSecondaryContainer = sec(14.0),
            tertiary = ter(40.0), onTertiary = ter(100.0), tertiaryContainer = ter(90.0), onTertiaryContainer = ter(14.0),
            error = err(40.0), onError = err(100.0), errorContainer = err(90.0), onErrorContainer = err(14.0),
            background = n(98.0), onBackground = n(10.0), surface = n(98.0), onSurface = n(10.0),
            surfaceVariant = nv(90.0), onSurfaceVariant = nv(30.0), outline = nv(48.0), outlineVariant = nv(80.0),
            inverseSurface = n(20.0), inverseOnSurface = n(95.0), inversePrimary = p(80.0), surfaceTint = p(38.0),
            surfaceDim = n(87.0), surfaceBright = n(98.0), surfaceContainerLowest = n(100.0),
            surfaceContainerLow = n(96.0), surfaceContainer = n(94.0), surfaceContainerHigh = n(92.0),
            surfaceContainerHighest = n(90.0), scrim = Color.Black,
        ) else darkColorScheme(
            primary = p(82.0), onPrimary = p(20.0), primaryContainer = p(30.0), onPrimaryContainer = p(92.0),
            secondary = sec(80.0), onSecondary = sec(20.0), secondaryContainer = sec(30.0), onSecondaryContainer = sec(90.0),
            tertiary = ter(80.0), onTertiary = ter(20.0), tertiaryContainer = ter(30.0), onTertiaryContainer = ter(90.0),
            error = err(80.0), onError = err(20.0), errorContainer = err(30.0), onErrorContainer = err(90.0),
            background = n(5.0), onBackground = n(92.0), surface = n(5.0), onSurface = n(92.0),
            surfaceVariant = nv(28.0), onSurfaceVariant = nv(82.0), outline = nv(60.0), outlineVariant = nv(28.0),
            inverseSurface = n(90.0), inverseOnSurface = n(20.0), inversePrimary = p(38.0), surfaceTint = p(82.0),
            surfaceDim = n(5.0), surfaceBright = n(24.0), surfaceContainerLowest = n(3.0),
            surfaceContainerLow = n(9.0), surfaceContainer = n(12.0), surfaceContainerHigh = n(16.0),
            surfaceContainerHighest = n(21.0), scrim = Color.Black,
        )
    }

    /** The exact light "Coffee" and dark "Espresso" tokens of the Toulouse Cupping web app. */
    private fun toulouse(dark: Boolean): ColorScheme {
        fun c(hex: Long) = Color(hex)
        return if (!dark) lightColorScheme(
            primary = c(0xFF8D6E4D), onPrimary = c(0xFFFFFFFF), primaryContainer = c(0xFFFFDCBE), onPrimaryContainer = c(0xFF2C1600),
            secondary = c(0xFF77574E), onSecondary = c(0xFFFFFFFF), secondaryContainer = c(0xFFFFDBD1), onSecondaryContainer = c(0xFF2C150F),
            tertiary = c(0xFF6C5D2F), onTertiary = c(0xFFFFFFFF), tertiaryContainer = c(0xFFF5E1A6), onTertiaryContainer = c(0xFF221B00),
            error = c(0xFFBA1A1A), onError = c(0xFFFFFFFF), errorContainer = c(0xFFFFDAD6), onErrorContainer = c(0xFF410002),
            background = c(0xFFFFF8F6), onBackground = c(0xFF201A18), surface = c(0xFFFFF8F6), onSurface = c(0xFF201A18),
            surfaceVariant = c(0xFFF4DED4), onSurfaceVariant = c(0xFF52433D), outline = c(0xFF85736D), outlineVariant = c(0xFFD7C2B8),
            inverseSurface = c(0xFF362F2C), inverseOnSurface = c(0xFFFBEEE9), inversePrimary = c(0xFFFFB77C), surfaceTint = c(0xFF8D6E4D),
            surfaceDim = c(0xFFE8D7D1), surfaceBright = c(0xFFFFF8F6), surfaceContainerLowest = c(0xFFFFFFFF),
            surfaceContainerLow = c(0xFFFFF1EC), surfaceContainer = c(0xFFFCECE6), surfaceContainerHigh = c(0xFFF6E6E0),
            surfaceContainerHighest = c(0xFFF0E1DB), scrim = Color.Black,
        ) else darkColorScheme(
            primary = c(0xFFFFB77C), onPrimary = c(0xFF50381A), primaryContainer = c(0xFF6E5231), onPrimaryContainer = c(0xFFFFDCBE),
            secondary = c(0xFFE7BDB2), onSecondary = c(0xFF442922), secondaryContainer = c(0xFF5D3F38), onSecondaryContainer = c(0xFFFFDBD1),
            tertiary = c(0xFFD8C58D), onTertiary = c(0xFF3B2F06), tertiaryContainer = c(0xFF53461A), onTertiaryContainer = c(0xFFF5E1A6),
            error = c(0xFFFFB4AB), onError = c(0xFF690005), errorContainer = c(0xFF93000A), onErrorContainer = c(0xFFFFDAD6),
            background = c(0xFF18120F), onBackground = c(0xFFECE0DB), surface = c(0xFF18120F), onSurface = c(0xFFECE0DB),
            surfaceVariant = c(0xFF52433D), onSurfaceVariant = c(0xFFD7C2B8), outline = c(0xFFA08C85), outlineVariant = c(0xFF52433D),
            inverseSurface = c(0xFFECE0DB), inverseOnSurface = c(0xFF362F2C), inversePrimary = c(0xFF8D6E4D), surfaceTint = c(0xFFFFB77C),
            surfaceDim = c(0xFF18120F), surfaceBright = c(0xFF3F3734), surfaceContainerLowest = c(0xFF0F0A07),
            surfaceContainerLow = c(0xFF1D1714), surfaceContainer = c(0xFF211B18), surfaceContainerHigh = c(0xFF2B2522),
            surfaceContainerHighest = c(0xFF362F2C), scrim = Color.Black,
        )
    }

    /** CIE LCh(ab) to sRGB. Chroma is reduced until the colour fits the gamut, keeping lightness intact. */
    fun lch(l: Double, c: Double, hDeg: Double): Color {
        var chroma = c
        repeat(40) {
            val rgb = labToLinearRgb(l, chroma * cos(Math.toRadians(hDeg)), chroma * sin(Math.toRadians(hDeg)))
            if (rgb.all { it >= -0.0005 && it <= 1.0005 } || chroma < 0.5) {
                return Color(gamma(rgb[0]), gamma(rgb[1]), gamma(rgb[2]))
            }
            chroma *= 0.92
        }
        val rgb = labToLinearRgb(l, 0.0, 0.0)
        return Color(gamma(rgb[0]), gamma(rgb[1]), gamma(rgb[2]))
    }

    private fun labToLinearRgb(l: Double, a: Double, b: Double): DoubleArray {
        val fy = (l + 16.0) / 116.0
        val fx = fy + a / 500.0
        val fz = fy - b / 200.0
        fun inv(t: Double) = if (t * t * t > 0.008856) t * t * t else (116.0 * t - 16.0) / 903.3
        val x = 0.95047 * inv(fx)
        val y = inv(fy)
        val z = 1.08883 * inv(fz)
        return doubleArrayOf(
            3.2404542 * x - 1.5371385 * y - 0.4985314 * z,
            -0.9692660 * x + 1.8760108 * y + 0.0415560 * z,
            0.0556434 * x - 0.2040259 * y + 1.0572252 * z,
        )
    }

    private fun gamma(v: Double): Float {
        val c = v.coerceIn(0.0, 1.0)
        return (if (c <= 0.0031308) 12.92 * c else 1.055 * c.pow(1.0 / 2.4) - 0.055).toFloat()
    }
}
