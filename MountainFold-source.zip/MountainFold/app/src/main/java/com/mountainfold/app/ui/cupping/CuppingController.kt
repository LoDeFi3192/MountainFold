package com.mountainfold.app.ui.cupping

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.mountainfold.app.R
import com.mountainfold.app.core.cupping.CuppingCatalog
import com.mountainfold.app.core.cupping.CuppingFormat
import com.mountainfold.app.core.cupping.CuppingTimer
import com.mountainfold.app.data.Repository
import com.mountainfold.app.data.db.CuppingCoffee
import com.mountainfold.app.data.db.CuppingSession
import com.mountainfold.app.data.db.LabRecipe
import com.mountainfold.app.data.prefs.Settings
import com.mountainfold.app.data.prefs.SettingsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.UUID

enum class CupScreen { MAIN, SUMMARY, WHEEL, LAB, INFO, SESSIONS }

interface CuppingAlertSink {
    fun crust()
    fun finished()
}

/** Brewing Lab form. Text fields stay text so typing "1" then "18" never fights the parser. */
data class LabDraft(
    val method: String = CuppingCatalog.LabMethod.V60.id,
    val coffee: String = "20",
    val ratio: String = "16",
    val grind: String = "",
    val rating: Double = 8.0,
    val notes: String = "",
) {
    val coffeeG: Double get() = CuppingFormat.parse(coffee) ?: 0.0
    val ratioValue: Double get() = CuppingFormat.parse(ratio) ?: 0.0
    val water: Int get() = CuppingFormat.water(coffeeG, ratioValue)
}

/**
 * State and actions of the Toulouse Cupping module. It lives in the ViewModel, above the
 * Closed / Open / Flex layouts, so folding mid-session loses neither scores nor the running timer.
 * Writes are debounced and run on the application scope, the way the original saved to localStorage.
 */
class CuppingController(
    private val repo: Repository,
    private val settingsStore: SettingsStore,
    private val settings: StateFlow<Settings?>,
    private val uiScope: CoroutineScope,
    private val ioScope: CoroutineScope,
    private val text: (Int, Array<out Any>) -> String,
    private val clock: () -> Long,
    private val alerts: CuppingAlertSink,
) {
    val sessions = repo.cuppingSessions.stateIn(uiScope, SharingStarted.Eagerly, emptyList())
    val allCoffees = repo.cuppingCoffees.stateIn(uiScope, SharingStarted.Eagerly, emptyList())
    val labRecipes = repo.labRecipes.stateIn(uiScope, SharingStarted.Eagerly, emptyList())

    // ---- session on the table -----------------------------------------------------------------
    var session by mutableStateOf<CuppingSession?>(null)
        private set
    var coffees by mutableStateOf<List<CuppingCoffee>>(emptyList())
        private set
    var activeIndex by mutableIntStateOf(0)
        private set
    val active: CuppingCoffee? get() = coffees.getOrNull(activeIndex)

    // ---- navigation inside the module ----------------------------------------------------------
    var screen by mutableStateOf(CupScreen.MAIN)
    var menuOpen by mutableStateOf(false)
    var inviteOpen by mutableStateOf(false)
    var timerOpen by mutableStateOf(false)
    var confirmNewSession by mutableStateOf(false)
    /** Set by the launcher shortcut, the cupping twin of ?action=new_session. */
    var shortcutPrompt by mutableStateOf(false)
    var pendingDelete by mutableStateOf<CuppingCoffee?>(null)
    var pendingDeleteSession by mutableStateOf<CuppingSession?>(null)
    var wheelRotation by mutableFloatStateOf(0f)

    // ---- cupping timer -----------------------------------------------------------------------
    private val timer = CuppingTimer(clock)
    var timerState by mutableStateOf(CuppingTimer.State())
        private set
    private var timerJob: Job? = null

    // ---- Brewing Lab ---------------------------------------------------------------------------
    var lab by mutableStateOf(LabDraft())
    var labHistory by mutableStateOf(false)
    var labSeconds by mutableIntStateOf(0)
        private set
    var labRunning by mutableStateOf(false)
        private set
    private var labStartedAt = 0L
    private var labBaseMs = 0L
    private var labJob: Job? = null
    var pendingDeleteRecipe by mutableStateOf<LabRecipe?>(null)

    private var saveJob: Job? = null
    private var loadJob: Job? = null

    init {
        reload()
    }

    private fun str(id: Int, vararg args: Any) = text(id, args)

    /** Loads the session named in settings, else the latest one, else starts a fresh one. */
    fun reload() {
        loadJob?.cancel()
        loadJob = uiScope.launch {
            val s = settings.filterNotNull().first()
            val found = s.cuppingSessionId?.let { repo.cuppingSession(it) } ?: repo.latestCuppingSession()
            if (found == null) {
                startSession(openInfo = false)
            } else {
                show(found, repo.cuppingCoffeesOf(found.id).ifEmpty { listOf(newCoffee(str(R.string.cup_default_coffee))) })
                if (s.cuppingSessionId != found.id) settingsStore.update { it.copy(cuppingSessionId = found.id) }
            }
        }
    }

    private fun show(s: CuppingSession, list: List<CuppingCoffee>) {
        session = s
        coffees = list
        activeIndex = 0
    }

    private fun newCoffee(name: String) = CuppingCoffee(id = UUID.randomUUID().toString(), name = name, timestamp = System.currentTimeMillis())

    private fun freshSession(): CuppingSession = CuppingSession(
        id = UUID.randomUUID().toString(),
        createdAt = System.currentTimeMillis(),
        name = str(R.string.cup_new_session),
        dateIso = LocalDate.now().toString(),
    )

    private suspend fun startSession(openInfo: Boolean) {
        flush()
        val s = freshSession()
        val list = listOf(newCoffee(str(R.string.cup_default_coffee)))
        repo.saveCuppingSession(s, list)
        settingsStore.update { it.copy(cuppingSessionId = s.id) }
        show(s, list)
        if (openInfo) screen = CupScreen.INFO
    }

    /** "Nouvelle session": the original wiped the table. Here the old session is kept in the archive. */
    fun newSession() {
        confirmNewSession = false
        shortcutPrompt = false
        menuOpen = false
        uiScope.launch { startSession(openInfo = true) }
    }

    fun openSession(id: String) {
        uiScope.launch {
            flush()
            val s = repo.cuppingSession(id) ?: return@launch
            show(s, repo.cuppingCoffeesOf(id).ifEmpty { listOf(newCoffee(str(R.string.cup_default_coffee))) })
            settingsStore.update { it.copy(cuppingSessionId = id) }
            screen = CupScreen.MAIN
        }
    }

    fun deleteSession(s: CuppingSession) {
        pendingDeleteSession = null
        if (s.id == session?.id) return
        uiScope.launch { repo.deleteCuppingSession(s.id) }
    }

    // ---- editing ---------------------------------------------------------------------------
    fun select(index: Int) {
        if (index in coffees.indices) activeIndex = index
    }

    fun updateSession(transform: (CuppingSession) -> CuppingSession) {
        val s = session ?: return
        session = transform(s)
        persist()
    }

    /** Edits the active coffee. Ignored while it is validated, exactly like the original form. */
    fun edit(transform: (CuppingCoffee) -> CuppingCoffee) {
        val c = active ?: return
        if (c.isLocked) return
        replace(transform(c))
    }

    fun toggleFavorite() { active?.let { replace(it.copy(isFavorite = !it.isFavorite)) } }
    fun lock() { active?.let { replace(it.copy(isLocked = true)) } }
    fun unlock() { active?.let { replace(it.copy(isLocked = false)) } }

    /** Back to 8.00 on the six attributes. Works on a validated coffee too, as in the original menu. */
    fun resetNotes() {
        active?.let { replace(it.copy(fragranceScore = 8.0, flavorScore = 8.0, aftertasteScore = 8.0, acidityScore = 8.0, bodyScore = 8.0, balanceScore = 8.0)) }
    }

    private fun replace(c: CuppingCoffee) {
        coffees = coffees.map { if (it.id == c.id) c else it }
        persist()
    }

    fun addCoffee() {
        coffees = coffees + newCoffee(str(R.string.cup_coffee_n, coffees.size + 1))
        activeIndex = coffees.lastIndex
        persist()
    }

    fun canDelete(): Boolean = coffees.size > 1

    fun deleteCoffee(c: CuppingCoffee) {
        pendingDelete = null
        if (coffees.size <= 1) return
        coffees = coffees.filterNot { it.id == c.id }
        if (activeIndex >= coffees.size) activeIndex = coffees.lastIndex
        persist()
    }

    private fun persist() {
        saveJob?.cancel()
        saveJob = ioScope.launch {
            delay(250)
            writeNow()
        }
    }

    private suspend fun writeNow() {
        val s = session ?: return
        repo.saveCuppingSession(s, coffees)
    }

    /** Writes pending edits immediately. Called when the app goes to the background. */
    suspend fun flush() {
        if (saveJob?.isActive == true) {
            saveJob?.cancel()
            writeNow()
        }
    }

    fun flushAsync() { ioScope.launch { flush() } }

    /** Drops an unsaved edit, used right before a restore or a reset replaces the database. */
    fun cancelPendingSave() { saveJob?.cancel() }

    // ---- timer ------------------------------------------------------------------------------
    fun startTimer(minutes: Int) {
        timer.start(minutes)
        timerState = timer.state
        runTimer()
    }

    fun toggleTimer() {
        timer.togglePause()
        timerState = timer.state
        runTimer()
    }

    fun resetTimer() {
        timer.reset()
        timerState = timer.state
        timerJob?.cancel()
    }

    private fun runTimer() {
        timerJob?.cancel()
        if (!timer.state.running) return
        timerJob = uiScope.launch {
            while (timer.state.running) {
                delay(100)
                val fired = timer.tick()
                timerState = timer.state
                fired.forEach { a -> if (a == CuppingTimer.Alert.CRUST) alerts.crust() else alerts.finished() }
            }
        }
    }

    // ---- Brewing Lab ---------------------------------------------------------------------------
    fun pickMethod(id: String) {
        val m = CuppingCatalog.LabMethod.of(id) ?: return
        lab = lab.copy(method = id, ratio = m.defaultRatio.toString())
    }

    fun toggleLabTimer() {
        if (labRunning) {
            labBaseMs += clock() - labStartedAt
            labRunning = false
            labJob?.cancel()
            labSeconds = (labBaseMs / 1000).toInt()
        } else {
            labStartedAt = clock()
            labRunning = true
            labJob?.cancel()
            labJob = uiScope.launch {
                while (labRunning) {
                    labSeconds = ((labBaseMs + clock() - labStartedAt) / 1000).toInt()
                    delay(200)
                }
            }
        }
    }

    fun resetLabTimer() {
        labRunning = false
        labJob?.cancel()
        labBaseMs = 0
        labSeconds = 0
    }

    fun saveLab(): LabRecipe {
        val d = lab
        val r = LabRecipe(
            id = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            method = d.method,
            coffeeWeight = d.coffeeG,
            ratio = d.ratioValue,
            waterWeight = d.water,
            grindSize = d.grind,
            totalTime = labSeconds,
            rating = d.rating,
            notes = d.notes,
        )
        uiScope.launch { repo.saveLabRecipe(r) }
        return r
    }

    /** Loads a saved recipe back into the form. Unlike the original, the saved ratio is kept. */
    fun loadLab(r: LabRecipe) {
        lab = LabDraft(
            method = r.method,
            coffee = CuppingFormat.jsNumber(r.coffeeWeight),
            ratio = CuppingFormat.jsNumber(r.ratio),
            grind = r.grindSize,
            rating = r.rating,
            notes = r.notes,
        )
        resetLabTimer()
        labBaseMs = r.totalTime * 1000L
        labSeconds = r.totalTime
        labHistory = false
    }

    fun deleteLab(r: LabRecipe) {
        pendingDeleteRecipe = null
        uiScope.launch { repo.deleteLabRecipe(r.id) }
    }

    // ---- back handling --------------------------------------------------------------------------
    fun canGoBack(): Boolean = screen != CupScreen.MAIN || labHistory

    fun back(): Boolean {
        when {
            screen == CupScreen.LAB && labHistory -> labHistory = false
            screen != CupScreen.MAIN -> screen = CupScreen.MAIN
            else -> return false
        }
        return true
    }
}
