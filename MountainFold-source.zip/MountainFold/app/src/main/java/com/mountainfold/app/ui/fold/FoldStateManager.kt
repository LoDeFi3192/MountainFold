package com.mountainfold.app.ui.fold

import android.app.Activity
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.window.layout.FoldingFeature
import androidx.window.layout.WindowInfoTracker
import com.mountainfold.app.core.fold.FoldState
import com.mountainfold.app.core.fold.FoldStateResolver
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.model.LayoutOverride
import kotlinx.coroutines.flow.map

/**
 * Central posture detection. Reads the hinge from Jetpack WindowManager, which is what Samsung
 * Flex Mode reports through, so no vendor SDK is needed. The result is one of CLOSED, OPEN, FLEX.
 */
@Composable
fun rememberFoldState(activity: Activity, override: LayoutOverride): FoldState {
    val hingeFlow = remember(activity) {
        WindowInfoTracker.getOrCreate(activity).windowLayoutInfo(activity).map { info ->
            info.displayFeatures.filterIsInstance<FoldingFeature>().firstOrNull()?.let { f ->
                HingeInfo(
                    left = f.bounds.left, top = f.bounds.top, right = f.bounds.right, bottom = f.bounds.bottom,
                    vertical = f.orientation == FoldingFeature.Orientation.VERTICAL,
                    halfOpened = f.state == FoldingFeature.State.HALF_OPENED,
                )
            }
        }
    }
    val hinge by hingeFlow.collectAsStateWithLifecycle(initialValue = null)
    val config = LocalConfiguration.current
    val density = LocalDensity.current.density
    val container = LocalWindowInfo.current.containerSize
    val widthDp = if (container.width > 0) container.width / density else config.screenWidthDp.toFloat()
    val heightDp = if (container.height > 0) container.height / density else config.screenHeightDp.toFloat()
    return remember(hinge, widthDp, heightDp, override) { FoldStateResolver.resolve(widthDp, heightDp, hinge, override) }
}
