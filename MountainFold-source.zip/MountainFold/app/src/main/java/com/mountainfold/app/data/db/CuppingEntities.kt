package com.mountainfold.app.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json

/** A Toulouse Cupping session. Same fields as the original web app, plus an id kept stable across exports. */
@Serializable
@Entity(tableName = "cupping_sessions")
data class CuppingSession(
    @PrimaryKey val id: String,
    val createdAt: Long = 0,
    val name: String = "",
    val location: String = "",
    /** Local date, yyyy-MM-dd. */
    val dateIso: String = "",
    val originNotes: String = "",
    val roasterNotes: String = "",
    val importerNotes: String = "",
)

/** One coffee on the cupping table. Scores run from 6 to 10 in steps of 0.25. Notes hold French keys. */
@Serializable
@Entity(
    tableName = "cupping_coffees",
    foreignKeys = [ForeignKey(entity = CuppingSession::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("sessionId")],
)
data class CuppingCoffee(
    @PrimaryKey val id: String,
    val sessionId: String = "",
    val position: Int = 0,
    val name: String = "",
    val isLocked: Boolean = false,
    val isFavorite: Boolean = false,
    val timestamp: Long = 0,
    val process: String = "",
    val fragranceScore: Double = 8.0,
    val fragranceNotes: List<String> = emptyList(),
    val flavorScore: Double = 8.0,
    val flavorNotes: List<String> = emptyList(),
    val aftertasteScore: Double = 8.0,
    val acidityScore: Double = 8.0,
    val acidityType: String = "",
    val acidityIntensity: String = "",
    val bodyScore: Double = 8.0,
    val bodyType: String = "",
    val balanceScore: Double = 8.0,
    val comments: String = "",
) {
    /** Final score of the original: the plain mean of the six attributes. */
    val finalScore: Double get() = (fragranceScore + flavorScore + aftertasteScore + acidityScore + bodyScore + balanceScore) / 6.0

    /** Fragrance and flavor notes merged, first occurrence order, no duplicates. */
    val uniqueNotes: List<String> get() = (fragranceNotes + flavorNotes).distinct()
}

/** A Brewing Lab recipe, the quick brew notebook of the original app. */
@Serializable
@Entity(tableName = "lab_recipes")
data class LabRecipe(
    @PrimaryKey val id: String,
    val timestamp: Long = 0,
    val method: String = "v60",
    val coffeeWeight: Double = 20.0,
    val ratio: Double = 16.0,
    val waterWeight: Int = 0,
    val grindSize: String = "",
    val totalTime: Int = 0,
    val rating: Double = 8.0,
    val notes: String = "",
)

class CuppingConverters {
    private val json = Json { ignoreUnknownKeys = true }
    private val list = ListSerializer(String.serializer())

    @TypeConverter
    fun fromList(value: List<String>): String = json.encodeToString(list, value)

    @TypeConverter
    fun toList(value: String?): List<String> =
        if (value.isNullOrBlank()) emptyList() else runCatching { json.decodeFromString(list, value) }.getOrDefault(emptyList())
}
