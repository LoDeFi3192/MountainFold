package com.mountainfold.app.core.train

import com.mountainfold.app.core.engine.CopilotEngine
import com.mountainfold.app.core.engine.CopilotEngine.ChangeKind
import com.mountainfold.app.core.model.Symptom

data class SkillScore(val skill: Skill, val percent: Int?, val answers: Int)

data class LevelState(
    val level: TreeLevel,
    val lessons: List<String>,
    val validated: Set<String>,
    val tasksDone: Set<TreeTask>,
    val unlocked: Boolean,
) {
    val done: Int get() = lessons.count { it in validated } + tasksDone.size
    val total: Int get() = lessons.size + level.tasks.size
    val complete: Boolean get() = done == total
}

data class Progress(
    val xp: Int,
    val streak: Int,
    val validated: Set<String>,
    val levels: List<LevelState>,
    /** First level that is not complete, or 9 when everything is. */
    val currentLevel: Int,
    val levelsComplete: Int,
    /** Share of all lessons and practical gates validated, 0 to 100. */
    val percent: Int,
    val title: BaristaTitle,
    val scores: List<SkillScore>,
    val dailyDone: Boolean,
) {
    fun isUnlocked(lesson: Lesson): Boolean = levels.firstOrNull { it.level.number == lesson.level }?.unlocked ?: true
    val strongest: SkillScore? get() = scores.filter { it.percent != null }.maxByOrNull { it.percent!! }
    val weakest: SkillScore? get() = scores.filter { it.percent != null }.minByOrNull { it.percent!! }
}

sealed interface Recommendation {
    enum class Reason { BREW_PATTERN, WEAK_SKILL, NEXT_STEP, PRACTICE }
    val reason: Reason

    data class LessonRec(val lessonId: String, override val reason: Reason) : Recommendation
    data class DialInRec(val espresso: Boolean, override val reason: Reason) : Recommendation
    data class ExamRec(val category: ExamCategory, override val reason: Reason) : Recommendation
}

/** A pattern found in real brews that is worth a targeted lesson. */
data class Opportunity(val symptom: Symptom, val count: Int, val lessonId: String)

/** Minimal view of a logged brew, so this file stays free of Room. */
data class BrewSignal(val createdAt: Long, val espresso: Boolean, val symptoms: Set<Symptom>)

/**
 * Everything the trainer shows is derived from recorded events. Nothing is stored as a score,
 * so levels and percentages always reflect exercises that were actually done.
 */
object TrainProgress {
    const val LESSON_PASS = 0.66
    const val SESSION_PASS = 0.8
    const val EXAM_PASS = 0.7
    private const val SCORE_WINDOW = 30
    private const val DAY_MS = 86_400_000L

    fun passed(kind: EventKind, correct: Int, total: Int): Boolean {
        if (total <= 0) return false
        val ratio = correct.toDouble() / total
        return when (kind) {
            EventKind.LESSON -> ratio >= LESSON_PASS
            EventKind.DIAL_IN, EventKind.LEVEL_TEST -> ratio >= SESSION_PASS
            EventKind.EXAM -> ratio >= EXAM_PASS
            EventKind.DAILY -> correct == total
            else -> true
        }
    }

    /** Light XP. Lesson XP is only granted the first time a lesson is validated. */
    fun xpFor(kind: EventKind, passed: Boolean, firstValidation: Boolean): Int = when (kind) {
        EventKind.LESSON -> if (!passed) 0 else if (firstValidation) 75 else 25
        EventKind.DIAL_IN -> if (passed) 25 else 0
        EventKind.DAILY -> if (passed) 25 else 10
        EventKind.LEVEL_TEST -> if (passed) 50 else 0
        EventKind.EXAM -> if (passed) 50 else 0
        EventKind.BREW_CHALLENGE -> 100
        EventKind.TASTING_LOG -> 20
        EventKind.STREAK_BONUS -> 250
    }

    fun title(levelsComplete: Int): BaristaTitle = when {
        levelsComplete <= 0 -> BaristaTitle.TRAINEE
        levelsComplete <= 2 -> BaristaTitle.JUNIOR
        levelsComplete <= 4 -> BaristaTitle.BARISTA
        levelsComplete == 5 -> BaristaTitle.SENIOR
        levelsComplete <= 7 -> BaristaTitle.HEAD
        levelsComplete == 8 -> BaristaTitle.SPECIALIST
        else -> BaristaTitle.EXPERT
    }

    /** Consecutive days with training, ending today or yesterday. [dayOf] maps a timestamp to a local day number. */
    fun streak(events: List<TrainEvent>, today: Long, dayOf: (Long) -> Long): Int {
        val days = events.filter { it.kind != EventKind.STREAK_BONUS }.map { dayOf(it.createdAt) }.toSet()
        var day = when {
            today in days -> today
            today - 1 in days -> today - 1
            else -> return 0
        }
        var n = 0
        while (day in days) { n++; day-- }
        return n
    }

    fun scores(events: List<TrainEvent>): List<SkillScore> {
        val correct = IntArray(Skill.entries.size)
        val total = IntArray(Skill.entries.size)
        for (e in events.sortedByDescending { it.createdAt }) {
            for ((skill, c, t) in Breakdown.decode(e.breakdown)) {
                val i = skill.ordinal
                if (total[i] >= SCORE_WINDOW) continue
                correct[i] += c
                total[i] += t
            }
        }
        return Skill.entries.map { s ->
            val t = total[s.ordinal]
            SkillScore(s, if (t == 0) null else Math.round(correct[s.ordinal] * 100.0 / t).toInt(), t)
        }
    }

    fun compute(
        events: List<TrainEvent>,
        lessonsByLevel: Map<Int, List<String>>,
        today: Long,
        dayOf: (Long) -> Long = { it / DAY_MS },
    ): Progress {
        val passedEvents = events.filter { it.passed }
        val testedLevels = passedEvents.filter { it.kind == EventKind.LEVEL_TEST }.map { it.refId }.toSet()
        val validated = buildSet {
            addAll(passedEvents.filter { it.kind == EventKind.LESSON }.map { it.refId })
            lessonsByLevel.forEach { (level, ids) -> if (SkillTree.levelRef(level) in testedLevels) addAll(ids) }
        }
        val dialIns = passedEvents.filter { it.kind == EventKind.DIAL_IN }.map { it.refId }.toSet()
        val exams = passedEvents.filter { it.kind == EventKind.EXAM }.map { it.refId }.toSet()
        fun done(task: TreeTask) = when (task) {
            is TreeTask.DialIn -> (if (task.espresso) SkillTree.DIAL_IN_ESPRESSO else SkillTree.DIAL_IN_FILTER) in dialIns
            is TreeTask.Exam -> task.category.name in exams
        }
        var previousComplete = true
        val levels = SkillTree.levels.map { level ->
            val state = LevelState(
                level = level,
                lessons = lessonsByLevel[level.number].orEmpty(),
                validated = validated,
                tasksDone = level.tasks.filter(::done).toSet(),
                unlocked = previousComplete,
            )
            previousComplete = previousComplete && state.complete
            state
        }
        val levelsComplete = levels.takeWhile { it.complete }.size
        val doneCount = levels.sumOf { it.done }
        val totalCount = levels.sumOf { it.total }.coerceAtLeast(1)
        return Progress(
            xp = events.sumOf { it.xp },
            streak = streak(events, today, dayOf),
            validated = validated,
            levels = levels,
            currentLevel = (levelsComplete + 1).coerceAtMost(SkillTree.levels.size),
            levelsComplete = levelsComplete,
            percent = doneCount * 100 / totalCount,
            title = title(levelsComplete),
            scores = scores(events),
            dailyDone = events.any { it.kind == EventKind.DAILY && it.refId == SkillTree.dayRef(today) },
        )
    }

    // ---- Real brews and the Copilot feed the trainer ------------------------------------------

    fun lessonFor(symptom: Symptom, espresso: Boolean): String = when (symptom) {
        Symptom.SOUR, Symptom.BITTER, Symptom.DRY -> if (espresso) "espresso_grind_time" else "extraction"
        Symptom.WEAK, Symptom.STRONG -> if (espresso) "espresso_recipe" else "ratio"
        Symptom.ASTRINGENT, Symptom.HOLLOW -> if (espresso) "channeling" else "agitation_time"
        Symptom.MUDDY -> "grinder_flow"
        Symptom.HARSH -> "temperature"
        Symptom.FLAT -> "roasting"
    }

    fun lessonFor(diagnosis: CopilotEngine.Diagnosis, espresso: Boolean): String = when (diagnosis.change) {
        ChangeKind.GRIND_FINER, ChangeKind.GRIND_COARSER -> if (espresso) "espresso_grind_time" else "grind_size"
        ChangeKind.TEMP_UP, ChangeKind.TEMP_DOWN -> "temperature"
        ChangeKind.DOSE_UP, ChangeKind.DOSE_DOWN -> "ratio"
        ChangeKind.YIELD_UP, ChangeKind.YIELD_DOWN -> "espresso_recipe"
        ChangeKind.BLOOM_LONGER, ChangeKind.AGITATE_LESS -> "agitation_time"
        ChangeKind.PUCK_PREP -> if (diagnosis.cause == CopilotEngine.Cause.CHANNELING) "channeling" else "puck_prep"
        ChangeKind.FRESHER_COFFEE -> "roasting"
    }

    /** Three or more of the last twelve brews with the same main symptom make a training opportunity. */
    fun opportunity(brews: List<BrewSignal>): Opportunity? {
        val recent = brews.sortedByDescending { it.createdAt }.take(12)
        val tagged = recent.mapNotNull { b -> CopilotEngine.primarySymptom(b.symptoms)?.let { it to b.espresso } }
        val top = tagged.groupBy { it.first }.maxByOrNull { it.value.size } ?: return null
        if (top.value.size < 3) return null
        val espresso = top.value.count { it.second } * 2 > top.value.size
        return Opportunity(top.key, top.value.size, lessonFor(top.key, espresso))
    }

    private val dialInSkills = setOf(Skill.EXTRACTION, Skill.POUR_OVER, Skill.GRINDER, Skill.ESPRESSO)

    /** Up to three next steps, most useful first. */
    fun recommendations(
        progress: Progress,
        lessons: List<Lesson>,
        opportunity: Opportunity?,
        prefersEspresso: Boolean,
    ): List<Recommendation> {
        val out = mutableListOf<Recommendation>()
        fun add(r: Recommendation) { if (r !in out && out.none { it.sameTarget(r) }) out += r }

        opportunity?.let { add(Recommendation.LessonRec(it.lessonId, Recommendation.Reason.BREW_PATTERN)) }

        progress.scores.filter { it.percent != null && it.answers >= 4 && it.percent < 70 }.sortedBy { it.percent }.take(2).forEach { weak ->
            val lesson = lessons.firstOrNull { it.skill == weak.skill && it.id !in progress.validated }
                ?: lessons.firstOrNull { it.skill == weak.skill }
            when {
                weak.skill in dialInSkills && lesson?.id in progress.validated ->
                    add(Recommendation.DialInRec(weak.skill == Skill.ESPRESSO, Recommendation.Reason.WEAK_SKILL))
                lesson != null -> add(Recommendation.LessonRec(lesson.id, Recommendation.Reason.WEAK_SKILL))
            }
        }

        val current = progress.levels.firstOrNull { !it.complete }
        if (current != null) {
            current.lessons.filter { it !in progress.validated }.forEach { add(Recommendation.LessonRec(it, Recommendation.Reason.NEXT_STEP)) }
            current.level.tasks.filter { it !in current.tasksDone }.forEach { task ->
                when (task) {
                    is TreeTask.DialIn -> add(Recommendation.DialInRec(task.espresso, Recommendation.Reason.NEXT_STEP))
                    is TreeTask.Exam -> add(Recommendation.ExamRec(task.category, Recommendation.Reason.NEXT_STEP))
                }
            }
        }
        add(Recommendation.DialInRec(prefersEspresso, Recommendation.Reason.PRACTICE))
        add(Recommendation.DialInRec(!prefersEspresso, Recommendation.Reason.PRACTICE))
        return out.take(3)
    }

    private fun Recommendation.sameTarget(o: Recommendation): Boolean = when {
        this is Recommendation.LessonRec && o is Recommendation.LessonRec -> lessonId == o.lessonId
        this is Recommendation.DialInRec && o is Recommendation.DialInRec -> espresso == o.espresso
        this is Recommendation.ExamRec && o is Recommendation.ExamRec -> category == o.category
        else -> false
    }
}
