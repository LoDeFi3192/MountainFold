package com.mountainfold.app.ui.screens

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.School
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mountainfold.app.R
import com.mountainfold.app.core.engine.CoffeeEngine
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.train.BaristaTitle
import com.mountainfold.app.core.train.EventKind
import com.mountainfold.app.core.train.ExamCategory
import com.mountainfold.app.core.train.ExtractionSim
import com.mountainfold.app.core.train.Lesson
import com.mountainfold.app.core.train.Progress
import com.mountainfold.app.core.train.Recommendation
import com.mountainfold.app.core.train.SchoolCategory
import com.mountainfold.app.core.train.SimKind
import com.mountainfold.app.core.train.Skill
import com.mountainfold.app.core.train.TreeTask
import com.mountainfold.app.data.db.Brew
import com.mountainfold.app.data.db.TrainingEvent
import com.mountainfold.app.data.prefs.Settings
import com.mountainfold.app.ui.CopilotText
import com.mountainfold.app.ui.LocalUnits
import com.mountainfold.app.ui.MainViewModel
import com.mountainfold.app.ui.QuizResult
import com.mountainfold.app.ui.QuizRun
import com.mountainfold.app.ui.Tab
import com.mountainfold.app.ui.TrainScreen
import com.mountainfold.app.ui.components.BigButton
import com.mountainfold.app.ui.components.EmptyState
import com.mountainfold.app.ui.components.FlexSplit
import com.mountainfold.app.ui.components.ListRow
import com.mountainfold.app.ui.components.NumField
import com.mountainfold.app.ui.components.ScreenHeader
import com.mountainfold.app.ui.components.SectionTitle
import com.mountainfold.app.ui.components.Stat
import com.mountainfold.app.ui.components.ThinDivider
import com.mountainfold.app.ui.components.TimerText
import com.mountainfold.app.ui.components.TwoPane
import com.mountainfold.app.ui.components.methodLabel
import kotlinx.coroutines.delay

// ---------------------------------------------------------------------------------------------
// Labels
// ---------------------------------------------------------------------------------------------

@Composable
fun skillLabel(s: Skill): String = stringResource(
    when (s) {
        Skill.EXTRACTION -> R.string.skill_extraction
        Skill.ESPRESSO -> R.string.skill_espresso
        Skill.POUR_OVER -> R.string.skill_pour_over
        Skill.MILK -> R.string.skill_milk
        Skill.SENSORY -> R.string.skill_sensory
        Skill.GRINDER -> R.string.skill_grinder
        Skill.WATER -> R.string.skill_water
        Skill.WORKFLOW -> R.string.skill_workflow
        Skill.THEORY -> R.string.skill_theory
    }
)

@Composable
private fun categoryLabel(c: SchoolCategory): String = stringResource(
    when (c) {
        SchoolCategory.FOUNDATIONS -> R.string.cat_foundations
        SchoolCategory.BREWING -> R.string.cat_brewing
        SchoolCategory.ESPRESSO -> R.string.cat_espresso
        SchoolCategory.SENSORY -> R.string.cat_sensory
        SchoolCategory.ROASTING -> R.string.cat_roasting
        SchoolCategory.WATER -> R.string.cat_water
        SchoolCategory.ADVANCED -> R.string.cat_advanced
    }
)

@Composable
private fun levelTitle(n: Int): String = stringResource(
    when (n) {
        1 -> R.string.level_1
        2 -> R.string.level_2
        3 -> R.string.level_3
        4 -> R.string.level_4
        5 -> R.string.level_5
        6 -> R.string.level_6
        7 -> R.string.level_7
        8 -> R.string.level_8
        else -> R.string.level_9
    }
)

@Composable
private fun titleLabel(t: BaristaTitle): String = stringResource(
    when (t) {
        BaristaTitle.TRAINEE -> R.string.title_trainee
        BaristaTitle.JUNIOR -> R.string.title_junior
        BaristaTitle.BARISTA -> R.string.title_barista
        BaristaTitle.SENIOR -> R.string.title_senior
        BaristaTitle.HEAD -> R.string.title_head
        BaristaTitle.SPECIALIST -> R.string.title_specialist
        BaristaTitle.EXPERT -> R.string.title_expert
    }
)

@Composable
private fun examLabel(c: ExamCategory): String = stringResource(
    when (c) {
        ExamCategory.KNOWLEDGE -> R.string.exam_knowledge
        ExamCategory.BREWING -> R.string.exam_brewing
        ExamCategory.ESPRESSO -> R.string.exam_espresso
        ExamCategory.SENSORY -> R.string.exam_sensory
        ExamCategory.TROUBLESHOOTING -> R.string.exam_troubleshooting
    }
)

@Composable
private fun kindLabel(k: EventKind): String = stringResource(
    when (k) {
        EventKind.LESSON -> R.string.kind_lesson
        EventKind.DIAL_IN -> R.string.kind_dialin
        EventKind.DAILY -> R.string.kind_daily
        EventKind.LEVEL_TEST -> R.string.kind_level_test
        EventKind.EXAM -> R.string.kind_exam
        EventKind.BREW_CHALLENGE -> R.string.brew_challenge
        EventKind.TASTING_LOG -> R.string.kind_tasting
        EventKind.STREAK_BONUS -> R.string.kind_streak
    }
)

@Composable
private fun taskLabel(t: TreeTask): String = when (t) {
    is TreeTask.DialIn -> stringResource(if (t.espresso) R.string.task_dialin_espresso else R.string.task_dialin_filter)
    is TreeTask.Exam -> stringResource(R.string.task_exam, examLabel(t.category))
}

@Composable
private fun recTitle(vm: MainViewModel, rec: Recommendation): String = when (rec) {
    is Recommendation.LessonRec -> vm.train.lesson(rec.lessonId)?.title?.get(vm.lang).orEmpty()
    is Recommendation.DialInRec -> stringResource(if (rec.espresso) R.string.train_dialin_espresso else R.string.train_dialin_filter)
    is Recommendation.ExamRec -> stringResource(R.string.train_exam) + " · " + examLabel(rec.category)
}

private fun recMinutes(vm: MainViewModel, rec: Recommendation): Int = when (rec) {
    is Recommendation.LessonRec -> vm.train.lesson(rec.lessonId)?.minutes ?: 4
    is Recommendation.DialInRec -> 5
    is Recommendation.ExamRec -> 5
}

/** True for the screens that get the split training desk in Flex posture. */
fun isTrainDesk(screen: TrainScreen): Boolean =
    screen is TrainScreen.LessonView || screen == TrainScreen.Quiz || screen == TrainScreen.Lab

// ---------------------------------------------------------------------------------------------
// Entry point for Closed and Open
// ---------------------------------------------------------------------------------------------

@Composable
fun TrainScreen(vm: MainViewModel, settings: Settings, wide: Boolean, hinge: HingeInfo?) {
    val events by vm.trainEvents.collectAsStateWithLifecycle()
    val brews by vm.brews.collectAsStateWithLifecycle()
    val progress = remember(events) { vm.progressOf(events) }
    when (val screen = vm.trainScreen) {
        TrainScreen.Home -> TrainHome(vm, settings, progress, brews, wide, hinge)
        TrainScreen.Tree -> SkillTreeScreen(vm, progress)
        TrainScreen.School -> SchoolScreen(vm, progress)
        TrainScreen.History -> TrainHistoryScreen(vm, events)
        TrainScreen.Lab -> LabScreen(vm, wide, hinge)
        TrainScreen.ExamSetup -> ExamSetupScreen(vm)
        is TrainScreen.LessonView -> vm.train.lesson(screen.id)?.let { LessonScreen(vm, it, progress, wide, hinge) }
        TrainScreen.Quiz -> vm.quiz?.let { QuizScreen(vm, it, wide, hinge) }
        TrainScreen.Result -> vm.quizResult?.let { ResultScreen(vm, it, wide, hinge) }
    }
}

// ---------------------------------------------------------------------------------------------
// Train home
// ---------------------------------------------------------------------------------------------

@Composable
private fun TrainHome(vm: MainViewModel, settings: Settings, progress: Progress, brews: List<Brew>, wide: Boolean, hinge: HingeInfo?) {
    val left: @Composable () -> Unit = {
        Text(stringResource(R.string.train_title), style = MaterialTheme.typography.displaySmall)
        Text(stringResource(R.string.train_tagline), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))
        TodayCard(vm, progress, brews)
        Spacer(Modifier.height(12.dp))
        DailyRow(vm, progress)
        if (settings.pendingBrewChallenge != null) {
            Spacer(Modifier.height(12.dp))
            PendingChallenge(vm, settings.pendingBrewChallenge)
        }
        ProgressBlock(progress)
        SectionTitle(stringResource(R.string.train_practice))
    }
    val entries: @Composable () -> Unit = {
        EntryRow(stringResource(R.string.train_tree), stringResource(R.string.train_level_header, progress.currentLevel) + " · " + levelTitle(progress.currentLevel)) { vm.openTrain(TrainScreen.Tree) }
        EntryRow(stringResource(R.string.train_school), stringResource(R.string.lessons_count, progress.validated.size, vm.train.lessons.size)) { vm.openTrain(TrainScreen.School) }
        EntryRow(stringResource(R.string.train_dialin_filter), stringResource(R.string.train_dialin_hint)) { vm.startDialIn(false) }
        EntryRow(stringResource(R.string.train_dialin_espresso), stringResource(R.string.train_dialin_hint)) { vm.startDialIn(true) }
        EntryRow(stringResource(R.string.train_lab), stringResource(R.string.train_lab_hint)) { vm.openTrain(TrainScreen.Lab) }
        EntryRow(stringResource(R.string.train_exam), stringResource(R.string.exam_setup_short)) { vm.openTrain(TrainScreen.ExamSetup) }
        EntryRow(stringResource(R.string.train_history), null) { vm.openTrain(TrainScreen.History) }
    }
    val right: @Composable () -> Unit = {
        SkillsBlock(progress)
        ProfileBlock(vm, progress, brews)
    }
    if (wide) {
        TwoPane(
            hinge = hinge,
            left = {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 20.dp)) {
                    Column(Modifier.padding(horizontal = 28.dp)) { left() }
                    Column(Modifier.padding(horizontal = 12.dp)) { entries() }
                }
            },
            right = {
                Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 8.dp)) { right() }
                }
            },
        )
    } else {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 12.dp)) {
            Column(Modifier.padding(horizontal = 20.dp)) { left() }
            Column(Modifier.padding(horizontal = 4.dp)) { entries() }
            Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp)) { right() }
        }
    }
}

@Composable
private fun EntryRow(title: String, subtitle: String?, onClick: () -> Unit) {
    ListRow(
        title = title,
        subtitle = subtitle,
        trailing = { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
        onClick = onClick,
    )
}

@Composable
private fun TodayCard(vm: MainViewModel, progress: Progress, brews: List<Brew>) {
    val rec = remember(progress, brews) { vm.recommendationsOf(progress, brews).firstOrNull() } ?: return
    val opportunity = remember(brews) { vm.opportunityOf(brews) }
    val pattern = rec.reason == Recommendation.Reason.BREW_PATTERN && opportunity != null
    Surface(color = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer, shape = MaterialTheme.shapes.extraLarge, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(24.dp)) {
            Text(stringResource(if (pattern) R.string.train_opportunity else R.string.train_today).uppercase(), style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(6.dp))
            Text(recTitle(vm, rec), style = MaterialTheme.typography.headlineMedium, maxLines = 3, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text(
                when {
                    pattern -> stringResource(R.string.train_opportunity_body, opportunity!!.count, stringResource(CopilotText.symptom(opportunity.symptom)))
                    rec.reason == Recommendation.Reason.WEAK_SKILL -> stringResource(R.string.train_reason_weak)
                    rec.reason == Recommendation.Reason.NEXT_STEP -> stringResource(R.string.train_reason_next, progress.currentLevel)
                    else -> stringResource(R.string.train_reason_practice)
                } + "  ·  " + stringResource(R.string.train_minutes, recMinutes(vm, rec)),
                style = MaterialTheme.typography.bodyLarge,
            )
            Spacer(Modifier.height(16.dp))
            BigButton(
                stringResource(if (pattern) R.string.train_this else R.string.start),
                onClick = { vm.start(rec) },
                modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow, primary = true,
            )
        }
    }
}

@Composable
private fun DailyRow(vm: MainViewModel, progress: Progress) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.train_daily), style = MaterialTheme.typography.titleMedium)
                Text(
                    stringResource(if (progress.dailyDone) R.string.train_daily_done else R.string.train_daily_hint),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (progress.dailyDone) {
                Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            } else {
                BigButton(stringResource(R.string.start), onClick = vm::startDaily, minHeight = 48.dp)
            }
        }
    }
}

@Composable
private fun PendingChallenge(vm: MainViewModel, lessonId: String) {
    val lesson = vm.train.lesson(lessonId)
    Surface(color = MaterialTheme.colorScheme.tertiaryContainer, contentColor = MaterialTheme.colorScheme.onTertiaryContainer, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text(stringResource(R.string.brew_challenge_pending).uppercase(), style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(4.dp))
            Text(lesson?.brewTask?.get(vm.lang) ?: stringResource(R.string.brew_challenge_pending_body), style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton(stringResource(R.string.brew), onClick = { vm.selectTab(Tab.BREW) }, modifier = Modifier.weight(1f), primary = true, minHeight = 48.dp)
                BigButton(stringResource(R.string.cancel), onClick = vm::cancelBrewChallenge, modifier = Modifier.weight(1f), minHeight = 48.dp)
            }
        }
    }
}

@Composable
private fun ProgressBlock(progress: Progress) {
    SectionTitle(stringResource(R.string.train_progress))
    Row(verticalAlignment = Alignment.Bottom) {
        Column(Modifier.weight(1f)) {
            Text(stringResource(R.string.train_level_n, progress.currentLevel).uppercase(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(titleLabel(progress.title), style = MaterialTheme.typography.headlineSmall)
        }
        Text("${progress.percent}%", style = MaterialTheme.typography.headlineMedium)
    }
    Spacer(Modifier.height(8.dp))
    LinearProgressIndicator(
        progress = { progress.percent / 100f },
        modifier = Modifier.fillMaxWidth().height(8.dp),
        trackColor = MaterialTheme.colorScheme.surfaceContainerHighest,
        strokeCap = StrokeCap.Round, gapSize = 0.dp, drawStopIndicator = {},
    )
    Spacer(Modifier.height(8.dp))
    Text(
        stringResource(R.string.train_xp, progress.xp) + "  ·  " + stringResource(R.string.profile_streak) + " " + daysText(progress.streak),
        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun SkillsBlock(progress: Progress) {
    SectionTitle(stringResource(R.string.train_skills))
    progress.scores.forEach { score ->
        Row(Modifier.fillMaxWidth().heightIn(min = 40.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(skillLabel(score.skill), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.width(132.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
            LinearProgressIndicator(
                progress = { (score.percent ?: 0) / 100f },
                modifier = Modifier.weight(1f).height(6.dp),
                trackColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                strokeCap = StrokeCap.Round, gapSize = 0.dp, drawStopIndicator = {},
            )
            Text(
                score.percent?.let { "$it%" } ?: "–",
                style = MaterialTheme.typography.titleMedium, maxLines = 1, softWrap = false,
                modifier = Modifier.width(68.dp).padding(start = 12.dp),
            )
        }
    }
    Text(stringResource(R.string.train_scores_hint), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
}

/** Built from what the user actually did: training results and logged brews. */
@Composable
private fun ProfileBlock(vm: MainViewModel, progress: Progress, brews: List<Brew>) {
    val coffees by vm.coffees.collectAsStateWithLifecycle()
    val methods = brews.groupingBy { it.method }.eachCount().entries.sortedByDescending { it.value }.take(2).map { methodLabel(BrewMethod.fromKey(it.key)) }
    val favorites = brews.filter { it.rating > 0 && it.coffeeName.isNotBlank() }
        .groupBy { b -> coffees.firstOrNull { it.id == b.coffeeId || it.name == b.coffeeName }?.country?.takeIf { it.isNotBlank() } ?: b.coffeeName }
        .mapValues { e -> e.value.map { it.rating }.average() }
        .entries.sortedByDescending { it.value }.take(2).map { it.key }
    val strongest = progress.strongest
    val weakest = progress.weakest
    if (strongest == null && methods.isEmpty() && progress.streak == 0) return
    SectionTitle(stringResource(R.string.train_profile))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (strongest != null) Stat(stringResource(R.string.profile_strongest), skillLabel(strongest.skill))
        if (weakest != null && weakest.skill != strongest?.skill) Stat(stringResource(R.string.profile_weakest), skillLabel(weakest.skill))
        if (methods.isNotEmpty()) Stat(stringResource(R.string.profile_methods), methods.joinToString(" · "))
        if (favorites.isNotEmpty()) Stat(stringResource(R.string.profile_coffees), favorites.joinToString(" · "))
        Stat(stringResource(R.string.profile_streak), daysText(progress.streak))
    }
}

// ---------------------------------------------------------------------------------------------
// Skill tree, school, exam setup, history
// ---------------------------------------------------------------------------------------------

@Composable
private fun LessonRow(vm: MainViewModel, lesson: Lesson, validated: Boolean, unlocked: Boolean, lockedLevel: Int) {
    ListRow(
        title = lesson.title[vm.lang],
        subtitle = stringResource(R.string.lesson_meta, lesson.minutes, lesson.level) + " · " + skillLabel(lesson.skill),
        trailing = {
            when {
                validated -> Icon(Icons.Rounded.CheckCircle, contentDescription = stringResource(R.string.lesson_validated), tint = MaterialTheme.colorScheme.primary)
                !unlocked -> Icon(Icons.Rounded.Lock, contentDescription = stringResource(R.string.train_locked), tint = MaterialTheme.colorScheme.outline)
                else -> Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        onClick = { if (unlocked || validated) vm.openLesson(lesson.id) else vm.say(R.string.train_locked_msg, (lockedLevel - 1).toString()) },
    )
}

@Composable
private fun SkillTreeScreen(vm: MainViewModel, progress: Progress) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.train_tree), onBack = vm::back)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {
            progress.levels.forEach { state ->
                val n = state.level.number
                Column(Modifier.padding(horizontal = 20.dp).padding(top = 20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(stringResource(R.string.train_level_header, n).uppercase(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Text(levelTitle(n), style = MaterialTheme.typography.headlineSmall, color = if (state.unlocked) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(
                            when {
                                state.complete -> stringResource(R.string.train_complete)
                                !state.unlocked -> stringResource(R.string.train_locked)
                                else -> stringResource(R.string.train_in_progress, state.done, state.total)
                            },
                            style = MaterialTheme.typography.labelLarge,
                            color = if (state.complete) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Column(Modifier.padding(horizontal = 4.dp)) {
                    state.lessons.forEach { id ->
                        vm.train.lesson(id)?.let { LessonRow(vm, it, id in state.validated, state.unlocked, n) }
                    }
                    state.level.tasks.forEach { task ->
                        val done = task in state.tasksDone
                        ListRow(
                            title = taskLabel(task),
                            subtitle = stringResource(if (task is TreeTask.Exam) R.string.exam_setup_short else R.string.train_dialin_hint),
                            trailing = {
                                when {
                                    done -> Icon(Icons.Rounded.CheckCircle, contentDescription = stringResource(R.string.train_complete), tint = MaterialTheme.colorScheme.primary)
                                    !state.unlocked -> Icon(Icons.Rounded.Lock, contentDescription = stringResource(R.string.train_locked), tint = MaterialTheme.colorScheme.outline)
                                    else -> Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            },
                            onClick = {
                                if (!state.unlocked) vm.say(R.string.train_locked_msg, (n - 1).toString())
                                else when (task) {
                                    is TreeTask.DialIn -> vm.startDialIn(task.espresso)
                                    is TreeTask.Exam -> vm.startExam(task.category)
                                }
                            },
                        )
                    }
                }
                if (state.unlocked && state.lessons.any { it !in state.validated }) {
                    OutlinedButton(onClick = { vm.startLevelTest(n) }, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
                        Text(stringResource(R.string.train_test_out))
                    }
                }
            }
        }
    }
}

@Composable
private fun SchoolScreen(vm: MainViewModel, progress: Progress) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.train_school), onBack = vm::back)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {
            SchoolCategory.entries.forEach { category ->
                val lessons = vm.train.lessons.filter { it.category == category }
                if (lessons.isNotEmpty()) {
                    SectionTitle(categoryLabel(category), Modifier.padding(horizontal = 20.dp))
                    Column(Modifier.padding(horizontal = 4.dp)) {
                        lessons.forEach { l -> LessonRow(vm, l, l.id in progress.validated, progress.isUnlocked(l), l.level) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExamSetupScreen(vm: MainViewModel) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.train_exam), onBack = vm::back)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {
            Text(stringResource(R.string.exam_setup_hint), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
            Column(Modifier.padding(horizontal = 4.dp)) {
                ExamCategory.entries.forEach { c ->
                    ListRow(
                        title = examLabel(c),
                        trailing = { Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                        onClick = { vm.startExam(c) },
                    )
                }
            }
        }
    }
}

@Composable
private fun TrainHistoryScreen(vm: MainViewModel, events: List<TrainingEvent>) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.train_history), onBack = vm::back)
        if (events.isEmpty()) {
            EmptyState(Icons.Rounded.School, stringResource(R.string.train_history_empty_title), stringResource(R.string.train_history_empty_body))
            return
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 4.dp).padding(bottom = 32.dp)) {
            events.take(200).forEach { e ->
                val kind = EventKind.entries.firstOrNull { it.name == e.kind } ?: EventKind.LESSON
                val exercise = when (kind) {
                    EventKind.LESSON, EventKind.BREW_CHALLENGE -> vm.train.lesson(e.refId)?.title?.get(vm.lang) ?: e.refId
                    EventKind.DIAL_IN -> stringResource(if (e.refId == "espresso") R.string.train_dialin_espresso else R.string.train_dialin_filter)
                    EventKind.EXAM -> ExamCategory.entries.firstOrNull { it.name == e.refId }?.let { examLabel(it) } ?: e.refId
                    EventKind.LEVEL_TEST -> stringResource(R.string.train_level_test, e.refId.substringAfter(':').toIntOrNull() ?: 0)
                    else -> kindLabel(kind)
                }
                val skill = Skill.entries.firstOrNull { it.name == e.skill }?.let { skillLabel(it) }
                val score = if (e.total > 0) "${e.correct}/${e.total}" else null
                val time = if (e.durationS > 0) CoffeeEngine.formatClock(e.durationS.toLong()) else null
                val result = when {
                    e.total == 0 -> null
                    e.passed -> stringResource(R.string.result_passed)
                    else -> stringResource(R.string.result_failed)
                }
                ListRow(
                    title = exercise,
                    subtitle = listOfNotNull(kindLabel(kind).takeIf { it != exercise }, skill, score, time, result).joinToString(" · ") + "\n" + formatDate(e.createdAt),
                    trailing = if (e.xp > 0) ({ Text(stringResource(R.string.result_xp, e.xp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) }) else null,
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Simulations: readout on top, controls below. Split the same way on the hinge in Flex.
// ---------------------------------------------------------------------------------------------

@Composable
private fun ExtractionBar(pct: Double, min: Double = 10.0, max: Double = 28.0) {
    val under = MaterialTheme.colorScheme.secondaryContainer
    val balanced = MaterialTheme.colorScheme.primary
    val over = MaterialTheme.colorScheme.tertiaryContainer
    val marker = MaterialTheme.colorScheme.onSurface
    val description = stringResource(R.string.sim_extraction) + " ${CoffeeEngine.formatNumber(pct)}%"
    Column {
        Canvas(Modifier.fillMaxWidth().height(28.dp).semantics { contentDescription = description }) {
            fun x(v: Double) = ((v - min) / (max - min)).coerceIn(0.0, 1.0).toFloat() * size.width
            val h = size.height * 0.5f
            val top = (size.height - h) / 2f
            val r = CornerRadius(h / 2f)
            drawRoundRect(under, Offset(0f, top), Size(size.width, h), r)
            drawRect(balanced, Offset(x(18.0), top), Size(x(22.0) - x(18.0), h))
            drawRoundRect(over, Offset(x(22.0), top), Size(size.width - x(22.0), h), r)
            drawRect(over, Offset(x(22.0), top), Size((size.width - x(22.0)) / 2f, h))
            drawCircle(marker, radius = size.height / 2f, center = Offset(x(pct).coerceIn(size.height / 2f, size.width - size.height / 2f), size.height / 2f))
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
            Text(stringResource(R.string.sim_under), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(8f))
            Text(stringResource(R.string.sim_balanced), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(4f))
            Text(stringResource(R.string.sim_over), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(6f))
        }
    }
}

@Composable
private fun SimVerdict(r: ExtractionSim.Result, espresso: Boolean) {
    val big = MaterialTheme.typography.headlineSmall
    FlowRow(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Stat(stringResource(R.string.sim_time), if (espresso) "${r.timeS} s" else CoffeeEngine.formatClock(r.timeS.toLong()), valueStyle = big)
        Stat(stringResource(R.string.sim_extraction), "${CoffeeEngine.formatNumber(r.extractionPct)}%", valueStyle = big)
        Stat(
            stringResource(R.string.sim_strength),
            "${CoffeeEngine.formatNumber(r.tdsPct, 2)}% · " + stringResource(
                when (r.strength) {
                    ExtractionSim.Strength.WEAK -> R.string.sim_strength_weak
                    ExtractionSim.Strength.BALANCED -> R.string.sim_balanced
                    ExtractionSim.Strength.STRONG -> R.string.sim_strength_strong
                }
            ),
            valueStyle = big,
        )
    }
    Spacer(Modifier.height(12.dp))
    ExtractionBar(r.extractionPct)
    Spacer(Modifier.height(10.dp))
    Text(
        stringResource(
            when {
                r.uneven && espresso -> R.string.sim_uneven_shot
                r.uneven -> R.string.sim_uneven_filter
                r.zone == ExtractionSim.Zone.UNDER -> R.string.sim_zone_under
                r.zone == ExtractionSim.Zone.OVER -> R.string.sim_zone_over
                else -> R.string.sim_zone_balanced
            }
        ),
        style = MaterialTheme.typography.titleLarge,
    )
}

@Composable
private fun SimReadout(vm: MainViewModel, kind: SimKind, hint: String? = null) {
    val units = LocalUnits.current
    Column {
        when (kind) {
            SimKind.FILTER -> SimVerdict(ExtractionSim.filter(vm.filterSim), espresso = false)
            SimKind.ESPRESSO -> SimVerdict(ExtractionSim.shot(vm.shotSim), espresso = true)
            SimKind.YIELD_CALC -> {
                val (dose, beverage, tds) = vm.yieldCalc
                val ey = ExtractionSim.extractionYield(CoffeeEngine.parseNumber(dose) ?: 0.0, CoffeeEngine.parseNumber(beverage) ?: 0.0, CoffeeEngine.parseNumber(tds) ?: 0.0)
                Text(stringResource(R.string.sim_ey).uppercase(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                TimerText(ey?.let { "${CoffeeEngine.formatNumber(it)}%" } ?: "–", 56.sp)
                if (ey != null) {
                    Spacer(Modifier.height(8.dp))
                    ExtractionBar(ey)
                }
            }
            SimKind.MILK -> {
                val phase = ExtractionSim.milkPhase(vm.milkTemp)
                Text(stringResource(R.string.sim_milk_temp).uppercase(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                TimerText(units.t(vm.milkTemp.toDouble()), 56.sp)
                Spacer(Modifier.height(8.dp))
                Text(
                    stringResource(
                        when (phase) {
                            ExtractionSim.MilkPhase.STRETCH -> R.string.milk_stretch
                            ExtractionSim.MilkPhase.ROLL -> R.string.milk_roll
                            ExtractionSim.MilkPhase.READY -> R.string.milk_ready
                            ExtractionSim.MilkPhase.TOO_HOT -> R.string.milk_hot
                        }
                    ),
                    style = MaterialTheme.typography.titleLarge,
                )
            }
            SimKind.NONE -> Unit
        }
        if (hint != null) {
            Spacer(Modifier.height(10.dp))
            Text(hint, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (kind == SimKind.FILTER || kind == SimKind.ESPRESSO) {
            Text(stringResource(R.string.sim_disclaimer), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
private fun SliderRow(label: String, value: String, position: Float, range: ClosedFloatingPointRange<Float>, steps: Int, startLabel: String? = null, endLabel: String? = null, onChange: (Float) -> Unit) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
            Text(value, style = MaterialTheme.typography.titleMedium)
        }
        Slider(
            value = position, onValueChange = onChange, valueRange = range, steps = steps,
            colors = SliderDefaults.colors(activeTickColor = Color.Transparent, inactiveTickColor = Color.Transparent),
            modifier = Modifier.semantics { contentDescription = label },
        )
        if (startLabel != null && endLabel != null) {
            Row {
                Text(startLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                Text(endLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun SimControls(vm: MainViewModel, kind: SimKind) {
    val units = LocalUnits.current
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        when (kind) {
            SimKind.FILTER -> {
                val s = vm.filterSim
                SliderRow(stringResource(R.string.sim_grind), s.grind.toString(), s.grind.toFloat(), 0f..100f, 19, stringResource(R.string.sim_coarse), stringResource(R.string.sim_fine)) { vm.filterSim = s.copy(grind = Math.round(it)) }
                SliderRow(stringResource(R.string.dose), units.w(s.doseG), s.doseG.toFloat(), 10f..30f, 19) { vm.filterSim = s.copy(doseG = Math.round(it).toDouble()) }
                SliderRow(stringResource(R.string.water), units.w(s.waterG) + " · " + CoffeeEngine.formatRatio(CoffeeEngine.ratio(s.waterG, s.doseG)), s.waterG.toFloat(), 150f..500f, 34) { vm.filterSim = s.copy(waterG = Math.round(it / 10f) * 10.0) }
                SliderRow(stringResource(R.string.temperature), units.t(s.tempC), s.tempC.toFloat(), 85f..100f, 14) { vm.filterSim = s.copy(tempC = Math.round(it).toDouble()) }
                Text(stringResource(R.string.sim_agitation), style = MaterialTheme.typography.bodyLarge)
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    listOf(R.string.sim_low, R.string.sim_mid, R.string.sim_high).forEachIndexed { i, label ->
                        SegmentedButton(s.agitation == i, { vm.filterSim = s.copy(agitation = i) }, SegmentedButtonDefaults.itemShape(i, 3)) { Text(stringResource(label), maxLines = 1) }
                    }
                }
                OutlinedButton(onClick = { vm.filterSim = ExtractionSim.FilterInput() }) { Text(stringResource(R.string.reset)) }
            }
            SimKind.ESPRESSO -> {
                val s = vm.shotSim
                SliderRow(stringResource(R.string.sim_grind), s.grind.toString(), s.grind.toFloat(), 0f..100f, 19, stringResource(R.string.sim_coarse), stringResource(R.string.sim_fine)) { vm.shotSim = s.copy(grind = Math.round(it)) }
                SliderRow(stringResource(R.string.dose), units.w(s.doseG), s.doseG.toFloat(), 14f..22f, 15) { vm.shotSim = s.copy(doseG = Math.round(it * 2f) / 2.0) }
                SliderRow(stringResource(R.string.yield_label), units.w(s.yieldG) + " · " + CoffeeEngine.formatRatio(CoffeeEngine.ratio(s.yieldG, s.doseG)), s.yieldG.toFloat(), 18f..60f, 41) { vm.shotSim = s.copy(yieldG = Math.round(it).toDouble()) }
                SliderRow(stringResource(R.string.temperature), units.t(s.tempC), s.tempC.toFloat(), 88f..96f, 7) { vm.shotSim = s.copy(tempC = Math.round(it).toDouble()) }
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable(role = Role.Switch) { vm.shotSim = s.copy(channeling = !s.channeling) },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(stringResource(R.string.sim_channeling), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    Switch(checked = s.channeling, onCheckedChange = null)
                }
                OutlinedButton(onClick = { vm.shotSim = ExtractionSim.ShotInput() }) { Text(stringResource(R.string.reset)) }
            }
            SimKind.YIELD_CALC -> {
                val (dose, beverage, tds) = vm.yieldCalc
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    NumField(dose, { vm.yieldCalc = Triple(it, beverage, tds) }, stringResource(R.string.dose), Modifier.weight(1f), suffix = "g")
                    NumField(beverage, { vm.yieldCalc = Triple(dose, it, tds) }, stringResource(R.string.sim_beverage), Modifier.weight(1f), suffix = "g")
                }
                NumField(tds, { vm.yieldCalc = Triple(dose, beverage, it) }, stringResource(R.string.sim_tds), Modifier.fillMaxWidth(), suffix = "%")
            }
            SimKind.MILK -> SliderRow(stringResource(R.string.sim_milk_temp), units.t(vm.milkTemp.toDouble()), vm.milkTemp.toFloat(), 5f..80f, 74) { vm.milkTemp = Math.round(it) }
            SimKind.NONE -> Unit
        }
    }
}

@Composable
private fun LabModeToggle(vm: MainViewModel) {
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
        SegmentedButton(!vm.labEspresso, { vm.labEspresso = false }, SegmentedButtonDefaults.itemShape(0, 2)) { Text(stringResource(R.string.filter)) }
        SegmentedButton(vm.labEspresso, { vm.labEspresso = true }, SegmentedButtonDefaults.itemShape(1, 2)) { Text(BrewMethod.ESPRESSO.label) }
    }
}

@Composable
private fun LabScreen(vm: MainViewModel, wide: Boolean, hinge: HingeInfo?) {
    val kind = if (vm.labEspresso) SimKind.ESPRESSO else SimKind.FILTER
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.train_lab), onBack = vm::back)
        if (wide) {
            TwoPane(
                hinge = hinge,
                left = { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp).padding(bottom = 24.dp)) { SimReadout(vm, kind, stringResource(R.string.train_lab_hint)) } },
                right = {
                    Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxSize()) {
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            LabModeToggle(vm)
                            SimControls(vm, kind)
                        }
                    }
                },
            )
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                LabModeToggle(vm)
                SimReadout(vm, kind)
                SimControls(vm, kind)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Lesson: LEARN on the left, PRACTICE on the right
// ---------------------------------------------------------------------------------------------

@Composable
private fun LessonMeta(vm: MainViewModel, lesson: Lesson, validated: Boolean) {
    Text(
        stringResource(R.string.lesson_meta, lesson.minutes, lesson.level) + " · " + skillLabel(lesson.skill) +
            if (validated) " · " + stringResource(R.string.lesson_validated) else "",
        style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun LessonObjectives(vm: MainViewModel, lesson: Lesson) {
    SectionTitle(stringResource(R.string.lesson_objectives))
    lesson.objectives.forEach { o ->
        Row(Modifier.padding(vertical = 3.dp)) {
            Text("•  ", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
            Text(o[vm.lang], style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
private fun LessonBlock(vm: MainViewModel, lesson: Lesson, index: Int, large: Boolean = false) {
    val block = lesson.blocks[index]
    Text(block.title[vm.lang], style = if (large) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(if (large) 10.dp else 4.dp))
    Text(block.body[vm.lang], style = if (large) MaterialTheme.typography.titleLarge.copy(fontFamily = MaterialTheme.typography.bodyLarge.fontFamily, fontWeight = MaterialTheme.typography.bodyLarge.fontWeight) else MaterialTheme.typography.bodyLarge)
}

@Composable
private fun LessonTheory(vm: MainViewModel, lesson: Lesson, validated: Boolean) {
    LessonMeta(vm, lesson, validated)
    LessonObjectives(vm, lesson)
    SectionTitle(stringResource(R.string.lesson_theory))
    lesson.blocks.indices.forEach { i ->
        LessonBlock(vm, lesson, i)
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun ValidationCard(vm: MainViewModel, lesson: Lesson) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text(stringResource(R.string.lesson_validate).uppercase(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(4.dp))
            Text(stringResource(R.string.lesson_validation_hint, lesson.questions.size), style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(14.dp))
            BigButton(stringResource(R.string.lesson_start_validation), onClick = { vm.startLessonQuiz(lesson.id) }, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow, primary = true)
        }
    }
}

/** What a compact lesson page shows. */
private sealed interface LessonPage {
    data class Theory(val index: Int) : LessonPage
    data object Sim : LessonPage
    data object Validate : LessonPage
}

private fun lessonPage(lesson: Lesson, page: Int): LessonPage = when {
    page < lesson.blocks.size -> LessonPage.Theory(page)
    page == lesson.blocks.size && lesson.sim != SimKind.NONE -> LessonPage.Sim
    else -> LessonPage.Validate
}

@Composable
private fun LessonScreen(vm: MainViewModel, lesson: Lesson, progress: Progress, wide: Boolean, hinge: HingeInfo?) {
    val validated = lesson.id in progress.validated
    Column(Modifier.fillMaxSize().imePadding()) {
        ScreenHeader(lesson.title[vm.lang], onBack = vm::back)
        if (wide) {
            TwoPane(
                hinge = hinge,
                left = { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp).padding(bottom = 24.dp)) { LessonTheory(vm, lesson, validated) } },
                right = {
                    Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxSize()) {
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            if (lesson.sim != SimKind.NONE) {
                                Text(stringResource(R.string.lesson_practice).uppercase(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                SimReadout(vm, lesson.sim, lesson.simHint?.get(vm.lang))
                                SimControls(vm, lesson.sim)
                            }
                            ValidationCard(vm, lesson)
                        }
                    }
                },
            )
        } else {
            val run = vm.lessonRun
            val page = run?.page ?: 0
            val count = vm.lessonPageCount(lesson)
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
                when (val p = lessonPage(lesson, page)) {
                    is LessonPage.Theory -> {
                        if (p.index == 0) {
                            LessonMeta(vm, lesson, validated)
                            LessonObjectives(vm, lesson)
                            Spacer(Modifier.height(20.dp))
                        }
                        LessonBlock(vm, lesson, p.index, large = true)
                    }
                    LessonPage.Sim -> {
                        Text(stringResource(R.string.lesson_practice).uppercase(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(8.dp))
                        SimReadout(vm, lesson.sim, lesson.simHint?.get(vm.lang))
                        Spacer(Modifier.height(12.dp))
                        SimControls(vm, lesson.sim)
                    }
                    LessonPage.Validate -> ValidationCard(vm, lesson)
                }
                Spacer(Modifier.height(16.dp))
            }
            LessonPager(vm, page, count, Modifier.padding(horizontal = 20.dp, vertical = 12.dp))
        }
    }
}

@Composable
private fun LessonPager(vm: MainViewModel, page: Int, count: Int, modifier: Modifier = Modifier, large: Boolean = false) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        BigButton(stringResource(R.string.back), onClick = { vm.lessonPage(-1) }, modifier = Modifier.weight(1f).then(if (large) Modifier.fillMaxHeight() else Modifier), enabled = page > 0, minHeight = 56.dp, large = large)
        Text(stringResource(R.string.lesson_page, page + 1, count), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        BigButton(stringResource(R.string.next), onClick = { vm.lessonPage(1) }, modifier = Modifier.weight(1f).then(if (large) Modifier.fillMaxHeight() else Modifier), enabled = page < count - 1, primary = true, minHeight = 56.dp, large = large)
    }
}

// ---------------------------------------------------------------------------------------------
// Quiz: question to KNOW, answers to DO
// ---------------------------------------------------------------------------------------------

@Composable
private fun remainingSeconds(run: QuizRun): Int? {
    val limit = run.timeLimitS ?: return null
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(run.startedAtMs) {
        while (true) {
            now = SystemClock.elapsedRealtime()
            delay(500)
        }
    }
    return (limit - (now - run.startedAtMs) / 1000).toInt().coerceAtLeast(0)
}

@Composable
private fun QuizHeader(vm: MainViewModel, run: QuizRun, remaining: Int?) {
    ScreenHeader(run.title, onBack = vm::back) {
        if (remaining != null) {
            TimerText(CoffeeEngine.formatClock(remaining.toLong()), 22.sp, Modifier.padding(end = 16.dp), color = if (remaining <= 30) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
private fun QuestionPane(run: QuizRun, large: Boolean = false) {
    val item = run.current
    Text(stringResource(R.string.quiz_question_n, run.index + 1, run.items.size).uppercase(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(8.dp))
    if (item.facts.isNotEmpty()) {
        Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
            FlowRow(Modifier.padding(18.dp), horizontalArrangement = Arrangement.spacedBy(24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item.facts.forEach { (label, value) -> Stat(label, value) }
            }
        }
        Spacer(Modifier.height(14.dp))
    }
    Text(item.prompt, style = if (large) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.headlineSmall)
}

@Composable
private fun Feedback(run: QuizRun) {
    val selected = run.selected ?: return
    if (!run.instantFeedback) return
    val item = run.current
    val right = selected == item.correct
    Surface(
        color = if (right) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer,
        contentColor = if (right) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer,
        shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(stringResource(if (right) R.string.quiz_correct else R.string.quiz_incorrect), style = MaterialTheme.typography.titleLarge)
            if (!right) Text(stringResource(R.string.quiz_answer_was, item.options[item.correct]), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 2.dp))
            Text(item.why, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
private fun OptionButton(vm: MainViewModel, run: QuizRun, index: Int, modifier: Modifier = Modifier, large: Boolean = false) {
    val item = run.current
    val selected = run.selected
    val revealed = run.instantFeedback && selected != null
    val isCorrect = index == item.correct
    val isChosen = index == selected
    val container = when {
        revealed && isCorrect -> MaterialTheme.colorScheme.primary
        revealed && isChosen -> MaterialTheme.colorScheme.error
        !revealed && isChosen -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.secondaryContainer
    }
    val content = when {
        revealed && isCorrect -> MaterialTheme.colorScheme.onPrimary
        revealed && isChosen -> MaterialTheme.colorScheme.onError
        !revealed && isChosen -> MaterialTheme.colorScheme.onPrimary
        revealed -> MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.5f)
        else -> MaterialTheme.colorScheme.onSecondaryContainer
    }
    Surface(
        color = container, contentColor = content, shape = MaterialTheme.shapes.large,
        modifier = modifier.fillMaxWidth().heightIn(min = 60.dp).clip(MaterialTheme.shapes.large)
            .clickable(enabled = !revealed, role = Role.RadioButton) { vm.answer(index) },
    ) {
        Row(Modifier.padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                item.options[index],
                style = if (large) MaterialTheme.typography.titleLarge else MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f), maxLines = 4, overflow = TextOverflow.Ellipsis,
            )
            if (revealed && isCorrect) Icon(Icons.Rounded.CheckCircle, contentDescription = stringResource(R.string.quiz_correct), modifier = Modifier.padding(start = 8.dp))
            if (revealed && isChosen && !isCorrect) Icon(Icons.Rounded.Cancel, contentDescription = stringResource(R.string.quiz_incorrect), modifier = Modifier.padding(start = 8.dp))
        }
    }
}

@Composable
private fun QuizNav(vm: MainViewModel, run: QuizRun, modifier: Modifier = Modifier, large: Boolean = false) {
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (!run.instantFeedback && run.index > 0) {
            BigButton(stringResource(R.string.back), onClick = vm::previousQuestion, modifier = Modifier.weight(1f), minHeight = 56.dp, large = large)
        }
        BigButton(
            stringResource(if (run.isLast) R.string.quiz_finish else R.string.next),
            onClick = vm::nextQuestion,
            modifier = Modifier.weight(2f),
            primary = true,
            enabled = run.selected != null || !run.instantFeedback,
            minHeight = 56.dp, large = large,
        )
    }
}

@Composable
private fun QuizScreen(vm: MainViewModel, run: QuizRun, wide: Boolean, hinge: HingeInfo?) {
    val remaining = remainingSeconds(run)
    LaunchedEffect(remaining == 0) { if (remaining == 0) vm.finishQuiz() }
    val lesson = run.lessonId?.let { vm.train.lesson(it) }
    Column(Modifier.fillMaxSize()) {
        QuizHeader(vm, run, remaining)
        if (wide) {
            TwoPane(
                hinge = hinge,
                left = {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp).padding(bottom = 24.dp)) {
                        // During a lesson the theory stays in view. Otherwise the question owns the left side.
                        if (lesson != null) LessonTheory(vm, lesson, validated = false) else QuestionPane(run, large = true)
                    }
                },
                right = {
                    Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxSize()) {
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (lesson != null) {
                                QuestionPane(run)
                                Spacer(Modifier.height(6.dp))
                            }
                            run.current.options.indices.forEach { OptionButton(vm, run, it) }
                            Feedback(run)
                            QuizNav(vm, run)
                        }
                    }
                },
            )
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                QuestionPane(run)
                Spacer(Modifier.height(6.dp))
                run.current.options.indices.forEach { OptionButton(vm, run, it) }
                Feedback(run)
                QuizNav(vm, run)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Result
// ---------------------------------------------------------------------------------------------

@Composable
private fun ResultSummary(vm: MainViewModel, r: QuizResult) {
    Text(
        stringResource(if (r.passed) R.string.result_passed else R.string.result_failed).uppercase(),
        style = MaterialTheme.typography.labelLarge, color = if (r.passed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
    )
    TimerText(stringResource(R.string.result_score, r.correct, r.total), 72.sp)
    Text(
        listOfNotNull(
            if (r.xp > 0) stringResource(R.string.result_xp, r.xp) else null,
            CoffeeEngine.formatClock(r.durationS.toLong()),
            if (r.lessonValidated) stringResource(R.string.result_lesson_validated) else null,
            if (r.streakBonus) stringResource(R.string.result_streak_bonus) else null,
        ).joinToString("  ·  "),
        style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    val task = r.run.lessonId?.let { vm.train.lesson(it)?.brewTask }
    if (r.lessonValidated && task != null) {
        Spacer(Modifier.height(16.dp))
        Surface(color = MaterialTheme.colorScheme.tertiaryContainer, contentColor = MaterialTheme.colorScheme.onTertiaryContainer, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text(stringResource(R.string.brew_challenge).uppercase(), style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(4.dp))
                Text(task[vm.lang], style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(12.dp))
                BigButton(stringResource(R.string.brew_challenge_accept), onClick = { vm.acceptBrewChallenge(r.run.lessonId!!) }, modifier = Modifier.fillMaxWidth(), primary = true, minHeight = 56.dp)
            }
        }
    }
    Spacer(Modifier.height(16.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (!r.passed && r.run.kind != EventKind.DAILY) {
            BigButton(
                stringResource(R.string.result_retry),
                onClick = {
                    val run = r.run
                    vm.closeResult()
                    when (run.kind) {
                        EventKind.LESSON -> { vm.openLesson(run.refId) }
                        EventKind.DIAL_IN -> vm.startDialIn(run.refId == "espresso")
                        EventKind.EXAM -> ExamCategory.entries.firstOrNull { it.name == run.refId }?.let(vm::startExam)
                        EventKind.LEVEL_TEST -> run.refId.substringAfter(':').toIntOrNull()?.let(vm::startLevelTest)
                        else -> Unit
                    }
                },
                modifier = Modifier.weight(1f), minHeight = 56.dp,
            )
        }
        BigButton(stringResource(R.string.result_done), onClick = vm::closeResult, modifier = Modifier.weight(1f), primary = r.passed, minHeight = 56.dp)
    }
}

@Composable
private fun ResultDetails(vm: MainViewModel, r: QuizResult) {
    if (r.weak.isNotEmpty()) {
        SectionTitle(stringResource(R.string.result_weak))
        Text(r.weak.map { skillLabel(it) }.joinToString(" · "), style = MaterialTheme.typography.titleLarge)
    }
    if (r.recommendations.isNotEmpty()) {
        SectionTitle(stringResource(R.string.result_recommended))
        r.recommendations.forEach { rec ->
            ListRow(
                title = recTitle(vm, rec),
                subtitle = stringResource(R.string.train_minutes, recMinutes(vm, rec)),
                trailing = { Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                onClick = { vm.closeResult(); vm.start(rec) },
            )
        }
    }
    val wrong = r.run.items.indices.filter { r.run.answers[it] != r.run.items[it].correct }
    if (wrong.isNotEmpty()) {
        SectionTitle(stringResource(R.string.result_corrections))
        wrong.forEach { i ->
            val item = r.run.items[i]
            Column(Modifier.padding(vertical = 10.dp)) {
                if (item.facts.isNotEmpty()) {
                    Text(item.facts.joinToString(" · ") { it.second }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(item.prompt, style = MaterialTheme.typography.titleMedium)
                Text(
                    stringResource(R.string.result_your_answer, r.run.answers[i]?.let { item.options[it] } ?: stringResource(R.string.result_no_answer)),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 4.dp),
                )
                Text(stringResource(R.string.quiz_answer_was, item.options[item.correct]), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                Text(item.why, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 4.dp))
            }
            ThinDivider()
        }
    }
}

@Composable
private fun ResultScreen(vm: MainViewModel, r: QuizResult, wide: Boolean, hinge: HingeInfo?) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(r.run.title, onBack = vm::back)
        if (wide) {
            TwoPane(
                hinge = hinge,
                left = { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp).padding(bottom = 24.dp)) { ResultSummary(vm, r) } },
                right = {
                    Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxSize()) {
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
                            Column(Modifier.padding(horizontal = 12.dp)) { ResultDetails(vm, r) }
                        }
                    }
                },
            )
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
                ResultSummary(vm, r)
                ResultDetails(vm, r)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// FLEX: training desk. Question or simulation above the hinge, answers or controls below.
// ---------------------------------------------------------------------------------------------

@Composable
fun TrainDesk(vm: MainViewModel, settings: Settings, hinge: HingeInfo?) {
    val screen = vm.trainScreen
    val run = vm.quiz
    val lesson = (screen as? TrainScreen.LessonView)?.let { vm.train.lesson(it.id) }
    val remaining = if (screen == TrainScreen.Quiz && run != null) remainingSeconds(run) else null
    LaunchedEffect(remaining == 0) { if (remaining == 0) vm.finishQuiz() }
    val labKind = if (vm.labEspresso) SimKind.ESPRESSO else SimKind.FILTER

    FlexSplit(
        hinge = hinge,
        top = {
            Surface(color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxSize()) {
                Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 24.dp, vertical = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = vm::back) { Icon(Icons.Rounded.Close, contentDescription = stringResource(R.string.back)) }
                        Text(
                            when {
                                screen == TrainScreen.Quiz && run != null -> run.title
                                lesson != null -> lesson.title[vm.lang]
                                else -> stringResource(R.string.train_lab)
                            },
                            style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                        )
                        if (remaining != null) TimerText(CoffeeEngine.formatClock(remaining.toLong()), 24.sp, color = if (remaining <= 30) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                    }
                    Spacer(Modifier.height(8.dp))
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                        when {
                            screen == TrainScreen.Quiz && run != null -> {
                                QuestionPane(run, large = true)
                                Spacer(Modifier.height(12.dp))
                                Feedback(run)
                            }
                            lesson != null -> when (val p = lessonPage(lesson, vm.lessonRun?.page ?: 0)) {
                                is LessonPage.Theory -> LessonBlock(vm, lesson, p.index, large = true)
                                LessonPage.Sim -> SimReadout(vm, lesson.sim, lesson.simHint?.get(vm.lang))
                                LessonPage.Validate -> {
                                    LessonMeta(vm, lesson, validated = false)
                                    LessonObjectives(vm, lesson)
                                }
                            }
                            else -> SimReadout(vm, labKind, stringResource(R.string.train_lab_hint))
                        }
                    }
                }
            }
        },
        bottom = {
            Surface(color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxSize()) {
                Column(Modifier.fillMaxSize().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    when {
                        screen == TrainScreen.Quiz && run != null -> {
                            // Two by two, sized for a finger from across the table.
                            val options = run.current.options.indices.toList()
                            options.chunked(2).forEach { pair ->
                                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    pair.forEach { i -> OptionButton(vm, run, i, Modifier.weight(1f).fillMaxHeight(), large = true) }
                                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                                }
                            }
                            QuizNav(vm, run, large = true)
                        }
                        lesson != null -> {
                            val page = vm.lessonRun?.page ?: 0
                            val count = vm.lessonPageCount(lesson)
                            when (lessonPage(lesson, page)) {
                                LessonPage.Sim -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) { SimControls(vm, lesson.sim) }
                                LessonPage.Validate -> Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { ValidationCard(vm, lesson) }
                                is LessonPage.Theory -> Unit
                            }
                            val theory = lessonPage(lesson, page) is LessonPage.Theory
                            LessonPager(vm, page, count, if (theory) Modifier.weight(1f) else Modifier.height(88.dp), large = true)
                        }
                        else -> {
                            LabModeToggle(vm)
                            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) { SimControls(vm, labKind) }
                        }
                    }
                }
            }
        },
    )
}

/** Copilot to Trainer: a diagnosis points straight at the lesson that explains it. */
@Composable
fun TrainSuggestion(vm: MainViewModel, lessonId: String, modifier: Modifier = Modifier) {
    val lesson = vm.train.lesson(lessonId) ?: return
    Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = MaterialTheme.shapes.large, modifier = modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(stringResource(R.string.copilot_train_hint), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(lesson.title[vm.lang], style = MaterialTheme.typography.titleMedium)
            }
            BigButton(stringResource(R.string.train_now), onClick = { vm.openLesson(lessonId) }, minHeight = 48.dp)
        }
    }
}

/** Shown on the main Home when real brews repeat the same fault. */
@Composable
fun HomeOpportunity(vm: MainViewModel, brews: List<Brew>, modifier: Modifier = Modifier) {
    val opportunity = remember(brews) { vm.opportunityOf(brews) } ?: return
    ListRow(
        title = stringResource(R.string.train_opportunity),
        subtitle = stringResource(R.string.train_opportunity_body, opportunity.count, stringResource(CopilotText.symptom(opportunity.symptom))),
        leading = { Icon(Icons.Rounded.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        trailing = { Text(stringResource(R.string.train_this), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) },
        onClick = { vm.openLesson(opportunity.lessonId) },
        modifier = modifier,
    )
}
