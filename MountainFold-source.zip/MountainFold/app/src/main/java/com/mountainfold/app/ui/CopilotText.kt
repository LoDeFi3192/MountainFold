package com.mountainfold.app.ui

import com.mountainfold.app.R
import com.mountainfold.app.core.engine.CopilotEngine.Cause
import com.mountainfold.app.core.engine.CopilotEngine.ChangeKind
import com.mountainfold.app.core.model.Symptom

/** String resources for Copilot vocabulary. Shared by the diagnosis screen and the trainer. */
object CopilotText {
    fun symptom(s: Symptom): Int = when (s) {
        Symptom.SOUR -> R.string.sym_sour
        Symptom.BITTER -> R.string.sym_bitter
        Symptom.WEAK -> R.string.sym_weak
        Symptom.STRONG -> R.string.sym_strong
        Symptom.DRY -> R.string.sym_dry
        Symptom.ASTRINGENT -> R.string.sym_astringent
        Symptom.FLAT -> R.string.sym_flat
        Symptom.HOLLOW -> R.string.sym_hollow
        Symptom.HARSH -> R.string.sym_harsh
        Symptom.MUDDY -> R.string.sym_muddy
    }

    fun cause(c: Cause): Int = when (c) {
        Cause.UNDER_EXTRACTION -> R.string.cause_under
        Cause.OVER_EXTRACTION -> R.string.cause_over
        Cause.LOW_STRENGTH -> R.string.cause_weak
        Cause.HIGH_STRENGTH -> R.string.cause_strong
        Cause.UNEVEN_EXTRACTION -> R.string.cause_uneven
        Cause.TOO_HOT -> R.string.cause_hot
        Cause.STALE_COFFEE -> R.string.cause_stale
        Cause.TOO_MANY_FINES -> R.string.cause_fines
        Cause.CHANNELING -> R.string.cause_channeling
    }

    fun changeTitle(k: ChangeKind): Int = when (k) {
        ChangeKind.GRIND_FINER -> R.string.chg_finer
        ChangeKind.GRIND_COARSER -> R.string.chg_coarser
        ChangeKind.TEMP_UP -> R.string.chg_temp_up
        ChangeKind.TEMP_DOWN -> R.string.chg_temp_down
        ChangeKind.DOSE_UP -> R.string.chg_dose_up
        ChangeKind.DOSE_DOWN -> R.string.chg_dose_down
        ChangeKind.YIELD_UP -> R.string.chg_yield_up
        ChangeKind.YIELD_DOWN -> R.string.chg_yield_down
        ChangeKind.BLOOM_LONGER -> R.string.chg_bloom
        ChangeKind.AGITATE_LESS -> R.string.chg_agitate
        ChangeKind.PUCK_PREP -> R.string.chg_puck
        ChangeKind.FRESHER_COFFEE -> R.string.chg_fresh
    }

    fun changeWhy(k: ChangeKind): Int = when (k) {
        ChangeKind.GRIND_FINER -> R.string.why_finer
        ChangeKind.GRIND_COARSER -> R.string.why_coarser
        ChangeKind.TEMP_UP -> R.string.why_temp_up
        ChangeKind.TEMP_DOWN -> R.string.why_temp_down
        ChangeKind.DOSE_UP -> R.string.why_dose_up
        ChangeKind.DOSE_DOWN -> R.string.why_dose_down
        ChangeKind.YIELD_UP -> R.string.why_yield_up
        ChangeKind.YIELD_DOWN -> R.string.why_yield_down
        ChangeKind.BLOOM_LONGER -> R.string.why_bloom
        ChangeKind.AGITATE_LESS -> R.string.why_agitate
        ChangeKind.PUCK_PREP -> R.string.why_puck
        ChangeKind.FRESHER_COFFEE -> R.string.why_fresh
    }
}
