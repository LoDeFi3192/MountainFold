package com.mountainfold.app.core.train

import com.mountainfold.app.core.engine.CopilotEngine
import com.mountainfold.app.core.engine.CopilotEngine.ChangeKind
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.BrewStep
import com.mountainfold.app.core.model.StepType
import com.mountainfold.app.core.model.Symptom
import kotlin.random.Random

/**
 * Builds dial-in exercises from the same rules the Copilot uses on real brews.
 * The trainer and the copilot can therefore never disagree.
 */
object DialInGenerator {

    data class Scenario(
        val input: CopilotEngine.BrewInput,
        val symptom: Symptom,
        val diagnosis: CopilotEngine.Diagnosis,
        /** The correct change followed by three clearly wrong ones. */
        val options: List<ChangeKind>,
    ) {
        val correct: ChangeKind get() = options.first()
        val skill: Skill get() = if (input.method.isEspresso) Skill.ESPRESSO else Skill.EXTRACTION
    }

    /**
     * Changes that would also be reasonable for a symptom, even if they are not the first one.
     * They are never offered as wrong answers, so every wrong answer is defensibly wrong.
     */
    fun acceptable(symptom: Symptom): Set<ChangeKind> = when (symptom) {
        Symptom.SOUR ->
            setOf(ChangeKind.GRIND_FINER, ChangeKind.TEMP_UP, ChangeKind.YIELD_UP, ChangeKind.BLOOM_LONGER, ChangeKind.PUCK_PREP)
        Symptom.BITTER, Symptom.DRY, Symptom.HARSH ->
            setOf(ChangeKind.GRIND_COARSER, ChangeKind.TEMP_DOWN, ChangeKind.YIELD_DOWN, ChangeKind.AGITATE_LESS, ChangeKind.PUCK_PREP)
        Symptom.WEAK ->
            setOf(ChangeKind.DOSE_UP, ChangeKind.YIELD_DOWN, ChangeKind.GRIND_FINER, ChangeKind.TEMP_UP, ChangeKind.BLOOM_LONGER)
        Symptom.STRONG ->
            setOf(ChangeKind.DOSE_DOWN, ChangeKind.YIELD_UP, ChangeKind.GRIND_COARSER, ChangeKind.TEMP_DOWN, ChangeKind.AGITATE_LESS)
        Symptom.ASTRINGENT ->
            setOf(ChangeKind.GRIND_COARSER, ChangeKind.AGITATE_LESS, ChangeKind.PUCK_PREP, ChangeKind.TEMP_DOWN, ChangeKind.YIELD_DOWN)
        Symptom.MUDDY -> setOf(ChangeKind.GRIND_COARSER, ChangeKind.AGITATE_LESS, ChangeKind.PUCK_PREP)
        Symptom.HOLLOW -> setOf(ChangeKind.BLOOM_LONGER, ChangeKind.PUCK_PREP, ChangeKind.GRIND_FINER, ChangeKind.AGITATE_LESS)
        Symptom.FLAT -> setOf(ChangeKind.FRESHER_COFFEE, ChangeKind.TEMP_UP, ChangeKind.GRIND_FINER)
    }

    private val filterKinds = listOf(
        ChangeKind.GRIND_FINER, ChangeKind.GRIND_COARSER, ChangeKind.TEMP_UP, ChangeKind.TEMP_DOWN,
        ChangeKind.DOSE_UP, ChangeKind.DOSE_DOWN, ChangeKind.BLOOM_LONGER, ChangeKind.AGITATE_LESS,
    )
    private val espressoKinds = listOf(
        ChangeKind.GRIND_FINER, ChangeKind.GRIND_COARSER, ChangeKind.TEMP_UP, ChangeKind.TEMP_DOWN,
        ChangeKind.YIELD_UP, ChangeKind.YIELD_DOWN, ChangeKind.PUCK_PREP,
    )

    private val filterSymptoms = listOf(
        Symptom.SOUR, Symptom.BITTER, Symptom.WEAK, Symptom.STRONG, Symptom.DRY,
        Symptom.ASTRINGENT, Symptom.HARSH, Symptom.MUDDY, Symptom.HOLLOW,
    )
    private val espressoSymptoms = listOf(
        Symptom.SOUR, Symptom.BITTER, Symptom.WEAK, Symptom.STRONG, Symptom.ASTRINGENT, Symptom.HARSH, Symptom.HOLLOW,
    )

    fun generate(random: Random, espresso: Boolean): Scenario {
        val symptom = (if (espresso) espressoSymptoms else filterSymptoms).random(random)
        val input = if (espresso) shotInput(random) else filterInput(random)
        return build(random, input, symptom)
    }

    /** A session without repeated (method, symptom, answer) triples. */
    fun session(random: Random, espresso: Boolean?, count: Int): List<Scenario> {
        val out = mutableListOf<Scenario>()
        val seen = mutableSetOf<String>()
        var guard = 0
        while (out.size < count && guard++ < count * 40) {
            val s = generate(random, espresso ?: random.nextBoolean())
            val key = "${s.input.method.isEspresso}/${s.symptom}/${s.correct}"
            if (seen.add(key)) out += s
        }
        return out
    }

    fun build(random: Random, input: CopilotEngine.BrewInput, symptom: Symptom): Scenario {
        val diagnosis = checkNotNull(CopilotEngine.diagnose(input, setOf(symptom)))
        val pool = (if (input.method.isEspresso) espressoKinds else filterKinds) - acceptable(symptom) - diagnosis.change
        val wrong = pool.shuffled(random).take(3)
        return Scenario(input, symptom, diagnosis, listOf(diagnosis.change) + wrong)
    }

    private fun filterInput(random: Random): CopilotEngine.BrewInput {
        val method = listOf(BrewMethod.V60, BrewMethod.V60, BrewMethod.KALITA, BrewMethod.AEROPRESS, BrewMethod.FRENCH_PRESS).random(random)
        val dose = if (method == BrewMethod.FRENCH_PRESS) 30.0 else listOf(15.0, 18.0, 20.0).random(random)
        val ratio = listOf(15.0, 16.0, 16.5, 17.0).random(random)
        val water = Math.round(dose * ratio / 5.0) * 5.0
        val target = method.defaultTimeS
        val time = (target * listOf(0.72, 1.0, 1.0, 1.28).random(random)).toInt() / 5 * 5
        val temp = listOf(88.0, 90.0, 92.0, 94.0, 96.0).random(random)
        val steps = if (method == BrewMethod.V60 || method == BrewMethod.KALITA) {
            listOf(BrewStep("Bloom", StepType.BLOOM, 0, dose * 3), BrewStep("Pour", StepType.POUR, 45, water))
        } else emptyList()
        return CopilotEngine.BrewInput(method, dose, water, temp, time, target, "", steps)
    }

    private fun shotInput(random: Random): CopilotEngine.BrewInput {
        val dose = listOf(17.0, 18.0, 18.0, 20.0).random(random)
        val ratio = listOf(1.6, 2.0, 2.0, 2.5).random(random)
        val yieldG = Math.round(dose * ratio).toDouble()
        val time = listOf(17, 21, 28, 29, 36, 41).random(random)
        val temp = listOf(91.0, 93.0, 94.0).random(random)
        return CopilotEngine.BrewInput(BrewMethod.ESPRESSO, dose, yieldG, temp, time, 28, "")
    }
}
