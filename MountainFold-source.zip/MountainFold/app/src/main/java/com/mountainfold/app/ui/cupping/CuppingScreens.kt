package com.mountainfold.app.ui.cupping

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mountainfold.app.R
import com.mountainfold.app.core.cupping.CuppingCatalog
import com.mountainfold.app.core.cupping.CuppingFormat
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.model.ThemeMode
import com.mountainfold.app.data.db.CuppingCoffee
import com.mountainfold.app.data.prefs.LanguageStore
import com.mountainfold.app.data.prefs.Settings
import com.mountainfold.app.service.QrCode
import com.mountainfold.app.ui.MainViewModel
import com.mountainfold.app.ui.components.ConfirmDialog
import com.mountainfold.app.ui.components.FlexSplit
import com.mountainfold.app.ui.components.TwoPane
import com.mountainfold.app.ui.screens.findActivity
import com.mountainfold.app.ui.screens.reducedMotion
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

/** Red of the favourite heart in the original (Tailwind red-500). */
private val Heart = Color(0xFFEF4444)

/** True when the Flex desk has a dedicated layout for the current cupping screen. */
fun isCupDesk(screen: CupScreen): Boolean = screen == CupScreen.MAIN || screen == CupScreen.WHEEL || screen == CupScreen.LAB

/** Hides the bottom bar on Closed for the screens that were full-screen pages in the original. */
fun cupHidesBar(screen: CupScreen): Boolean = screen == CupScreen.WHEEL || screen == CupScreen.INFO

// ---------------------------------------------------------------------------------------------
// Entry points
// ---------------------------------------------------------------------------------------------

/** Closed and Open. Closed mirrors the phone layout of the original, Open splits KNOW / DO on the hinge. */
@Composable
fun CuppingTab(vm: MainViewModel, settings: Settings, wide: Boolean, hinge: HingeInfo?) {
    val cup = vm.cup
    val lang = rememberCupLang()
    val reduced = reducedMotion()
    ProvideCupHaptics(settings.haptics) {
        if (cup.session == null) return@ProvideCupHaptics
        when (cup.screen) {
            CupScreen.MAIN -> if (wide) {
                TwoPane(hinge, leftWeight = 0.42f, left = { CupOverview(vm, settings, lang) }, right = { FormPane(vm, lang) })
            } else {
                Column(Modifier.fillMaxSize()) {
                    CupHeader(vm, settings)
                    CoffeeTabs(cup)
                    FormPane(vm, lang, Modifier.weight(1f), showSummaryButton = true)
                }
            }
            CupScreen.SUMMARY -> SummaryPage(vm, wide)
            CupScreen.WHEEL -> if (wide) {
                TwoPane(
                    hinge,
                    left = {
                        BoxWithConstraints(Modifier.fillMaxSize()) {
                            val h = constraints.maxHeight.toFloat()
                            val w = constraints.maxWidth.toFloat()
                            WheelSurface(cup, Offset(0f, h / 2f), minOf(w * 0.9f, h * 0.46f), 0f, lang, reduced, Modifier.fillMaxSize())
                        }
                    },
                    right = {
                        Box(Modifier.fillMaxSize().padding(24.dp)) {
                            Button(onClick = { cup.screen = CupScreen.MAIN }, modifier = Modifier.align(Alignment.TopEnd)) { Text(stringResource(R.string.cup_close)) }
                            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                                WheelInfo(cup.wheelRotation, 0f, lang, alignEnd = false, nameSize = 56.sp)
                                WheelSiblings(cup.wheelRotation, 0f, lang, Modifier.widthIn(max = 420.dp)) { i ->
                                    cup.wheelRotation = com.mountainfold.app.core.cupping.FlavorWheel.rotationFor(i, cup.wheelRotation)
                                }
                            }
                        }
                    },
                )
            } else {
                FlavorWheelFull(cup, lang, reduced) { cup.screen = CupScreen.MAIN }
            }
            CupScreen.LAB -> if (wide) {
                TwoPane(hinge, left = { LabHistoryPane(vm, lang, standalone = true) }, right = { LabForm(vm, lang, showHistoryButton = false) })
            } else {
                if (cup.labHistory) LabHistoryPane(vm, lang, standalone = false) else LabForm(vm, lang, showHistoryButton = true)
            }
            CupScreen.INFO -> if (wide) {
                TwoPane(hinge, leftWeight = 0.42f, left = { CupOverview(vm, settings, lang) }, right = { SessionInfoPage(vm) })
            } else {
                SessionInfoPage(vm)
            }
            CupScreen.SESSIONS -> SessionsPage(vm, wide)
        }
        CuppingDialogs(vm, settings)
    }
}

/** Flex: info on the top half, hands-on controls on the bottom half, for a cupping table. */
@Composable
fun CuppingDesk(vm: MainViewModel, settings: Settings, hinge: HingeInfo?) {
    val cup = vm.cup
    val lang = rememberCupLang()
    val reduced = reducedMotion()
    ProvideCupHaptics(settings.haptics) {
        if (cup.session == null) return@ProvideCupHaptics
        FlexSplit(
            hinge = hinge,
            top = {
                Surface(color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxSize()) {
                    Box(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 24.dp, vertical = 12.dp)) {
                        when (cup.screen) {
                            CupScreen.WHEEL -> {
                                WheelInfo(cup.wheelRotation, 270f, lang, Modifier.align(Alignment.Center), nameSize = 64.sp, alignEnd = false)
                                Button(onClick = { cup.screen = CupScreen.MAIN }, modifier = Modifier.align(Alignment.TopEnd)) { Text(stringResource(R.string.cup_close)) }
                            }
                            CupScreen.LAB -> LabDeskTop(vm, lang)
                            else -> MainDeskTop(vm)
                        }
                    }
                }
            },
            bottom = {
                Surface(color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxSize()) {
                    Box(Modifier.fillMaxSize().navigationBarsPadding()) {
                        when (cup.screen) {
                            CupScreen.WHEEL -> BoxWithConstraints(Modifier.fillMaxSize()) {
                                val h = constraints.maxHeight.toFloat()
                                val w = constraints.maxWidth.toFloat()
                                val r = minOf(h * 0.9f, w / 2f * 0.95f)
                                WheelSurface(cup, Offset(w / 2f, h), r, 270f, lang, reduced, Modifier.fillMaxSize())
                            }
                            CupScreen.LAB -> if (cup.labHistory) LabHistoryPane(vm, lang, standalone = false) else LabForm(vm, lang, showHistoryButton = true, desk = true)
                            else -> Column(Modifier.fillMaxSize()) {
                                CoffeeTabs(cup)
                                FormPane(vm, lang, Modifier.weight(1f), showSummaryButton = true, showTimerButton = false)
                            }
                        }
                    }
                }
            },
        )
        CuppingDialogs(vm, settings)
    }
}

// ---------------------------------------------------------------------------------------------
// Header, menu, coffee tabs
// ---------------------------------------------------------------------------------------------

@Composable
fun CupHeader(vm: MainViewModel, settings: Settings, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme
    Surface(color = colors.surfaceContainer, modifier = modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 12.dp)) {
            TcLogo(48.dp, Modifier.align(Alignment.CenterStart))
            Text(
                stringResource(R.string.cup_title),
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, fontSize = 24.sp),
                color = colors.onSurface,
                maxLines = 1,
                modifier = Modifier.align(Alignment.Center).padding(horizontal = 56.dp).semantics { heading() },
            )
            Box(Modifier.align(Alignment.CenterEnd)) {
                IconButton(onClick = { vm.cup.menuOpen = true }) {
                    Icon(Icons.Rounded.Menu, contentDescription = stringResource(R.string.cup_menu), tint = colors.onSurfaceVariant)
                }
                CupMenu(vm, settings)
            }
        }
    }
    HorizontalDivider(color = colors.outline.copy(alpha = 0.05f))
}

/** The burger menu of the original. Google sign-in, fake cloud save and the PWA updater are left out. */
@Composable
private fun CupMenu(vm: MainViewModel, settings: Settings) {
    val cup = vm.cup
    val context = LocalContext.current
    val colors = MaterialTheme.colorScheme
    val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
    val dark = when (settings.themeMode) { ThemeMode.DARK -> true; ThemeMode.LIGHT -> false; ThemeMode.SYSTEM -> systemDark }
    val lang = LanguageStore.get(context)
    DropdownMenu(
        expanded = cup.menuOpen,
        onDismissRequest = { cup.menuOpen = false },
        modifier = Modifier.widthIn(min = 280.dp, max = 320.dp),
        containerColor = colors.surfaceContainerHigh,
        shape = RoundedCornerShape(12.dp),
    ) {
        Text(
            stringResource(R.string.cup_preferences).uppercase(),
            style = MaterialTheme.typography.labelMedium,
            color = colors.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )
        Row(
            Modifier
                .padding(horizontal = 12.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(colors.surfaceVariant.copy(alpha = 0.3f))
                .clickable(role = Role.Switch) { vm.setSettings { it.copy(themeMode = if (dark) ThemeMode.LIGHT else ThemeMode.DARK) } }
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(if (dark) TcIcons.Moon else TcIcons.Sun, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(stringResource(if (dark) R.string.cup_dark_mode else R.string.cup_light_mode), style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
            Switch(checked = dark, onCheckedChange = null, modifier = Modifier.scale(0.7f))
        }
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier
                .padding(horizontal = 12.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(colors.surfaceVariant.copy(alpha = 0.3f))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(TcIcons.Translate, contentDescription = null, tint = colors.onSurfaceVariant, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.language), style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
            Row(Modifier.clip(RoundedCornerShape(8.dp)).background(colors.surfaceContainer).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("fr" to "FR", "en" to "EN", "es" to "ES").forEach { (code, label) ->
                    val on = lang == code
                    Text(
                        label,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (on) colors.onPrimary else colors.onSurfaceVariant,
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (on) colors.primary else Color.Transparent)
                            .clickable(role = Role.RadioButton) {
                                if (!on) {
                                    cup.menuOpen = false
                                    LanguageStore.set(context, code)
                                    context.findActivity()?.recreate()
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                    )
                }
            }
        }
        HorizontalDivider(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), color = colors.outline.copy(alpha = 0.1f))
        MenuItem(TcIcons.InfoSession, stringResource(R.string.cup_session_info)) { cup.menuOpen = false; cup.screen = CupScreen.INFO }
        MenuItem(TcIcons.Brew, stringResource(R.string.cup_brewing_mode)) { cup.menuOpen = false; cup.screen = CupScreen.LAB }
        MenuItem(TcIcons.QrCode, stringResource(R.string.cup_invite)) { cup.menuOpen = false; cup.inviteOpen = true }
        MenuItem(TcIcons.Wheel, stringResource(R.string.cup_flavor_wheel)) { cup.menuOpen = false; cup.screen = CupScreen.WHEEL }
        MenuItem(TcIcons.SummaryTable, stringResource(R.string.cup_summary)) { cup.menuOpen = false; cup.screen = CupScreen.SUMMARY }
        MenuItem(TcIcons.Calendar, stringResource(R.string.cup_sessions)) { cup.menuOpen = false; cup.screen = CupScreen.SESSIONS }
        HorizontalDivider(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), color = colors.outline.copy(alpha = 0.1f))
        MenuItem(TcIcons.DeleteSession, stringResource(R.string.cup_new_session), tint = colors.error) { cup.menuOpen = false; cup.confirmNewSession = true }
    }
}

@Composable
private fun MenuItem(icon: ImageVector, label: String, tint: Color = Color.Unspecified, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    DropdownMenuItem(
        text = { Text(label, style = MaterialTheme.typography.labelLarge, color = if (tint == Color.Unspecified) colors.onSurface else tint) },
        leadingIcon = { Icon(icon, contentDescription = null, tint = if (tint == Color.Unspecified) colors.onSurfaceVariant else tint, modifier = Modifier.size(20.dp)) },
        onClick = onClick,
    )
}

/** Horizontal coffee tabs with the heart and lock marks, then "+ New". The active tab scrolls into view. */
@Composable
fun CoffeeTabs(cup: CuppingController, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme
    val state = rememberLazyListState()
    LaunchedEffect(cup.activeIndex, cup.coffees.size) {
        runCatching { state.animateScrollToItem(cup.activeIndex, -120) }
    }
    Surface(color = colors.surface, modifier = modifier.fillMaxWidth()) {
        LazyRow(state = state, contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(cup.coffees, key = { _, c -> c.id }) { i, c ->
                val on = i == cup.activeIndex
                Row(
                    Modifier
                        .scale(if (on) 1.05f else 1f)
                        .clip(CircleShape)
                        .background(if (on) colors.secondaryContainer else Color.Transparent)
                        .clickable(role = Role.Tab) { cup.select(i) }
                        .heightIn(min = 36.dp)
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (c.isFavorite) Text("♥ ", color = Heart, style = MaterialTheme.typography.labelLarge)
                    Text(
                        c.name + if (c.isLocked) " 🔒" else "",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color = if (on) colors.onSecondaryContainer else colors.onSurfaceVariant.copy(alpha = 0.8f),
                        maxLines = 1,
                    )
                }
            }
            item {
                Box(
                    Modifier
                        .clip(CircleShape)
                        .border(1.dp, colors.outline, CircleShape)
                        .clickable(role = Role.Button) { cup.addCoffee() }
                        .heightIn(min = 36.dp)
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(stringResource(R.string.cup_new_coffee_btn), style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = colors.primary)
                }
            }
        }
    }
    HorizontalDivider(color = colors.outline.copy(alpha = 0.1f))
}

// ---------------------------------------------------------------------------------------------
// Coffee form
// ---------------------------------------------------------------------------------------------

/** The scrolling form and its floating score bar. */
@Composable
fun FormPane(vm: MainViewModel, lang: String, modifier: Modifier = Modifier, showSummaryButton: Boolean = false, showTimerButton: Boolean = true) {
    val cup = vm.cup
    val c = cup.active ?: return
    Box(modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .padding(bottom = 112.dp),
        ) {
            CoffeeForm(cup, c, lang)
            if (showSummaryButton) {
                Button(
                    onClick = { cup.screen = CupScreen.SUMMARY },
                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp).height(48.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp),
                ) { Text(stringResource(R.string.cup_see_summary), style = MaterialTheme.typography.titleMedium) }
            }
        }
        ScoreBar(cup, c, showTimerButton, Modifier.align(Alignment.BottomCenter).padding(16.dp))
    }
}

@Composable
fun CoffeeForm(cup: CuppingController, c: CuppingCoffee, lang: String) {
    val enabled = !c.isLocked
    val colors = MaterialTheme.colorScheme
    val score = stringResource(R.string.cup_score)

    // Name card
    Surface(color = colors.surfaceContainerHigh, shape = RoundedCornerShape(16.dp), shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
        Box(Modifier.padding(20.dp)) {
            Column {
                FloatingLabelField(
                    c.name, { v -> cup.edit { it.copy(name = v) } }, stringResource(R.string.cup_coffee_name), enabled,
                    Modifier.padding(top = 8.dp, end = if (enabled && cup.canDelete()) 40.dp else 0.dp),
                )
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.cup_date_line, cupDate(c.timestamp)), style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant, modifier = Modifier.weight(1f))
                    if (c.isLocked) {
                        Text(
                            "🔒 " + stringResource(R.string.cup_validated),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = colors.onSecondaryContainer,
                            modifier = Modifier.clip(CircleShape).background(colors.secondaryContainer).padding(horizontal = 12.dp, vertical = 4.dp),
                        )
                    }
                }
            }
            if (enabled && cup.canDelete()) {
                IconButton(onClick = { cup.pendingDelete = c }, modifier = Modifier.align(Alignment.TopEnd).padding(0.dp)) {
                    Icon(TcIcons.DeleteSession, contentDescription = stringResource(R.string.cup_delete_coffee), tint = colors.onSurfaceVariant)
                }
            }
        }
    }

    CollapsibleSection(stringResource(R.string.cup_fragrance), TcIcons.Fragrance, c.fragranceScore, { v -> cup.edit { it.copy(fragranceScore = v) } }, enabled, score, "frag-${c.id}") {
        Text(stringResource(R.string.cup_notes_olfactory), style = MaterialTheme.typography.labelMedium, color = colors.onSurfaceVariant, modifier = Modifier.padding(bottom = 12.dp))
        AromaSelector(c.fragranceNotes, { n -> cup.edit { it.copy(fragranceNotes = n) } }, enabled, lang, "fragsel-${c.id}")
    }
    CollapsibleSection(stringResource(R.string.cup_flavor), TcIcons.Flavor, c.flavorScore, { v -> cup.edit { it.copy(flavorScore = v) } }, enabled, score, "flav-${c.id}") {
        Text(stringResource(R.string.cup_notes_mouth), style = MaterialTheme.typography.labelMedium, color = colors.onSurfaceVariant, modifier = Modifier.padding(bottom = 12.dp))
        AromaSelector(c.flavorNotes, { n -> cup.edit { it.copy(flavorNotes = n) } }, enabled, lang, "flavsel-${c.id}")
    }
    TcCard {
        TcSectionTitle(stringResource(R.string.cup_process), TcIcons.Process)
        ChoiceChips(CuppingCatalog.PROCESSING_METHODS, c.process, enabled, lang) { v -> cup.edit { it.copy(process = v) } }
    }
    TcCard {
        TcSectionTitle(stringResource(R.string.cup_aftertaste), TcIcons.Aftertaste)
        TcSlider(score, c.aftertasteScore, { v -> cup.edit { it.copy(aftertasteScore = v) } }, enabled = enabled)
    }
    CollapsibleSection(stringResource(R.string.cup_acidity), TcIcons.Acidity, c.acidityScore, { v -> cup.edit { it.copy(acidityScore = v) } }, enabled, score, "acid-${c.id}") {
        SmallCapsLabel(stringResource(R.string.cup_type))
        ChoiceChips(CuppingCatalog.ACIDITY_TYPES, c.acidityType, enabled, lang) { v -> cup.edit { it.copy(acidityType = v) } }
        Spacer(Modifier.height(24.dp))
        SmallCapsLabel(stringResource(R.string.cup_intensity))
        ChoiceChips(CuppingCatalog.ACIDITY_INTENSITIES, c.acidityIntensity, enabled, lang) { v -> cup.edit { it.copy(acidityIntensity = v) } }
    }
    CollapsibleSection(stringResource(R.string.cup_body), TcIcons.Body, c.bodyScore, { v -> cup.edit { it.copy(bodyScore = v) } }, enabled, score, "body-${c.id}") {
        SmallCapsLabel(stringResource(R.string.cup_texture))
        ChoiceChips(CuppingCatalog.BODY_TYPES, c.bodyType, enabled, lang) { v -> cup.edit { it.copy(bodyType = v) } }
    }
    TcCard {
        TcSectionTitle(stringResource(R.string.cup_balance), TcIcons.Balance)
        TcSlider(score, c.balanceScore, { v -> cup.edit { it.copy(balanceScore = v) } }, enabled = enabled)
    }
    TcCard {
        TcSectionTitle(stringResource(R.string.cup_comments), TcIcons.Comment)
        OutlinedTextField(
            value = c.comments,
            onValueChange = { v -> cup.edit { it.copy(comments = v) } },
            enabled = enabled,
            placeholder = { Text(stringResource(R.string.cup_comments_placeholder)) },
            minLines = 4,
            textStyle = MaterialTheme.typography.bodyLarge,
            shape = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = colors.surfaceContainer, focusedContainerColor = colors.surfaceContainer, disabledContainerColor = colors.surfaceContainer,
                disabledTextColor = colors.onSurface,
            ),
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

/** Floating bar: favourite, live score, timer, then Validate or the Modify split button. */
@Composable
fun ScoreBar(cup: CuppingController, c: CuppingCoffee, showTimer: Boolean, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme
    var more by remember { mutableStateOf(false) }
    Surface(
        color = colors.surfaceContainerHigh,
        shape = CircleShape,
        shadowElevation = 6.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, colors.outline.copy(alpha = 0.1f)),
        modifier = modifier,
    ) {
        Row(Modifier.padding(start = 12.dp, end = 8.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = cup::toggleFavorite) {
                Icon(
                    if (c.isFavorite) TcIcons.HeartFilled else TcIcons.Heart,
                    contentDescription = stringResource(R.string.cup_favorite),
                    tint = if (c.isFavorite) Heart else colors.onSurfaceVariant,
                    modifier = Modifier.size(28.dp),
                )
            }
            Box(Modifier.width(1.dp).height(32.dp).background(colors.outlineVariant))
            Column(Modifier.padding(horizontal = 12.dp).widthIn(min = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(stringResource(R.string.cup_score).uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = colors.onSurfaceVariant, letterSpacing = 1.sp)
                Text(
                    CuppingFormat.fixed2(c.finalScore),
                    style = MaterialTheme.typography.headlineSmall.copy(fontFeatureSettings = "tnum", fontWeight = FontWeight.Bold),
                    color = colors.primary,
                )
            }
            if (showTimer) {
                IconButton(onClick = { cup.timerOpen = true }) {
                    Icon(TcIcons.Timer, contentDescription = stringResource(R.string.cup_timer), tint = colors.onSurfaceVariant)
                }
            }
            Spacer(Modifier.width(8.dp))
            if (!c.isLocked) {
                Button(onClick = cup::lock, modifier = Modifier.height(48.dp), contentPadding = PaddingValues(horizontal = 24.dp)) {
                    Text(stringResource(R.string.cup_validate))
                }
            } else {
                Row(Modifier.height(48.dp).clip(CircleShape).background(colors.secondaryContainer), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.fillMaxHeight().clickable(role = Role.Button, onClick = cup::unlock).padding(horizontal = 20.dp), contentAlignment = Alignment.Center) {
                        Text(stringResource(R.string.cup_modify), style = MaterialTheme.typography.labelLarge, color = colors.onSecondaryContainer)
                    }
                    Box(Modifier.width(1.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.2f)))
                    Box {
                        IconButton(onClick = { more = true }) {
                            Icon(Icons.Rounded.ArrowDropDown, contentDescription = stringResource(R.string.cup_more_actions), tint = colors.onSecondaryContainer)
                        }
                        DropdownMenu(expanded = more, onDismissRequest = { more = false }, containerColor = colors.surfaceContainerHigh) {
                            DropdownMenuItem(text = { Text(stringResource(R.string.cup_reset_notes)) }, onClick = { more = false; cup.resetNotes() })
                            if (cup.canDelete()) {
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.cup_delete_coffee), color = colors.error) },
                                    onClick = { more = false; cup.pendingDelete = c },
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Open: left pane
// ---------------------------------------------------------------------------------------------

/** KNOW side of the workstation: session card, the table of coffees, the timer and every tool one tap away. */
@Composable
fun CupOverview(vm: MainViewModel, settings: Settings, lang: String) {
    val cup = vm.cup
    val s = cup.session ?: return
    val colors = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize()) {
        CupHeader(vm, settings)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Surface(
                color = colors.surfaceContainerLow, shape = RoundedCornerShape(16.dp), shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(RoundedCornerShape(16.dp)).clickable { cup.screen = CupScreen.INFO },
            ) {
                Column(Modifier.padding(16.dp)) {
                    TcSectionTitle(stringResource(R.string.cup_session_info), TcIcons.InfoSession, Modifier.padding(bottom = 0.dp))
                    InfoLine(TcIcons.Calendar, cupDate(s.dateIso))
                    InfoLine(TcIcons.Location, s.location.ifBlank { stringResource(R.string.cup_no_location) })
                    if (s.originNotes.isNotBlank()) InfoLine(TcIcons.Globe, s.originNotes)
                    if (s.roasterNotes.isNotBlank()) InfoLine(TcIcons.Flame, s.roasterNotes)
                    if (s.importerNotes.isNotBlank()) InfoLine(TcIcons.Box, s.importerNotes)
                }
            }
            TcCard {
                TcSectionTitle(stringResource(R.string.tab_coffee), TcIcons.SummaryTable)
                cup.coffees.forEachIndexed { i, c ->
                    val on = i == cup.activeIndex
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (on) colors.secondaryContainer else Color.Transparent)
                            .clickable(role = Role.Tab) { cup.select(i) }
                            .heightIn(min = 48.dp)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("${i + 1}", style = MaterialTheme.typography.labelLarge, color = colors.onSurfaceVariant, modifier = Modifier.width(24.dp))
                        if (c.isFavorite) Text("♥ ", color = Heart)
                        Text(
                            c.name + if (c.isLocked) " 🔒" else "",
                            style = MaterialTheme.typography.titleSmall,
                            color = if (on) colors.onSecondaryContainer else colors.onSurface,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                        )
                        Text(CuppingFormat.fixed2(c.finalScore), style = MaterialTheme.typography.titleMedium.copy(fontFeatureSettings = "tnum"), color = colors.primary)
                    }
                }
                OutlinedButton(onClick = cup::addCoffee, modifier = Modifier.padding(top = 8.dp)) { Text(stringResource(R.string.cup_new_coffee_btn)) }
            }
            TcCard {
                TcSectionTitle(stringResource(R.string.cup_timer), TcIcons.Timer)
                TimerPanel(cup, ring = 180.dp, horizontal = false)
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ToolTile(TcIcons.Wheel, stringResource(R.string.cup_flavor_wheel)) { cup.screen = CupScreen.WHEEL }
                ToolTile(TcIcons.SummaryTable, stringResource(R.string.cup_summary)) { cup.screen = CupScreen.SUMMARY }
                ToolTile(TcIcons.Brew, stringResource(R.string.cup_brewing_mode)) { cup.screen = CupScreen.LAB }
                ToolTile(TcIcons.QrCode, stringResource(R.string.cup_invite)) { cup.inviteOpen = true }
                ToolTile(TcIcons.Calendar, stringResource(R.string.cup_sessions)) { cup.screen = CupScreen.SESSIONS }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun InfoLine(icon: ImageVector, text: String) {
    Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ToolTile(icon: ImageVector, label: String, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Column(
        Modifier
            .width(120.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(colors.surfaceContainerHigh)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = colors.primary, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(6.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center, maxLines = 2)
    }
}

// ---------------------------------------------------------------------------------------------
// Flex: top of the main desk
// ---------------------------------------------------------------------------------------------

@Composable
private fun MainDeskTop(vm: MainViewModel) {
    val cup = vm.cup
    val c = cup.active
    val colors = MaterialTheme.colorScheme
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val ring = minOf(maxHeight * 0.78f, maxWidth - 520.dp).coerceIn(140.dp, 300.dp)
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            TimerPanel(cup, ring = ring, horizontal = true)
            if (c != null) {
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (c.isFavorite) Text("♥ ", color = Heart, style = MaterialTheme.typography.titleLarge)
                        Text(c.name, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(stringResource(R.string.cup_score).uppercase(), style = MaterialTheme.typography.labelMedium, color = colors.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
                    Text(CuppingFormat.fixed2(c.finalScore), style = MaterialTheme.typography.displayMedium.copy(fontFeatureSettings = "tnum"), color = colors.primary)
                    TextButton(onClick = { cup.screen = CupScreen.SUMMARY }) { Text(stringResource(R.string.cup_summary)) }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Session info page, sessions archive
// ---------------------------------------------------------------------------------------------

@Composable
fun SessionInfoPage(vm: MainViewModel) {
    val cup = vm.cup
    val s = cup.session ?: return
    val colors = MaterialTheme.colorScheme
    var pickDate by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(colors.surface)) {
        Row(Modifier.fillMaxWidth().background(colors.surfaceContainer).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.cup_session_info), style = MaterialTheme.typography.headlineSmall, color = colors.primary, modifier = Modifier.weight(1f).semantics { heading() })
            IconButton(onClick = { cup.screen = CupScreen.MAIN }) { Text("✕", color = colors.onSurface, style = MaterialTheme.typography.titleLarge) }
        }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Column(Modifier.widthIn(max = 448.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(24.dp)) {
                InfoField(stringResource(R.string.cup_tasting_location), s.location, stringResource(R.string.cup_location_ph), TcIcons.Location, colors.primary) { v -> cup.updateSession { it.copy(location = v) } }
                Column {
                    Text(stringResource(R.string.cup_session_date), style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = colors.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp))
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(colors.surfaceContainerHigh)
                            .border(1.dp, colors.outline.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            .clickable(role = Role.Button) { pickDate = true }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(TcIcons.Calendar, contentDescription = null, tint = colors.primary)
                        Spacer(Modifier.width(12.dp))
                        Text(cupDate(s.dateIso), style = MaterialTheme.typography.bodyLarge)
                    }
                }
                HorizontalDivider(color = colors.outline.copy(alpha = 0.1f))
                Text(stringResource(R.string.cup_general_notes), style = MaterialTheme.typography.titleMedium)
                InfoField(stringResource(R.string.cup_origins), s.originNotes, stringResource(R.string.cup_origins_ph), TcIcons.Globe, colors.onSurfaceVariant) { v -> cup.updateSession { it.copy(originNotes = v) } }
                InfoField(stringResource(R.string.cup_roaster), s.roasterNotes, stringResource(R.string.cup_roaster_ph), TcIcons.Flame, colors.onSurfaceVariant) { v -> cup.updateSession { it.copy(roasterNotes = v) } }
                InfoField(stringResource(R.string.cup_importer), s.importerNotes, stringResource(R.string.cup_importer_ph), TcIcons.Box, colors.onSurfaceVariant) { v -> cup.updateSession { it.copy(importerNotes = v) } }
                Spacer(Modifier.height(48.dp))
            }
        }
        Surface(color = colors.surfaceContainer) {
            Button(onClick = { cup.screen = CupScreen.MAIN }, modifier = Modifier.fillMaxWidth().padding(16.dp).height(56.dp)) {
                Text(stringResource(R.string.cup_validate), style = MaterialTheme.typography.titleMedium)
            }
        }
    }
    if (pickDate) {
        val initial = runCatching { LocalDate.parse(s.dateIso).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli() }.getOrNull()
        val state = rememberDatePickerState(initialSelectedDateMillis = initial)
        DatePickerDialog(
            onDismissRequest = { pickDate = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { ms ->
                        val d = Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate()
                        cup.updateSession { it.copy(dateIso = d.toString()) }
                    }
                    pickDate = false
                }) { Text(stringResource(R.string.cup_ok)) }
            },
            dismissButton = { TextButton(onClick = { pickDate = false }) { Text(stringResource(R.string.cancel)) } },
        ) { DatePicker(state) }
    }
}

@Composable
private fun InfoField(label: String, value: String, placeholder: String, icon: ImageVector, tint: Color, onChange: (String) -> Unit) {
    val colors = MaterialTheme.colorScheme
    Column {
        Text(label, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = colors.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            placeholder = { Text(placeholder) },
            leadingIcon = { Icon(icon, contentDescription = null, tint = tint) },
            shape = RoundedCornerShape(12.dp),
            textStyle = MaterialTheme.typography.bodyLarge,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = colors.surfaceContainerHigh, focusedContainerColor = colors.surfaceContainerHigh,
                unfocusedBorderColor = colors.outline.copy(alpha = 0.3f),
            ),
            modifier = Modifier.fillMaxWidth().semantics { contentDescription = label },
        )
    }
}

/** Archive of past sessions. The original kept only one; here nothing is lost when a new one starts. */
@Composable
fun SessionsPage(vm: MainViewModel, wide: Boolean) {
    val cup = vm.cup
    val sessions by cup.sessions.collectAsStateWithLifecycle()
    val coffees by cup.allCoffees.collectAsStateWithLifecycle()
    val bySession = remember(coffees) { coffees.groupBy { it.sessionId } }
    val colors = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize()) {
        PageHeader(stringResource(R.string.cup_sessions)) { cup.screen = CupScreen.MAIN }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Column(Modifier.widthIn(max = if (wide) 720.dp else 600.dp).fillMaxWidth()) {
                sessions.forEach { s ->
                    val current = s.id == cup.session?.id
                    val list = if (current) cup.coffees else bySession[s.id].orEmpty()
                    val best = list.maxByOrNull { it.finalScore }
                    Surface(
                        color = if (current) colors.secondaryContainer else colors.surfaceContainerLow,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(16.dp)).clickable { cup.openSession(s.id) },
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(cupDate(s.dateIso), style = MaterialTheme.typography.titleMedium)
                                    if (current) {
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            stringResource(R.string.cup_current),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = colors.onPrimary,
                                            modifier = Modifier.clip(CircleShape).background(colors.primary).padding(horizontal = 8.dp, vertical = 2.dp),
                                        )
                                    }
                                }
                                Text(s.location.ifBlank { stringResource(R.string.cup_no_location) }, style = MaterialTheme.typography.bodyMedium, color = colors.onSurfaceVariant)
                                Text(
                                    stringResource(R.string.cup_coffees_count, list.size) +
                                        (best?.let { " · " + stringResource(R.string.cup_best, it.name + " " + CuppingFormat.fixed2(it.finalScore)) } ?: ""),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colors.onSurfaceVariant,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                )
                            }
                            if (!current) {
                                IconButton(onClick = { cup.pendingDeleteSession = s }) {
                                    Icon(TcIcons.DeleteSession, contentDescription = stringResource(R.string.delete), tint = colors.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PageHeader(title: String, onBack: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().background(colors.surface).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, style = MaterialTheme.typography.headlineSmall, color = colors.primary, modifier = Modifier.weight(1f).semantics { heading() })
        OutlinedButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(stringResource(R.string.back))
        }
    }
    HorizontalDivider(color = colors.outline.copy(alpha = 0.1f))
}

// ---------------------------------------------------------------------------------------------
// Dialogs
// ---------------------------------------------------------------------------------------------

@Composable
fun CuppingDialogs(vm: MainViewModel, settings: Settings) {
    val cup = vm.cup
    if (cup.timerOpen) TimerDialog(cup)
    if (cup.inviteOpen) InviteDialog(vm, settings)
    if (cup.confirmNewSession) {
        ConfirmDialog(stringResource(R.string.cup_new_session), stringResource(R.string.cup_confirm_reset), stringResource(R.string.cup_new_session), cup::newSession) { cup.confirmNewSession = false }
    }
    if (cup.shortcutPrompt) {
        ConfirmDialog(stringResource(R.string.cup_new_session), stringResource(R.string.cup_shortcut_detected), stringResource(R.string.cup_new_session), cup::newSession) { cup.shortcutPrompt = false }
    }
    cup.pendingDelete?.let { c ->
        ConfirmDialog(stringResource(R.string.cup_delete_coffee), stringResource(R.string.cup_delete_confirm), stringResource(R.string.delete), { cup.deleteCoffee(c) }) { cup.pendingDelete = null }
    }
    cup.pendingDeleteRecipe?.let { r ->
        ConfirmDialog(stringResource(R.string.delete), stringResource(R.string.cup_confirm_delete_recipe), stringResource(R.string.delete), { cup.deleteLab(r) }) { cup.pendingDeleteRecipe = null }
    }
    cup.pendingDeleteSession?.let { s ->
        ConfirmDialog(stringResource(R.string.delete), stringResource(R.string.cup_delete_session_confirm), stringResource(R.string.delete), { cup.deleteSession(s) }) { cup.pendingDeleteSession = null }
    }
}

@Composable
private fun TimerDialog(cup: CuppingController) {
    AlertDialog(
        onDismissRequest = { cup.timerOpen = false },
        confirmButton = {},
        dismissButton = { TextButton(onClick = { cup.timerOpen = false }) { Text(stringResource(R.string.cup_close)) } },
        title = { Text(stringResource(R.string.cup_timer), color = MaterialTheme.colorScheme.primary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) },
        text = { TimerPanel(cup, ring = 240.dp, horizontal = false) },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(24.dp),
    )
}

/** QR code for guests. Generated on the device, unlike the original which called api.qrserver.com. */
@Composable
private fun InviteDialog(vm: MainViewModel, settings: Settings) {
    val cup = vm.cup
    val colors = MaterialTheme.colorScheme
    var editing by remember { mutableStateOf(false) }
    var url by remember { mutableStateOf(settings.cuppingInviteUrl) }
    val bitmap = remember(settings.cuppingInviteUrl) { QrCode.bitmap(settings.cuppingInviteUrl)?.asImageBitmap() }
    val host = remember(settings.cuppingInviteUrl) { runCatching { java.net.URI(settings.cuppingInviteUrl).host }.getOrNull() ?: settings.cuppingInviteUrl }
    AlertDialog(
        onDismissRequest = { cup.inviteOpen = false },
        title = { Text(stringResource(R.string.cup_invite), color = colors.primary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.cup_invite_body), style = MaterialTheme.typography.bodyMedium, color = colors.onSurfaceVariant, textAlign = TextAlign.Center)
                Spacer(Modifier.height(24.dp))
                Box(Modifier.clip(RoundedCornerShape(12.dp)).background(Color.White).padding(16.dp)) {
                    if (bitmap != null) {
                        androidx.compose.foundation.Image(bitmap, contentDescription = settings.cuppingInviteUrl, modifier = Modifier.size(192.dp))
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(stringResource(R.string.cup_link, host), style = MaterialTheme.typography.labelSmall, color = colors.outline)
                if (editing) {
                    OutlinedTextField(
                        value = url, onValueChange = { url = it }, singleLine = true, label = { Text(stringResource(R.string.cup_invite_url)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Done),
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    )
                    TextButton(onClick = {
                        val clean = url.trim()
                        if (clean.isNotEmpty()) vm.setSettings { it.copy(cuppingInviteUrl = clean) }
                        editing = false
                    }) { Text(stringResource(R.string.save)) }
                } else {
                    TextButton(onClick = { url = settings.cuppingInviteUrl; editing = true }) { Text(stringResource(R.string.cup_edit_link)) }
                }
            }
        },
        confirmButton = {
            FilledTonalButton(onClick = { cup.inviteOpen = false }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.cup_close)) }
        },
        containerColor = colors.surfaceContainer,
    )
}

/** Countdown ring, phase label, the 4 and 6 minute presets and the controls. */
@Composable
fun TimerPanel(cup: CuppingController, ring: androidx.compose.ui.unit.Dp, horizontal: Boolean, modifier: Modifier = Modifier) {
    val st = cup.timerState
    val colors = MaterialTheme.colorScheme
    val phase = when (st.phase) {
        com.mountainfold.app.core.cupping.CuppingTimer.Phase.CRUST -> stringResource(R.string.cup_crust)
        com.mountainfold.app.core.cupping.CuppingTimer.Phase.TASTE -> stringResource(R.string.cup_taste)
        com.mountainfold.app.core.cupping.CuppingTimer.Phase.FINISHED -> stringResource(R.string.cup_finished)
        com.mountainfold.app.core.cupping.CuppingTimer.Phase.PAUSED -> stringResource(R.string.pause)
    }
    val ringBlock: @Composable () -> Unit = {
        TimerRing(st.progress, st.sixMinute, ring) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    CuppingFormat.clock(st.remainingS),
                    style = com.mountainfold.app.ui.theme.TimerStyle.copy(fontSize = (ring.value * 0.23f).sp, lineHeight = (ring.value * 0.25f).sp),
                    color = colors.onSurface,
                    modifier = Modifier.semantics { contentDescription = CuppingFormat.clock(st.remainingS) },
                )
                Text(phase.uppercase(), style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 2.sp), color = colors.onSurfaceVariant)
            }
        }
    }
    val controls: @Composable () -> Unit = {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                Preset(4, stringResource(R.string.cup_crust), st.initialS == 240, Modifier.weight(1f)) { cup.startTimer(4) }
                Preset(6, stringResource(R.string.cup_taste), st.initialS == 360, Modifier.weight(1f)) { cup.startTimer(6) }
            }
            if (st.initialS > 0) {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
                    val pad = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                    FilledTonalButton(onClick = cup::resetTimer, modifier = Modifier.weight(1f), contentPadding = pad) {
                        Text(stringResource(R.string.cup_reset), maxLines = 1, softWrap = false)
                    }
                    Button(onClick = cup::toggleTimer, modifier = Modifier.weight(2f), contentPadding = pad) {
                        Text(stringResource(if (st.running) R.string.pause else R.string.cup_resume), maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
    if (horizontal) {
        Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            ringBlock()
            Box(Modifier.width(260.dp)) { controls() }
        }
    } else {
        Column(modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(24.dp)) {
            ringBlock()
            controls()
        }
    }
}

@Composable
private fun Preset(minutes: Int, sub: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Column(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) colors.primary else colors.secondaryContainer)
            .then(if (selected) Modifier.border(2.dp, colors.primary.copy(alpha = 0.5f), RoundedCornerShape(12.dp)) else Modifier)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        val fg = if (selected) colors.onPrimary else colors.onSecondaryContainer
        Text(stringResource(R.string.cup_minutes, minutes), style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = fg)
        Text(sub, fontSize = 10.sp, color = fg.copy(alpha = 0.7f))
    }
}
