package com.mountainfold.app.data

import android.content.Context
import androidx.room.withTransaction
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.BrewStep
import com.mountainfold.app.data.db.AppDatabase
import com.mountainfold.app.data.db.Brew
import com.mountainfold.app.data.db.Coffee
import com.mountainfold.app.data.db.CuppingCoffee
import com.mountainfold.app.data.db.CuppingSession
import com.mountainfold.app.data.db.LabRecipe
import com.mountainfold.app.data.db.Grinder
import com.mountainfold.app.data.db.Recipe
import com.mountainfold.app.data.db.TrainingEvent
import com.mountainfold.app.data.prefs.Settings
import com.mountainfold.app.data.prefs.SettingsStore
import com.mountainfold.app.data.seed.SeedData
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

object StepsCodec {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; coerceInputValues = true }
    private val serializer = ListSerializer(BrewStep.serializer())
    fun encode(steps: List<BrewStep>): String = json.encodeToString(serializer, steps)
    fun decode(raw: String?): List<BrewStep> =
        if (raw.isNullOrBlank()) emptyList() else runCatching { json.decodeFromString(serializer, raw) }.getOrDefault(emptyList())
}

/** Portable snapshot of everything the user owns. Photos stay on the device; only their paths travel. */
@Serializable
data class Backup(
    val app: String = APP_ID,
    val version: Int = 1,
    val exportedAt: Long = 0,
    val settings: Settings = Settings(),
    val coffees: List<Coffee> = emptyList(),
    val recipes: List<Recipe> = emptyList(),
    val brews: List<Brew> = emptyList(),
    val grinders: List<Grinder> = emptyList(),
    val training: List<TrainingEvent> = emptyList(),
    val cuppingSessions: List<CuppingSession> = emptyList(),
    val cuppingCoffees: List<CuppingCoffee> = emptyList(),
    val labRecipes: List<LabRecipe> = emptyList(),
) {
    companion object { const val APP_ID = "MountainFold" }
}

/**
 * Single entry point to local data. A future cloud sync would sit behind this class
 * and nothing in the UI would need to change.
 */
class Repository(private val db: AppDatabase, private val settingsStore: SettingsStore) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = true; coerceInputValues = true }

    val coffees: Flow<List<Coffee>> = db.coffees().observeAll()
    val recipes: Flow<List<Recipe>> = db.recipes().observeAll()
    val brews: Flow<List<Brew>> = db.brews().observeAll()
    val grinders: Flow<List<Grinder>> = db.grinders().observeAll()
    val training: Flow<List<TrainingEvent>> = db.training().observeAll()

    suspend fun saveTrainingEvents(events: List<TrainingEvent>) = db.training().insertAll(events)

    // ---- Toulouse Cupping ----
    val cuppingSessions: Flow<List<CuppingSession>> = db.cupping().observeSessions()
    val cuppingCoffees: Flow<List<CuppingCoffee>> = db.cupping().observeCoffees()
    val labRecipes: Flow<List<LabRecipe>> = db.cupping().observeLab()

    suspend fun cuppingSession(id: String): CuppingSession? = db.cupping().session(id)
    suspend fun latestCuppingSession(): CuppingSession? = db.cupping().latestSession()
    suspend fun cuppingCoffeesOf(sessionId: String): List<CuppingCoffee> = db.cupping().coffeesOf(sessionId)
    suspend fun saveCuppingSession(session: CuppingSession, coffees: List<CuppingCoffee>) = db.cupping().saveSession(session, coffees)
    suspend fun deleteCuppingSession(id: String) = db.cupping().deleteSession(id)
    suspend fun saveLabRecipe(r: LabRecipe) = db.cupping().insertLab(r)
    suspend fun deleteLabRecipe(id: String) = db.cupping().deleteLab(id)

    suspend fun saveCoffee(c: Coffee): Long =
        db.coffees().upsert(if (c.createdAt == 0L) c.copy(createdAt = System.currentTimeMillis()) else c)

    suspend fun deleteCoffee(c: Coffee) = db.withTransaction {
        db.recipes().unlinkCoffee(c.id)
        db.coffees().delete(c)
    }

    suspend fun saveRecipe(r: Recipe): Long {
        val now = System.currentTimeMillis()
        return db.recipes().upsert(r.copy(createdAt = if (r.createdAt == 0L) now else r.createdAt, updatedAt = now))
    }

    suspend fun recipe(id: Long): Recipe? = db.recipes().byId(id)
    suspend fun deleteRecipe(r: Recipe) = db.recipes().delete(r)

    suspend fun saveBrew(b: Brew): Long =
        db.brews().upsert(if (b.createdAt == 0L) b.copy(createdAt = System.currentTimeMillis()) else b)

    suspend fun deleteBrew(b: Brew) = db.brews().delete(b)

    suspend fun saveGrinder(g: Grinder): Long = db.grinders().upsert(g)
    suspend fun deleteGrinder(g: Grinder) = db.grinders().delete(g)

    /** Adds one starter recipe per method the first time the app runs. */
    suspend fun seedIfEmpty(ctx: Context, favorites: List<BrewMethod> = emptyList()) {
        if (db.recipes().count() > 0) return
        val now = System.currentTimeMillis()
        val items = BrewMethod.entries.filter { it != BrewMethod.CUSTOM }.mapIndexed { i, m ->
            SeedData.defaultRecipe(ctx, m, now = now - i).copy(favorite = m in favorites)
        }
        db.recipes().insertAll(items)
    }

    suspend fun exportJson(): String = json.encodeToString(
        Backup.serializer(),
        Backup(
            exportedAt = System.currentTimeMillis(),
            settings = settingsStore.settings.first(),
            coffees = db.coffees().all(),
            recipes = db.recipes().all(),
            brews = db.brews().all(),
            grinders = db.grinders().all(),
            training = db.training().all(),
            cuppingSessions = db.cupping().allSessions(),
            cuppingCoffees = db.cupping().allCoffees(),
            labRecipes = db.cupping().allLab(),
        ),
    )

    /** Replaces local data with the backup. Throws when the file is not a Mountain Fold backup. */
    suspend fun importJson(text: String) {
        val backup = json.decodeFromString(Backup.serializer(), text)
        require(backup.app == Backup.APP_ID) { "Not a Mountain Fold backup" }
        db.withTransaction {
            db.coffees().clear(); db.recipes().clear(); db.brews().clear(); db.grinders().clear(); db.training().clear()
            clearCupping()
            db.training().insertAll(backup.training)
            // Sessions first: coffees point at them.
            db.cupping().insertSessions(backup.cuppingSessions)
            val sessionIds = backup.cuppingSessions.mapTo(HashSet()) { it.id }
            db.cupping().insertCoffees(backup.cuppingCoffees.filter { it.sessionId in sessionIds })
            db.cupping().insertLabAll(backup.labRecipes)
            db.coffees().insertAll(backup.coffees)
            db.recipes().insertAll(backup.recipes)
            db.brews().insertAll(backup.brews)
            db.grinders().insertAll(backup.grinders)
        }
        settingsStore.replace(backup.settings.copy(onboarded = true))
    }

    /** Wipes everything. Onboarding runs again and seeds the starter recipes. */
    suspend fun resetAll() {
        db.withTransaction {
            db.coffees().clear(); db.recipes().clear(); db.brews().clear(); db.grinders().clear(); db.training().clear()
            clearCupping()
        }
        settingsStore.replace(Settings())
    }

    private suspend fun clearCupping() {
        db.cupping().clearCoffees(); db.cupping().clearSessions(); db.cupping().clearLab()
    }
}
