package com.mountainfold.app.ui

import com.mountainfold.app.core.train.EventKind
import com.mountainfold.app.core.train.Recommendation
import com.mountainfold.app.core.train.Skill

sealed interface TrainScreen {
    data object Home : TrainScreen
    data object Tree : TrainScreen
    data object School : TrainScreen
    data object History : TrainScreen
    data object Lab : TrainScreen
    data object ExamSetup : TrainScreen
    data class LessonView(val id: String) : TrainScreen
    data object Quiz : TrainScreen
    data object Result : TrainScreen
}

/** A question ready to show: text already in the user's language, options already shuffled. */
data class QuizItem(
    val id: String,
    val skill: Skill,
    val prompt: String,
    /** Scenario numbers shown above the prompt, as label and value. */
    val facts: List<Pair<String, String>> = emptyList(),
    val options: List<String>,
    val correct: Int,
    val why: String,
)

data class QuizRun(
    val kind: EventKind,
    val refId: String,
    val title: String,
    val items: List<QuizItem>,
    val answers: List<Int?> = List(items.size) { null },
    val index: Int = 0,
    /** Monotonic clock at start. */
    val startedAtMs: Long = 0,
    /** Exams are timed and give no feedback until the end. */
    val timeLimitS: Int? = null,
    val lessonId: String? = null,
) {
    val instantFeedback: Boolean get() = timeLimitS == null
    val current: QuizItem get() = items[index]
    val selected: Int? get() = answers[index]
    val isLast: Boolean get() = index == items.lastIndex
    val correctCount: Int get() = items.indices.count { answers[it] == items[it].correct }
}

data class QuizResult(
    val run: QuizRun,
    val correct: Int,
    val total: Int,
    val passed: Boolean,
    val xp: Int,
    val durationS: Int,
    val weak: List<Skill>,
    val recommendations: List<Recommendation>,
    val streakBonus: Boolean,
    val lessonValidated: Boolean,
)

/** Position inside a lesson on a compact screen: theory cards, then the simulation, then validation. */
data class LessonRun(val lessonId: String, val page: Int = 0)
