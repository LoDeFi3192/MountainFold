package com.mountainfold.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Troubleshoot
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.foundation.selection.selectable
import androidx.compose.ui.semantics.Role
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mountainfold.app.R
import com.mountainfold.app.core.engine.CoffeeEngine
import com.mountainfold.app.core.engine.CoffeeEngine.Solve
import com.mountainfold.app.core.engine.CopilotEngine
import com.mountainfold.app.core.engine.CopilotEngine.Cause
import com.mountainfold.app.core.engine.CopilotEngine.ChangeKind
import com.mountainfold.app.core.engine.CopilotEngine.Variable
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.train.TrainProgress
import com.mountainfold.app.data.db.Brew
import com.mountainfold.app.data.db.Coffee
import com.mountainfold.app.data.db.Grinder
import com.mountainfold.app.data.db.Recipe
import com.mountainfold.app.data.prefs.Settings
import com.mountainfold.app.data.seed.SeedData
import com.mountainfold.app.ui.CalcState
import com.mountainfold.app.ui.CopilotText
import com.mountainfold.app.ui.LocalUnits
import com.mountainfold.app.ui.MainViewModel
import com.mountainfold.app.ui.Tab
import com.mountainfold.app.ui.Units
import com.mountainfold.app.ui.components.BigButton
import com.mountainfold.app.ui.components.DropdownField
import com.mountainfold.app.ui.components.EmptyState
import com.mountainfold.app.ui.components.ListRow
import com.mountainfold.app.ui.components.NumField
import com.mountainfold.app.ui.components.ScreenHeader
import com.mountainfold.app.ui.components.SectionTitle
import com.mountainfold.app.ui.components.Stat
import com.mountainfold.app.ui.components.TextFieldLine
import com.mountainfold.app.ui.components.ThinDivider
import com.mountainfold.app.ui.components.TimerText
import com.mountainfold.app.ui.components.TwoPane
import com.mountainfold.app.ui.components.methodLabel

/** Header plus one or two panes. Tools use the fold as a natural divider: input left, answer right. */
@Composable
private fun ToolScaffold(
    title: String,
    vm: MainViewModel,
    wide: Boolean,
    hinge: HingeInfo?,
    left: @Composable () -> Unit,
    right: @Composable () -> Unit,
) {
    Column(Modifier.fillMaxSize().imePadding()) {
        ScreenHeader(title, onBack = vm::back)
        if (wide) {
            TwoPane(
                hinge = hinge,
                left = { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp).padding(bottom = 24.dp)) { left() } },
                right = {
                    Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxSize()) {
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 16.dp)) { right() }
                    }
                },
            )
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
                left()
                Spacer(Modifier.height(20.dp))
                right()
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Coffee calculator
// ---------------------------------------------------------------------------------------------

private fun recalc(c: CalcState): CalcState {
    val r = CoffeeEngine.solve(c.solve, CoffeeEngine.parseNumber(c.dose), CoffeeEngine.parseNumber(c.water), CoffeeEngine.parseNumber(c.ratio)) ?: return c
    return when (c.solve) {
        Solve.WATER -> c.copy(water = CoffeeEngine.formatNumber(r.waterG))
        Solve.COFFEE -> c.copy(dose = CoffeeEngine.formatNumber(r.doseG))
        Solve.RATIO -> c.copy(ratio = CoffeeEngine.formatNumber(r.ratio, 2))
    }
}

@Composable
fun CalculatorScreen(vm: MainViewModel, settings: Settings, wide: Boolean, hinge: HingeInfo?) {
    val units = LocalUnits.current
    val c = vm.calc
    fun update(n: CalcState) { vm.calc = recalc(n) }
    val waterLabel = stringResource(if (c.espresso) R.string.yield_label else R.string.water)
    ToolScaffold(
        stringResource(R.string.calculator), vm, wide, hinge,
        left = {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(!c.espresso, { update(CalcState(dose = units.wValue(15.0), water = units.wValue(250.0), ratio = "16.7")) }, SegmentedButtonDefaults.itemShape(0, 2)) {
                    Text(stringResource(R.string.filter))
                }
                SegmentedButton(c.espresso, { update(CalcState(espresso = true, dose = units.wValue(18.0), water = units.wValue(36.0), ratio = "2")) }, SegmentedButtonDefaults.itemShape(1, 2)) {
                    Text(BrewMethod.ESPRESSO.label)
                }
            }
            SectionTitle(stringResource(R.string.solve_for))
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                listOf(Solve.WATER to waterLabel, Solve.COFFEE to stringResource(R.string.coffee), Solve.RATIO to stringResource(R.string.ratio)).forEachIndexed { i, (s, label) ->
                    SegmentedButton(c.solve == s, { update(c.copy(solve = s)) }, SegmentedButtonDefaults.itemShape(i, 3)) { Text(label, maxLines = 1) }
                }
            }
            Spacer(Modifier.height(16.dp))
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (c.solve != Solve.COFFEE) NumField(c.dose, { update(c.copy(dose = it)) }, stringResource(R.string.coffee), Modifier.fillMaxWidth(), suffix = units.wLabel)
                if (c.solve != Solve.WATER) NumField(c.water, { update(c.copy(water = it)) }, waterLabel, Modifier.fillMaxWidth(), suffix = units.wLabel)
                if (c.solve != Solve.RATIO) {
                    NumField(c.ratio, { update(c.copy(ratio = it)) }, stringResource(R.string.ratio_one_to), Modifier.fillMaxWidth())
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        (if (c.espresso) listOf("1.5", "2", "2.5", "3") else listOf("15", "16", "16.7", "17")).forEach { r ->
                            FilterChip(selected = c.ratio == r, onClick = { update(c.copy(ratio = r)) }, label = { Text("1:$r") })
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    NumField(c.time, { vm.calc = c.copy(time = it) }, stringResource(if (c.espresso) R.string.time_seconds else R.string.time_clock), Modifier.weight(1f))
                    NumField(c.temp, { vm.calc = c.copy(temp = it) }, stringResource(R.string.temperature), Modifier.weight(1f), suffix = units.tLabel)
                }
            }
        },
        right = {
            val dose = units.parseW(c.dose)
            val water = units.parseW(c.water)
            val ratio = if (dose != null && water != null) CoffeeEngine.ratio(water, dose) else null
            Text(
                stringResource(
                    when (c.solve) {
                        Solve.WATER -> if (c.espresso) R.string.yield_label else R.string.water
                        Solve.COFFEE -> R.string.coffee
                        Solve.RATIO -> R.string.ratio
                    }
                ).uppercase(),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
            )
            TimerText(
                when (c.solve) {
                    Solve.WATER -> water?.let(units::w) ?: "–"
                    Solve.COFFEE -> dose?.let(units::w) ?: "–"
                    Solve.RATIO -> CoffeeEngine.formatRatio(ratio)
                },
                if (wide) 88.sp else 64.sp,
            )
            Spacer(Modifier.height(16.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Stat(stringResource(R.string.coffee), dose?.let(units::w) ?: "–")
                Stat(waterLabel, water?.let(units::w) ?: "–")
                Stat(stringResource(R.string.ratio), CoffeeEngine.formatRatio(ratio))
                if (dose != null && water != null && !c.espresso) {
                    Stat(stringResource(R.string.in_the_cup), "≈ " + units.w(CoffeeEngine.beverageEstimate(water, dose, BrewMethod.V60)))
                }
                val seconds = CoffeeEngine.parseClock(c.time)
                if (c.espresso && water != null && seconds != null && seconds > 0) {
                    Stat(stringResource(R.string.flow), "${CoffeeEngine.formatNumber(water / seconds)} g/s")
                }
            }
            Spacer(Modifier.height(24.dp))
            val method = if (c.espresso) BrewMethod.ESPRESSO else settings.defaultMethod.takeIf { !it.isEspresso } ?: BrewMethod.V60
            BigButton(
                stringResource(R.string.brew_with, methodLabel(method)),
                onClick = { vm.brewAdHoc(method, dose!!, water!!, units.parseT(c.temp)) },
                modifier = Modifier.fillMaxWidth(),
                icon = Icons.Rounded.PlayArrow,
                primary = true,
                enabled = dose != null && water != null && dose > 0 && water > 0,
            )
        },
    )
}

// ---------------------------------------------------------------------------------------------
// Extraction diagnosis
// ---------------------------------------------------------------------------------------------

@Composable
fun causeLabel(c: Cause): String = stringResource(CopilotText.cause(c))

@Composable
fun variableLabel(v: Variable): String = stringResource(
    when (v) {
        Variable.GRIND -> R.string.grind
        Variable.TEMPERATURE -> R.string.temperature
        Variable.DOSE -> R.string.dose
        Variable.YIELD -> R.string.yield_label
        Variable.RATIO -> R.string.ratio
        Variable.TIME -> R.string.time
        Variable.BLOOM -> R.string.type_bloom
        Variable.AGITATION -> R.string.var_agitation
        Variable.FRESHNESS -> R.string.var_freshness
        Variable.PUCK_PREP -> R.string.var_puck
    }
)

@Composable
fun changeTitle(k: ChangeKind): String = stringResource(CopilotText.changeTitle(k))

@Composable
fun changeWhy(k: ChangeKind): String = stringResource(CopilotText.changeWhy(k))

private fun timeText(seconds: Int, method: BrewMethod) =
    if (method.isEspresso) "$seconds s" else CoffeeEngine.formatClock(seconds.toLong())

@Composable
fun DiagnoseScreen(vm: MainViewModel, settings: Settings, wide: Boolean, hinge: HingeInfo?) {
    val units = LocalUnits.current
    val d = vm.diag
    val r = d.recipe
    if (r == null) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader(stringResource(R.string.diagnose), onBack = vm::back)
            EmptyState(Icons.Rounded.Troubleshoot, stringResource(R.string.diag_empty_title), stringResource(R.string.diag_empty_body))
        }
        return
    }
    val result = vm.diagnosis()
    ToolScaffold(
        stringResource(R.string.diagnose), vm, wide, hinge,
        left = {
            Text(d.title, style = MaterialTheme.typography.headlineSmall)
            Text(
                listOf(r.coffeeName, methodLabel(r.method)).filter { it.isNotBlank() }.joinToString(" · "),
                style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(16.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Stat(stringResource(R.string.dose), units.w(r.doseG))
                Stat(stringResource(if (r.method.isEspresso) R.string.yield_label else R.string.water), units.w(r.waterG))
                Stat(stringResource(R.string.temperature), units.t(r.tempC))
                Stat(stringResource(R.string.time), timeText(d.timeS ?: r.targetTimeS, r.method))
                if (r.grind.isNotBlank()) Stat(stringResource(R.string.grind), r.grind)
            }
            SectionTitle(stringResource(R.string.how_did_it_taste))
            SymptomChips(d.symptoms) { s -> vm.diag = d.copy(symptoms = if (s in d.symptoms) d.symptoms - s else d.symptoms + s) }
        },
        right = {
            if (result == null) {
                Text(stringResource(R.string.diag_pick), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                return@ToolScaffold
            }
            Text(stringResource(R.string.probable_cause).uppercase(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            Text(causeLabel(result.cause), style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                stringResource(R.string.variables_involved) + "  " + result.variables.map { variableLabel(it) }.joinToString(" · "),
                style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(16.dp))
            Surface(color = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text(stringResource(R.string.change_one_thing).uppercase(), style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(changeTitle(result.change), style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(6.dp))
                    Text(changeWhy(result.change), style = MaterialTheme.typography.bodyLarge)
                }
            }
            SectionTitle(stringResource(R.string.suggested_recipe))
            val s = result.suggestion
            val grindChange = result.change == ChangeKind.GRIND_FINER || result.change == ChangeKind.GRIND_COARSER
            val grindAfter = when {
                !grindChange -> s.grind.ifBlank { "–" }
                result.grindStepped -> s.grind
                else -> stringResource(if (result.change == ChangeKind.GRIND_FINER) R.string.one_step_finer else R.string.one_step_coarser)
            }
            CompareTable(
                stringResource(R.string.current), stringResource(R.string.suggestion),
                listOf(
                    CmpRow(stringResource(R.string.dose), units.w(r.doseG), units.w(s.doseG)),
                    CmpRow(stringResource(if (r.method.isEspresso) R.string.yield_label else R.string.water), units.w(r.waterG), units.w(s.waterG)),
                    CmpRow(stringResource(R.string.ratio), CoffeeEngine.formatRatio(CoffeeEngine.ratio(r.waterG, r.doseG)), CoffeeEngine.formatRatio(CoffeeEngine.ratio(s.waterG, s.doseG))),
                    CmpRow(stringResource(R.string.temperature), units.t(r.tempC), units.t(s.tempC)),
                    CmpRow(stringResource(R.string.grind), r.grind.ifBlank { "–" }, grindAfter),
                    // Target against target. The measured time sits with the brew on the left.
                    CmpRow(
                        stringResource(R.string.target), timeText(r.targetTimeS, r.method),
                        (if (result.timeIsEstimate) "≈ " else "") + timeText(s.targetTimeS, r.method),
                    ),
                ),
            )
            Spacer(Modifier.height(8.dp))
            Text(
                stringResource(
                    when {
                        result.grindStepped -> R.string.grind_assumption
                        result.recipeChanged || grindChange -> R.string.rest_unchanged
                        else -> R.string.technique_only
                    }
                ),
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(20.dp))
            BigButton(
                stringResource(R.string.brew_suggestion),
                onClick = { vm.suggestedSession(result)?.let { vm.brew(it.copy(recipeId = null)) } },
                modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow, primary = true, minHeight = 56.dp,
            )
            if (result.recipeChanged) {
                Spacer(Modifier.height(10.dp))
                BigButton(stringResource(R.string.save_as_recipe), onClick = { vm.saveSuggestion(result) }, modifier = Modifier.fillMaxWidth(), minHeight = 56.dp)
            }
            Spacer(Modifier.height(16.dp))
            TrainSuggestion(vm, TrainProgress.lessonFor(result, r.method.isEspresso))
        },
    )
}

// ---------------------------------------------------------------------------------------------
// Comparison
// ---------------------------------------------------------------------------------------------

class CmpRow(val label: String, val a: String, val b: String, val differs: Boolean = a != b)

@Composable
fun CompareTable(titleA: String, titleB: String, rows: List<CmpRow>) {
    Column {
        Row(Modifier.padding(vertical = 8.dp)) {
            Spacer(Modifier.weight(0.9f))
            Text(titleA, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(titleB, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        rows.forEach { row ->
            ThinDivider()
            Row(Modifier.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(row.label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(0.9f))
                Text(row.a, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Text(
                    row.b,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (row.differs) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun recipeRows(a: Recipe?, b: Recipe?, coffees: List<Coffee>, units: Units): List<CmpRow> {
    fun v(r: Recipe?, f: (Recipe) -> String) = r?.let(f) ?: "–"
    fun coffee(r: Recipe) = coffees.firstOrNull { it.id == r.coffeeId }?.name ?: "–"
    return listOf(
        CmpRow(stringResource(R.string.method), v(a) { BrewMethod.fromKey(it.method).label }, v(b) { BrewMethod.fromKey(it.method).label }),
        CmpRow(stringResource(R.string.coffee), v(a, ::coffee), v(b, ::coffee)),
        CmpRow(stringResource(R.string.dose), v(a) { units.w(it.doseG) }, v(b) { units.w(it.doseG) }),
        CmpRow(stringResource(R.string.water), v(a) { units.w(it.waterG) }, v(b) { units.w(it.waterG) }),
        CmpRow(stringResource(R.string.ratio), v(a) { CoffeeEngine.formatRatio(CoffeeEngine.ratio(it.waterG, it.doseG)) }, v(b) { CoffeeEngine.formatRatio(CoffeeEngine.ratio(it.waterG, it.doseG)) }),
        CmpRow(stringResource(R.string.temperature), v(a) { units.t(it.tempC) }, v(b) { units.t(it.tempC) }),
        CmpRow(stringResource(R.string.grind), v(a) { it.grind.ifBlank { "–" } }, v(b) { it.grind.ifBlank { "–" } }),
        CmpRow(stringResource(R.string.time), v(a, ::recipeTimeText), v(b, ::recipeTimeText)),
    )
}

@Composable
private fun brewRows(a: Brew?, b: Brew?, units: Units): List<CmpRow> {
    fun v(x: Brew?, f: (Brew) -> String) = x?.let(f) ?: "–"
    fun level(n: Int) = if (n > 0) "$n / 5" else "–"
    val symA = a?.let { parseSymptoms(it.symptoms).map { s -> symptomLabel(s) }.joinToString(", ") }.orEmpty().ifBlank { "–" }
    val symB = b?.let { parseSymptoms(it.symptoms).map { s -> symptomLabel(s) }.joinToString(", ") }.orEmpty().ifBlank { "–" }
    return listOf(
        CmpRow(stringResource(R.string.coffee), v(a) { it.coffeeName.ifBlank { "–" } }, v(b) { it.coffeeName.ifBlank { "–" } }),
        CmpRow(stringResource(R.string.method), v(a) { BrewMethod.fromKey(it.method).label }, v(b) { BrewMethod.fromKey(it.method).label }),
        CmpRow(stringResource(R.string.dose), v(a) { units.w(it.doseG) }, v(b) { units.w(it.doseG) }),
        CmpRow(stringResource(R.string.water), v(a) { units.w(it.waterG) }, v(b) { units.w(it.waterG) }),
        CmpRow(stringResource(R.string.ratio), v(a) { CoffeeEngine.formatRatio(CoffeeEngine.ratio(it.waterG, it.doseG)) }, v(b) { CoffeeEngine.formatRatio(CoffeeEngine.ratio(it.waterG, it.doseG)) }),
        CmpRow(stringResource(R.string.temperature), v(a) { units.t(it.tempC) }, v(b) { units.t(it.tempC) }),
        CmpRow(stringResource(R.string.grind), v(a) { it.grind.ifBlank { "–" } }, v(b) { it.grind.ifBlank { "–" } }),
        CmpRow(stringResource(R.string.grinder), v(a) { it.grinderName.ifBlank { "–" } }, v(b) { it.grinderName.ifBlank { "–" } }),
        CmpRow(stringResource(R.string.time), v(a, ::brewTimeText), v(b, ::brewTimeText)),
        CmpRow(stringResource(R.string.rating), v(a) { level(it.rating) }, v(b) { level(it.rating) }),
        CmpRow(stringResource(R.string.acidity), v(a) { level(it.acidity) }, v(b) { level(it.acidity) }),
        CmpRow(stringResource(R.string.sweetness), v(a) { level(it.sweetness) }, v(b) { level(it.sweetness) }),
        CmpRow(stringResource(R.string.body), v(a) { level(it.body) }, v(b) { level(it.body) }),
        CmpRow(stringResource(R.string.balance), v(a) { level(it.balance) }, v(b) { level(it.balance) }),
        CmpRow(stringResource(R.string.clarity), v(a) { level(it.clarity) }, v(b) { level(it.clarity) }),
        CmpRow(stringResource(R.string.what_was_off), symA, symB),
    )
}

@Composable
private fun CompareSide(title: String, selector: @Composable () -> Unit, rows: List<CmpRow>, pick: (CmpRow) -> String) {
    Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(8.dp))
    selector()
    Spacer(Modifier.height(8.dp))
    rows.forEach { row ->
        ThinDivider()
        Row(Modifier.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(row.label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(0.8f))
            Text(
                pick(row),
                style = MaterialTheme.typography.titleMedium,
                color = if (row.differs) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
fun CompareScreen(vm: MainViewModel, settings: Settings, wide: Boolean, hinge: HingeInfo?) {
    val units = LocalUnits.current
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    val brews by vm.brews.collectAsStateWithLifecycle()
    val coffees by vm.coffees.collectAsStateWithLifecycle()
    val c = vm.compare
    val pickLabel = stringResource(R.string.pick_one)
    val rows = if (c.brews) brewRows(brews.firstOrNull { it.id == c.aId }, brews.firstOrNull { it.id == c.bId }, units)
    else recipeRows(recipes.firstOrNull { it.id == c.aId }, recipes.firstOrNull { it.id == c.bId }, coffees, units)

    @Composable
    fun brewName(b: Brew) = "${b.coffeeName.ifBlank { b.recipeName }} · ${formatDate(b.createdAt)}"

    @Composable
    fun selector(isA: Boolean) {
        val id = if (isA) c.aId else c.bId
        fun set(v: Long?) { vm.compare = if (isA) c.copy(aId = v) else c.copy(bId = v) }
        if (c.brews) {
            DropdownField(
                stringResource(R.string.brew_label), brews.firstOrNull { it.id == id }?.let { brewName(it) } ?: pickLabel, brews.take(40),
                optionLabel = { brewName(it) }, onSelect = { set(it.id) }, modifier = Modifier.fillMaxWidth(),
            )
        } else {
            DropdownField(
                stringResource(R.string.recipe), recipes.firstOrNull { it.id == id }?.name ?: pickLabel, recipes,
                optionLabel = { it.name }, onSelect = { set(it.id) }, modifier = Modifier.fillMaxWidth(),
            )
        }
    }

    val mode: @Composable () -> Unit = {
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            SegmentedButton(!c.brews, { vm.compare = c.copy(brews = false, aId = null, bId = null) }, SegmentedButtonDefaults.itemShape(0, 2)) { Text(stringResource(R.string.tab_recipes)) }
            SegmentedButton(c.brews, { vm.compare = c.copy(brews = true, aId = null, bId = null) }, SegmentedButtonDefaults.itemShape(1, 2)) { Text(stringResource(R.string.brews)) }
        }
        Spacer(Modifier.height(16.dp))
    }
    val labelA = stringResource(if (c.brews) R.string.brew_a else R.string.recipe_a)
    val labelB = stringResource(if (c.brews) R.string.brew_b else R.string.recipe_b)
    if (wide) {
        ToolScaffold(
            stringResource(R.string.compare), vm, true, hinge,
            left = { mode(); CompareSide(labelA, { selector(true) }, rows) { it.a } },
            right = { Spacer(Modifier.height(40.dp)); CompareSide(labelB, { selector(false) }, rows) { it.b } },
        )
    } else {
        ToolScaffold(
            stringResource(R.string.compare), vm, false, hinge,
            left = {
                mode()
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) { selector(true); selector(false) }
            },
            right = { CompareTable("A", "B", rows) },
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Grind advisor
// ---------------------------------------------------------------------------------------------

@Composable
fun GrindAdvisorScreen(vm: MainViewModel, settings: Settings, wide: Boolean, hinge: HingeInfo?) {
    val units = LocalUnits.current
    val grinders by vm.grinders.collectAsStateWithLifecycle()
    val brews by vm.brews.collectAsStateWithLifecycle()
    val coffees by vm.coffees.collectAsStateWithLifecycle()
    val f = vm.grindFilter
    var newName by rememberSaveable { mutableStateOf("") }
    val all = stringResource(R.string.all)
    val matching = brews.filter { b ->
        b.grind.isNotBlank() &&
            (f.grinderId == null || b.grinderId == f.grinderId) &&
            (f.coffeeId == null || b.coffeeId == f.coffeeId) &&
            (f.method == null || b.method == f.method.name)
    }
    ToolScaffold(
        stringResource(R.string.grind_advisor), vm, wide, hinge,
        left = {
            SectionTitle(stringResource(R.string.your_grinders))
            if (grinders.isEmpty()) {
                Text(stringResource(R.string.no_grinders), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            grinders.forEach { g ->
                Row(
                    Modifier.fillMaxWidth().selectable(selected = g.id == settings.defaultGrinderId, role = Role.RadioButton) {
                        vm.setSettings { it.copy(defaultGrinderId = g.id) }
                    },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(selected = g.id == settings.defaultGrinderId, onClick = null, modifier = Modifier.padding(12.dp))
                    Text(g.name, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    IconButton(onClick = { vm.deleteGrinder(g) }) {
                        Icon(Icons.Rounded.Close, contentDescription = stringResource(R.string.remove_grinder, g.name))
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextFieldLine(newName, { newName = it }, stringResource(R.string.grinder_name), Modifier.weight(1f))
                OutlinedButton(onClick = { vm.addGrinder(newName); newName = "" }, enabled = newName.isNotBlank()) { Text(stringResource(R.string.add)) }
            }
            Spacer(Modifier.height(8.dp))
            DropdownField(
                stringResource(R.string.common_grinders), stringResource(R.string.pick_one),
                SeedData.grinderPresets.filter { p -> grinders.none { it.name == p } },
                optionLabel = { it }, onSelect = { vm.addGrinder(it) }, modifier = Modifier.fillMaxWidth(),
            )
            SectionTitle(stringResource(R.string.filter_history))
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                DropdownField(
                    stringResource(R.string.grinder), grinders.firstOrNull { it.id == f.grinderId }?.name ?: all, listOf<Grinder?>(null) + grinders,
                    optionLabel = { it?.name ?: all }, onSelect = { vm.grindFilter = f.copy(grinderId = it?.id) }, modifier = Modifier.fillMaxWidth(),
                )
                DropdownField(
                    stringResource(R.string.coffee), coffees.firstOrNull { it.id == f.coffeeId }?.name ?: all, listOf<Coffee?>(null) + coffees,
                    optionLabel = { it?.name ?: all }, onSelect = { vm.grindFilter = f.copy(coffeeId = it?.id) }, modifier = Modifier.fillMaxWidth(),
                )
                DropdownField(
                    stringResource(R.string.method), f.method?.let { methodLabel(it) } ?: all, listOf<BrewMethod?>(null) + BrewMethod.entries,
                    optionLabel = { m -> m?.let { methodLabel(it) } ?: all }, onSelect = { vm.grindFilter = f.copy(method = it) }, modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        right = {
            if (matching.isEmpty()) {
                EmptyState(Icons.Rounded.Tune, stringResource(R.string.no_grind_title), stringResource(R.string.no_grind_body))
                return@ToolScaffold
            }
            val best = matching.filter { it.rating > 0 }.maxWithOrNull(compareBy<Brew> { it.rating }.thenBy { it.createdAt })
            val last = matching.first()
            FlowRow(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                best?.let { Stat(stringResource(R.string.best_grind), "${it.grind} · ★${it.rating}", valueStyle = MaterialTheme.typography.headlineSmall) }
                Stat(stringResource(R.string.last_setting), last.grind, valueStyle = MaterialTheme.typography.headlineSmall)
            }
            val advice = CopilotEngine.diagnose(
                CopilotEngine.BrewInput(
                    BrewMethod.fromKey(last.method), last.doseG, last.waterG, last.tempC,
                    (last.timeMs / 1000).toInt().takeIf { it > 0 }, last.targetTimeS.takeIf { it > 0 } ?: (last.timeMs / 1000).toInt(), last.grind,
                ),
                parseSymptoms(last.symptoms),
            )
            Spacer(Modifier.height(16.dp))
            Surface(color = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text(stringResource(R.string.next_brew).uppercase(), style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.height(4.dp))
                    val grindAdvice = advice?.takeIf { it.change == ChangeKind.GRIND_FINER || it.change == ChangeKind.GRIND_COARSER }
                    when {
                        grindAdvice != null -> {
                            Text(changeTitle(grindAdvice.change), style = MaterialTheme.typography.headlineSmall)
                            if (grindAdvice.grindStepped) {
                                Text("${last.grind} → ${grindAdvice.suggestion.grind}", style = MaterialTheme.typography.titleLarge)
                            }
                            Text(changeWhy(grindAdvice.change), style = MaterialTheme.typography.bodyLarge)
                        }
                        advice != null -> {
                            Text(stringResource(R.string.keep_grind), style = MaterialTheme.typography.headlineSmall)
                            Text(stringResource(R.string.keep_grind_other, changeTitle(advice.change)), style = MaterialTheme.typography.bodyLarge)
                        }
                        else -> {
                            Text(stringResource(R.string.keep_grind), style = MaterialTheme.typography.headlineSmall)
                            Text(stringResource(R.string.keep_grind_body), style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            }
            SectionTitle(stringResource(R.string.grind_history))
            matching.take(60).forEach { b ->
                ListRow(
                    title = b.grind + if (b.grinderName.isNotBlank()) "  ·  ${b.grinderName}" else "",
                    subtitle = "${b.coffeeName.ifBlank { b.recipeName }} · ${brewSummary(b, units)}\n${formatDate(b.createdAt)}",
                    trailing = if (b.rating > 0) ({ RatingBadge(b.rating) }) else null,
                    onClick = { vm.selectTab(Tab.HISTORY); vm.historySel = b.id },
                )
            }
        },
    )
}
