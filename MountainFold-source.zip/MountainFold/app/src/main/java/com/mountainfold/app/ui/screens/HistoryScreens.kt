package com.mountainfold.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.CompareArrows
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Troubleshoot
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mountainfold.app.R
import com.mountainfold.app.core.engine.CoffeeEngine
import com.mountainfold.app.core.engine.CopilotEngine
import com.mountainfold.app.core.train.TrainProgress
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.Symptom
import com.mountainfold.app.data.db.Brew
import com.mountainfold.app.data.db.Grinder
import com.mountainfold.app.data.prefs.Settings
import com.mountainfold.app.ui.CopilotText
import com.mountainfold.app.ui.LocalUnits
import com.mountainfold.app.ui.LogDraft
import com.mountainfold.app.ui.MainViewModel
import com.mountainfold.app.ui.Overlay
import com.mountainfold.app.ui.Tab
import com.mountainfold.app.ui.components.BigButton
import com.mountainfold.app.ui.components.ConfirmDialog
import com.mountainfold.app.ui.components.DropdownField
import com.mountainfold.app.ui.components.EmptyState
import com.mountainfold.app.ui.components.LevelRow
import com.mountainfold.app.ui.components.ListRow
import com.mountainfold.app.ui.components.NumField
import com.mountainfold.app.ui.components.ScreenHeader
import com.mountainfold.app.ui.components.SectionTitle
import com.mountainfold.app.ui.components.StarRating
import com.mountainfold.app.ui.components.Stat
import com.mountainfold.app.ui.components.TextFieldLine
import com.mountainfold.app.ui.components.TimerText
import com.mountainfold.app.ui.components.TwoPane
import com.mountainfold.app.ui.components.methodLabel

@Composable
fun symptomLabel(s: Symptom): String = stringResource(CopilotText.symptom(s))

@Composable
fun SymptomChips(selected: Set<Symptom>, onToggle: (Symptom) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Symptom.entries.forEach { s ->
            FilterChip(selected = s in selected, onClick = { onToggle(s) }, label = { Text(symptomLabel(s)) })
        }
    }
}

fun parseSymptoms(raw: String): Set<Symptom> =
    raw.split(',').mapNotNull { n -> Symptom.entries.firstOrNull { it.name == n } }.toSet()

@Composable
fun HistoryScreen(vm: MainViewModel, settings: Settings, wide: Boolean, hinge: HingeInfo?) {
    val brews by vm.brews.collectAsStateWithLifecycle()
    val selected = brews.firstOrNull { it.id == vm.historySel }
    if (wide) {
        TwoPane(
            hinge = hinge,
            left = { HistoryList(vm, brews, selected?.id) },
            right = {
                Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxSize()) {
                    if (selected != null) BrewDetail(vm, selected, false)
                    else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(stringResource(R.string.select_brew), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            },
        )
    } else if (selected != null) {
        BrewDetail(vm, selected, true)
    } else {
        HistoryList(vm, brews, null)
    }
}

@Composable
private fun HistoryList(vm: MainViewModel, brews: List<Brew>, selectedId: Long?) {
    val units = LocalUnits.current
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.tab_history))
        if (brews.isEmpty()) {
            EmptyState(
                Icons.Rounded.History,
                stringResource(R.string.no_history_title),
                stringResource(R.string.no_brews_yet),
                actionLabel = stringResource(R.string.start_brewing),
                onAction = { vm.selectTab(Tab.BREW) },
            )
        } else {
            LazyColumn(contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)) {
                items(brews, key = { it.id }) { b ->
                    ListRow(
                        title = b.coffeeName.ifBlank { b.recipeName },
                        subtitle = "${brewSummary(b, units)}\n${formatDate(b.createdAt)}",
                        selected = b.id == selectedId,
                        trailing = if (b.rating > 0) ({ RatingBadge(b.rating) }) else null,
                        onClick = { vm.historySel = b.id },
                    )
                }
            }
        }
    }
}

@Composable
private fun BrewDetail(vm: MainViewModel, b: Brew, showBack: Boolean) {
    val units = LocalUnits.current
    val method = BrewMethod.fromKey(b.method)
    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(b.coffeeName.ifBlank { b.recipeName }, onBack = if (showBack) vm::back else null) {
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Rounded.Delete, contentDescription = stringResource(R.string.delete)) }
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Text(
                listOf(methodLabel(method), b.recipeName, formatDate(b.createdAt)).filter { it.isNotBlank() }.joinToString(" · "),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            StarRating(b.rating, size = 28.dp)
            Spacer(Modifier.height(16.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Stat(stringResource(R.string.dose), units.w(b.doseG))
                Stat(stringResource(if (method.isEspresso) R.string.yield_label else R.string.water), units.w(b.waterG))
                Stat(stringResource(R.string.ratio), CoffeeEngine.formatRatio(CoffeeEngine.ratio(b.waterG, b.doseG)))
                Stat(stringResource(R.string.time), brewTimeText(b))
                Stat(stringResource(R.string.temperature), units.t(b.tempC))
                if (b.grind.isNotBlank()) Stat(stringResource(R.string.grind), b.grind)
                if (b.grinderName.isNotBlank()) Stat(stringResource(R.string.grinder), b.grinderName)
                b.pressureBar?.let { Stat(stringResource(R.string.pressure), "${CoffeeEngine.formatNumber(it)} bar") }
            }
            if (listOf(b.acidity, b.sweetness, b.body, b.balance, b.clarity).any { it > 0 }) {
                SectionTitle(stringResource(R.string.taste))
                LevelRow(stringResource(R.string.acidity), b.acidity)
                LevelRow(stringResource(R.string.sweetness), b.sweetness)
                LevelRow(stringResource(R.string.body), b.body)
                LevelRow(stringResource(R.string.balance), b.balance)
                LevelRow(stringResource(R.string.clarity), b.clarity)
            }
            val symptoms = parseSymptoms(b.symptoms)
            if (symptoms.isNotEmpty()) {
                SectionTitle(stringResource(R.string.what_was_off))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    symptoms.forEach { SuggestionChip(onClick = {}, enabled = false, label = { Text(symptomLabel(it)) }) }
                }
            }
            if (b.notes.isNotBlank()) {
                SectionTitle(stringResource(R.string.notes))
                Text(b.notes, style = MaterialTheme.typography.bodyLarge)
            }
            CopilotEngine.primarySymptom(symptoms)?.let { main ->
                Spacer(Modifier.height(16.dp))
                TrainSuggestion(vm, TrainProgress.lessonFor(main, method.isEspresso))
            }
            Spacer(Modifier.height(24.dp))
            BigButton(stringResource(R.string.diagnose), onClick = { vm.diagnoseBrew(b) }, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.Troubleshoot, primary = true, minHeight = 56.dp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton(stringResource(R.string.brew_again), onClick = { vm.brewAgain(b) }, modifier = Modifier.weight(1f), icon = Icons.Rounded.PlayArrow, minHeight = 56.dp)
                BigButton(
                    stringResource(R.string.compare),
                    onClick = { vm.compare = vm.compare.copy(brews = true, aId = b.id); vm.open(Overlay.Compare) },
                    modifier = Modifier.weight(1f), icon = Icons.AutoMirrored.Rounded.CompareArrows, minHeight = 56.dp,
                )
            }
        }
    }
    if (confirmDelete) {
        ConfirmDialog(
            stringResource(R.string.delete_brew_title),
            stringResource(R.string.delete_brew_body),
            stringResource(R.string.delete),
            onConfirm = { confirmDelete = false; vm.deleteBrew(b) },
            onDismiss = { confirmDelete = false },
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Log a brew
// ---------------------------------------------------------------------------------------------

@Composable
fun LogBrewScreen(vm: MainViewModel, settings: Settings, wide: Boolean, hinge: HingeInfo?) {
    val d = vm.logDraft ?: return
    val recipe = vm.session.state.collectAsStateWithLifecycle().value.recipe ?: return
    val grinders by vm.grinders.collectAsStateWithLifecycle()
    fun update(n: LogDraft) { vm.logDraft = n }
    val numbers: @Composable () -> Unit = { LogNumbers(d, ::update, recipe.method, grinders) }
    val taste: @Composable () -> Unit = { LogTaste(d, ::update) }
    Column(Modifier.fillMaxSize().imePadding()) {
        ScreenHeader(stringResource(R.string.log_this_brew), onBack = vm::back) {
            Button(onClick = vm::saveLog, modifier = Modifier.padding(end = 12.dp)) { Text(stringResource(R.string.save)) }
        }
        if (wide) {
            TwoPane(
                hinge = hinge,
                left = { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp).padding(bottom = 24.dp)) { numbers() } },
                right = {
                    Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxSize()) {
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 8.dp)) { taste() }
                    }
                },
            )
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
                numbers()
                taste()
            }
        }
    }
}

@Composable
private fun LogNumbers(d: LogDraft, update: (LogDraft) -> Unit, method: BrewMethod, grinders: List<Grinder>) {
    val units = LocalUnits.current
    val none = stringResource(R.string.none)
    Row(verticalAlignment = Alignment.Bottom) {
        TimerText(if (method.isEspresso) CoffeeEngine.formatTenths(d.timeMs) else CoffeeEngine.formatClock(d.timeMs / 1000), 64.sp)
        if (method.isEspresso) Text(" s", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 6.dp))
    }
    Spacer(Modifier.height(12.dp))
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            NumField(d.dose, { update(d.copy(dose = it)) }, stringResource(R.string.dose), Modifier.weight(1f), suffix = units.wLabel)
            NumField(d.water, { update(d.copy(water = it)) }, stringResource(if (method.isEspresso) R.string.yield_label else R.string.water), Modifier.weight(1f), suffix = units.wLabel)
        }
        val dose = units.parseW(d.dose)
        val water = units.parseW(d.water)
        Text(
            stringResource(R.string.ratio) + "  " + CoffeeEngine.formatRatio(if (dose != null && water != null) CoffeeEngine.ratio(water, dose) else null),
            style = MaterialTheme.typography.titleMedium,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            NumField(d.temp, { update(d.copy(temp = it)) }, stringResource(R.string.temperature), Modifier.weight(1f), suffix = units.tLabel)
            TextFieldLine(d.grind, { update(d.copy(grind = it)) }, stringResource(R.string.grind_setting), Modifier.weight(1f))
        }
        if (grinders.isNotEmpty()) {
            DropdownField(
                stringResource(R.string.grinder), grinders.firstOrNull { it.id == d.grinderId }?.name ?: none,
                listOf<Grinder?>(null) + grinders,
                optionLabel = { it?.name ?: none },
                onSelect = { update(d.copy(grinderId = it?.id)) },
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun LogTaste(d: LogDraft, update: (LogDraft) -> Unit) {
    SectionTitle(stringResource(R.string.rating))
    StarRating(d.rating, onChange = { update(d.copy(rating = it)) })
    SectionTitle(stringResource(R.string.taste))
    LevelRow(stringResource(R.string.acidity), d.acidity) { update(d.copy(acidity = it)) }
    LevelRow(stringResource(R.string.sweetness), d.sweetness) { update(d.copy(sweetness = it)) }
    LevelRow(stringResource(R.string.body), d.body) { update(d.copy(body = it)) }
    LevelRow(stringResource(R.string.balance), d.balance) { update(d.copy(balance = it)) }
    LevelRow(stringResource(R.string.clarity), d.clarity) { update(d.copy(clarity = it)) }
    SectionTitle(stringResource(R.string.anything_off))
    SymptomChips(d.symptoms) { s -> update(d.copy(symptoms = if (s in d.symptoms) d.symptoms - s else d.symptoms + s)) }
    Spacer(Modifier.height(12.dp))
    TextFieldLine(d.notes, { update(d.copy(notes = it)) }, stringResource(R.string.notes), Modifier.fillMaxWidth(), singleLine = false, minLines = 3)
}
