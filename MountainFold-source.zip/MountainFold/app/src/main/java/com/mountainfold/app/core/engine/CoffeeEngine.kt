package com.mountainfold.app.core.engine

import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.BrewStep
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/** Pure brewing maths. No Android types, so every function is unit-testable. */
object CoffeeEngine {

    enum class Solve { WATER, COFFEE, RATIO }

    data class Triple3(val doseG: Double, val waterG: Double, val ratio: Double)

    /** Ratio = water / coffee. Returns null when the dose is not usable. */
    fun ratio(waterG: Double, doseG: Double): Double? =
        if (doseG > 0.0 && waterG >= 0.0) waterG / doseG else null

    fun waterFor(doseG: Double, ratio: Double): Double = doseG * ratio

    fun doseFor(waterG: Double, ratio: Double): Double? = if (ratio > 0.0) waterG / ratio else null

    /** Solves the missing value from the two others. Returns null if inputs cannot produce a result. */
    fun solve(target: Solve, doseG: Double?, waterG: Double?, ratio: Double?): Triple3? = when (target) {
        Solve.WATER -> if (doseG != null && ratio != null && doseG > 0 && ratio > 0)
            Triple3(doseG, waterFor(doseG, ratio), ratio) else null
        Solve.COFFEE -> if (waterG != null && ratio != null && waterG > 0 && ratio > 0)
            Triple3(doseFor(waterG, ratio)!!, waterG, ratio) else null
        Solve.RATIO -> if (doseG != null && waterG != null && doseG > 0 && waterG > 0)
            Triple3(doseG, waterG, waterG / doseG) else null
    }

    /**
     * Rough beverage weight. Filter coffee grounds keep about twice their weight in water.
     * Espresso yield is measured in the cup, so it is returned unchanged.
     */
    fun beverageEstimate(waterG: Double, doseG: Double, method: BrewMethod): Double =
        if (method.isEspresso) waterG else (waterG - 2.0 * doseG).coerceAtLeast(0.0)

    /** Average flow in g/s. Mostly useful for espresso. */
    fun flowRate(yieldG: Double, timeS: Double): Double? = if (timeS > 0.0) yieldG / timeS else null

    /** Rescales cumulative water targets when the total water changes. */
    fun scaleSteps(steps: List<BrewStep>, oldWaterG: Double, newWaterG: Double): List<BrewStep> {
        if (oldWaterG <= 0.0 || abs(oldWaterG - newWaterG) < 0.05) return steps
        val f = newWaterG / oldWaterG
        return steps.map { s -> s.copy(targetWaterG = s.targetWaterG?.let { round1(it * f) }) }
    }

    fun gToOz(g: Double): Double = g / 28.349523125
    fun ozToG(oz: Double): Double = oz * 28.349523125
    fun cToF(c: Double): Double = c * 9.0 / 5.0 + 32.0
    fun fToC(f: Double): Double = (f - 32.0) * 5.0 / 9.0

    fun round1(v: Double): Double = (v * 10.0).roundToLong() / 10.0
    fun round2(v: Double): Double = (v * 100.0).roundToLong() / 100.0

    /** "1:16.7", "1:2". Trailing ".0" is dropped. */
    fun formatRatio(r: Double?): String {
        if (r == null || r.isNaN() || r.isInfinite()) return "–"
        val v = round1(r)
        return if (v == v.roundToInt().toDouble()) "1:${v.roundToInt()}" else "1:$v"
    }

    /** 1 decimal, without a useless ".0". */
    fun formatNumber(v: Double, decimals: Int = 1): String {
        val r = if (decimals >= 2) round2(v) else round1(v)
        return if (r == r.roundToLong().toDouble()) r.roundToLong().toString() else r.toString()
    }

    /** m:ss, or h:mm:ss for long steeps such as cold brew. */
    fun formatClock(totalSeconds: Long): String {
        val s = totalSeconds.coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
    }

    /** Seconds with tenths: "28.4". Used for espresso shots. */
    fun formatTenths(ms: Long): String {
        val t = (ms.coerceAtLeast(0) / 100)
        return "${t / 10}.${t % 10}"
    }

    fun parseNumber(text: String): Double? = text.trim().replace(',', '.').toDoubleOrNull()

    /** Accepts "3:05", "185", "1:02:00". Returns seconds. */
    fun parseClock(text: String): Int? {
        val t = text.trim()
        if (t.isEmpty()) return null
        val parts = t.split(":")
        if (parts.any { it.toIntOrNull() == null || it.toInt() < 0 }) return null
        return when (parts.size) {
            1 -> parts[0].toInt()
            2 -> parts[0].toInt() * 60 + parts[1].toInt()
            3 -> parts[0].toInt() * 3600 + parts[1].toInt() * 60 + parts[2].toInt()
            else -> null
        }
    }
}
