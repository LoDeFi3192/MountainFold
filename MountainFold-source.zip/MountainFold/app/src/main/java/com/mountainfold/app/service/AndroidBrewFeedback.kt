package com.mountainfold.app.service

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.mountainfold.app.core.model.BrewStep
import com.mountainfold.app.core.model.SessionRecipe
import com.mountainfold.app.data.prefs.Settings
import com.mountainfold.app.data.session.BrewFeedback

/** Haptics, optional sounds and the background notification. Used sparingly on purpose. */
class AndroidBrewFeedback(
    private val context: Context,
    private val settings: () -> Settings,
) : BrewFeedback {

    private val vibrator: Vibrator? by lazy {
        runCatching {
            if (Build.VERSION.SDK_INT >= 31) context.getSystemService(VibratorManager::class.java)?.defaultVibrator
            else @Suppress("DEPRECATION") (context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)
        }.getOrNull()
    }

    private var tone: ToneGenerator? = null

    override fun onRunningChanged(running: Boolean, recipe: SessionRecipe?) {
        if (running) BrewTimerService.start(context) else BrewTimerService.stop(context)
    }

    override fun onStep(step: BrewStep, index: Int, recipe: SessionRecipe) {
        vibrate(Pattern.STEP)
        beep(ToneGenerator.TONE_PROP_BEEP, 120)
        BrewTimerService.refresh(context)
    }

    override fun onTarget(recipe: SessionRecipe) {
        vibrate(Pattern.DONE)
        beep(ToneGenerator.TONE_PROP_BEEP2, 300)
    }

    override fun onAction() = vibrate(Pattern.TICK)

    private enum class Pattern { TICK, STEP, DONE }

    private fun vibrate(pattern: Pattern) {
        if (!settings().haptics) return
        val v = vibrator ?: return
        runCatching {
            if (!v.hasVibrator()) return
            val effect = when {
                Build.VERSION.SDK_INT >= 29 -> VibrationEffect.createPredefined(
                    when (pattern) {
                        Pattern.TICK -> VibrationEffect.EFFECT_TICK
                        Pattern.STEP -> VibrationEffect.EFFECT_HEAVY_CLICK
                        Pattern.DONE -> VibrationEffect.EFFECT_DOUBLE_CLICK
                    }
                )
                else -> when (pattern) {
                    Pattern.TICK -> VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE)
                    Pattern.STEP -> VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE)
                    Pattern.DONE -> VibrationEffect.createWaveform(longArrayOf(0, 60, 90, 60), -1)
                }
            }
            v.vibrate(effect)
        }
    }

    private fun beep(toneType: Int, durationMs: Int) {
        if (!settings().sounds) return
        runCatching {
            val t = tone ?: ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70).also { tone = it }
            t.startTone(toneType, durationMs)
        }
    }
}
