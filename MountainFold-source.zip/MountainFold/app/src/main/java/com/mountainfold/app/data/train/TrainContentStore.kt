package com.mountainfold.app.data.train

import android.content.Context
import com.mountainfold.app.core.train.TrainContent
import kotlinx.serialization.json.Json

/** Lessons and questions ship as one JSON asset. Parsed once, on first use. */
class TrainContentStore(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; coerceInputValues = true }

    val content: TrainContent by lazy {
        runCatching {
            context.assets.open("train/content.json").use { json.decodeFromString(TrainContent.serializer(), it.readBytes().decodeToString()) }
        }.getOrDefault(TrainContent())
    }
}
