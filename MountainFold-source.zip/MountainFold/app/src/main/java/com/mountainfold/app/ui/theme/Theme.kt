package com.mountainfold.app.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.mountainfold.app.R
import com.mountainfold.app.core.model.ThemeMode
import com.mountainfold.app.data.prefs.Settings
import com.mountainfold.app.ui.LocalUnits
import com.mountainfold.app.ui.Units

/** Titles: Bricolage Grotesque Bold. Two optical sizes, one for display, one for small titles. */
val DisplayFont = FontFamily(Font(R.font.bricolage_display_bold, FontWeight.Bold))
val TitleFont = FontFamily(Font(R.font.bricolage_title_bold, FontWeight.Bold))

/** Body: Open Sans family. */
val BodyFont = FontFamily(
    Font(R.font.open_sans_regular, FontWeight.Normal),
    Font(R.font.open_sans_medium, FontWeight.Medium),
    Font(R.font.open_sans_semibold, FontWeight.SemiBold),
    Font(R.font.open_sans_bold, FontWeight.Bold),
)

private fun display(size: Int, line: Int, tracking: Double) = TextStyle(
    fontFamily = DisplayFont, fontWeight = FontWeight.Bold, fontSize = size.sp, lineHeight = line.sp, letterSpacing = tracking.em,
)

private fun title(size: Int, line: Int) = TextStyle(
    fontFamily = TitleFont, fontWeight = FontWeight.Bold, fontSize = size.sp, lineHeight = line.sp, letterSpacing = (-0.005).em,
)

private fun body(size: Int, line: Int, weight: FontWeight = FontWeight.Normal, tracking: Double = 0.0) = TextStyle(
    fontFamily = BodyFont, fontWeight = weight, fontSize = size.sp, lineHeight = line.sp, letterSpacing = tracking.em,
)

val MountainTypography = Typography(
    displayLarge = display(57, 60, -0.03),
    displayMedium = display(45, 48, -0.025),
    displaySmall = display(36, 40, -0.02),
    headlineLarge = display(32, 36, -0.02),
    headlineMedium = display(28, 32, -0.015),
    headlineSmall = title(24, 30),
    titleLarge = title(21, 27),
    titleMedium = title(17, 23),
    titleSmall = title(15, 20),
    bodyLarge = body(16, 24),
    bodyMedium = body(14, 21),
    bodySmall = body(12, 17),
    labelLarge = body(14, 20, FontWeight.SemiBold, 0.01),
    labelMedium = body(12, 16, FontWeight.SemiBold, 0.04),
    labelSmall = body(11, 16, FontWeight.SemiBold, 0.06),
)

/** Timer digits: display face with tabular figures so the clock never jitters. */
val TimerStyle = TextStyle(
    fontFamily = DisplayFont, fontWeight = FontWeight.Bold, fontFeatureSettings = "tnum", letterSpacing = (-0.03).em,
)

private val MountainShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun MountainFoldTheme(settings: Settings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val context = LocalContext.current
    val scheme = if (settings.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        Palettes.scheme(settings.palette, dark)
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            (view.context as? Activity)?.window?.let { window ->
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    CompositionLocalProvider(LocalUnits provides Units(settings.weightUnit, settings.tempUnit)) {
        MaterialTheme(colorScheme = scheme, typography = MountainTypography, shapes = MountainShapes, content = content)
    }
}
