package com.mountainfold.app.ui

import androidx.compose.runtime.staticCompositionLocalOf
import com.mountainfold.app.core.engine.CoffeeEngine
import com.mountainfold.app.core.model.TempUnit
import com.mountainfold.app.core.model.WeightUnit

/** Formats and parses values in the user's units. Storage is always grams and Celsius. */
class Units(val weight: WeightUnit = WeightUnit.G, val temp: TempUnit = TempUnit.C) {
    val wLabel: String get() = if (weight == WeightUnit.G) "g" else "oz"
    val tLabel: String get() = if (temp == TempUnit.C) "°C" else "°F"

    fun wValue(g: Double): String =
        if (weight == WeightUnit.G) CoffeeEngine.formatNumber(g) else CoffeeEngine.formatNumber(CoffeeEngine.gToOz(g), 2)

    fun w(g: Double): String = "${wValue(g)} $wLabel"

    fun parseW(text: String): Double? =
        CoffeeEngine.parseNumber(text)?.let { if (weight == WeightUnit.G) it else CoffeeEngine.ozToG(it) }

    fun tValue(c: Double): String =
        if (temp == TempUnit.C) CoffeeEngine.formatNumber(c) else Math.round(CoffeeEngine.cToF(c)).toString()

    fun t(c: Double?): String = if (c == null) "–" else "${tValue(c)}$tLabel"

    fun parseT(text: String): Double? =
        CoffeeEngine.parseNumber(text)?.let { if (temp == TempUnit.C) it else CoffeeEngine.round1(CoffeeEngine.fToC(it)) }
}

val LocalUnits = staticCompositionLocalOf { Units() }
