package com.mountainfold.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.mountainfold.app.MainActivity
import com.mountainfold.app.MountainFoldApp
import com.mountainfold.app.R
import com.mountainfold.app.core.engine.StepSchedule

/**
 * Keeps the process alive while a brew is running in the background and shows the live timer.
 * The timer itself never depends on this service: it is derived from the monotonic clock.
 */
class BrewTimerService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val session = (application as MountainFoldApp).container.session
        if (intent?.action == ACTION_TOGGLE) session.toggle()
        if (!session.timer.state.value.running) {
            // startForegroundService() demands a startForeground() call, even when we stop right away.
            runCatching { promote(buildNotification(this)) }
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        runCatching { promote(buildNotification(this)) }.onFailure { stopSelf() }
        return START_NOT_STICKY
    }

    private fun promote(notification: Notification) {
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    companion object {
        const val CHANNEL_ID = "brew_timer"
        const val NOTIFICATION_ID = 41
        const val ACTION_TOGGLE = "com.mountainfold.app.TOGGLE"

        fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT < 26) return
            val nm = context.getSystemService(NotificationManager::class.java) ?: return
            val channel = NotificationChannel(CHANNEL_ID, context.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
            channel.setShowBadge(false)
            nm.createNotificationChannel(channel)
        }

        fun start(context: Context) {
            ensureChannel(context)
            runCatching { ContextCompat.startForegroundService(context, Intent(context, BrewTimerService::class.java)) }
        }

        fun stop(context: Context) {
            runCatching { context.stopService(Intent(context, BrewTimerService::class.java)) }
        }

        /** Refreshes the text of the running notification, for example on a step change. */
        fun refresh(context: Context) {
            val session = (context.applicationContext as MountainFoldApp).container.session
            if (!session.timer.state.value.running) return
            runCatching {
                context.getSystemService(NotificationManager::class.java)?.notify(NOTIFICATION_ID, buildNotification(context))
            }
        }

        fun buildNotification(context: Context): Notification {
            ensureChannel(context)
            val session = (context.applicationContext as MountainFoldApp).container.session
            val recipe = session.state.value.recipe
            val elapsed = session.timer.elapsedMs()
            val idx = session.currentStepIndex()
            val step = recipe?.steps?.getOrNull(idx)
            val target = recipe?.let { StepSchedule.targetWaterAt(it.steps, idx) }
            val text = buildString {
                append(step?.label ?: context.getString(R.string.brewing))
                if (step != null && target != null && step.targetWaterG != null) append(" → ${target.toInt()} g")
            }
            val open = PendingIntent.getActivity(
                context, 0,
                Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            val toggle = PendingIntent.getService(
                context, 1,
                Intent(context, BrewTimerService::class.java).setAction(ACTION_TOGGLE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            return NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_brew)
                .setContentTitle(recipe?.name ?: context.getString(R.string.app_name))
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(true)
                .setUsesChronometer(true)
                .setWhen(System.currentTimeMillis() - elapsed)
                .setCategory(NotificationCompat.CATEGORY_STOPWATCH)
                .setContentIntent(open)
                .addAction(0, context.getString(R.string.pause), toggle)
                .build()
        }
    }
}
