package com.mountainfold.app.data.session

import android.content.Context
import com.mountainfold.app.core.engine.CoffeeEngine
import com.mountainfold.app.core.engine.StepSchedule
import com.mountainfold.app.core.engine.TimerEngine
import com.mountainfold.app.core.model.BrewStep
import com.mountainfold.app.core.model.SessionRecipe
import com.mountainfold.app.core.weight.WeightProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

data class SessionState(
    /** Recipe being brewed, including live schedule changes. */
    val recipe: SessionRecipe? = null,
    /** Recipe as loaded, used by reset. */
    val base: SessionRecipe? = null,
    val notes: String = "",
    /** True once the user stops the brew and the log sheet should show. */
    val finished: Boolean = false,
    val targetReached: Boolean = false,
)

/** Side effects of a brew: vibration, sound, notification. Kept behind an interface for tests. */
interface BrewFeedback {
    fun onRunningChanged(running: Boolean, recipe: SessionRecipe?) {}
    fun onStep(step: BrewStep, index: Int, recipe: SessionRecipe) {}
    fun onTarget(recipe: SessionRecipe) {}
    fun onAction() {}
}

interface SessionPersistence {
    fun save(snapshot: PersistedSession?)
    fun load(): PersistedSession?
}

@Serializable
data class PersistedSession(
    val recipe: SessionRecipe,
    val base: SessionRecipe,
    val notes: String = "",
    val finished: Boolean = false,
    val targetReached: Boolean = false,
    val accumulatedMs: Long = 0,
    val running: Boolean = false,
    val laps: List<Long> = emptyList(),
    val pouredG: Double = 0.0,
    val savedWallMs: Long = 0,
)

class PrefsSessionPersistence(context: Context) : SessionPersistence {
    private val prefs = context.getSharedPreferences("brew_session", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    override fun save(snapshot: PersistedSession?) {
        prefs.edit().apply {
            if (snapshot == null) remove("s") else putString("s", json.encodeToString(PersistedSession.serializer(), snapshot))
        }.apply()
    }
    override fun load(): PersistedSession? = prefs.getString("s", null)?.let {
        runCatching { json.decodeFromString(PersistedSession.serializer(), it) }.getOrNull()
    }
}

/**
 * Owns the active brew. Lives at application scope, above every screen and every posture,
 * so folding, rotating or leaving the app never touches the timer, the step or the recipe.
 */
class BrewSessionManager(
    private val scope: CoroutineScope,
    val timer: TimerEngine,
    val weight: WeightProvider,
    private val feedback: BrewFeedback,
    private val autoStopAtTarget: () -> Boolean,
    private val persistence: SessionPersistence? = null,
    private val wallClock: () -> Long = System::currentTimeMillis,
    private val tickMs: Long = 100L,
) {
    private val _state = MutableStateFlow(SessionState())
    val state: StateFlow<SessionState> = _state.asStateFlow()

    private var lastStepIndex = -1

    init {
        restore()
        scope.launch {
            timer.state.map { it.running }.distinctUntilChanged().collectLatest { running ->
                feedback.onRunningChanged(running, _state.value.recipe)
                if (running) {
                    lastStepIndex = currentStepIndex()
                    while (true) {
                        tick()
                        delay(tickMs)
                    }
                }
            }
        }
    }

    val elapsedSeconds: Double get() = timer.elapsedMs() / 1000.0

    fun currentStepIndex(): Int = _state.value.recipe?.let { StepSchedule.indexAt(it.steps, elapsedSeconds) } ?: -1

    /** Checks step boundaries and the target time. Driven by the monotonic clock, not by frames. */
    fun tick() {
        val recipe = _state.value.recipe ?: return
        val elapsed = elapsedSeconds
        val idx = StepSchedule.indexAt(recipe.steps, elapsed)
        if (idx != lastStepIndex) {
            if (idx > lastStepIndex && idx in recipe.steps.indices && idx > 0) feedback.onStep(recipe.steps[idx], idx, recipe)
            lastStepIndex = idx
        }
        if (!_state.value.targetReached && recipe.targetTimeS > 0 && elapsed >= recipe.targetTimeS) {
            _state.update { it.copy(targetReached = true) }
            feedback.onTarget(recipe)
            if (autoStopAtTarget()) finish() else persist()
        }
    }

    fun load(recipe: SessionRecipe) {
        timer.reset()
        weight.tare()
        lastStepIndex = -1
        _state.value = SessionState(recipe = recipe, base = recipe)
        persist()
    }

    fun start() {
        if (_state.value.recipe == null || _state.value.finished) return
        timer.start(); feedback.onAction(); persist()
    }

    fun pause() { timer.pause(); feedback.onAction(); persist() }

    fun toggle() = if (timer.state.value.running) pause() else start()

    fun reset() {
        timer.reset()
        weight.tare()
        lastStepIndex = -1
        _state.update { it.copy(recipe = it.base, finished = false, targetReached = false) }
        feedback.onAction()
        persist()
    }

    /** Starts the brew if idle, otherwise jumps to the next step now. */
    fun nextStep() {
        val recipe = _state.value.recipe ?: return
        if (!timer.state.value.hasStarted) { start(); return }
        val moved = StepSchedule.advanceNow(recipe.steps, elapsedSeconds, recipe.targetTimeS) ?: return
        _state.update { it.copy(recipe = recipe.copy(steps = moved.first, targetTimeS = moved.second)) }
        tick()
        feedback.onAction()
        persist()
    }

    val hasNextStep: Boolean
        get() = _state.value.recipe?.let { currentStepIndex() < it.steps.lastIndex } ?: false

    /** Gives the current step more time and pushes the rest of the schedule. */
    fun extend(deltaS: Int = 10) {
        val recipe = _state.value.recipe ?: return
        val moved = StepSchedule.extendCurrent(recipe.steps, elapsedSeconds, recipe.targetTimeS, deltaS)
        _state.update { it.copy(recipe = recipe.copy(steps = moved.first, targetTimeS = moved.second), targetReached = false) }
        feedback.onAction()
        persist()
    }

    fun addWater(deltaG: Double) { weight.add(deltaG); feedback.onAction(); persist() }
    fun setWater(grams: Double) { weight.set(grams); persist() }
    fun lap() { timer.lap(); feedback.onAction(); persist() }
    fun setNotes(text: String) { _state.update { it.copy(notes = text) }; persist() }

    /** Changes dose and water before or during a brew. Water targets of each step are rescaled. */
    fun adjust(doseG: Double, waterG: Double) {
        val r = _state.value.recipe ?: return
        if (doseG <= 0 || waterG <= 0) return
        fun SessionRecipe.scaled() = copy(doseG = doseG, waterG = waterG, steps = CoffeeEngine.scaleSteps(steps, this.waterG, waterG))
        _state.update { it.copy(recipe = r.scaled(), base = it.base?.scaled()) }
        persist()
    }

    fun setTemp(tempC: Double?) {
        _state.update { it.copy(recipe = it.recipe?.copy(tempC = tempC), base = it.base?.copy(tempC = tempC)) }
        persist()
    }

    /** Stops the clock and marks the brew ready to log. */
    fun finish() {
        if (_state.value.recipe == null) return
        timer.pause()
        _state.update { it.copy(finished = true) }
        feedback.onAction()
        persist()
    }

    /** Back from the log sheet without saving: the brew stays as it was, paused. */
    fun cancelFinish() { _state.update { it.copy(finished = false) }; persist() }

    /** After logging: same recipe, fresh timer, ready for the next cup. */
    fun clearAfterLog() {
        timer.reset()
        weight.tare()
        lastStepIndex = -1
        _state.update { SessionState(recipe = it.base, base = it.base) }
        persist()
    }

    /** Drops the session entirely, for example after a data reset. */
    fun unload() {
        timer.reset()
        weight.tare()
        lastStepIndex = -1
        _state.value = SessionState()
        persist()
    }

    private fun persist() {
        val s = _state.value
        val recipe = s.recipe
        val base = s.base
        if (persistence == null) return
        if (recipe == null || base == null) { persistence.save(null); return }
        val t = timer.state.value
        persistence.save(
            PersistedSession(
                recipe, base, s.notes, s.finished, s.targetReached,
                accumulatedMs = timer.elapsedMs(), running = t.running, laps = t.laps,
                pouredG = weight.weightG.value, savedWallMs = wallClock(),
            )
        )
    }

    private fun restore() {
        val p = persistence?.load() ?: return
        val away = wallClock() - p.savedWallMs
        // A brew left running long past its target was abandoned. It comes back paused, not hours deep.
        val abandoned = p.running && away > maxOf(p.recipe.targetTimeS * 3_000L, 3_600_000L)
        _state.value = SessionState(p.recipe, p.base, p.notes, p.finished, p.targetReached)
        timer.restore(p.accumulatedMs, p.running && !abandoned, p.laps, extraMs = away)
        weight.set(p.pouredG)
    }
}
