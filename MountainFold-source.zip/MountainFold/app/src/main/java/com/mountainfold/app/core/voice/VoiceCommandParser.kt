package com.mountainfold.app.core.voice

sealed interface VoiceCommand {
    data object Start : VoiceCommand
    data object Pause : VoiceCommand
    data object NextStep : VoiceCommand
    data object Reset : VoiceCommand
    data object AskRatio : VoiceCommand
    data class AddWater(val grams: Double) : VoiceCommand
    data object Unknown : VoiceCommand
}

/** Maps a recognised sentence to a command. English, French and Spanish keywords. */
object VoiceCommandParser {
    private val number = Regex("(\\d+(?:[.,]\\d+)?)")

    fun parse(raw: String): VoiceCommand {
        val t = raw.lowercase().trim()
        if (t.isEmpty()) return VoiceCommand.Unknown
        fun has(vararg keys: String) = keys.any { t.contains(it) }
        return when {
            has("ratio") -> VoiceCommand.AskRatio
            has("add", "ajoute", "añade", "anade", "agrega") && number.containsMatchIn(t) ->
                VoiceCommand.AddWater(number.find(t)!!.value.replace(',', '.').toDouble())
            has("next", "suivant", "siguiente") -> VoiceCommand.NextStep
            has("reset", "réinitialise", "reinitialise", "remise à zéro", "reinicia") -> VoiceCommand.Reset
            has("pause", "stop", "arrête", "arrete", "pausa", "para") -> VoiceCommand.Pause
            has("start", "resume", "démarre", "demarre", "lance", "reprends", "empieza", "inicia", "continúa", "continua") ->
                VoiceCommand.Start
            else -> VoiceCommand.Unknown
        }
    }
}
