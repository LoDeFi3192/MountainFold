package com.mountainfold.app.service

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.mountainfold.app.core.cupping.CuppingFormat
import com.mountainfold.app.data.db.CuppingCoffee
import java.io.ByteArrayOutputStream
import java.io.FileOutputStream
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sin

/** The two cupping timer alerts of the original: one beep at the crust, three at the end, each with a vibration. */
class CuppingAlerts(private val context: Context) : com.mountainfold.app.ui.cupping.CuppingAlertSink {
    private val vibrator: Vibrator? by lazy {
        runCatching {
            if (Build.VERSION.SDK_INT >= 31) context.getSystemService(VibratorManager::class.java)?.defaultVibrator
            else @Suppress("DEPRECATION") (context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)
        }.getOrNull()
    }

    override fun crust() {
        play(listOf(Beep(0.0, 880.0, 1.0)))
        vibrate(longArrayOf(0, 200, 100, 200))
    }

    override fun finished() {
        play(listOf(Beep(0.0, 880.0, 1.0), Beep(0.2, 880.0, 1.0), Beep(0.4, 1100.0, 1.5)))
        vibrate(longArrayOf(0, 200, 100, 200, 100, 500))
    }

    private data class Beep(val at: Double, val freq: Double, val duration: Double)

    private fun vibrate(pattern: LongArray) {
        val v = vibrator ?: return
        runCatching { if (v.hasVibrator()) v.vibrate(VibrationEffect.createWaveform(pattern, -1)) }
    }

    /** Sine beeps with an exponential fade from 0.5 to 0.01, the same envelope the Web Audio version used. */
    private fun play(beeps: List<Beep>) {
        runCatching {
            val rate = 44_100
            val total = beeps.maxOf { it.at + it.duration }
            val n = (total * rate).toInt()
            val pcm = ShortArray(n)
            val mix = DoubleArray(n)
            for (b in beeps) {
                val start = (b.at * rate).toInt()
                val len = (b.duration * rate).toInt()
                val k = ln(0.01 / 0.5) / b.duration
                for (i in 0 until len) {
                    val idx = start + i
                    if (idx >= n) break
                    val t = i.toDouble() / rate
                    mix[idx] += 0.5 * exp(k * t) * sin(2 * PI * b.freq * t)
                }
            }
            for (i in 0 until n) pcm[i] = (mix[i].coerceIn(-1.0, 1.0) * 30_000).toInt().toShort()
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setTransferMode(AudioTrack.MODE_STATIC)
                .setBufferSizeInBytes(n * 2)
                .build()
            track.write(pcm, 0, n)
            track.play()
            Handler(Looper.getMainLooper()).postDelayed({ runCatching { track.stop(); track.release() } }, (total * 1000).toLong() + 300)
        }
    }
}

/** Offline QR code, same colours as the original (dark brown on white). */
object QrCode {
    fun bitmap(text: String, size: Int = 512, dark: Int = 0xFF4D2900.toInt(), light: Int = Color.WHITE): Bitmap? = runCatching {
        val hints = mapOf(EncodeHintType.MARGIN to 1, EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M, EncodeHintType.CHARACTER_SET to "UTF-8")
        val m = QRCodeWriter().encode(text.ifBlank { " " }, BarcodeFormat.QR_CODE, size, size, hints)
        val pixels = IntArray(m.width * m.height) { i -> if (m.get(i % m.width, i / m.width)) dark else light }
        Bitmap.createBitmap(pixels, m.width, m.height, Bitmap.Config.ARGB_8888)
    }.getOrNull()
}

/**
 * PDF report of the summary table, laid out like the jsPDF + autoTable report of the original:
 * A4 landscape, brown header row, striped body, page numbers bottom right.
 */
object CuppingPdf {
    data class Texts(
        val title: String,
        val subtitle: String,
        val location: String?,
        val meta: String?,
        val headers: List<String>,
        val pageLabel: (Int, Int) -> String,
    )

    private const val MM = 72f / 25.4f
    private const val W = 297f
    private const val H = 210f
    private const val MARGIN = 14f
    private const val BOTTOM = 14.1f
    private const val PAD = 3f
    /** Horizontal padding a little tighter than the original 3 mm, so "Fav" and "Arrière-goût" keep their words. */
    private const val PAD_X = 2f
    private const val FONT = 9f
    private const val LINE = FONT * 1.15f / MM // mm per line
    private val widths = floatArrayOf(30f, 12f, 22f, 15f, 0f, 23f, 23f, 23f, 23f, 23f, 23f)

    class Cell internal constructor(val lines: List<String>, internal val bold: Boolean, internal val center: Boolean, internal val color: Int)
    class Row internal constructor(val cells: List<Cell>, internal val height: Float)

    /** Everything needed to draw the report, computed once and shared by the PDF, the print job and the preview. */
    class Plan internal constructor(
        val texts: Texts,
        internal val widths: FloatArray,
        internal val head: Row,
        val pages: List<List<IndexedValue<Row>>>,
        internal val firstTop: Float,
        internal val regular: Paint,
        internal val bold: Paint,
    ) {
        val pageCount: Int get() = pages.size
        /** Text of every body row, cell by cell, line by line. Used by tests. */
        val rows: List<List<String>> get() = pages.flatten().sortedBy { it.index }.map { r -> r.value.cells.map { it.lines.joinToString(" ") } }
    }

    fun plan(coffees: List<CuppingCoffee>, t: Texts, label: (String) -> String): Plan {
        val w = widths.copyOf()
        w[4] = (W - 2 * MARGIN) - w.sum()
        val regular = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = FONT; typeface = Typeface.DEFAULT }
        val bold = Paint(regular).apply { typeface = Typeface.DEFAULT_BOLD }
        val textColor = Color.rgb(20, 20, 20)

        fun cell(text: String, i: Int, head: Boolean): Cell {
            val isBold = head || i == 0 || i == 3
            val p = if (isBold) bold else regular
            val color = when {
                head -> Color.WHITE
                i == 1 -> Color.rgb(220, 50, 50)
                else -> textColor
            }
            return Cell(wrap(text, p, (w[i] - 2 * PAD_X) * MM), isBold, !head && (i == 1 || i == 3), color)
        }
        fun row(values: List<String>, head: Boolean): Row {
            val cells = values.mapIndexed { i, v -> cell(v, i, head) }
            return Row(cells, cells.maxOf { it.lines.size } * LINE + 2 * PAD)
        }

        val head = row(t.headers, true)
        val body = coffees.map { c ->
            row(
                listOf(
                    c.name,
                    if (c.isFavorite) "♥" else "-",
                    c.process.ifEmpty { "-" }.let { if (it == "-") it else label(it) },
                    CuppingFormat.fixed2(c.finalScore),
                    c.uniqueNotes.joinToString(", ") { label(it) },
                    CuppingFormat.jsNumber(c.fragranceScore), CuppingFormat.jsNumber(c.flavorScore), CuppingFormat.jsNumber(c.aftertasteScore),
                    CuppingFormat.jsNumber(c.acidityScore), CuppingFormat.jsNumber(c.bodyScore), CuppingFormat.jsNumber(c.balanceScore),
                ),
                false,
            )
        }

        // Header block, then the table. The header row repeats on every page.
        var y = 33f
        if (t.meta != null) y += 5f
        val firstTop = y + 10f
        val pages = ArrayList<List<IndexedValue<Row>>>()
        var current = ArrayList<IndexedValue<Row>>()
        var cursor = firstTop + head.height
        body.forEachIndexed { i, r ->
            if (cursor + r.height > H - BOTTOM && current.isNotEmpty()) {
                pages += current
                current = ArrayList()
                cursor = MARGIN + head.height
            }
            current += IndexedValue(i, r)
            cursor += r.height
        }
        pages += current
        return Plan(t, w, head, pages, firstTop, regular, bold)
    }

    /** Draws one page in PDF points (A4 landscape, 842 x 595). */
    fun drawPage(canvas: Canvas, plan: Plan, pageIndex: Int) {
        val t = plan.texts
        var top = if (pageIndex == 0) plan.firstTop else MARGIN
        if (pageIndex == 0) drawHeader(canvas, t)
        top = drawRow(canvas, plan.head, top, plan.widths, Color.rgb(141, 110, 77), plan.bold, plan.regular)
        plan.pages[pageIndex].forEach { (i, r) ->
            top = drawRow(canvas, r, top, plan.widths, if (i % 2 == 0) Color.rgb(245, 245, 245) else Color.WHITE, plan.bold, plan.regular)
        }
        val foot = Paint(plan.regular).apply { textSize = 8f; color = Color.rgb(150, 150, 150); textAlign = Paint.Align.RIGHT }
        canvas.drawText(t.pageLabel(pageIndex + 1, plan.pageCount), (W - 20f) * MM, (H - 10f) * MM, foot)
    }

    fun render(plan: Plan): ByteArray {
        val doc = PdfDocument()
        val out = ByteArrayOutputStream()
        try {
            for (pageIndex in plan.pages.indices) {
                val page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageIndex + 1).create())
                drawPage(page.canvas, plan, pageIndex)
                doc.finishPage(page)
            }
            doc.writeTo(out)
        } finally {
            doc.close()
        }
        return out.toByteArray()
    }

    /** Bitmap of a page, same drawing code as the PDF. */
    fun preview(plan: Plan, pageIndex: Int, scale: Float = 2f): Bitmap {
        val bmp = Bitmap.createBitmap((PAGE_W * scale).toInt(), (PAGE_H * scale).toInt(), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)
        canvas.scale(scale, scale)
        drawPage(canvas, plan, pageIndex)
        return bmp
    }

    val PAGE_W: Int = (W * MM).toInt()
    val PAGE_H: Int = (H * MM).toInt()

    private fun drawHeader(canvas: Canvas, t: Texts) {
        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 22f; color = Color.rgb(141, 110, 77); typeface = Typeface.DEFAULT }
        canvas.drawText(t.title, MARGIN * MM, 20f * MM, title)
        val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f; color = Color.rgb(100, 100, 100) }
        canvas.drawText(t.subtitle, MARGIN * MM, 28f * MM, small)
        t.location?.let { canvas.drawText(it, MARGIN * MM, 33f * MM, small) }
        t.meta?.let { canvas.drawText(it, MARGIN * MM, 38f * MM, small) }
    }

    private fun drawRow(canvas: Canvas, r: Row, top: Float, w: FloatArray, fill: Int, bold: Paint, regular: Paint): Float {
        val bg = Paint().apply { color = fill; style = Paint.Style.FILL }
        canvas.drawRect(MARGIN * MM, top * MM, (W - MARGIN) * MM, (top + r.height) * MM, bg)
        var x = MARGIN
        r.cells.forEachIndexed { i, c ->
            val p = Paint(if (c.bold) bold else regular).apply {
                color = c.color
                textAlign = if (c.center) Paint.Align.CENTER else Paint.Align.LEFT
            }
            val tx = if (c.center) x + w[i] / 2f else x + PAD_X
            c.lines.forEachIndexed { li, line ->
                // Baseline sits about 0.8 of the line box down, as jsPDF places it.
                val baseline = top + PAD + li * LINE + LINE * 0.8f
                canvas.drawText(line, tx * MM, baseline * MM, p)
            }
            x += w[i]
        }
        return top + r.height
    }

    /** Greedy word wrap. Words longer than the column are cut by characters. */
    fun wrap(text: String, paint: Paint, maxWidth: Float): List<String> {
        if (text.isEmpty()) return listOf("")
        val out = ArrayList<String>()
        text.split('\n').forEach { para ->
            var line = ""
            para.split(' ').forEach { word ->
                val candidate = if (line.isEmpty()) word else "$line $word"
                if (paint.measureText(candidate) <= maxWidth) {
                    line = candidate
                } else {
                    if (line.isNotEmpty()) out += line
                    var rest = word
                    while (paint.measureText(rest) > maxWidth && rest.length > 1) {
                        var cut = rest.length - 1
                        while (cut > 1 && paint.measureText(rest, 0, cut) > maxWidth) cut--
                        // Prefer breaking right after a hyphen when one fits.
                        val hyphen = rest.lastIndexOf('-', cut - 1)
                        if (hyphen in 1 until cut) cut = hyphen + 1
                        out += rest.substring(0, cut)
                        rest = rest.substring(cut)
                    }
                    line = rest
                }
            }
            out += line
        }
        return out
    }

    /** Sends an already rendered PDF to the Android print dialog. */
    fun print(context: Context, jobName: String, bytes: ByteArray, pages: Int) {
        val manager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val attrs = PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4.asLandscape()).build()
        manager.print(jobName, object : PrintDocumentAdapter() {
            override fun onLayout(old: PrintAttributes?, new: PrintAttributes?, cancel: CancellationSignal?, callback: LayoutResultCallback, extras: Bundle?) {
                if (cancel?.isCanceled == true) { callback.onLayoutCancelled(); return }
                callback.onLayoutFinished(
                    PrintDocumentInfo.Builder("$jobName.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(max(1, pages)).build(),
                    true,
                )
            }

            override fun onWrite(pages: Array<out PageRange>?, destination: ParcelFileDescriptor, cancel: CancellationSignal?, callback: WriteResultCallback) {
                runCatching { FileOutputStream(destination.fileDescriptor).use { it.write(bytes) } }
                    .onSuccess { callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES)) }
                    .onFailure { callback.onWriteFailed(it.message) }
            }
        }, attrs)
    }
}
