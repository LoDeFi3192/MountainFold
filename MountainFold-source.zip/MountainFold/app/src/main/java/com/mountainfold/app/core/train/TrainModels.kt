package com.mountainfold.app.core.train

import kotlinx.serialization.Serializable

enum class Skill { EXTRACTION, ESPRESSO, POUR_OVER, MILK, SENSORY, GRINDER, WATER, WORKFLOW, THEORY }

enum class SchoolCategory { FOUNDATIONS, BREWING, ESPRESSO, SENSORY, ROASTING, WATER, ADVANCED }

enum class SimKind { NONE, FILTER, ESPRESSO, YIELD_CALC, MILK }

/** Timed exams. TROUBLESHOOTING is built from generated dial-in scenarios. */
enum class ExamCategory(val skills: Set<Skill>) {
    KNOWLEDGE(setOf(Skill.THEORY, Skill.WATER)),
    BREWING(setOf(Skill.EXTRACTION, Skill.POUR_OVER, Skill.GRINDER)),
    ESPRESSO(setOf(Skill.ESPRESSO, Skill.MILK, Skill.WORKFLOW)),
    SENSORY(setOf(Skill.SENSORY)),
    TROUBLESHOOTING(emptySet()),
}

enum class EventKind { LESSON, DIAL_IN, DAILY, LEVEL_TEST, EXAM, BREW_CHALLENGE, TASTING_LOG, STREAK_BONUS }

enum class BaristaTitle { TRAINEE, JUNIOR, BARISTA, SENIOR, HEAD, SPECIALIST, EXPERT }

/** Text in the three app languages. English is the fallback. */
@Serializable
data class L(val en: String, val fr: String = en, val es: String = en) {
    operator fun get(lang: String): String = when (lang) {
        "fr" -> fr
        "es" -> es
        else -> en
    }
}

@Serializable
data class Block(val title: L, val body: L)

/** The first option is always the correct one in the source. Options are shuffled when a quiz is built. */
@Serializable
data class Question(
    val id: String,
    val prompt: L,
    val options: List<L>,
    val correct: Int = 0,
    val why: L,
    val skill: Skill? = null,
)

@Serializable
data class Lesson(
    val id: String,
    val category: SchoolCategory,
    val skill: Skill,
    val level: Int,
    val minutes: Int,
    val title: L,
    val objectives: List<L> = emptyList(),
    val blocks: List<Block> = emptyList(),
    val sim: SimKind = SimKind.NONE,
    val simHint: L? = null,
    /** Real-brew follow up. Completing it closes the learn, brew, log loop. */
    val brewTask: L? = null,
    val questions: List<Question> = emptyList(),
)

@Serializable
data class TrainContent(val version: Int = 1, val lessons: List<Lesson> = emptyList(), val bank: List<Question> = emptyList()) {
    fun lesson(id: String): Lesson? = lessons.firstOrNull { it.id == id }
    val lessonsByLevel: Map<Int, List<String>> get() = lessons.groupBy({ it.level }, { it.id })
}

sealed interface TreeTask {
    data class DialIn(val espresso: Boolean) : TreeTask
    data class Exam(val category: ExamCategory) : TreeTask
}

data class TreeLevel(val number: Int, val tasks: List<TreeTask> = emptyList())

/** Nine levels. Lessons come from the content by level number, tasks are practical gates. */
object SkillTree {
    val levels: List<TreeLevel> = listOf(
        TreeLevel(1),
        TreeLevel(2),
        TreeLevel(3),
        TreeLevel(4, listOf(TreeTask.DialIn(espresso = false))),
        TreeLevel(5),
        TreeLevel(6, listOf(TreeTask.DialIn(espresso = true))),
        TreeLevel(7),
        TreeLevel(8, listOf(TreeTask.Exam(ExamCategory.BREWING), TreeTask.Exam(ExamCategory.ESPRESSO), TreeTask.Exam(ExamCategory.TROUBLESHOOTING))),
        TreeLevel(9, listOf(TreeTask.Exam(ExamCategory.KNOWLEDGE), TreeTask.Exam(ExamCategory.SENSORY))),
    )

    const val DIAL_IN_FILTER = "filter"
    const val DIAL_IN_ESPRESSO = "espresso"
    fun levelRef(level: Int) = "level:$level"
    fun dayRef(epochDay: Long) = "day:$epochDay"
}

/** One recorded training activity. Mirrors the Room row without depending on Room. */
data class TrainEvent(
    val createdAt: Long,
    val kind: EventKind,
    val refId: String,
    val correct: Int = 0,
    val total: Int = 0,
    val xp: Int = 0,
    val passed: Boolean = false,
    /** Per-skill results, for example "EXTRACTION:3/4;ESPRESSO:1/2". */
    val breakdown: String = "",
)

object Breakdown {
    fun encode(results: List<Pair<Skill, Boolean>>): String =
        results.groupBy { it.first }.entries.joinToString(";") { (skill, list) -> "${skill.name}:${list.count { it.second }}/${list.size}" }

    fun decode(raw: String): List<Triple<Skill, Int, Int>> = raw.split(';').mapNotNull { part ->
        val name = part.substringBefore(':', "")
        val score = part.substringAfter(':', "")
        val skill = Skill.entries.firstOrNull { it.name == name } ?: return@mapNotNull null
        val c = score.substringBefore('/').toIntOrNull() ?: return@mapNotNull null
        val t = score.substringAfter('/').toIntOrNull() ?: return@mapNotNull null
        if (t <= 0) null else Triple(skill, c.coerceIn(0, t), t)
    }
}
