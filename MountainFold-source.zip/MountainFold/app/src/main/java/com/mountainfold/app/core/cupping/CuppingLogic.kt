package com.mountainfold.app.core.cupping

import com.mountainfold.app.data.db.CuppingCoffee
import java.math.BigDecimal
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToLong

/** Number formatting and small helpers shared by the cupping screens, exports and tests. */
object CuppingFormat {
    /** Score with two decimals and a dot, like toFixed(2) in the original. */
    fun fixed2(v: Double): String = BigDecimal(v).setScale(2, java.math.RoundingMode.HALF_UP).toPlainString()

    /** A number the way JavaScript prints it: 8 for 8.0, 8.25 for 8.25. */
    fun jsNumber(v: Double): String =
        if (v == floor(v) && kotlin.math.abs(v) < 1e15) v.toLong().toString()
        else BigDecimal(v.toString()).stripTrailingZeros().toPlainString()

    /** mm:ss with both parts on two digits. Minutes keep growing past 99. */
    fun clock(seconds: Int): String {
        val s = seconds.coerceAtLeast(0)
        return "%02d:%02d".format(s / 60, s % 60)
    }

    /** Brewing Lab: water = coffee x ratio, rounded to the gram. */
    fun water(coffeeG: Double, ratio: Double): Int {
        val w = coffeeG * ratio
        return if (w.isFinite()) w.roundToLong().coerceIn(Int.MIN_VALUE.toLong(), Int.MAX_VALUE.toLong()).toInt() else 0
    }

    /** Lenient number parsing for text fields: comma or dot, empty means 0 like Number('') in the original. */
    fun parse(text: String): Double? {
        val t = text.trim().replace(',', '.')
        if (t.isEmpty()) return 0.0
        return t.toDoubleOrNull()?.takeIf { it.isFinite() }
    }
}

/**
 * The cupping countdown of the original: 4 or 6 minutes. In the 6 minute mode it rings once when
 * 2 minutes remain (4 minutes elapsed, time to break the crust) and twice at the end.
 * Time comes from a monotonic clock so the display never drifts.
 */
class CuppingTimer(private val now: () -> Long) {
    enum class Alert { CRUST, FINISHED }
    enum class Phase { CRUST, TASTE, FINISHED, PAUSED }

    data class State(val initialS: Int = 0, val remainingMs: Long = 0, val running: Boolean = false) {
        /** Whole seconds left, rounded up like a countdown display. */
        val remainingS: Int get() = ceil(remainingMs / 1000.0).toInt().coerceAtLeast(0)
        val progress: Float get() = if (initialS > 0) ((initialS * 1000L - remainingMs).toFloat() / (initialS * 1000f)).coerceIn(0f, 1f) else 0f
        val sixMinute: Boolean get() = initialS == SIX_MIN
        val phase: Phase get() = when {
            running -> if (sixMinute && remainingS > CRUST_AT) Phase.CRUST else Phase.TASTE
            remainingS == 0 && initialS > 0 -> Phase.FINISHED
            else -> Phase.PAUSED
        }
    }

    var state = State()
        private set
    private var endAt = 0L

    fun start(minutes: Int) {
        val s = minutes * 60
        state = State(initialS = s, remainingMs = s * 1000L, running = true)
        endAt = now() + s * 1000L
    }

    fun togglePause() {
        val st = state
        state = when {
            st.running -> st.copy(remainingMs = (endAt - now()).coerceAtLeast(0), running = false)
            st.remainingMs > 0 -> { endAt = now() + st.remainingMs; st.copy(running = true) }
            else -> st
        }
    }

    fun reset() {
        state = state.copy(remainingMs = state.initialS * 1000L, running = false)
    }

    /** Advances the clock. Returns the alerts crossed since the previous call. */
    fun tick(): List<Alert> {
        val st = state
        if (!st.running) return emptyList()
        val before = st.remainingS
        val left = (endAt - now()).coerceAtLeast(0)
        val next = st.copy(remainingMs = left, running = left > 0)
        state = next
        val alerts = ArrayList<Alert>(2)
        if (st.sixMinute && before > CRUST_AT && next.remainingS <= CRUST_AT && left > 0) alerts += Alert.CRUST
        if (left == 0L) alerts += Alert.FINISHED
        return alerts
    }

    companion object {
        const val SIX_MIN = 360
        const val CRUST_AT = 120
    }
}

/** Geometry of the flavor wheel: one equal slice per aroma, in catalogue order, clockwise from 3 o'clock. */
object FlavorWheel {
    data class Slice(
        val key: String,
        val category: CuppingCatalog.AromaCategory,
        val color: Long,
        val startDeg: Float,
        val endDeg: Float,
    ) {
        val midDeg: Float get() = (startDeg + endDeg) / 2f
    }

    val slices: List<Slice> by lazy {
        val all = CuppingCatalog.AROMA_CATEGORIES.flatMap { c -> c.items.map { c to it } }
        val step = 360f / all.size
        all.mapIndexed { i, (c, item) ->
            Slice(item.key, c, CuppingCatalog.ITEM_COLOR_OVERRIDES[item.key] ?: c.color, i * step, (i + 1) * step)
        }
    }

    val step: Float get() = 360f / slices.size

    /** Index of the slice under a pointer placed at [pointerDeg] when the wheel is turned by [rotationDeg]. */
    fun activeIndex(rotationDeg: Float, pointerDeg: Float = 0f): Int {
        var target = (pointerDeg - rotationDeg) % 360f
        if (target < 0f) target += 360f
        return floor(target / step).toInt().coerceIn(0, slices.lastIndex)
    }

    /** Rotation that puts slice [index] under the pointer, nearest to [fromDeg]. */
    fun rotationFor(index: Int, fromDeg: Float, pointerDeg: Float = 0f): Float {
        val wanted = pointerDeg - slices[index].midDeg
        val turns = Math.round((fromDeg - wanted) / 360f)
        return wanted + turns * 360f
    }

    /** Shortest signed difference between two angles, in -180..180. */
    fun delta(fromDeg: Float, toDeg: Float): Float {
        var d = toDeg - fromDeg
        while (d > 180f) d -= 360f
        while (d < -180f) d += 360f
        return d
    }
}

/** CSV export of the summary table. Columns and order follow the original. */
object CuppingCsv {
    fun build(
        coffees: List<CuppingCoffee>,
        headers: List<String>,
        yes: String,
        no: String,
        label: (String) -> String = { it },
    ): String {
        val sb = StringBuilder()
        sb.append(headers.joinToString(",") { field(it) }).append('\n')
        coffees.forEachIndexed { i, c ->
            val row = listOf(
                quoted(c.name),
                if (c.isFavorite) yes else no,
                field(label(c.process)),
                CuppingFormat.fixed2(c.finalScore),
                quoted(c.uniqueNotes.joinToString(", ") { label(it) }),
                CuppingFormat.jsNumber(c.fragranceScore),
                CuppingFormat.jsNumber(c.flavorScore),
                CuppingFormat.jsNumber(c.aftertasteScore),
                CuppingFormat.jsNumber(c.acidityScore),
                CuppingFormat.jsNumber(c.bodyScore),
                CuppingFormat.jsNumber(c.balanceScore),
                quoted(c.comments),
            )
            sb.append(row.joinToString(","))
            if (i < coffees.lastIndex) sb.append('\n')
        }
        return sb.toString()
    }

    private fun quoted(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
    private fun field(s: String) = if (s.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) quoted(s) else s
}
