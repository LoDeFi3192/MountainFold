#!/usr/bin/env python3
"""Draws the app icons from the Android adaptive icon (a mountain made of one folded sheet)."""
import os
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(os.path.dirname(HERE), "public", "icons")
BG = (0x2B, 0x1D, 0x14)
FACES = [
    ((0xF3, 0xE7, 0xD8), [(56, 33), (27, 74), (49, 74)]),
    ((0xC9, 0x9B, 0x6B), [(56, 33), (49, 74), (81, 74)]),
    ((0x8F, 0x68, 0x44), [(70, 53), (62, 74), (81, 74)]),
]


def icon(size, scale=1.0, rounded=False):
    ss = 4
    big = size * ss
    img = Image.new("RGBA", (big, big), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if rounded:
        d.rounded_rectangle([0, 0, big - 1, big - 1], radius=int(big * 0.22), fill=BG)
    else:
        d.rectangle([0, 0, big, big], fill=BG)
    # The adaptive icon viewport is 108; the artwork is centred on 54.
    k = big / 108 * scale
    off = big / 2 - 54 * k
    for color, pts in FACES:
        d.polygon([(off + x * k, off + y * k) for x, y in pts], fill=color)
    return img.resize((size, size), Image.LANCZOS)


os.makedirs(OUT, exist_ok=True)
icon(180, 1.25).convert("RGB").save(os.path.join(OUT, "apple-touch-icon.png"))
icon(192, 1.25, rounded=True).save(os.path.join(OUT, "icon-192.png"))
icon(512, 1.25, rounded=True).save(os.path.join(OUT, "icon-512.png"))
icon(512, 1.0).convert("RGB").save(os.path.join(OUT, "icon-maskable-512.png"))
icon(32, 1.3, rounded=True).save(os.path.join(OUT, "favicon-32.png"))

svg = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108"><rect width="108" height="108" rx="24" fill="#2B1D14"/>',
       '<g transform="translate(54 54) scale(1.25) translate(-54 -54)">']
for color, pts in FACES:
    svg.append('<path fill="#%02X%02X%02X" d="M%s Z"/>' % (color + (" L".join(f"{x},{y}" for x, y in pts),)))
svg.append("</g></svg>")
open(os.path.join(os.path.dirname(OUT), "favicon.svg"), "w").write("".join(svg))
print("icons written to", OUT)
