package com.mountainfold.app.data
import com.mountainfold.app.core.model.*
import com.mountainfold.app.data.db.*
import com.mountainfold.app.data.prefs.Settings
import kotlinx.serialization.json.Json
import java.io.File

// Same configuration as Repository.json
private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = true; coerceInputValues = true }

fun main(args: Array<String>) {
    when (args[0]) {
        "export" -> {
            val steps = listOf(BrewStep("Bloom", StepType.BLOOM, 0, 45.0), BrewStep("Pour", StepType.POUR, 45, 250.0, "slow"), BrewStep("Wait", StepType.WAIT, 120))
            val b = Backup(
                exportedAt = 1_760_000_000_000,
                settings = Settings(themeMode = ThemeMode.DARK, palette = Palette.TOULOUSE, defaultMethod = BrewMethod.ESPRESSO, defaultDoseG = 18.0,
                    weightUnit = WeightUnit.OZ, tempUnit = TempUnit.F, layoutOverride = LayoutOverride.FLEX, flexLayout = FlexLayout.SHOT, waterStepG = 25.0,
                    onboarded = true, currentCoffeeId = 2, lastRecipeId = 1, defaultGrinderId = 1, preferredMethods = listOf(BrewMethod.V60, BrewMethod.ESPRESSO),
                    cuppingSessionId = "s1"),
                coffees = listOf(Coffee(id = 2, name = "Ethiopia Guji", origin = "Ethiopia", process = "Washed", roastDateEpochDay = 20370, tastingNotes = "Jasmine", photoPath = "/data/user/0/com.mountainfold.app/files/photos/a.jpg", createdAt = 1_759_000_000_000)),
                recipes = listOf(Recipe(id = 1, name = "V60 classique", method = "V60", coffeeId = 2, doseG = 15.0, waterG = 250.0, tempC = 93.5, grind = "22", targetTimeS = 180, stepsJson = StepsCodec.encode(steps), favorite = true, createdAt = 1, updatedAt = 2),
                    Recipe(id = 3, name = "Cold", method = "COLD_BREW", tempC = null, targetTimeS = 57600)),
                brews = listOf(Brew(id = 7, coffeeId = 2, recipeId = 1, coffeeName = "Ethiopia Guji", recipeName = "V60 classique", method = "V60", doseG = 15.0, waterG = 250.0, tempC = 93.0, grind = "22", grinderId = 1, grinderName = "Comandante C40", timeMs = 182_400, targetTimeS = 180, notes = "Sweet", rating = 4, acidity = 3, sweetness = 4, body = 3, balance = 4, clarity = 5, symptoms = "SOUR,WEAK", stepsJson = StepsCodec.encode(steps), createdAt = 1_760_000_000_000)),
                grinders = listOf(Grinder(id = 1, name = "Comandante C40", notes = "clicks")),
                training = listOf(TrainingEvent(id = 1, createdAt = 1_760_000_000_000, kind = "LESSON", refId = "ratio", skill = "THEORY", correct = 3, total = 3, durationS = 60, xp = 75, passed = true, breakdown = "THEORY:3/3")),
                cuppingSessions = listOf(CuppingSession(id = "s1", createdAt = 5, name = "Morning", location = "Labo", dateIso = "2026-10-13", originNotes = "Ethiopia", roasterNotes = "R", importerNotes = "I")),
                cuppingCoffees = listOf(CuppingCoffee(id = "c1", sessionId = "s1", position = 0, name = "Guji", isLocked = true, isFavorite = true, timestamp = 6, process = "Lavé", fragranceScore = 8.5, fragranceNotes = listOf("Citron", "Jasmin"), flavorScore = 9.25, flavorNotes = listOf("Miel"), acidityType = "Citrique", acidityIntensity = "Forte", bodyType = "Soyeux", comments = "Clean, \"sweet\""),
                    CuppingCoffee(id = "orphan", sessionId = "gone", name = "Lost")),
                labRecipes = listOf(LabRecipe(id = "r1", timestamp = 3, method = "chemex", coffeeWeight = 30.0, ratio = 15.0, waterWeight = 450, grindSize = "Sel fin", totalTime = 245, rating = 8.5, notes = "Floral")),
            )
            File(args[1]).writeText(json.encodeToString(Backup.serializer(), b))
        }
        "import" -> {
            // What Repository.importJson does before writing to Room.
            val backup = json.decodeFromString(Backup.serializer(), File(args[1]).readText())
            require(backup.app == Backup.APP_ID)
            val steps = (backup.recipes.map { it.stepsJson } + backup.brews.map { it.stepsJson }).map { StepsCodec.decode(it) }
            val out = mapOf("backup" to json.encodeToString(Backup.serializer(), backup), "steps" to steps.toString())
            File(args[2]).writeText(out["backup"]!!)
            File(args[2] + ".steps.txt").writeText(steps.joinToString("\n"))
        }
    }
}
