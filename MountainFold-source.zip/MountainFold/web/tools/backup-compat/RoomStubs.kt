package androidx.room
import kotlin.reflect.KClass
annotation class Entity(val tableName: String = "", val foreignKeys: Array<ForeignKey> = [], val indices: Array<Index> = [])
annotation class PrimaryKey(val autoGenerate: Boolean = false)
annotation class Index(vararg val value: String)
annotation class ForeignKey(val entity: KClass<*>, val parentColumns: Array<String>, val childColumns: Array<String>, val onDelete: Int = 0) {
  companion object { const val CASCADE = 5 }
}
annotation class TypeConverter
