#!/usr/bin/env python3
"""Builds the web app's data from the same sources as the Android app, so both clients never drift.

- strings:  ../tools/gen_strings.py (S) + ../tools/strings_cupping.py (CUP) + tools/strings_web.py (WEB)
- lessons:  ../app/src/main/assets/train/content.json
- fonts:    ../app/src/main/res/font/*.ttf -> src/assets/fonts/*.woff2
- icons:    Material Icons Rounded (Apache 2.0) + the original Toulouse Cupping icons (paths only)

Run from web/: python3 tools/build_data.py [path/to/original/components__Icons.js]
"""
import json, os, re, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
WEB = os.path.dirname(HERE)
ROOT = os.path.dirname(WEB)
sys.path.insert(0, os.path.join(ROOT, "tools"))
sys.path.insert(0, HERE)

# ---- strings ---------------------------------------------------------------------------------
src = open(os.path.join(ROOT, "tools", "gen_strings.py"), encoding="utf-8").read()
table = src[src.index("S = {"):src.index("# Modules keep")]
scope = {}
exec(table, scope)  # the table is a plain dict literal written by us
S = dict(scope["S"])
from strings_cupping import CUP  # noqa: E402
from strings_web import WEB as WEB_STRINGS  # noqa: E402
for extra in (CUP, WEB_STRINGS):
    dup = set(extra) & set(S)
    assert not dup, f"duplicate keys: {dup}"
    S.update(extra)

bad = [k for k, v in S.items() if len({tuple(sorted(re.findall(r"%\d\$[sd]", x))) for x in v}) != 1]
assert not bad, f"placeholder mismatch: {bad}"
os.makedirs(os.path.join(WEB, "src", "i18n"), exist_ok=True)
with open(os.path.join(WEB, "src", "i18n", "strings.json"), "w", encoding="utf-8") as f:
    json.dump({k: list(S[k]) for k in sorted(S)}, f, ensure_ascii=False, separators=(",", ":"))

# Every key used in the web code must exist.
used = set()
for d, _, files in os.walk(os.path.join(WEB, "src")):
    for name in files:
        if name.endswith((".ts", ".tsx")):
            text = open(os.path.join(d, name), encoding="utf-8").read()
            used |= set(re.findall(r"""\bt\(\s*["']([a-z0-9_]+)["']""", text))
            used |= set(re.findall(r"""\bS\.([a-z0-9_]+)\b""", text))
missing = sorted(used - set(S))

# ---- lessons ---------------------------------------------------------------------------------
os.makedirs(os.path.join(WEB, "src", "data"), exist_ok=True)
shutil.copyfile(os.path.join(ROOT, "app", "src", "main", "assets", "train", "content.json"),
                os.path.join(WEB, "src", "data", "train-content.json"))

# ---- fonts -----------------------------------------------------------------------------------
from fontTools.ttLib import TTFont  # noqa: E402
fonts_out = os.path.join(WEB, "src", "assets", "fonts")
os.makedirs(fonts_out, exist_ok=True)
lic_out = os.path.join(WEB, "public", "licenses")
os.makedirs(lic_out, exist_ok=True)
for name in ["bricolage_display_bold", "bricolage_title_bold", "open_sans_regular", "open_sans_medium", "open_sans_semibold", "open_sans_bold"]:
    target = os.path.join(fonts_out, name + ".woff2")
    if not os.path.exists(target):
        font = TTFont(os.path.join(ROOT, "app", "src", "main", "res", "font", name + ".ttf"))
        font.flavor = "woff2"
        font.save(target)
for lic in ["OpenSans-OFL.txt", "BricolageGrotesque-OFL.txt"]:
    shutil.copyfile(os.path.join(ROOT, "licenses", lic), os.path.join(lic_out, lic))

# ---- Material icons --------------------------------------------------------------------------
MATERIAL = """home coffee_maker menu_book coffee school history settings terrain play_arrow pause skip_next flag mic
water_drop more_time restart_alt timer apps tune calculate troubleshoot compare_arrows star star_border add remove close
edit delete more_vert arrow_back expand_more keyboard_arrow_right check_circle lock cancel check keyboard_arrow_down
arrow_drop_down menu ios_share file_download file_upload photo_camera add_to_home_screen""".split()
icons = {}
base = os.path.join(WEB, "node_modules", "@material-design-icons", "svg", "round")
for n in MATERIAL:
    svg = open(os.path.join(base, n + ".svg"), encoding="utf-8").read()
    inner = re.search(r"<svg[^>]*>(.*)</svg>", svg, re.S).group(1)
    icons[n] = inner

# ---- original Toulouse Cupping icons ------------------------------------------------------------
tc = {}
icons_js = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "tc-icons.js")
if os.path.exists(icons_js):
    s = open(icons_js, encoding="utf-8").read()
    for part in s.split("export const ")[1:]:
        name = re.match(r"(\w+)", part).group(1)
        if name == "V":
            name = "V60Icon"
        svg = re.search(r'\("svg", \{([^\[]*?)children', part).group(1)
        sa = dict(re.findall(r'(\w+): "([^"]*)"', svg))
        els = re.findall(r'_jsx\("(path|circle|line|polyline|rect|ellipse)", \{([^}]*)\}', part)
        inner = ""
        for tag, blob in els:
            a = dict(re.findall(r'(\w+): "([^"]*)"', blob))
            attrs = " ".join(f'{re.sub("([A-Z])", lambda m: "-" + m.group(1).lower(), k)}="{v}"' for k, v in a.items())
            inner += f"<{tag} {attrs}/>"
        root = {k: v for k, v in sa.items() if k in ("viewBox", "fill", "stroke", "strokeWidth", "strokeLinecap", "strokeLinejoin")}
        tc[name.replace("Icon", "") or name] = {"root": root, "inner": inner}
    shutil.copyfile(icons_js, os.path.join(HERE, "tc-icons.js")) if os.path.abspath(icons_js) != os.path.join(HERE, "tc-icons.js") else None

with open(os.path.join(WEB, "src", "ui", "icons.data.ts"), "w", encoding="utf-8") as f:
    f.write("// Generated by tools/build_data.py. Material Icons Rounded (Apache 2.0) and the original Toulouse Cupping icons.\n")
    f.write("export const MATERIAL: Record<string, string> = " + json.dumps(icons, separators=(",", ":")) + ";\n")
    f.write("export const TC: Record<string, { root: Record<string, string>; inner: string }> = " + json.dumps(tc, separators=(",", ":")) + ";\n")

print(f"{len(S)} strings x 3, {len(icons)} material icons, {len(tc)} cupping icons. missing={missing}")
sys.exit(1 if missing else 0)
