# Strings used only by the web app (iPhone, iPad, any browser). key: (en, fr, es)
WEB = {
"layout_phone": ("Phone", "Téléphone", "Teléfono"),
"layout_tablet": ("Tablet", "Tablette", "Tableta"),
"layout_desk": ("Counter", "Comptoir", "Mostrador"),
"layout_mode_hint_web": (
    "Auto: phone layout in portrait, workstation on iPad, counter mode when the phone lies sideways on the brew or cupping screen.",
    "Auto : mise en page téléphone en portrait, poste de travail sur iPad, mode comptoir quand le téléphone est en paysage sur le brew ou le cupping.",
    "Auto: diseño de teléfono en vertical, estación de trabajo en iPad, modo mostrador con el teléfono en horizontal en el brew o la cata."),
"desk_section": ("Counter mode", "Mode comptoir", "Modo mostrador"),
"web_install_title": ("Install on your home screen", "Installer sur l'écran d'accueil", "Instalar en la pantalla de inicio"),
"web_install_ios": (
    "In Safari, tap Share, then Add to Home Screen. Mountain Fold then opens full screen and works offline.",
    "Dans Safari, touchez Partager, puis Sur l'écran d'accueil. Mountain Fold s'ouvre alors en plein écran et fonctionne hors ligne.",
    "En Safari, toca Compartir y luego Añadir a pantalla de inicio. Mountain Fold se abre a pantalla completa y funciona sin conexión."),
"web_install_other": (
    "Use your browser menu: Install app or Add to Home screen.",
    "Utilisez le menu du navigateur : Installer l'application ou Ajouter à l'écran d'accueil.",
    "Usa el menú del navegador: Instalar aplicación o Añadir a pantalla de inicio."),
"web_install_done": ("Installed. It works offline.", "Installée. Elle fonctionne hors ligne.", "Instalada. Funciona sin conexión."),
"web_dismiss": ("Not now", "Plus tard", "Ahora no"),
"web_storage_note": (
    "Your data stays in this browser on this device. Export a backup from time to time: it also moves your data between the Android app and this one.",
    "Vos données restent dans ce navigateur, sur cet appareil. Exportez une sauvegarde de temps en temps : elle sert aussi à passer vos données entre l'app Android et celle-ci.",
    "Tus datos se quedan en este navegador, en este dispositivo. Exporta una copia de vez en cuando: también sirve para pasar tus datos entre la app Android y esta."),
"web_storage_persisted": ("Storage protected from automatic cleanup.", "Stockage protégé du nettoyage automatique.", "Almacenamiento protegido de la limpieza automática."),
"web_background_note": (
    "iOS pauses web apps in the background. The timer keeps exact time, but step alerts and beeps only play while the app is on screen.",
    "iOS met les web apps en pause en arrière-plan. Le chrono garde l'heure exacte, mais les alertes d'étape et les bips ne sonnent qu'app à l'écran.",
    "iOS pausa las web apps en segundo plano. El cronómetro mantiene la hora exacta, pero los avisos y pitidos solo suenan con la app en pantalla."),
"web_update_ready": ("A new version is ready.", "Une nouvelle version est prête.", "Hay una nueva versión lista."),
"web_reload": ("Reload", "Recharger", "Recargar"),
"web_haptics_hint": (
    "On iPhone, Safari only allows a light tap on some buttons.",
    "Sur iPhone, Safari n'autorise qu'un léger retour sur certains boutons.",
    "En iPhone, Safari solo permite un leve toque en algunos botones."),
"web_sounds_hint": (
    "Beeps follow the ring/silent switch on iPhone.",
    "Les bips suivent le bouton sonnerie/silencieux de l'iPhone.",
    "Los pitidos siguen el interruptor de sonido/silencio del iPhone."),
"web_keep_awake_unsupported": (
    "This browser cannot keep the screen on.",
    "Ce navigateur ne peut pas garder l'écran allumé.",
    "Este navegador no puede mantener la pantalla encendida."),
"web_backup_saved": ("Backup ready. Choose where to save it.", "Sauvegarde prête. Choisissez où l'enregistrer.", "Copia lista. Elige dónde guardarla."),
"web_photos_note": (
    "Web backups include coffee photos. Android backups do not, so photos stay on each device.",
    "Les sauvegardes web incluent les photos des cafés. Les sauvegardes Android non : les photos restent sur chaque appareil.",
    "Las copias web incluyen las fotos de los cafés. Las de Android no: las fotos se quedan en cada dispositivo."),
"web_version": ("Web app %1$s", "Web app %1$s", "Web app %1$s"),
"web_open_app": ("Open the app", "Ouvrir l'app", "Abrir la app"),
"web_tap_to_enable_sound": ("Tap anywhere once to allow beeps.", "Touchez l'écran une fois pour autoriser les bips.", "Toca la pantalla una vez para permitir los pitidos."),
"web_offline": ("Offline", "Hors ligne", "Sin conexión"),
"web_file_ready": ("File ready. Tap Save to choose where it goes.", "Fichier prêt. Touchez Enregistrer pour choisir où le mettre.", "Archivo listo. Toca Guardar para elegir dónde."),
"web_share_failed":("Could not share the file.", "Impossible de partager le fichier.", "No se pudo compartir el archivo."),
"onb_postures_web": (
    "On iPhone, a quick assistant. On iPad, a coffee workstation. Phone sideways on the counter, a brewing companion.",
    "Sur iPhone, un assistant rapide. Sur iPad, un poste de travail café. Téléphone en paysage sur le plan de travail, un compagnon d'extraction.",
    "En iPhone, un asistente rápido. En iPad, una estación de trabajo de café. Teléfono en horizontal sobre la encimera, un compañero de preparación."),
"backup_hint_web": (
    "One JSON file with coffees, recipes, history, training, cupping sessions and preferences. Same format as the Android app.",
    "Un fichier JSON avec cafés, recettes, historique, entraînement, sessions de cupping et préférences. Même format que l'app Android.",
    "Un archivo JSON con cafés, recetas, historial, entrenamiento, sesiones de cata y preferencias. Mismo formato que la app Android."),
"flex_layout_web": ("Counter layout", "Disposition comptoir", "Disposición mostrador"),
"web_section": ("Web app", "Web app", "Web app"),
}
