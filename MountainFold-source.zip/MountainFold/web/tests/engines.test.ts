// Port of app/src/test/.../EngineTests.kt. Same inputs, same expected values as the Android app.
import { describe, expect, it } from 'vitest';
import {
  beverageEstimate, cToF, elapsedMs, formatClock, formatRatio, formatTenths, fToC, gToOz, hasStarted, idleTimer, lapTimer,
  ozToG, parseClock, parseNumber, pauseTimer, ratio, scaleSteps, solve, startTimer, StepSchedule,
} from '../src/core/coffee';
import { adjustGrind, BrewInput, diagnose } from '../src/core/copilot';
import { step, SYMPTOMS } from '../src/core/models';
import { parseVoice } from '../src/core/voice';
import { resolveLayout } from '../src/ui/layout';

describe('CoffeeEngine', () => {
  it('ratio is water over coffee', () => {
    expect(ratio(250, 15)!).toBeCloseTo(16.667, 3);
    expect(formatRatio(ratio(250, 15))).toBe('1:16.7');
    expect(formatRatio(ratio(36, 18))).toBe('1:2');
    expect(ratio(250, 0)).toBeNull();
  });

  it('solves each direction', () => {
    expect(solve('WATER', 15, null, 16.7)!.waterG).toBeCloseTo(250.5, 3);
    expect(solve('COFFEE', null, 240, 16)!.doseG).toBeCloseTo(15, 3);
    expect(solve('RATIO', 18, 36, null)!.ratio).toBeCloseTo(2, 3);
    expect(solve('WATER', 0, null, 16)).toBeNull();
    expect(solve('RATIO', 18, null, null)).toBeNull();
  });

  it('formats and parses clocks', () => {
    expect(formatClock(165)).toBe('02:45');
    expect(formatClock(57600)).toBe('16:00:00');
    expect(formatTenths(28_449)).toBe('28.4');
    expect(parseClock('3:05')).toBe(185);
    expect(parseClock('28')).toBe(28);
    expect(parseClock('1:02:00')).toBe(3720);
    expect(parseClock('a:b')).toBeNull();
    expect(parseNumber('15,5')).toBe(15.5);
  });

  it('round trips units', () => {
    expect(ozToG(gToOz(15))).toBeCloseTo(15, 9);
    expect(cToF(93)).toBeCloseTo(199.4, 9);
    expect(fToC(199.4)).toBeCloseTo(93, 9);
  });

  it('scales steps with water', () => {
    const steps = [step('Bloom', 'BLOOM', 0, 45), step('Pour', 'POUR', 45, 250), step('Wait', 'WAIT', 90)];
    expect(scaleSteps(steps, 250, 500).map((s) => s.targetWaterG)).toEqual([90, 500, null]);
    expect(scaleSteps(steps, 250, 250)).toEqual(steps);
  });

  it('estimates the beverage', () => {
    expect(beverageEstimate(250, 15, 'V60')).toBe(220);
    expect(beverageEstimate(36, 18, 'ESPRESSO')).toBe(36);
  });
});

describe('Timer', () => {
  it('counts only while running', () => {
    let now = 1_000;
    let t = idleTimer();
    expect(elapsedMs(t, now)).toBe(0);
    t = startTimer(t, now); now += 42_000;
    expect(elapsedMs(t, now)).toBe(42_000);
    t = pauseTimer(t, now); now += 10_000;
    expect(elapsedMs(t, now)).toBe(42_000);
    t = startTimer(t, now); now += 3_000;
    expect(elapsedMs(t, now)).toBe(45_000);
    expect(hasStarted(t)).toBe(true);
  });

  it('double start does not reset the clock', () => {
    let now = 1_000;
    let t = startTimer(idleTimer(), now); now += 5_000;
    t = startTimer(t, now); now += 5_000;
    expect(elapsedMs(t, now)).toBe(10_000);
  });

  it('laps', () => {
    let now = 1_000;
    let t = startTimer(idleTimer(), now); now += 45_000;
    t = lapTimer(t, now); now += 35_000;
    t = lapTimer(t, now);
    expect(t.laps).toEqual([45_000, 80_000]);
    expect(hasStarted(idleTimer())).toBe(false);
  });

  it('keeps counting through sleep: the clock is the wall clock', () => {
    const t = startTimer(idleTimer(), 0);
    // Phone locked for 15 s: no tick happened, the elapsed time is still right on wake.
    expect(elapsedMs(t, 75_000)).toBe(75_000);
  });
});

describe('StepSchedule', () => {
  const steps = [step('Bloom', 'BLOOM', 0, 45), step('Pour 1', 'POUR', 45, 120), step('Pour 2', 'POUR', 80, 190), step('Final', 'POUR', 130, 250)];

  it('finds the active step', () => {
    expect(StepSchedule.indexAt(steps, 0)).toBe(0);
    expect(StepSchedule.indexAt(steps, 44.9)).toBe(0);
    expect(StepSchedule.indexAt(steps, 45)).toBe(1);
    expect(StepSchedule.indexAt(steps, 500)).toBe(3);
    expect(StepSchedule.indexAt([], 10)).toBe(-1);
    expect(StepSchedule.endOf(steps, 1, 180)).toBe(80);
    expect(StepSchedule.endOf(steps, 3, 180)).toBe(180);
    expect(StepSchedule.targetWaterAt(steps, 2)).toBe(190);
  });

  it('+10 s pushes later steps only', () => {
    const [out, target] = StepSchedule.extendCurrent(steps, 50, 180, 10);
    expect(out.map((s) => s.startS)).toEqual([0, 45, 90, 140]);
    expect(target).toBe(190);
  });

  it('next step slides the schedule to now', () => {
    const [out, target] = StepSchedule.advanceNow(steps, 30, 180)!;
    expect(out.map((s) => s.startS)).toEqual([0, 30, 65, 115]);
    expect(target).toBe(165);
    expect(StepSchedule.indexAt(out, 30)).toBe(1);
    expect(StepSchedule.advanceNow(steps, 140, 180)).toBeNull();
  });
});

describe('Copilot', () => {
  const v60Steps = [step('Bloom', 'BLOOM', 0, 45), step('Pour', 'POUR', 45, 250)];
  const filter = (o: { temp?: number | null; time?: number | null; target?: number; grind?: string } = {}): BrewInput => ({
    method: 'V60', doseG: 15, waterG: 250, tempC: o.temp === undefined ? 92 : o.temp, timeS: o.time === undefined ? 165 : o.time,
    targetTimeS: o.target ?? 165, grind: o.grind ?? 'medium-fine', steps: v60Steps,
  });
  const shot = (o: { yieldG?: number; time?: number | null; temp?: number | null; grind?: string } = {}): BrewInput => ({
    method: 'ESPRESSO', doseG: 18, waterG: o.yieldG ?? 36, tempC: o.temp === undefined ? 93 : o.temp,
    timeS: o.time === undefined ? 28 : o.time, targetTimeS: 28, grind: o.grind ?? '8', steps: [],
  });

  it('sour filter raises the temperature only (example from the brief)', () => {
    const d = diagnose(filter(), ['SOUR'])!;
    expect(d.cause).toBe('UNDER_EXTRACTION');
    expect(d.change).toBe('TEMP_UP');
    expect(d.suggestion.tempC).toBe(94);
    expect(d.suggestion.doseG).toBe(15);
    expect(d.suggestion.waterG).toBe(250);
    expect(d.suggestion.grind).toBe('medium-fine');
  });

  it('sour and fast goes finer', () => {
    const d = diagnose(filter({ time: 130, target: 180 }), ['SOUR'])!;
    expect(d.change).toBe('GRIND_FINER');
    expect(d.grindStepped).toBe(false);
    expect(d.timeIsEstimate).toBe(true);
    expect(d.suggestion.targetTimeS).toBe(200);
  });

  it('steps a numeric grind', () => {
    const d = diagnose(filter({ time: 240, target: 180, grind: '22' }), ['BITTER'])!;
    expect(d.change).toBe('GRIND_COARSER');
    expect(d.grindStepped).toBe(true);
    expect(d.suggestion.grind).toBe('23');
    expect(adjustGrind('22.5', true)).toBe('22');
    expect(adjustGrind('22', true)).toBe('21');
    expect(adjustGrind('2.5', false)).toBe('3');
    expect(adjustGrind('medium', true)).toBeNull();
  });

  it('sour plus bitter means uneven and a longer bloom', () => {
    const d = diagnose(filter(), ['SOUR', 'BITTER'])!;
    expect(d.symptom).toBe('HOLLOW');
    expect(d.change).toBe('BLOOM_LONGER');
    expect(d.suggestion.steps.map((s) => s.startS)).toEqual([0, 60]);
    expect(d.suggestion.targetTimeS).toBe(180);
  });

  it('espresso rules', () => {
    expect(diagnose(shot({ time: 19 }), ['SOUR'])!.change).toBe('GRIND_FINER');
    const longer = diagnose(shot({ yieldG: 30 }), ['SOUR'])!;
    expect(longer.change).toBe('YIELD_UP');
    expect(longer.suggestion.waterG).toBe(34);
    expect(diagnose(shot({ time: 40 }), ['BITTER'])!.change).toBe('GRIND_COARSER');
    expect(diagnose(shot(), ['ASTRINGENT'])!.change).toBe('PUCK_PREP');
    expect(diagnose(shot(), ['ASTRINGENT'])!.recipeChanged).toBe(false);
  });

  it('does not fix stale coffee with settings', () => {
    const d = diagnose({ ...filter(), roastAgeDays: 70 }, ['FLAT'])!;
    expect(d.cause).toBe('STALE_COFFEE');
    expect(d.recipeChanged).toBe(false);
  });

  it('never changes more than one variable', () => {
    const inputs = [filter(), filter({ temp: 96, time: 240, grind: '20' }), filter({ temp: null, time: null }), shot(), shot({ yieldG: 45, time: 35, temp: null })];
    for (const input of inputs) for (const s of SYMPTOMS) {
      const d = diagnose(input, [s]);
      expect(d, `${s} on ${input.method}`).not.toBeNull();
      const sg = d!.suggestion;
      const changed = [sg.doseG !== input.doseG, sg.waterG !== input.waterG, sg.tempC !== input.tempC, sg.grind !== input.grind,
        JSON.stringify(sg.steps) !== JSON.stringify(input.steps)].filter(Boolean).length;
      expect(changed, `${s} on ${input.method} changed ${changed} variables`).toBeLessThanOrEqual(1);
      expect(d!.variables.length).toBeGreaterThan(0);
    }
    expect(diagnose(filter(), [])).toBeNull();
  });
});

describe('Layout (web version of FoldStateResolver)', () => {
  it('iPhone in portrait is the closed Fold', () => {
    expect(resolveLayout(393, 852, 'AUTO').posture).toBe('CLOSED');
    expect(resolveLayout(375, 667, 'AUTO').posture).toBe('CLOSED');
  });
  it('iPad is the open Fold, in both orientations', () => {
    expect(resolveLayout(820, 1180, 'AUTO').posture).toBe('OPEN');
    expect(resolveLayout(1180, 820, 'AUTO').posture).toBe('OPEN');
    expect(resolveLayout(744, 1133, 'AUTO').posture).toBe('OPEN');
  });
  it('iPhone on its side is the counter mode (Flex)', () => {
    const l = resolveLayout(852, 393, 'AUTO');
    expect(l.posture).toBe('FLEX');
    expect(l.phoneSideways).toBe(true);
    expect(l.rowSplit).toBe(true);
    // Pro Max sideways is wide but still too short to be a workstation.
    expect(resolveLayout(932, 430, 'AUTO').posture).toBe('FLEX');
  });
  it('a folded screen reported by the browser is Flex, split top and bottom', () => {
    const l = resolveLayout(840, 950, 'AUTO', true);
    expect(l.posture).toBe('FLEX');
    expect(l.phoneSideways).toBe(false);
    expect(l.rowSplit).toBe(false);
  });
  it('the setting wins', () => {
    expect(resolveLayout(393, 852, 'FLEX').posture).toBe('FLEX');
    expect(resolveLayout(393, 852, 'FLEX').phoneSideways).toBe(false);
    expect(resolveLayout(1180, 820, 'CLOSED').posture).toBe('CLOSED');
    expect(resolveLayout(852, 393, 'CLOSED').posture).toBe('CLOSED');
  });
});

describe('Voice commands', () => {
  it('parses the commands from the brief', () => {
    expect(parseVoice('Start timer')).toEqual({ kind: 'START' });
    expect(parseVoice('Pause')).toEqual({ kind: 'PAUSE' });
    expect(parseVoice('Add 50 grams')).toEqual({ kind: 'ADD', grams: 50 });
    expect(parseVoice('Next step')).toEqual({ kind: 'NEXT' });
    expect(parseVoice('Reset')).toEqual({ kind: 'RESET' });
    expect(parseVoice("What's my ratio?")).toEqual({ kind: 'RATIO' });
    expect(parseVoice('ajoute 37,5 grammes')).toEqual({ kind: 'ADD', grams: 37.5 });
    expect(parseVoice('étape suivante')).toEqual({ kind: 'NEXT' });
    expect(parseVoice('démarre')).toEqual({ kind: 'START' });
    expect(parseVoice('siguiente paso')).toEqual({ kind: 'NEXT' });
    expect(parseVoice('tell me a joke')).toEqual({ kind: 'UNKNOWN' });
  });
});
