// Second pass: every remaining screen, the backup import/export through the UI, CSV and PDF downloads,
// dark mode on the phone and the counter layouts of the trainer and the cupping.
// Usage: node tests/e2e/screens.mjs http://localhost:4173/ out-dir
import { chromium } from 'playwright-core';
import fs from 'node:fs';
import path from 'node:path';

const base = process.argv[2] ?? 'http://localhost:4173/';
const out = process.argv[3] ?? 'shots2';
fs.mkdirSync(out, { recursive: true });
const exe = process.env.CHROME ?? '/opt/pw-browsers/chromium-1194/chrome-linux/chrome';
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1';
const errors = [];
const notes = [];

// The Android fixture, with phone-friendly units and layout so the screens read normally.
const fixture = JSON.parse(fs.readFileSync(new URL('../fixtures/android-backup.json', import.meta.url), 'utf8'));
Object.assign(fixture.settings, { layoutOverride: 'AUTO', weightUnit: 'G', tempUnit: 'C' });
const fixturePath = path.join(out, 'import.json');
fs.writeFileSync(fixturePath, JSON.stringify(fixture, null, 4));

const browser = await chromium.launch({ executablePath: exe, args: ['--no-sandbox'] });
const ctx = await browser.newContext({ viewport: { width: 393, height: 852 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, userAgent: UA, locale: 'fr-FR', acceptDownloads: true });
await ctx.addInitScript(() => { try { localStorage.setItem('mf.lang', '"fr"'); localStorage.setItem('mf.installHintSeen', 'true'); } catch {} });
const page = await ctx.newPage();
page.setDefaultTimeout(7000);
page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
page.on('console', (m) => { if (m.type() === 'error') errors.push(`console: ${m.text()}`); });

const shot = (name) => page.screenshot({ path: `${out}/${name}.png` });
const wait = (ms = 300) => page.waitForTimeout(ms);
const btn = (name, exact = true) => page.getByRole('button', { name, exact }).first();
const tap = async (name, exact = true) => { await btn(name, exact).click(); await wait(); };
const row = async (text) => { await page.getByRole('button').filter({ hasText: text }).first().click(); await wait(400); };
const nav = async (label) => { await page.locator(`nav button[aria-label="${label}"]`).first().click(); await wait(); };
async function step(name, fn) {
  try { await fn(); } catch (e) { errors.push(`step ${name}: ${e.message.split('\n')[0]}`); await shot(`ERR_${name}`).catch(() => {}); }
}
async function snackbar() { return (await page.locator('.snackbar').first().textContent({ timeout: 3000 }).catch(() => ''))?.trim(); }

await page.goto(base);
await wait(800);
await step('onboarding', async () => { for (const l of ['Suivant', 'Suivant', 'Suivant', 'Commencer']) await tap(l); await wait(500); });

await step('import', async () => {
  await page.getByRole('button', { name: 'Réglages' }).first().click();
  await wait(400);
  await shot('30_settings_top');
  await btn('Importer').scrollIntoViewIfNeeded();
  await shot('31_settings_backup');
  await tap('Importer');
  const chooser = page.waitForEvent('filechooser');
  await page.getByRole('dialog').getByRole('button', { name: 'Importer' }).click();
  await (await chooser).setFiles(fixturePath);
  await wait(900);
  notes.push(`import snackbar: ${await snackbar()}`);
  await shot('32_after_import_dark_toulouse');
});

await step('export', async () => {
  const dl = page.waitForEvent('download', { timeout: 8000 });
  await tap('Exporter');
  const d = await dl;
  const file = path.join(out, d.suggestedFilename());
  await d.saveAs(file);
  const j = JSON.parse(fs.readFileSync(file, 'utf8'));
  notes.push(`export: ${d.suggestedFilename()} app=${j.app} coffees=${j.coffees.length} brews=${j.brews.length} cupping=${j.cuppingSessions.length}/${j.cuppingCoffees.length} lab=${j.labRecipes.length} palette=${j.settings.palette}`);
  await page.getByRole('button', { name: 'Retour' }).first().click();
  await wait(400);
});

await step('home_dark', async () => { await nav('Accueil').catch(() => {}); await wait(300); await shot('33_home_dark'); });
await step('calculator', async () => { await tap('Calculateur'); await shot('34_calculator'); await page.getByRole('button', { name: 'Retour' }).first().click(); await wait(); });
await step('diagnose', async () => { await tap('Diagnostic'); await wait(400); await shot('35_diagnose'); await page.getByRole('button', { name: 'Retour' }).first().click(); await wait(); });
await step('grind', async () => { await tap('Mouture'); await shot('36_grind'); await page.getByRole('button', { name: 'Retour' }).first().click(); await wait(); });
await step('compare', async () => { await tap('Comparer'); await shot('37_compare'); await page.getByRole('button', { name: 'Retour' }).first().click(); await wait(); });

await step('history', async () => {
  await nav('Historique');
  await shot('38_history');
  await page.getByRole('button').filter({ hasText: 'Ethiopia Guji' }).first().click();
  await wait(400);
  await shot('39_brew_detail');
  await page.getByRole('button', { name: 'Retour' }).first().click();
  await wait();
});

await step('coffee_detail', async () => {
  await nav('Cafés');
  await page.getByRole('button').filter({ hasText: 'Ethiopia Guji' }).first().click();
  await wait(400);
  await shot('40_coffee_detail');
  await page.getByRole('button', { name: 'Retour' }).first().click();
  await wait();
});

await step('recipe_editor', async () => {
  await nav('Recettes');
  await page.getByRole('button').filter({ hasText: 'V60 classique' }).first().click();
  await wait(400);
  await shot('41_recipe_detail');
  await page.getByRole('button', { name: 'Modifier' }).first().click();
  await wait(400);
  await shot('42_recipe_editor');
  await page.getByRole('button', { name: 'Retour' }).first().click();
  await wait();
  await page.getByRole('button', { name: 'Retour' }).first().click().catch(() => {});
  await wait();
});

await step('lesson', async () => {
  await nav('Train');
  await shot('43_train_dark');
  await row('École du café');
  await shot('44_school');
  await page.locator('.list-row.clickable').first().click();
  await wait(400);
  await shot('45_lesson_p1');
  for (let i = 0; i < 6; i++) {
    const start = page.getByRole('button', { name: 'Lancer la validation' });
    if (await start.count()) break;
    await tap('Suivant');
  }
  await shot('46_lesson_last_page');
  // Train desk: the phone sideways while learning.
  await page.setViewportSize({ width: 852, height: 393 });
  await wait(500);
  await shot('47_lesson_counter');
  await page.setViewportSize({ width: 393, height: 852 });
  await wait(400);
  await tap('Lancer la validation');
  for (let i = 0; i < 6; i++) {
    const opt = page.locator('button.option').first();
    if (!(await opt.count())) break;
    await opt.click();
    await wait(250);
    if (i === 0) await shot('48_quiz_feedback');
    const fin = page.getByRole('button', { name: 'Voir le résultat' });
    if (await fin.count()) { await fin.first().click(); break; }
    await tap('Suivant');
  }
  await wait(500);
  await shot('49_result');
  await tap('Terminé');
});

await step('lab', async () => {
  // The result closes back to the school, like on Android.
  if (await page.getByRole('heading', { name: 'École du café' }).count()) { await page.getByRole('button', { name: 'Retour' }).first().click(); await wait(); }
  await row("Labo d'extraction");
  await shot('50_extraction_lab');
  await page.getByRole('button', { name: 'Retour' }).first().click();
  await wait();
});

await step('cupping', async () => {
  await nav('Cupping');
  await wait(500);
  await shot('51_cupping_imported');
  const menu = async (label) => { await page.getByRole('button', { name: 'Menu cupping' }).click(); await wait(250); await page.getByRole('menuitem', { name: label }).click(); await wait(400); };
  await menu('Infos Session');
  await shot('52_session_info');
  await tap('Valider');
  await wait();
  await menu('Sessions précédentes');
  await shot('53_sessions');
  await page.getByRole('button', { name: 'Retour' }).first().click().catch(() => {});
  await wait();
  await menu('Inviter / QR Code');
  await shot('54_invite_qr');
  await page.keyboard.press('Escape');
  await wait();
  await page.getByRole('button', { name: 'Chronomètre' }).first().click();
  await wait(300);
  await page.getByRole('button', { name: /6 min/ }).first().click();
  await wait(1200);
  await shot('55_timer');
  await page.keyboard.press('Escape');
  await wait();
});

await step('summary', async () => {
  await page.getByRole('button', { name: 'Menu cupping' }).click();
  await wait(250);
  await page.getByRole('menuitem', { name: 'Tableau récapitulatif' }).click();
  await wait(500);
  await shot('56_summary');
  let dl = page.waitForEvent('download', { timeout: 8000 });
  dl.catch(() => {});
  await tap(/CSV/, false);
  let d = await dl;
  await d.saveAs(path.join(out, d.suggestedFilename()));
  const csv = fs.readFileSync(path.join(out, d.suggestedFilename()), 'utf8');
  notes.push(`csv: ${d.suggestedFilename()} bom=${csv.charCodeAt(0) === 0xfeff} lines=${csv.trim().split('\n').length} row1=${csv.split('\n')[1]}`);
  dl = page.waitForEvent('download', { timeout: 15000 });
  dl.catch(() => {});
  await tap('Télécharger PDF', false);
  d = await dl;
  await d.saveAs(path.join(out, d.suggestedFilename()));
  const pdf = fs.readFileSync(path.join(out, d.suggestedFilename()));
  notes.push(`pdf: ${d.suggestedFilename()} bytes=${pdf.length} head=${pdf.subarray(0, 5).toString()}`);
  await page.getByRole('button', { name: 'Retour' }).first().click().catch(() => {});
  await wait();
});

await step('brewing_lab', async () => {
  await page.getByRole('button', { name: 'Menu cupping' }).click();
  await wait(250);
  await page.getByRole('menuitem', { name: 'Mode Brewing' }).click();
  await wait(500);
  await shot('57_brewing_lab');
  await page.setViewportSize({ width: 852, height: 393 });
  await wait(500);
  await shot('58_brewing_lab_counter');
  await page.setViewportSize({ width: 393, height: 852 });
  await wait(300);
  await page.getByRole('button', { name: 'Retour' }).first().click().catch(() => {});
  await wait();
});

await step('cupping_counter', async () => {
  await page.setViewportSize({ width: 852, height: 393 });
  await wait(500);
  await shot('59_cupping_counter');
  await page.setViewportSize({ width: 393, height: 852 });
  await wait(300);
});

await step('settings_bottom', async () => {
  await page.getByRole('button', { name: 'Réglages' }).first().click().catch(async () => { await nav('Accueil'); await page.getByRole('button', { name: 'Réglages' }).first().click(); });
  await wait(400);
  await page.mouse.wheel(0, 5000);
  await page.evaluate(() => document.querySelectorAll('.scroll').forEach((e) => e.scrollTo(0, 1e6)));
  await wait(300);
  await shot('60_settings_bottom');
});

await ctx.close();

// iPad landscape: the trainer and cupping workstations.
const tab = await browser.newContext({ viewport: { width: 1180, height: 820 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, userAgent: UA.replace('iPhone', 'iPad'), locale: 'fr-FR', acceptDownloads: true });
await tab.addInitScript(() => { try { localStorage.setItem('mf.lang', '"fr"'); localStorage.setItem('mf.installHintSeen', 'true'); } catch {} });
const p2 = await tab.newPage();
p2.setDefaultTimeout(7000);
p2.on('pageerror', (e) => errors.push(`pageerror(ipad): ${e.message}`));
p2.on('console', (m) => { if (m.type() === 'error') errors.push(`console(ipad): ${m.text()}`); });
await p2.goto(base);
await p2.waitForTimeout(700);
try {
  for (const l of ['Suivant', 'Suivant', 'Suivant', 'Commencer']) { await p2.getByRole('button', { name: l, exact: true }).first().click(); await p2.waitForTimeout(250); }
  await p2.locator('nav button[aria-label="Train"]').click();
  await p2.waitForTimeout(300);
  await p2.getByRole('button').filter({ hasText: 'École du café' }).first().click();
  await p2.waitForTimeout(300);
  await p2.locator('.list-row.clickable').first().click();
  await p2.waitForTimeout(400);
  await p2.screenshot({ path: `${out}/61_ipad_lesson.png` });
  await p2.locator('nav button[aria-label="Cupping"]').click();
  await p2.waitForTimeout(400);
  await p2.getByRole('button', { name: 'Menu cupping' }).click();
  await p2.waitForTimeout(250);
  await p2.getByRole('menuitem', { name: 'Tableau récapitulatif' }).click();
  await p2.waitForTimeout(500);
  await p2.screenshot({ path: `${out}/62_ipad_summary.png` });
  await p2.locator('nav button[aria-label="Réglages"], button[aria-label="Réglages"]').first().click();
  await p2.waitForTimeout(400);
  await p2.screenshot({ path: `${out}/63_ipad_settings.png` });
} catch (e) { errors.push(`ipad: ${e.message.split('\n')[0]}`); await p2.screenshot({ path: `${out}/ERR_ipad.png` }); }
await tab.close();

await browser.close();
fs.writeFileSync(`${out}/errors.txt`, errors.join('\n'));
fs.writeFileSync(`${out}/notes.txt`, notes.join('\n'));
console.log(notes.join('\n'));
console.log(errors.length ? errors.join('\n') : 'no errors');
