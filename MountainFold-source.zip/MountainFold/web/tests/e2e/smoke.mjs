// Smoke run in Chromium with iPhone and iPad viewports. Not Safari: it checks layouts and flows, not WebKit quirks.
// Usage: node tests/e2e/smoke.mjs http://localhost:4173/ out-dir
import { chromium } from 'playwright-core';
import fs from 'node:fs';

const base = process.argv[2] ?? 'http://localhost:4173/';
const out = process.argv[3] ?? 'shots';
fs.mkdirSync(out, { recursive: true });
const exe = process.env.CHROME ?? '/opt/pw-browsers/chromium-1194/chrome-linux/chrome';
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1';
const errors = [];

const browser = await chromium.launch({ executablePath: exe, args: ['--no-sandbox'] });
async function phone(scheme = 'light') {
  const ctx = await browser.newContext({ viewport: { width: 393, height: 852 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, userAgent: UA, colorScheme: scheme, locale: 'fr-FR' });
  await ctx.addInitScript(() => { try { localStorage.setItem('mf.lang', '"fr"'); localStorage.setItem('mf.installHintSeen', 'true'); } catch {} });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(`console: ${m.text()}`); });
  return { ctx, page };
}
const shot = (page, name) => page.screenshot({ path: `${out}/${name}.png` });
const tap = async (page, name, opts = {}) => { await page.getByRole('button', { name, exact: opts.exact ?? true }).first().click(); await page.waitForTimeout(250); };
const nav = (page, label) => page.locator(`nav button[aria-label="${label}"]`).first().click().then(() => page.waitForTimeout(300));

const { ctx, page } = await phone();
await page.goto(base);
await page.waitForTimeout(800);
await shot(page, '01_onboarding');
await tap(page, 'Suivant');
await shot(page, '02_onboarding_methods');
await tap(page, 'Suivant');
await page.getByRole('button', { name: 'Comandante C40' }).click();
await tap(page, 'Suivant');
await tap(page, 'Commencer');
await page.waitForTimeout(600);
await shot(page, '03_home');

await nav(page, 'Brew');
await tap(page, 'Démarrer');
await page.waitForTimeout(2300);
await shot(page, '04_brew_running');
await tap(page, '+50 g');

// Sideways phone on the counter: brew companion.
await page.setViewportSize({ width: 852, height: 393 });
await page.waitForTimeout(500);
await shot(page, '05_counter_brew');
await page.setViewportSize({ width: 393, height: 852 });
await page.waitForTimeout(400);
await tap(page, 'Terminer');
await page.waitForTimeout(400);
await shot(page, '06_log');
await page.getByRole('button', { name: '4' }).first().click();
await tap(page, 'Enregistrer');
await page.waitForTimeout(500);
await shot(page, '07_history');

await nav(page, 'Recettes');
await shot(page, '08_recipes');
await nav(page, 'Cafés');
await tap(page, 'Ajouter un café');
await page.getByLabel('Nom').fill('Ethiopia Guji');
await tap(page, 'Enregistrer');
await page.waitForTimeout(400);
await shot(page, '09_coffee');

await nav(page, 'Cupping');
await page.waitForTimeout(500);
await shot(page, '10_cupping');
const slider = page.getByRole('slider').first();
const box = await slider.boundingBox();
await page.mouse.click(box.x + box.width * 0.85, box.y + box.height / 2);
await page.waitForTimeout(300);
await shot(page, '11_cupping_scored');
await page.getByRole('button', { name: 'Menu cupping' }).click();
await page.waitForTimeout(300);
await shot(page, '12_cupping_menu');
await page.getByRole('menuitem', { name: 'Roue des Saveurs' }).click();
await page.waitForTimeout(500);
await shot(page, '13_wheel');
await tap(page, 'Fermer');

await nav(page, 'Train');
await page.waitForTimeout(400);
await shot(page, '14_train');
await page.getByRole('button', { name: 'Démarrer' }).nth(1).click();
await page.waitForTimeout(400);
await shot(page, '15_daily');

await ctx.close();

// iPad: workstation.
const tab = await browser.newContext({ viewport: { width: 1180, height: 820 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, userAgent: UA.replace('iPhone', 'iPad'), locale: 'fr-FR', colorScheme: 'dark' });
await tab.addInitScript(() => { try { localStorage.setItem('mf.lang', '"fr"'); localStorage.setItem('mf.installHintSeen', 'true'); } catch {} });
const p2 = await tab.newPage();
p2.on('pageerror', (e) => errors.push(`pageerror(ipad): ${e.message}`));
p2.on('console', (m) => { if (m.type() === 'error') errors.push(`console(ipad): ${m.text()}`); });
await p2.goto(base);
await p2.waitForTimeout(700);
for (const label of ['Suivant', 'Suivant', 'Suivant', 'Commencer']) await tap(p2, label);
await p2.waitForTimeout(600);
await shot(p2, '20_ipad_home');
await p2.locator('nav button[aria-label="Brew"]').click();
await p2.waitForTimeout(300);
await shot(p2, '21_ipad_brew');
await p2.locator('nav button[aria-label="Cupping"]').click();
await p2.waitForTimeout(500);
await shot(p2, '22_ipad_cupping');
await p2.locator('nav button[aria-label="Train"]').click();
await p2.waitForTimeout(300);
await shot(p2, '23_ipad_train');
await p2.locator('nav button[aria-label="Recettes"]').click();
await p2.waitForTimeout(300);
await p2.getByRole('button').filter({ hasText: 'V60 classique' }).first().click();
await p2.waitForTimeout(300);
await shot(p2, '24_ipad_recipes');
await tab.close();

await browser.close();
fs.writeFileSync(`${out}/errors.txt`, errors.join('\n'));
console.log(errors.length ? errors.join('\n') : 'no errors');
