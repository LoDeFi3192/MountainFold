// Port of app/src/test/.../TrainEngineTests.kt, against the same content.json the Android app ships.
import { describe, expect, it } from 'vitest';
import { BrewInput, diagnose } from '../src/core/copilot';
import { isEspresso, SYMPTOMS, Symptom } from '../src/core/models';
import { KRandom } from '../src/core/random';
import {
  acceptable, Breakdown, BrewSignal, defaultFilterInput, defaultShotInput, DialIn, EXAM_CATEGORIES, EXAM_SKILLS, ExtractionSim,
  FilterInput, lessonsByLevel, ShotInput, SKILLS, SkillTree, TrainContent, TrainEvent, TrainProgress,
} from '../src/core/train';
import raw from '../src/data/train-content.json';

const content = raw as unknown as TrainContent;
const byLevel = lessonsByLevel(content);
const lessonOf = (id: string) => content.lessons.find((l) => l.id === id);
const DAY = 86_400_000;
const dayOf = (ms: number) => Math.floor(ms / DAY);
const at = (d: number) => d * DAY + 3_600_000;
const lesson = (id: string, d: number, passed = true, breakdown = ''): TrainEvent =>
  ({ createdAt: at(d), kind: 'LESSON', refId: id, correct: passed ? 3 : 1, total: 3, xp: passed ? 75 : 0, passed, breakdown });
const ev = (d: number, kind: TrainEvent['kind'], refId: string, correct: number, total: number, xp: number, passed: boolean, breakdown = ''): TrainEvent =>
  ({ createdAt: at(d), kind, refId, correct, total, xp, passed, breakdown });
const compute = (events: TrainEvent[], today: number) => TrainProgress.compute(events, byLevel, today, dayOf);
const filterSim = (o: Partial<FilterInput> = {}) => ExtractionSim.filter({ ...defaultFilterInput(), ...o });
const shotSim = (o: Partial<ShotInput> = {}) => ExtractionSim.shot({ ...defaultShotInput(), ...o });

describe('Train content', () => {
  it('ships the whole curriculum', () => {
    expect(content.lessons.length).toBe(26);
    expect(new Set(content.lessons.map((l) => l.id)).size).toBe(26);
    for (let level = 1; level <= 8; level++) expect(byLevel.get(level)?.length ?? 0, `level ${level}`).toBeGreaterThan(0);
    expect(new Set(content.lessons.map((l) => l.skill))).toEqual(new Set(SKILLS));
    for (const l of content.lessons) {
      expect((l.blocks?.length ?? 0) >= 3 && (l.objectives?.length ?? 0) > 0 && (l.questions?.length ?? 0) >= 3, l.id).toBe(true);
      for (const q of [...(l.questions ?? []), ...content.bank]) {
        expect(q.correct ?? 0, q.id).toBe(0);
        expect(q.options.length >= 3 && q.options.length <= 4, q.id).toBe(true);
        for (const lang of ['en', 'fr', 'es'] as const) expect(!!q.prompt[lang]?.trim() && !!q.why[lang]?.trim(), `${q.id} ${lang}`).toBe(true);
      }
    }
  });

  it('lessons are interactive', () => {
    expect(content.lessons.filter((l) => l.sim && l.sim !== 'NONE').length).toBeGreaterThanOrEqual(10);
    expect(content.lessons.filter((l) => l.brewTask).length).toBeGreaterThanOrEqual(15);
    expect(content.lessons.filter((l) => (l.sim && l.sim !== 'NONE') || l.brewTask).length).toBeGreaterThanOrEqual(20);
  });

  it('every exam category has enough questions', () => {
    for (const c of EXAM_CATEGORIES.filter((x) => x !== 'TROUBLESHOOTING')) {
      const skills = EXAM_SKILLS[c];
      const n = content.lessons.filter((l) => skills.includes(l.skill)).reduce((a, l) => a + (l.questions?.length ?? 0), 0)
        + content.bank.filter((q) => q.skill && skills.includes(q.skill)).length;
      expect(n, `${c} has ${n} questions`).toBeGreaterThanOrEqual(10);
    }
  });

  it('copilot and brew patterns map to real lessons', () => {
    for (const s of SYMPTOMS) for (const espresso of [false, true]) expect(lessonOf(TrainProgress.lessonForSymptom(s, espresso)), s).toBeDefined();
    const inputs: BrewInput[] = [
      { method: 'V60', doseG: 15, waterG: 250, tempC: 92, timeS: 165, targetTimeS: 180, grind: '22' },
      { method: 'ESPRESSO', doseG: 18, waterG: 36, tempC: 93, timeS: 20, targetTimeS: 28, grind: '8' },
    ];
    for (const input of inputs) for (const s of SYMPTOMS) {
      const d = diagnose({ ...input, roastAgeDays: s === 'FLAT' ? 70 : null }, [s])!;
      expect(lessonOf(TrainProgress.lessonForDiagnosis(d, isEspresso(input.method))), `${s} ${input.method}`).toBeDefined();
    }
  });
});

describe('ExtractionSim', () => {
  const base = filterSim();
  it('default recipe is balanced', () => {
    expect(base.zone).toBe('BALANCED');
    expect(base.strength).toBe('BALANCED');
    expect(base.timeS).toBe(180);
    expect(base.uneven).toBe(false);
  });
  it('finer is slower and extracts more until the bed chokes', () => {
    const finer = filterSim({ grind: 70 });
    expect(finer.timeS > base.timeS && finer.extractionPct > base.extractionPct).toBe(true);
    const coarse = filterSim({ grind: 20 });
    expect(coarse.timeS).toBeLessThan(base.timeS);
    expect(coarse.zone).toBe('UNDER');
    const choked = filterSim({ grind: 100 });
    const edge = filterSim({ grind: ExtractionSim.CHOKE_POINT });
    expect(choked.uneven && choked.extractionPct < edge.extractionPct && choked.timeS > edge.timeS).toBe(true);
  });
  it('temperature and agitation raise extraction', () => {
    expect(filterSim({ tempC: 97 }).extractionPct).toBeGreaterThan(base.extractionPct);
    expect(filterSim({ tempC: 87 }).extractionPct).toBeLessThan(base.extractionPct);
    expect(filterSim({ agitation: 2 }).extractionPct).toBeGreaterThan(base.extractionPct);
  });
  it('a longer ratio is weaker yet more extracted', () => {
    const longer = filterSim({ waterG: 300 });
    expect(longer.tdsPct < base.tdsPct && longer.extractionPct > base.extractionPct).toBe(true);
    const strongUnder = filterSim({ grind: 25, doseG: 22, waterG: 250, tempC: 88 });
    expect(strongUnder.zone).toBe('UNDER');
    expect(strongUnder.strength).toBe('STRONG');
  });
  it('espresso shot', () => {
    const shot = shotSim();
    expect(shot.timeS).toBe(28);
    expect(shot.zone).toBe('BALANCED');
    expect(shotSim({ grind: 30 }).timeS).toBeLessThan(25);
    const long = shotSim({ yieldG: 50 });
    expect(long.extractionPct > shot.extractionPct && long.tdsPct < shot.tdsPct).toBe(true);
    const ch = shotSim({ channeling: true });
    expect(ch.uneven && ch.timeS < shot.timeS && ch.extractionPct < shot.extractionPct).toBe(true);
  });
  it('extraction yield formula and milk phases', () => {
    expect(ExtractionSim.extractionYield(15, 220, 1.36)!).toBeCloseTo(19.95, 2);
    expect(ExtractionSim.extractionYield(0, 220, 1.36)).toBeNull();
    expect(ExtractionSim.milkPhase(20)).toBe('STRETCH');
    expect(ExtractionSim.milkPhase(45)).toBe('ROLL');
    expect(ExtractionSim.milkPhase(60)).toBe('READY');
    expect(ExtractionSim.milkPhase(75)).toBe('TOO_HOT');
  });
});

describe('DialIn generator', () => {
  it('agrees with the copilot and has clean distractors over 600 scenarios', () => {
    const r = KRandom.ofLong(42);
    for (let n = 0; n < 600; n++) {
      const s = DialIn.generate(r, n % 2 === 0);
      expect(s.options.length).toBe(4);
      expect(new Set(s.options).size).toBe(4);
      expect(diagnose(s.input, [s.symptom])!.change).toBe(s.options[0]);
      expect(acceptable(s.symptom)).toContain(s.options[0]);
      for (const wrong of s.options.slice(1)) expect(acceptable(s.symptom), `${s.symptom}: ${wrong}`).not.toContain(wrong);
    }
  });
  it('sessions are varied and repeatable by seed', () => {
    const a = DialIn.session(KRandom.ofLong(7), false, 5);
    const b = DialIn.session(KRandom.ofLong(7), false, 5);
    expect(a.length).toBe(5);
    expect(a.map((s) => [s.symptom, s.options])).toEqual(b.map((s) => [s.symptom, s.options]));
    expect(new Set(a.map((s) => `${s.symptom}/${s.options[0]}`)).size).toBe(5);
    expect(a.some((s) => isEspresso(s.input.method))).toBe(false);
    expect(DialIn.session(KRandom.ofLong(7), true, 5).every((s) => isEspresso(s.input.method))).toBe(true);
  });
  it('example from the brief: 18 g in, 36 g out, 18 s, very sour means grind finer', () => {
    const s = DialIn.build(KRandom.ofLong(1), { method: 'ESPRESSO', doseG: 18, waterG: 36, tempC: 93, timeS: 18, targetTimeS: 28, grind: '' }, 'SOUR');
    expect(s.options[0]).toBe('GRIND_FINER');
  });
});

describe('TrainProgress', () => {
  it('empty history is a trainee', () => {
    const p = compute([], 100);
    expect([p.xp, p.streak, p.percent, p.currentLevel]).toEqual([0, 0, 0, 1]);
    expect(p.title).toBe('TRAINEE');
    expect(p.levels[0].unlocked).toBe(true);
    expect(p.levels[1].unlocked).toBe(false);
    expect(p.scores.every((s) => s.percent == null)).toBe(true);
    expect(p.dailyDone).toBe(false);
  });

  it('levels unlock in order from validated work', () => {
    const level1 = byLevel.get(1)!.map((id) => lesson(id, 100));
    const p1 = compute(level1.slice(0, -1), 100);
    expect(p1.currentLevel).toBe(1);
    expect(p1.levels[1].unlocked).toBe(false);
    const p2 = compute(level1, 100);
    expect(p2.currentLevel).toBe(2);
    expect(p2.levelsComplete).toBe(1);
    expect(p2.title).toBe('JUNIOR');
    expect(p2.levels[1].unlocked).toBe(true);
    expect(compute([lesson('ratio', 100, false)], 100).validated.has('ratio')).toBe(false);
  });

  it('testing out validates a whole level and gates need practice', () => {
    const tests = [1, 2, 3, 4].map((l) => ev(100, 'LEVEL_TEST', SkillTree.levelRef(l), 5, 6, 50, true));
    const p = compute(tests, 100);
    for (const id of [...byLevel.get(1)!, ...byLevel.get(4)!]) expect(p.validated.has(id)).toBe(true);
    expect(p.levelsComplete).toBe(3);
    expect(p.currentLevel).toBe(4);
    const withDialIn = [...tests, ev(100, 'DIAL_IN', SkillTree.DIAL_IN_FILTER, 4, 5, 25, true)];
    expect(compute(withDialIn, 100).levelsComplete).toBe(4);
    expect(compute(withDialIn, 100).title).toBe('BARISTA');
  });

  it('pass marks and xp', () => {
    expect(TrainProgress.passed('LESSON', 2, 3)).toBe(true);
    expect(TrainProgress.passed('LESSON', 1, 3)).toBe(false);
    expect(TrainProgress.passed('DIAL_IN', 4, 5)).toBe(true);
    expect(TrainProgress.passed('DIAL_IN', 3, 5)).toBe(false);
    expect(TrainProgress.passed('EXAM', 7, 10)).toBe(true);
    expect(TrainProgress.passed('EXAM', 6, 10)).toBe(false);
    expect(TrainProgress.xpFor('LESSON', true, true)).toBe(75);
    expect(TrainProgress.xpFor('LESSON', true, false)).toBe(25);
    expect(TrainProgress.xpFor('LESSON', false, true)).toBe(0);
    expect(TrainProgress.xpFor('BREW_CHALLENGE', true, false)).toBe(100);
    expect(TrainProgress.xpFor('TASTING_LOG', true, false)).toBe(20);
    expect(TrainProgress.xpFor('STREAK_BONUS', true, false)).toBe(250);
  });

  it('streak counts consecutive days', () => {
    const events = [98, 99, 100].map((d) => lesson('ratio', d));
    expect(compute(events, 100).streak).toBe(3);
    expect(compute(events, 101).streak).toBe(3);
    expect(compute(events, 102).streak).toBe(0);
    expect(compute([lesson('ratio', 96), lesson('ratio', 100)], 100).streak).toBe(1);
  });

  it('skill scores come from recent answers only', () => {
    const enc = Breakdown.encode([['ESPRESSO', true], ['ESPRESSO', false], ['SENSORY', true]]);
    expect(Breakdown.decode(enc)).toEqual([['ESPRESSO', 1, 2], ['SENSORY', 1, 1]]);
    const old = Array.from({ length: 10 }, (_, i) => ev(i + 1, 'EXAM', 'ESPRESSO', 0, 3, 0, false, 'ESPRESSO:0/3'));
    const recent = Array.from({ length: 10 }, (_, i) => ev(i + 11, 'EXAM', 'ESPRESSO', 3, 3, 0, true, 'ESPRESSO:3/3'));
    const scores = TrainProgress.scores([...old, ...recent]);
    expect(scores.find((s) => s.skill === 'ESPRESSO')!.percent).toBe(100);
    expect(scores.find((s) => s.skill === 'MILK')!.percent).toBeNull();
    expect(TrainProgress.scores([lesson('x', 1, true, 'MILK:1/2')]).find((s) => s.skill === 'MILK')!.percent).toBe(50);
  });

  it('a repeated fault in real brews becomes a training opportunity', () => {
    const brew = (i: number, s: Symptom[], espresso = false): BrewSignal => ({ createdAt: i, espresso, symptoms: s });
    expect(TrainProgress.opportunity([brew(1, ['SOUR']), brew(2, ['SOUR']), brew(3, [])])).toBeNull();
    const o = TrainProgress.opportunity([brew(1, ['SOUR']), brew(2, ['SOUR']), brew(3, ['BITTER']), brew(4, ['SOUR'])])!;
    expect([o.symptom, o.count, o.lessonId]).toEqual(['SOUR', 3, 'extraction']);
    const shots = [1, 2, 3].map((i) => brew(i, ['SOUR'], true));
    expect(TrainProgress.opportunity(shots)!.lessonId).toBe('espresso_grind_time');
  });

  it('recommendations put brew patterns and weak skills first', () => {
    const empty = compute([], 100);
    const first = TrainProgress.recommendations(empty, content.lessons, null, false);
    expect(first.length).toBe(3);
    expect(first[0]).toEqual({ type: 'LESSON', lessonId: byLevel.get(1)![0], reason: 'NEXT_STEP' });

    const opportunity = TrainProgress.opportunity([1, 2, 3].map((i) => ({ createdAt: i, espresso: false, symptoms: ['SOUR'] as Symptom[] })));
    expect(TrainProgress.recommendations(empty, content.lessons, opportunity, false)[0]).toEqual({ type: 'LESSON', lessonId: 'extraction', reason: 'BREW_PATTERN' });

    const weak = compute([ev(100, 'EXAM', 'ESPRESSO', 2, 6, 0, false, 'ESPRESSO:2/6')], 100);
    const recs = TrainProgress.recommendations(weak, content.lessons, null, false);
    expect(recs[0].reason).toBe('WEAK_SKILL');
    expect(recs[0].type).toBe('LESSON');
    if (recs[0].type === 'LESSON') expect(lessonOf(recs[0].lessonId)!.skill).toBe('ESPRESSO');
    expect(new Set(recs.map((r) => JSON.stringify(r))).size).toBe(recs.length);
  });
});
