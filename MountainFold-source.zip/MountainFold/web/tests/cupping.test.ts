// Port of app/src/test/.../CuppingTests.kt (CuppingLogicTest): rules of the original Toulouse Cupping app.
import { describe, expect, it } from 'vitest';
import {
  angleDelta, AROMA_CATEGORIES, BODY_TYPES, buildCsv, contrastOn, cupIdle, cupLabel, cupPhase, cupProgress, cupRemainingS, cupReset,
  cupStart, cupTick, cupToggle, CupFormat, CupTimerState, ITEM_COLOR_OVERRIDES, LAB_METHODS, noteColor, PROCESSING_METHODS, SLICES,
  WHEEL_STEP, wheelActiveIndex, wheelRotationFor,
} from '../src/core/cupping';
import { CuppingCoffee, cuppingFinalScore, cuppingUniqueNotes } from '../src/core/models';

const coffee = (o: Partial<CuppingCoffee>): CuppingCoffee => ({
  id: 'x', sessionId: 's', position: 0, name: '', isLocked: false, isFavorite: false, timestamp: 0, process: '',
  fragranceScore: 8, fragranceNotes: [], flavorScore: 8, flavorNotes: [], aftertasteScore: 8, acidityScore: 8, acidityType: '',
  acidityIntensity: '', bodyScore: 8, bodyType: '', balanceScore: 8, comments: '', ...o,
});

describe('Cupping timer', () => {
  it('6 minutes rings at the crust then at the end', () => {
    let t: CupTimerState = cupStart(6, 0);
    let alerts: string[];
    expect(cupRemainingS(t)).toBe(360);
    expect(cupPhase(t)).toBe('CRUST');
    [t, alerts] = cupTick(t, 239_900);
    expect(alerts).toEqual([]);
    expect(cupRemainingS(t)).toBe(121);
    [t, alerts] = cupTick(t, 240_000);
    expect(alerts).toEqual(['CRUST']);
    expect(cupPhase(t)).toBe('TASTE');
    [t, alerts] = cupTick(t, 250_000);
    expect(alerts, 'the crust rings once').toEqual([]);
    [t, alerts] = cupTick(t, 360_000);
    expect(alerts).toEqual(['FINISHED']);
    expect(t.running).toBe(false);
    expect(cupPhase(t)).toBe('FINISHED');
    expect(cupProgress(t)).toBe(1);
    expect(cupTick(t, 370_000)[1]).toEqual([]);
  });

  it('4 minutes has no crust alert and pauses exactly', () => {
    expect(cupPhase(cupIdle())).toBe('PAUSED');
    let t = cupStart(4, 0);
    expect(cupPhase(t)).toBe('TASTE');
    [t] = cupTick(t, 100_000);
    t = cupToggle(t, 100_000);
    expect(t.running).toBe(false);
    expect(cupRemainingS(t)).toBe(140);
    let alerts: string[];
    [t, alerts] = cupTick(t, 500_000);
    expect(alerts).toEqual([]);
    t = cupToggle(t, 500_000);
    [t, alerts] = cupTick(t, 639_000);
    expect(alerts).toEqual([]);
    expect(cupRemainingS(t)).toBe(1);
    [t, alerts] = cupTick(t, 640_000);
    expect(alerts).toEqual(['FINISHED']);
    t = cupToggle(t, 650_000);
    expect(t.running, 'resuming at zero does nothing').toBe(false);
    t = cupReset(t);
    expect(cupRemainingS(t)).toBe(240);
    expect(t.running).toBe(false);
    expect(cupPhase(t)).toBe('PAUSED');
  });
});

describe('Cupping catalog', () => {
  it('matches the original', () => {
    const items = AROMA_CATEGORIES.flatMap((c) => c.items);
    expect(AROMA_CATEGORIES.length).toBe(6);
    expect(items.length).toBe(44);
    expect(new Set(items.map((i) => i.key)).size).toBe(44);
    expect(items.every((i) => i.key in ITEM_COLOR_OVERRIDES), 'every aroma has its own colour').toBe(true);
    expect(cupLabel('Citron', 'en')).toBe('Lemon');
    expect(cupLabel('Citron', 'es')).toBe('Limón');
    expect(cupLabel('Citron', 'fr')).toBe('Citron');
    expect(cupLabel('Lavé', 'en')).toBe('Washed');
    expect(cupLabel('unknown', 'en')).toBe('unknown');
    expect(contrastOn('#F5E452').toUpperCase()).toBe('#1E1B18');
    expect(contrastOn('#462920').toUpperCase()).toBe('#FFFFFF');
    expect(noteColor('Cerise')!.toUpperCase()).toBe('#E72D37');
    expect(noteColor('nope')).toBeNull();
    expect(LAB_METHODS.map((m) => m.defaultRatio)).toEqual([16, 15, 14, 12, 10, 16]);
    expect(PROCESSING_METHODS.length).toBe(5);
    expect(BODY_TYPES.length).toBe(8);
  });
});

describe('Flavor wheel', () => {
  it('picks the slice under the pointer', () => {
    expect(WHEEL_STEP).toBeCloseTo(360 / 44, 4);
    expect(SLICES[wheelActiveIndex(0)].key).toBe('Citron');
    expect(SLICES[wheelActiveIndex(-WHEEL_STEP * 1.5)].key).toBe('Orange');
    expect(SLICES[wheelActiveIndex(WHEEL_STEP * 0.5)].key).toBe('Noisette grillée');
    expect(wheelActiveIndex(10)).toBe(wheelActiveIndex(370));
    for (const i of [0, 7, 20, 43]) for (const pointer of [0, 270]) {
      const r = wheelRotationFor(i, 1234, pointer);
      expect(wheelActiveIndex(r, pointer)).toBe(i);
      expect(Math.abs(r - 1234)).toBeLessThanOrEqual(180 + WHEEL_STEP);
    }
    expect(angleDelta(350, 10)).toBeCloseTo(20, 4);
    expect(angleDelta(10, 350)).toBeCloseTo(-20, 4);
  });
});

describe('Cupping numbers, score and CSV', () => {
  it('prints numbers like the original', () => {
    expect(CupFormat.fixed2(8)).toBe('8.00');
    expect(CupFormat.fixed2(8.125)).toBe('8.13');
    expect(CupFormat.jsNumber(8)).toBe('8');
    expect(CupFormat.jsNumber(8.25)).toBe('8.25');
    expect(CupFormat.clock(195)).toBe('03:15');
    expect(CupFormat.clock(7200)).toBe('120:00');
    expect(CupFormat.water(20, 16)).toBe(320);
    expect(CupFormat.water(15.5, 16)).toBe(248);
    expect(CupFormat.parse('')).toBe(0);
    expect(CupFormat.parse('1,5')).toBe(1.5);
    expect(CupFormat.parse('abc')).toBeNull();
  });

  it('score and notes follow the original rules', () => {
    const c = coffee({
      fragranceScore: 8.5, flavorScore: 8.25, aftertasteScore: 7.75, acidityScore: 8, bodyScore: 7.5, balanceScore: 8,
      fragranceNotes: ['Citron', 'Miel'], flavorNotes: ['Miel', 'Cacao'],
    });
    expect(cuppingFinalScore(c)).toBeCloseTo(8, 9);
    expect(cuppingUniqueNotes(c)).toEqual(['Citron', 'Miel', 'Cacao']);
  });

  it('CSV has the original columns and escapes text', () => {
    const a = coffee({ id: 'a', name: 'Guji "lot 7"', isFavorite: true, process: 'Lavé', fragranceScore: 8.25, fragranceNotes: ['Citron'], flavorNotes: ['Citron', 'Miel'], comments: 'Clean, sweet' });
    const b = coffee({ id: 'b', name: 'Huila' });
    const headers = ['Nom du café', 'Fav', 'Procédé / Process', 'Score', 'Notes', 'Fragrance / Arôme', 'Saveur', 'Arrière-goût', 'Acidité', 'Corps', 'Équilibre', 'Commentaires'];
    const lines = buildCsv([a, b], headers, 'Oui', 'Non', (k) => cupLabel(k, 'fr')).split('\n');
    expect(lines.length).toBe(3);
    expect(lines[0]).toBe(headers.join(','));
    expect(lines[1]).toBe('"Guji ""lot 7""",Oui,Lavé,8.04,"Citron, Miel",8.25,8,8,8,8,8,"Clean, sweet"');
    expect(lines[2]).toBe('"Huila",Non,,8.00,"",8,8,8,8,8,8,""');
    expect(buildCsv([a], headers, 'Yes', 'No', (k) => cupLabel(k, 'en'))).toContain('Yes,Washed,8.04,"Lemon, Honey"');
  });
});
