// Same colour system as the Android app's fallback palettes: tonal palettes in CIE LCh,
// so "tone" means perceptual lightness, the idea Material You uses. iOS has no dynamic colour,
// so the web app always uses these.
import { Palette } from './models';

export type Scheme = Record<string, string>;

interface Seed { ph: number; pc: number; sh: number; sc: number; th: number; tc: number; nh: number; nc: number }
const SEEDS: Record<Exclude<Palette, 'TOULOUSE'>, Seed> = {
  COFFEE: { ph: 58, pc: 40, sh: 68, sc: 16, th: 115, tc: 26, nh: 62, nc: 6 },
  MOUNTAIN: { ph: 255, pc: 30, sh: 245, sc: 12, th: 60, tc: 30, nh: 255, nc: 5 },
  FOREST: { ph: 150, pc: 34, sh: 140, sc: 13, th: 85, tc: 28, nh: 140, nc: 5 },
  STONE: { ph: 80, pc: 9, sh: 80, sc: 6, th: 45, tc: 22, nh: 80, nc: 3 },
};

function labToLinearRgb(l: number, a: number, b: number): [number, number, number] {
  const fy = (l + 16) / 116;
  const fx = fy + a / 500;
  const fz = fy - b / 200;
  const inv = (t: number) => (t * t * t > 0.008856 ? t * t * t : (116 * t - 16) / 903.3);
  const x = 0.95047 * inv(fx);
  const y = inv(fy);
  const z = 1.08883 * inv(fz);
  return [
    3.2404542 * x - 1.5371385 * y - 0.4985314 * z,
    -0.969266 * x + 1.8760108 * y + 0.041556 * z,
    0.0556434 * x - 0.2040259 * y + 1.0572252 * z,
  ];
}

const gamma = (v: number) => {
  const c = Math.min(1, Math.max(0, v));
  return c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
};

const hex = (rgb: [number, number, number]) =>
  '#' + rgb.map((v) => Math.round(gamma(v) * 255).toString(16).padStart(2, '0')).join('').toUpperCase();

/** CIE LCh(ab) to sRGB. Chroma is reduced until the colour fits the gamut, keeping lightness intact. */
export function lch(l: number, c: number, hDeg: number): string {
  let chroma = c;
  const h = (hDeg * Math.PI) / 180;
  for (let i = 0; i < 40; i++) {
    const rgb = labToLinearRgb(l, chroma * Math.cos(h), chroma * Math.sin(h));
    if (rgb.every((v) => v >= -0.0005 && v <= 1.0005) || chroma < 0.5) return hex(rgb);
    chroma *= 0.92;
  }
  return hex(labToLinearRgb(l, 0, 0));
}

export function scheme(palette: Palette, dark: boolean): Scheme {
  if (palette === 'TOULOUSE') return toulouse(dark);
  const s = SEEDS[palette];
  const p = (t: number) => lch(t, s.pc, s.ph);
  const sec = (t: number) => lch(t, s.sc, s.sh);
  const ter = (t: number) => lch(t, s.tc, s.th);
  const n = (t: number) => lch(t, s.nc, s.nh);
  const nv = (t: number) => lch(t, s.nc * 2 + 2, s.nh);
  const err = (t: number) => lch(t, 60, 30);
  return !dark
    ? {
        primary: p(38), onPrimary: p(100), primaryContainer: p(90), onPrimaryContainer: p(14),
        secondary: sec(40), onSecondary: sec(100), secondaryContainer: sec(90), onSecondaryContainer: sec(14),
        tertiary: ter(40), onTertiary: ter(100), tertiaryContainer: ter(90), onTertiaryContainer: ter(14),
        error: err(40), onError: err(100), errorContainer: err(90), onErrorContainer: err(14),
        background: n(98), onBackground: n(10), surface: n(98), onSurface: n(10),
        surfaceVariant: nv(90), onSurfaceVariant: nv(30), outline: nv(48), outlineVariant: nv(80),
        inverseSurface: n(20), inverseOnSurface: n(95), inversePrimary: p(80),
        surfaceDim: n(87), surfaceBright: n(98), surfaceContainerLowest: n(100),
        surfaceContainerLow: n(96), surfaceContainer: n(94), surfaceContainerHigh: n(92), surfaceContainerHighest: n(90),
      }
    : {
        primary: p(82), onPrimary: p(20), primaryContainer: p(30), onPrimaryContainer: p(92),
        secondary: sec(80), onSecondary: sec(20), secondaryContainer: sec(30), onSecondaryContainer: sec(90),
        tertiary: ter(80), onTertiary: ter(20), tertiaryContainer: ter(30), onTertiaryContainer: ter(90),
        error: err(80), onError: err(20), errorContainer: err(30), onErrorContainer: err(90),
        background: n(5), onBackground: n(92), surface: n(5), onSurface: n(92),
        surfaceVariant: nv(28), onSurfaceVariant: nv(82), outline: nv(60), outlineVariant: nv(28),
        inverseSurface: n(90), inverseOnSurface: n(20), inversePrimary: p(38),
        surfaceDim: n(5), surfaceBright: n(24), surfaceContainerLowest: n(3),
        surfaceContainerLow: n(9), surfaceContainer: n(12), surfaceContainerHigh: n(16), surfaceContainerHighest: n(21),
      };
}

/** The exact light "Coffee" and dark "Espresso" tokens of the Toulouse Cupping web app. */
function toulouse(dark: boolean): Scheme {
  return !dark
    ? {
        primary: '#8D6E4D', onPrimary: '#FFFFFF', primaryContainer: '#FFDCBE', onPrimaryContainer: '#2C1600',
        secondary: '#77574E', onSecondary: '#FFFFFF', secondaryContainer: '#FFDBD1', onSecondaryContainer: '#2C150F',
        tertiary: '#6C5D2F', onTertiary: '#FFFFFF', tertiaryContainer: '#F5E1A6', onTertiaryContainer: '#221B00',
        error: '#BA1A1A', onError: '#FFFFFF', errorContainer: '#FFDAD6', onErrorContainer: '#410002',
        background: '#FFF8F6', onBackground: '#201A18', surface: '#FFF8F6', onSurface: '#201A18',
        surfaceVariant: '#F4DED4', onSurfaceVariant: '#52433D', outline: '#85736D', outlineVariant: '#D7C2B8',
        inverseSurface: '#362F2C', inverseOnSurface: '#FBEEE9', inversePrimary: '#FFB77C',
        surfaceDim: '#E8D7D1', surfaceBright: '#FFF8F6', surfaceContainerLowest: '#FFFFFF',
        surfaceContainerLow: '#FFF1EC', surfaceContainer: '#FCECE6', surfaceContainerHigh: '#F6E6E0', surfaceContainerHighest: '#F0E1DB',
      }
    : {
        primary: '#FFB77C', onPrimary: '#50381A', primaryContainer: '#6E5231', onPrimaryContainer: '#FFDCBE',
        secondary: '#E7BDB2', onSecondary: '#442922', secondaryContainer: '#5D3F38', onSecondaryContainer: '#FFDBD1',
        tertiary: '#D8C58D', onTertiary: '#3B2F06', tertiaryContainer: '#53461A', onTertiaryContainer: '#F5E1A6',
        error: '#FFB4AB', onError: '#690005', errorContainer: '#93000A', onErrorContainer: '#FFDAD6',
        background: '#18120F', onBackground: '#ECE0DB', surface: '#18120F', onSurface: '#ECE0DB',
        surfaceVariant: '#52433D', onSurfaceVariant: '#D7C2B8', outline: '#A08C85', outlineVariant: '#52433D',
        inverseSurface: '#ECE0DB', inverseOnSurface: '#362F2C', inversePrimary: '#8D6E4D',
        surfaceDim: '#18120F', surfaceBright: '#3F3734', surfaceContainerLowest: '#0F0A07',
        surfaceContainerLow: '#1D1714', surfaceContainer: '#211B18', surfaceContainerHigh: '#2B2522', surfaceContainerHighest: '#362F2C',
      };
}

const kebab = (k: string) => k.replace(/[A-Z]/g, (m) => '-' + m.toLowerCase());

/** Writes the scheme as CSS custom properties on :root. */
export function applyScheme(s: Scheme, dark: boolean) {
  const root = document.documentElement;
  for (const [k, v] of Object.entries(s)) root.style.setProperty(`--${kebab(k)}`, v);
  root.style.setProperty('color-scheme', dark ? 'dark' : 'light');
  root.dataset.theme = dark ? 'dark' : 'light';
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', s.surface);
}
