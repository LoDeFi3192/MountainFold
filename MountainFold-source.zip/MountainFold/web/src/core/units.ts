// Formats and parses values in the user's units. Storage is always grams and Celsius.
import { cToF, formatNumber, fToC, gToOz, ozToG, parseNumber, round1 } from './coffee';
import type { TempUnit, WeightUnit } from './models';

export class Units {
  constructor(readonly weight: WeightUnit = 'G', readonly temp: TempUnit = 'C') {}
  get wLabel() { return this.weight === 'G' ? 'g' : 'oz'; }
  get tLabel() { return this.temp === 'C' ? '°C' : '°F'; }
  wValue(g: number) { return this.weight === 'G' ? formatNumber(g) : formatNumber(gToOz(g), 2); }
  w(g: number) { return `${this.wValue(g)} ${this.wLabel}`; }
  parseW(text: string): number | null { const v = parseNumber(text); return v == null ? null : this.weight === 'G' ? v : ozToG(v); }
  tValue(c: number) { return this.temp === 'C' ? formatNumber(c) : String(Math.round(cToF(c))); }
  t(c: number | null | undefined) { return c == null ? '–' : `${this.tValue(c)}${this.tLabel}`; }
  parseT(text: string): number | null { const v = parseNumber(text); return v == null ? null : this.temp === 'C' ? v : round1(fToC(v)); }
}
