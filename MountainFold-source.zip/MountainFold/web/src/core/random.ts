// Kotlin's default Random (XorWow) and the collection helpers built on it, bit for bit.
// The daily challenge is seeded with the date, so the Fold and the iPhone show the same question on the same day.

export class KRandom {
  private x: number;
  private y: number;
  private z: number;
  private w: number;
  private v: number;
  private addend: number;

  private constructor(seed1: number, seed2: number) {
    this.x = seed1 | 0;
    this.y = seed2 | 0;
    this.z = 0;
    this.w = 0;
    this.v = ~seed1 | 0;
    this.addend = ((seed1 << 10) ^ (seed2 >>> 4)) | 0;
    for (let i = 0; i < 64; i++) this.nextInt();
  }

  /** Random(seed: Long) of Kotlin. Safe for |seed| < 2^53. */
  static ofLong(seed: number): KRandom {
    const big = BigInt.asIntN(64, BigInt(Math.trunc(seed)));
    const lo = Number(BigInt.asIntN(32, big));
    const hi = Number(BigInt.asIntN(32, big >> 32n));
    return new KRandom(lo, hi);
  }

  /** A fresh random generator, for sessions that do not need to be reproducible. */
  static fresh(): KRandom {
    const a = new Uint32Array(2);
    if (globalThis.crypto?.getRandomValues) globalThis.crypto.getRandomValues(a);
    else { a[0] = (Math.random() * 2 ** 32) >>> 0; a[1] = (Math.random() * 2 ** 32) >>> 0; }
    return new KRandom(a[0] | 0, a[1] | 0 || 1);
  }

  nextInt(): number {
    let t = this.x;
    t = t ^ (t >>> 2);
    this.x = this.y;
    this.y = this.z;
    this.z = this.w;
    const v0 = this.v;
    this.w = v0;
    t = (t ^ (t << 1)) ^ v0 ^ (v0 << 4);
    this.v = t | 0;
    this.addend = (this.addend + 362437) | 0;
    return (t + this.addend) | 0;
  }

  private nextBits(bitCount: number): number {
    return (this.nextInt() >>> (32 - bitCount)) & (-bitCount >> 31);
  }

  /** nextInt(until) of Kotlin: 0 <= result < until. */
  nextIntBelow(until: number): number {
    const n = until | 0;
    if (n <= 0) throw new Error('bound must be positive');
    if ((n & -n) === n) {
      const bitCount = 31 - Math.clz32(n);
      return this.nextBits(bitCount);
    }
    let bits: number;
    let v: number;
    do {
      bits = this.nextInt() >>> 1;
      v = bits % n;
    } while (((bits - v + (n - 1)) | 0) < 0);
    return v;
  }

  nextBoolean(): boolean {
    return this.nextBits(1) !== 0;
  }

  /** List.random(random) */
  pick<T>(list: readonly T[]): T {
    if (list.length === 0) throw new Error('empty');
    return list[this.nextIntBelow(list.length)];
  }

  /** Iterable.shuffled(random): a copy shuffled with Kotlin's Fisher-Yates order. */
  shuffled<T>(list: readonly T[]): T[] {
    const out = list.slice();
    for (let i = out.length - 1; i >= 1; i--) {
      const j = this.nextIntBelow(i + 1);
      const tmp = out[j];
      out[j] = out[i];
      out[i] = tmp;
    }
    return out;
  }
}

/** indices.shuffled(random) */
export const shuffledIndices = (r: KRandom, n: number) => r.shuffled(Array.from({ length: n }, (_, i) => i));
