// Port of core/train: lesson model, extraction simulator, dial-in generator, progress and recommendations.
import { formatNumber, round1, round2 } from './coffee';
import { ChangeKind, Diagnosis, BrewInput, diagnose, primarySymptom } from './copilot';
import { BrewMethod, isEspresso, METHODS, step, Symptom } from './models';
import { KRandom } from './random';

export const SKILLS = ['EXTRACTION', 'ESPRESSO', 'POUR_OVER', 'MILK', 'SENSORY', 'GRINDER', 'WATER', 'WORKFLOW', 'THEORY'] as const;
export type Skill = (typeof SKILLS)[number];
export const SCHOOL_CATEGORIES = ['FOUNDATIONS', 'BREWING', 'ESPRESSO', 'SENSORY', 'ROASTING', 'WATER', 'ADVANCED'] as const;
export type SchoolCategory = (typeof SCHOOL_CATEGORIES)[number];
export type SimKind = 'NONE' | 'FILTER' | 'ESPRESSO' | 'YIELD_CALC' | 'MILK';
export const EXAM_CATEGORIES = ['KNOWLEDGE', 'BREWING', 'ESPRESSO', 'SENSORY', 'TROUBLESHOOTING'] as const;
export type ExamCategory = (typeof EXAM_CATEGORIES)[number];
export const EXAM_SKILLS: Record<ExamCategory, Skill[]> = {
  KNOWLEDGE: ['THEORY', 'WATER'],
  BREWING: ['EXTRACTION', 'POUR_OVER', 'GRINDER'],
  ESPRESSO: ['ESPRESSO', 'MILK', 'WORKFLOW'],
  SENSORY: ['SENSORY'],
  TROUBLESHOOTING: [],
};
export const EVENT_KINDS = ['LESSON', 'DIAL_IN', 'DAILY', 'LEVEL_TEST', 'EXAM', 'BREW_CHALLENGE', 'TASTING_LOG', 'STREAK_BONUS'] as const;
export type EventKind = (typeof EVENT_KINDS)[number];
export type BaristaTitle = 'TRAINEE' | 'JUNIOR' | 'BARISTA' | 'SENIOR' | 'HEAD' | 'SPECIALIST' | 'EXPERT';

export interface L { en: string; fr?: string; es?: string }
export const lt = (l: L | null | undefined, lang: string): string =>
  !l ? '' : lang === 'fr' ? l.fr ?? l.en : lang === 'es' ? l.es ?? l.en : l.en;

export interface Block { title: L; body: L }
export interface Question { id: string; prompt: L; options: L[]; correct?: number; why: L; skill?: Skill | null }
export interface Lesson {
  id: string;
  category: SchoolCategory;
  skill: Skill;
  level: number;
  minutes: number;
  title: L;
  objectives?: L[];
  blocks?: Block[];
  sim?: SimKind;
  simHint?: L | null;
  brewTask?: L | null;
  questions?: Question[];
}
export interface TrainContent { version?: number; lessons: Lesson[]; bank: Question[] }

export type TreeTask = { kind: 'DIAL_IN'; espresso: boolean } | { kind: 'EXAM'; category: ExamCategory };
export interface TreeLevel { number: number; tasks: TreeTask[] }
export const taskKey = (t: TreeTask) => (t.kind === 'DIAL_IN' ? `dial:${t.espresso}` : `exam:${t.category}`);

export const SkillTree = {
  levels: [
    { number: 1, tasks: [] },
    { number: 2, tasks: [] },
    { number: 3, tasks: [] },
    { number: 4, tasks: [{ kind: 'DIAL_IN', espresso: false }] },
    { number: 5, tasks: [] },
    { number: 6, tasks: [{ kind: 'DIAL_IN', espresso: true }] },
    { number: 7, tasks: [] },
    { number: 8, tasks: [{ kind: 'EXAM', category: 'BREWING' }, { kind: 'EXAM', category: 'ESPRESSO' }, { kind: 'EXAM', category: 'TROUBLESHOOTING' }] },
    { number: 9, tasks: [{ kind: 'EXAM', category: 'KNOWLEDGE' }, { kind: 'EXAM', category: 'SENSORY' }] },
  ] as TreeLevel[],
  DIAL_IN_FILTER: 'filter',
  DIAL_IN_ESPRESSO: 'espresso',
  levelRef: (level: number) => `level:${level}`,
  dayRef: (epochDay: number) => `day:${epochDay}`,
};

export function lessonsByLevel(content: TrainContent): Map<number, string[]> {
  const m = new Map<number, string[]>();
  for (const l of content.lessons) {
    if (!m.has(l.level)) m.set(l.level, []);
    m.get(l.level)!.push(l.id);
  }
  return m;
}

export interface TrainEvent {
  createdAt: number;
  kind: EventKind;
  refId: string;
  correct: number;
  total: number;
  xp: number;
  passed: boolean;
  breakdown: string;
}

export const Breakdown = {
  encode(results: [Skill, boolean][]): string {
    const groups = new Map<Skill, boolean[]>();
    for (const [s, ok] of results) {
      if (!groups.has(s)) groups.set(s, []);
      groups.get(s)!.push(ok);
    }
    return [...groups.entries()].map(([s, l]) => `${s}:${l.filter(Boolean).length}/${l.length}`).join(';');
  },
  decode(raw: string): [Skill, number, number][] {
    const out: [Skill, number, number][] = [];
    for (const part of raw.split(';')) {
      const i = part.indexOf(':');
      if (i < 0) continue;
      const name = part.slice(0, i);
      const score = part.slice(i + 1);
      if (!(SKILLS as readonly string[]).includes(name)) continue;
      const j = score.indexOf('/');
      const c = parseInt(j < 0 ? score : score.slice(0, j), 10);
      const t = parseInt(j < 0 ? score : score.slice(j + 1), 10);
      if (!/^-?\d+$/.test(j < 0 ? score : score.slice(0, j)) || !/^-?\d+$/.test(j < 0 ? score : score.slice(j + 1))) continue;
      if (t <= 0) continue;
      out.push([name as Skill, Math.min(t, Math.max(0, c)), t]);
    }
    return out;
  },
};

// ---- extraction simulator ----------------------------------------------------------------------

export type Zone = 'UNDER' | 'BALANCED' | 'OVER';
export type Strength = 'WEAK' | 'BALANCED' | 'STRONG';
export interface SimResult { timeS: number; extractionPct: number; tdsPct: number; zone: Zone; strength: Strength; uneven: boolean }
export interface FilterInput { grind: number; doseG: number; waterG: number; tempC: number; agitation: number }
export interface ShotInput { grind: number; doseG: number; yieldG: number; tempC: number; channeling: boolean }
export const defaultFilterInput = (): FilterInput => ({ grind: 50, doseG: 15, waterG: 250, tempC: 93, agitation: 1 });
export const defaultShotInput = (): ShotInput => ({ grind: 50, doseG: 18, yieldG: 36, tempC: 93, channeling: false });

const zoneOf = (ey: number): Zone => (ey < 18 ? 'UNDER' : ey <= 22 ? 'BALANCED' : 'OVER');
const clampN = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

export const ExtractionSim = {
  CHOKE_POINT: 85,
  filter(i: FilterInput): SimResult {
    const dose = Math.max(1, i.doseG);
    const ratio = i.waterG / dose;
    const choke = Math.max(0, i.grind - 85);
    let ey = 20 + 0.08 * (i.grind - 50) + 0.2 * (i.tempC - 93) + 0.9 * (i.agitation - 1) + 0.2 * (ratio - 16.67);
    ey -= 0.45 * choke;
    ey = clampN(ey, 10, 28);
    const time = 180 * (1 + 0.01 * (i.grind - 50)) * Math.pow(Math.max(0.2, i.waterG / 250), 0.7) * (1 + 0.05 * (i.agitation - 1)) * (1 + 0.04 * choke);
    const beverage = Math.max(1, i.waterG - 2 * dose);
    const tds = (ey * dose) / beverage;
    return {
      timeS: Math.max(20, Math.round(time)),
      extractionPct: round1(ey),
      tdsPct: round2(tds),
      zone: zoneOf(ey),
      strength: tds < 1.15 ? 'WEAK' : tds <= 1.45 ? 'BALANCED' : 'STRONG',
      uneven: choke > 0,
    };
  },
  shot(i: ShotInput): SimResult {
    const dose = Math.max(1, i.doseG);
    const ratio = i.yieldG / dose;
    let ey = 19.5 + 0.07 * (i.grind - 50) + 2.2 * (ratio - 2) + 0.25 * (i.tempC - 93);
    let time = 28 * (1 + 0.016 * (i.grind - 50)) * Math.pow(Math.max(0.2, i.yieldG / 36), 0.9) * Math.pow(dose / 18, 1.2);
    if (i.channeling) {
      ey -= 3.5;
      time *= 0.72;
    }
    ey = clampN(ey, 8, 28);
    const tds = (ey * dose) / Math.max(1, i.yieldG);
    return {
      timeS: Math.max(5, Math.round(time)),
      extractionPct: round1(ey),
      tdsPct: round1(tds),
      zone: zoneOf(ey),
      strength: tds < 8 ? 'WEAK' : tds <= 12 ? 'BALANCED' : 'STRONG',
      uneven: i.channeling,
    };
  },
  /** EY % = beverage weight x TDS % / dose. Exact, not a model. */
  extractionYield(doseG: number, beverageG: number, tdsPct: number): number | null {
    return doseG > 0 && beverageG > 0 && tdsPct > 0 ? (beverageG * tdsPct) / doseG : null;
  },
  milkPhase(tempC: number): 'STRETCH' | 'ROLL' | 'READY' | 'TOO_HOT' {
    return tempC < 37 ? 'STRETCH' : tempC < 55 ? 'ROLL' : tempC <= 65 ? 'READY' : 'TOO_HOT';
  },
};

// ---- dial-in generator ---------------------------------------------------------------------------

export interface Scenario {
  input: BrewInput;
  symptom: Symptom;
  diagnosis: Diagnosis;
  /** The correct change followed by three clearly wrong ones. */
  options: ChangeKind[];
}
export const scenarioSkill = (s: Scenario): Skill => (isEspresso(s.input.method) ? 'ESPRESSO' : 'EXTRACTION');

export function acceptable(symptom: Symptom): ChangeKind[] {
  switch (symptom) {
    case 'SOUR': return ['GRIND_FINER', 'TEMP_UP', 'YIELD_UP', 'BLOOM_LONGER', 'PUCK_PREP'];
    case 'BITTER': case 'DRY': case 'HARSH': return ['GRIND_COARSER', 'TEMP_DOWN', 'YIELD_DOWN', 'AGITATE_LESS', 'PUCK_PREP'];
    case 'WEAK': return ['DOSE_UP', 'YIELD_DOWN', 'GRIND_FINER', 'TEMP_UP', 'BLOOM_LONGER'];
    case 'STRONG': return ['DOSE_DOWN', 'YIELD_UP', 'GRIND_COARSER', 'TEMP_DOWN', 'AGITATE_LESS'];
    case 'ASTRINGENT': return ['GRIND_COARSER', 'AGITATE_LESS', 'PUCK_PREP', 'TEMP_DOWN', 'YIELD_DOWN'];
    case 'MUDDY': return ['GRIND_COARSER', 'AGITATE_LESS', 'PUCK_PREP'];
    case 'HOLLOW': return ['BLOOM_LONGER', 'PUCK_PREP', 'GRIND_FINER', 'AGITATE_LESS'];
    case 'FLAT': return ['FRESHER_COFFEE', 'TEMP_UP', 'GRIND_FINER'];
  }
}

const FILTER_KINDS: ChangeKind[] = ['GRIND_FINER', 'GRIND_COARSER', 'TEMP_UP', 'TEMP_DOWN', 'DOSE_UP', 'DOSE_DOWN', 'BLOOM_LONGER', 'AGITATE_LESS'];
const ESPRESSO_KINDS: ChangeKind[] = ['GRIND_FINER', 'GRIND_COARSER', 'TEMP_UP', 'TEMP_DOWN', 'YIELD_UP', 'YIELD_DOWN', 'PUCK_PREP'];
const FILTER_SYMPTOMS: Symptom[] = ['SOUR', 'BITTER', 'WEAK', 'STRONG', 'DRY', 'ASTRINGENT', 'HARSH', 'MUDDY', 'HOLLOW'];
const ESPRESSO_SYMPTOMS: Symptom[] = ['SOUR', 'BITTER', 'WEAK', 'STRONG', 'ASTRINGENT', 'HARSH', 'HOLLOW'];

function filterInput(r: KRandom): BrewInput {
  const method = r.pick<BrewMethod>(['V60', 'V60', 'KALITA', 'AEROPRESS', 'FRENCH_PRESS']);
  const dose = method === 'FRENCH_PRESS' ? 30 : r.pick([15, 18, 20]);
  const ratio = r.pick([15, 16, 16.5, 17]);
  const water = Math.round((dose * ratio) / 5) * 5;
  const target = METHODS[method].defaultTimeS;
  const time = Math.trunc(Math.trunc(target * r.pick([0.72, 1, 1, 1.28])) / 5) * 5;
  const temp = r.pick([88, 90, 92, 94, 96]);
  const steps = method === 'V60' || method === 'KALITA' ? [step('Bloom', 'BLOOM', 0, dose * 3), step('Pour', 'POUR', 45, water)] : [];
  return { method, doseG: dose, waterG: water, tempC: temp, timeS: time, targetTimeS: target, grind: '', steps };
}

function shotInput(r: KRandom): BrewInput {
  const dose = r.pick([17, 18, 18, 20]);
  const ratio = r.pick([1.6, 2, 2, 2.5]);
  const yieldG = Math.round(dose * ratio);
  const time = r.pick([17, 21, 28, 29, 36, 41]);
  const temp = r.pick([91, 93, 94]);
  return { method: 'ESPRESSO', doseG: dose, waterG: yieldG, tempC: temp, timeS: time, targetTimeS: 28, grind: '' };
}

export const DialIn = {
  build(r: KRandom, input: BrewInput, symptom: Symptom): Scenario {
    const diagnosis = diagnose(input, [symptom])!;
    const ok = acceptable(symptom);
    const pool = (isEspresso(input.method) ? ESPRESSO_KINDS : FILTER_KINDS).filter((k) => !ok.includes(k) && k !== diagnosis.change);
    const wrong = r.shuffled(pool).slice(0, 3);
    return { input, symptom, diagnosis, options: [diagnosis.change, ...wrong] };
  },
  generate(r: KRandom, espresso: boolean): Scenario {
    const symptom = r.pick(espresso ? ESPRESSO_SYMPTOMS : FILTER_SYMPTOMS);
    const input = espresso ? shotInput(r) : filterInput(r);
    return DialIn.build(r, input, symptom);
  },
  /** A session without repeated (method, symptom, answer) triples. */
  session(r: KRandom, espresso: boolean | null, count: number): Scenario[] {
    const out: Scenario[] = [];
    const seen = new Set<string>();
    let guard = 0;
    while (out.length < count && guard++ < count * 40) {
      const s = DialIn.generate(r, espresso ?? r.nextBoolean());
      const key = `${isEspresso(s.input.method)}/${s.symptom}/${s.options[0]}`;
      if (!seen.has(key)) { seen.add(key); out.push(s); }
    }
    return out;
  },
};

// ---- progress ----------------------------------------------------------------------------------

export interface SkillScore { skill: Skill; percent: number | null; answers: number }
export interface LevelState {
  level: TreeLevel;
  lessons: string[];
  tasksDone: Set<string>;
  unlocked: boolean;
  done: number;
  total: number;
  complete: boolean;
}
export interface Progress {
  xp: number;
  streak: number;
  validated: Set<string>;
  levels: LevelState[];
  currentLevel: number;
  levelsComplete: number;
  percent: number;
  title: BaristaTitle;
  scores: SkillScore[];
  dailyDone: boolean;
}

export type RecReason = 'BREW_PATTERN' | 'WEAK_SKILL' | 'NEXT_STEP' | 'PRACTICE';
export type Recommendation =
  | { type: 'LESSON'; lessonId: string; reason: RecReason }
  | { type: 'DIAL_IN'; espresso: boolean; reason: RecReason }
  | { type: 'EXAM'; category: ExamCategory; reason: RecReason };

export interface Opportunity { symptom: Symptom; count: number; lessonId: string }
export interface BrewSignal { createdAt: number; espresso: boolean; symptoms: Symptom[] }

export const TrainProgress = {
  LESSON_PASS: 0.66,
  SESSION_PASS: 0.8,
  EXAM_PASS: 0.7,

  passed(kind: EventKind, correct: number, total: number): boolean {
    if (total <= 0) return false;
    const r = correct / total;
    switch (kind) {
      case 'LESSON': return r >= 0.66;
      case 'DIAL_IN': case 'LEVEL_TEST': return r >= 0.8;
      case 'EXAM': return r >= 0.7;
      case 'DAILY': return correct === total;
      default: return true;
    }
  },

  xpFor(kind: EventKind, passed: boolean, firstValidation: boolean): number {
    switch (kind) {
      case 'LESSON': return !passed ? 0 : firstValidation ? 75 : 25;
      case 'DIAL_IN': return passed ? 25 : 0;
      case 'DAILY': return passed ? 25 : 10;
      case 'LEVEL_TEST': return passed ? 50 : 0;
      case 'EXAM': return passed ? 50 : 0;
      case 'BREW_CHALLENGE': return 100;
      case 'TASTING_LOG': return 20;
      case 'STREAK_BONUS': return 250;
    }
  },

  title(levelsComplete: number): BaristaTitle {
    if (levelsComplete <= 0) return 'TRAINEE';
    if (levelsComplete <= 2) return 'JUNIOR';
    if (levelsComplete <= 4) return 'BARISTA';
    if (levelsComplete === 5) return 'SENIOR';
    if (levelsComplete <= 7) return 'HEAD';
    if (levelsComplete === 8) return 'SPECIALIST';
    return 'EXPERT';
  },

  streak(events: TrainEvent[], today: number, dayOf: (ms: number) => number): number {
    const days = new Set(events.filter((e) => e.kind !== 'STREAK_BONUS').map((e) => dayOf(e.createdAt)));
    let day: number;
    if (days.has(today)) day = today;
    else if (days.has(today - 1)) day = today - 1;
    else return 0;
    let n = 0;
    while (days.has(day)) { n++; day--; }
    return n;
  },

  scores(events: TrainEvent[]): SkillScore[] {
    const correct = new Array(SKILLS.length).fill(0);
    const total = new Array(SKILLS.length).fill(0);
    const sorted = [...events].sort((a, b) => b.createdAt - a.createdAt);
    for (const e of sorted) {
      for (const [skill, c, t] of Breakdown.decode(e.breakdown)) {
        const i = SKILLS.indexOf(skill);
        if (total[i] >= 30) continue;
        correct[i] += c;
        total[i] += t;
      }
    }
    return SKILLS.map((s, i) => ({ skill: s, percent: total[i] === 0 ? null : Math.round((correct[i] * 100) / total[i]), answers: total[i] }));
  },

  compute(events: TrainEvent[], byLevel: Map<number, string[]>, today: number, dayOf: (ms: number) => number): Progress {
    const passedEvents = events.filter((e) => e.passed);
    const tested = new Set(passedEvents.filter((e) => e.kind === 'LEVEL_TEST').map((e) => e.refId));
    const validated = new Set<string>(passedEvents.filter((e) => e.kind === 'LESSON').map((e) => e.refId));
    byLevel.forEach((ids, level) => { if (tested.has(SkillTree.levelRef(level))) ids.forEach((id) => validated.add(id)); });
    const dialIns = new Set(passedEvents.filter((e) => e.kind === 'DIAL_IN').map((e) => e.refId));
    const exams = new Set(passedEvents.filter((e) => e.kind === 'EXAM').map((e) => e.refId));
    const done = (t: TreeTask) => (t.kind === 'DIAL_IN' ? dialIns.has(t.espresso ? 'espresso' : 'filter') : exams.has(t.category));
    let previousComplete = true;
    const levels: LevelState[] = SkillTree.levels.map((level) => {
      const lessons = byLevel.get(level.number) ?? [];
      const tasksDone = new Set(level.tasks.filter(done).map(taskKey));
      const d = lessons.filter((id) => validated.has(id)).length + tasksDone.size;
      const total = lessons.length + level.tasks.length;
      const state: LevelState = { level, lessons, tasksDone, unlocked: previousComplete, done: d, total, complete: d === total };
      previousComplete = previousComplete && state.complete;
      return state;
    });
    let levelsComplete = 0;
    for (const l of levels) { if (l.complete) levelsComplete++; else break; }
    const doneCount = levels.reduce((a, l) => a + l.done, 0);
    const totalCount = Math.max(1, levels.reduce((a, l) => a + l.total, 0));
    return {
      xp: events.reduce((a, e) => a + e.xp, 0),
      streak: TrainProgress.streak(events, today, dayOf),
      validated,
      levels,
      currentLevel: Math.min(levelsComplete + 1, SkillTree.levels.length),
      levelsComplete,
      percent: Math.floor((doneCount * 100) / totalCount),
      title: TrainProgress.title(levelsComplete),
      scores: TrainProgress.scores(events),
      dailyDone: events.some((e) => e.kind === 'DAILY' && e.refId === SkillTree.dayRef(today)),
    };
  },

  lessonForSymptom(symptom: Symptom, espresso: boolean): string {
    switch (symptom) {
      case 'SOUR': case 'BITTER': case 'DRY': return espresso ? 'espresso_grind_time' : 'extraction';
      case 'WEAK': case 'STRONG': return espresso ? 'espresso_recipe' : 'ratio';
      case 'ASTRINGENT': case 'HOLLOW': return espresso ? 'channeling' : 'agitation_time';
      case 'MUDDY': return 'grinder_flow';
      case 'HARSH': return 'temperature';
      case 'FLAT': return 'roasting';
    }
  },

  lessonForDiagnosis(d: Diagnosis, espresso: boolean): string {
    switch (d.change) {
      case 'GRIND_FINER': case 'GRIND_COARSER': return espresso ? 'espresso_grind_time' : 'grind_size';
      case 'TEMP_UP': case 'TEMP_DOWN': return 'temperature';
      case 'DOSE_UP': case 'DOSE_DOWN': return 'ratio';
      case 'YIELD_UP': case 'YIELD_DOWN': return 'espresso_recipe';
      case 'BLOOM_LONGER': case 'AGITATE_LESS': return 'agitation_time';
      case 'PUCK_PREP': return d.cause === 'CHANNELING' ? 'channeling' : 'puck_prep';
      case 'FRESHER_COFFEE': return 'roasting';
    }
  },

  /** Three or more of the last twelve brews with the same main symptom make a training opportunity. */
  opportunity(brews: BrewSignal[]): Opportunity | null {
    const recent = [...brews].sort((a, b) => b.createdAt - a.createdAt).slice(0, 12);
    const tagged: [Symptom, boolean][] = [];
    for (const b of recent) {
      const p = primarySymptom(b.symptoms);
      if (p) tagged.push([p, b.espresso]);
    }
    const groups = new Map<Symptom, [Symptom, boolean][]>();
    for (const t of tagged) {
      if (!groups.has(t[0])) groups.set(t[0], []);
      groups.get(t[0])!.push(t);
    }
    let top: [Symptom, [Symptom, boolean][]] | null = null;
    groups.forEach((v, k) => { if (!top || v.length > top[1].length) top = [k, v]; });
    if (!top) return null;
    const [symptom, list] = top as [Symptom, [Symptom, boolean][]];
    if (list.length < 3) return null;
    const espresso = list.filter((x) => x[1]).length * 2 > list.length;
    return { symptom, count: list.length, lessonId: TrainProgress.lessonForSymptom(symptom, espresso) };
  },

  recommendations(progress: Progress, lessons: Lesson[], opportunity: Opportunity | null, prefersEspresso: boolean): Recommendation[] {
    const out: Recommendation[] = [];
    const same = (a: Recommendation, b: Recommendation) =>
      (a.type === 'LESSON' && b.type === 'LESSON' && a.lessonId === b.lessonId) ||
      (a.type === 'DIAL_IN' && b.type === 'DIAL_IN' && a.espresso === b.espresso) ||
      (a.type === 'EXAM' && b.type === 'EXAM' && a.category === b.category);
    const add = (r: Recommendation) => { if (!out.some((o) => same(o, r))) out.push(r); };
    const dialInSkills: Skill[] = ['EXTRACTION', 'POUR_OVER', 'GRINDER', 'ESPRESSO'];

    if (opportunity) add({ type: 'LESSON', lessonId: opportunity.lessonId, reason: 'BREW_PATTERN' });

    progress.scores
      .filter((s) => s.percent != null && s.answers >= 4 && s.percent < 70)
      .sort((a, b) => (a.percent ?? 0) - (b.percent ?? 0))
      .slice(0, 2)
      .forEach((weak) => {
        const lesson = lessons.find((l) => l.skill === weak.skill && !progress.validated.has(l.id)) ?? lessons.find((l) => l.skill === weak.skill);
        if (dialInSkills.includes(weak.skill) && lesson && progress.validated.has(lesson.id)) add({ type: 'DIAL_IN', espresso: weak.skill === 'ESPRESSO', reason: 'WEAK_SKILL' });
        else if (lesson) add({ type: 'LESSON', lessonId: lesson.id, reason: 'WEAK_SKILL' });
      });

    const current = progress.levels.find((l) => !l.complete);
    if (current) {
      current.lessons.filter((id) => !progress.validated.has(id)).forEach((id) => add({ type: 'LESSON', lessonId: id, reason: 'NEXT_STEP' }));
      current.level.tasks.filter((t) => !current.tasksDone.has(taskKey(t))).forEach((t) => {
        if (t.kind === 'DIAL_IN') add({ type: 'DIAL_IN', espresso: t.espresso, reason: 'NEXT_STEP' });
        else add({ type: 'EXAM', category: t.category, reason: 'NEXT_STEP' });
      });
    }
    add({ type: 'DIAL_IN', espresso: prefersEspresso, reason: 'PRACTICE' });
    add({ type: 'DIAL_IN', espresso: !prefersEspresso, reason: 'PRACTICE' });
    return out.slice(0, 3);
  },
};

export const fmtPct = (v: number) => formatNumber(v);
