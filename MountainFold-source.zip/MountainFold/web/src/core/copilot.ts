// Port of CopilotEngine: local, rule-based. It follows one rule above all: change one variable at a time.
import { formatNumber, parseNumber, ratio as ratioOf, round1 } from './coffee';
import { BrewMethod, BrewStep, isEspresso, Symptom } from './models';

export type Cause =
  | 'UNDER_EXTRACTION' | 'OVER_EXTRACTION' | 'LOW_STRENGTH' | 'HIGH_STRENGTH'
  | 'UNEVEN_EXTRACTION' | 'TOO_HOT' | 'STALE_COFFEE' | 'TOO_MANY_FINES' | 'CHANNELING';

export type Variable = 'GRIND' | 'TEMPERATURE' | 'DOSE' | 'YIELD' | 'RATIO' | 'TIME' | 'BLOOM' | 'AGITATION' | 'FRESHNESS' | 'PUCK_PREP';

export const CHANGE_KINDS = [
  'GRIND_FINER', 'GRIND_COARSER', 'TEMP_UP', 'TEMP_DOWN', 'DOSE_UP', 'DOSE_DOWN',
  'YIELD_UP', 'YIELD_DOWN', 'BLOOM_LONGER', 'AGITATE_LESS', 'PUCK_PREP', 'FRESHER_COFFEE',
] as const;
export type ChangeKind = (typeof CHANGE_KINDS)[number];

export interface BrewInput {
  method: BrewMethod;
  doseG: number;
  waterG: number;
  tempC: number | null;
  /** Measured brew time. Null when diagnosing a recipe that has not been timed. */
  timeS: number | null;
  targetTimeS: number;
  grind: string;
  steps?: BrewStep[];
  roastAgeDays?: number | null;
}

export interface Suggestion {
  doseG: number;
  waterG: number;
  tempC: number | null;
  grind: string;
  steps: BrewStep[];
  targetTimeS: number;
}

export interface Diagnosis {
  symptom: Symptom;
  cause: Cause;
  variables: Variable[];
  change: ChangeKind;
  suggestion: Suggestion;
  recipeChanged: boolean;
  grindStepped: boolean;
  timeIsEstimate: boolean;
}

const PRIORITY: Symptom[] = ['ASTRINGENT', 'DRY', 'HARSH', 'BITTER', 'SOUR', 'MUDDY', 'HOLLOW', 'FLAT', 'WEAK', 'STRONG'];

/** Sour and bitter in the same cup points to uneven extraction, not to either extreme. */
export function primarySymptom(symptoms: Set<Symptom> | Symptom[]): Symptom | null {
  const set = symptoms instanceof Set ? symptoms : new Set(symptoms);
  if (set.size === 0) return null;
  if (set.has('SOUR') && set.has('BITTER')) return 'HOLLOW';
  return PRIORITY.find((s) => set.has(s)) ?? null;
}

interface Rule { cause: Cause; variables: Variable[]; change: ChangeKind }
const rule = (cause: Cause, variables: Variable[], change: ChangeKind): Rule => ({ cause, variables, change });

const isShort = (i: BrewInput) => i.timeS != null && i.timeS < i.targetTimeS * 0.9;
const isLong = (i: BrewInput) => i.timeS != null && i.timeS > i.targetTimeS * 1.1;
const stale = (i: BrewInput) => i.roastAgeDays != null && i.roastAgeDays > 45;

function hasBloom(steps: BrewStep[]): boolean {
  const i = steps.findIndex((s) => s.type === 'BLOOM');
  return i >= 0 && i < steps.length - 1;
}

function filterRule(i: BrewInput, s: Symptom): Rule {
  const t = i.tempC;
  switch (s) {
    case 'SOUR':
      return rule('UNDER_EXTRACTION', ['GRIND', 'TEMPERATURE', 'TIME'], isShort(i) ? 'GRIND_FINER' : t != null && t < 94 ? 'TEMP_UP' : 'GRIND_FINER');
    case 'BITTER':
      return rule('OVER_EXTRACTION', ['GRIND', 'TEMPERATURE', 'TIME'], isLong(i) ? 'GRIND_COARSER' : t != null && t > 90 ? 'TEMP_DOWN' : 'GRIND_COARSER');
    case 'WEAK': return rule('LOW_STRENGTH', ['DOSE', 'RATIO'], 'DOSE_UP');
    case 'STRONG': return rule('HIGH_STRENGTH', ['DOSE', 'RATIO'], 'DOSE_DOWN');
    case 'DRY': return rule('OVER_EXTRACTION', ['GRIND', 'TEMPERATURE'], 'GRIND_COARSER');
    case 'ASTRINGENT': return rule('CHANNELING', ['AGITATION', 'GRIND'], isLong(i) ? 'GRIND_COARSER' : 'AGITATE_LESS');
    case 'FLAT':
      return stale(i)
        ? rule('STALE_COFFEE', ['FRESHNESS'], 'FRESHER_COFFEE')
        : rule('UNDER_EXTRACTION', ['TEMPERATURE', 'GRIND', 'FRESHNESS'], t != null && t < 96 ? 'TEMP_UP' : 'GRIND_FINER');
    case 'HOLLOW':
      return rule('UNEVEN_EXTRACTION', ['BLOOM', 'AGITATION', 'GRIND'], hasBloom(i.steps ?? []) ? 'BLOOM_LONGER' : 'GRIND_FINER');
    case 'HARSH': return rule('TOO_HOT', ['TEMPERATURE', 'GRIND'], t != null && t > 88 ? 'TEMP_DOWN' : 'GRIND_COARSER');
    case 'MUDDY': return rule('TOO_MANY_FINES', ['GRIND', 'AGITATION'], 'GRIND_COARSER');
  }
}

function espressoRule(i: BrewInput, s: Symptom): Rule {
  const r = ratioOf(i.waterG, i.doseG) ?? 2;
  const t = i.tempC;
  const time = i.timeS;
  switch (s) {
    case 'SOUR':
      return rule('UNDER_EXTRACTION', ['GRIND', 'YIELD', 'TEMPERATURE'],
        time != null && time < 25 ? 'GRIND_FINER' : r < 2 ? 'YIELD_UP' : t != null && t < 96 ? 'TEMP_UP' : 'GRIND_FINER');
    case 'BITTER':
      return rule('OVER_EXTRACTION', ['GRIND', 'YIELD', 'TEMPERATURE'],
        time != null && time > 32 ? 'GRIND_COARSER' : r > 2.2 ? 'YIELD_DOWN' : t != null && t > 88 ? 'TEMP_DOWN' : 'GRIND_COARSER');
    case 'WEAK': return rule('LOW_STRENGTH', ['YIELD', 'RATIO'], 'YIELD_DOWN');
    case 'STRONG': return rule('HIGH_STRENGTH', ['YIELD', 'RATIO'], 'YIELD_UP');
    case 'DRY': return rule('OVER_EXTRACTION', ['GRIND', 'YIELD'], 'GRIND_COARSER');
    case 'ASTRINGENT': return rule('CHANNELING', ['PUCK_PREP', 'GRIND'], 'PUCK_PREP');
    case 'HOLLOW': return rule('UNEVEN_EXTRACTION', ['PUCK_PREP', 'GRIND'], 'PUCK_PREP');
    case 'FLAT':
      return stale(i)
        ? rule('STALE_COFFEE', ['FRESHNESS'], 'FRESHER_COFFEE')
        : rule('UNDER_EXTRACTION', ['TEMPERATURE', 'GRIND', 'FRESHNESS'], t != null && t < 96 ? 'TEMP_UP' : 'GRIND_FINER');
    case 'HARSH': return rule('TOO_HOT', ['TEMPERATURE', 'GRIND'], t != null && t > 90 ? 'TEMP_DOWN' : 'GRIND_COARSER');
    case 'MUDDY': return rule('TOO_MANY_FINES', ['GRIND', 'PUCK_PREP'], 'GRIND_COARSER');
  }
}

const roundTo5 = (v: number) => Math.round(v / 5) * 5;
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/** Steps a numeric grind setting. Assumes a lower number is finer. Null for free-text settings. */
export function adjustGrind(grind: string, finer: boolean): string | null {
  const v = parseNumber(grind);
  if (v == null) return null;
  const stepSize = v === Math.trunc(v) ? 1 : 0.5;
  return formatNumber(Math.max(0, finer ? v - stepSize : v + stepSize));
}

const sameSteps = (a: BrewStep[], b: BrewStep[]) =>
  a.length === b.length && a.every((s, i) => s.startS === b[i].startS && s.label === b[i].label && s.type === b[i].type && s.targetWaterG === b[i].targetWaterG && s.note === b[i].note);

function build(i: BrewInput, symptom: Symptom, r: Rule): Diagnosis {
  const espresso = isEspresso(i.method);
  let dose = i.doseG;
  let water = i.waterG;
  let temp = i.tempC;
  let grind = i.grind;
  const inputSteps = i.steps ?? [];
  let steps = inputSteps;
  let target = i.targetTimeS;
  let grindStepped = false;
  let timeEstimate = false;
  const tempStep = espresso ? 1 : 2;
  const doseStep = Math.max(1, Math.round(i.doseG * 0.07));
  const yieldStep = Math.max(2, Math.round(i.doseG * 0.2));

  switch (r.change) {
    case 'GRIND_FINER':
    case 'GRIND_COARSER': {
      const finer = r.change === 'GRIND_FINER';
      const g = adjustGrind(i.grind, finer);
      if (g != null) { grind = g; grindStepped = true; }
      const delta = espresso ? 3 : clamp(roundTo5(i.targetTimeS * 0.1), 5, 600);
      target = Math.max(5, i.targetTimeS + (finer ? delta : -delta));
      timeEstimate = true;
      break;
    }
    case 'TEMP_UP': temp = temp == null ? null : Math.min(96, temp + tempStep); break;
    case 'TEMP_DOWN': temp = temp == null ? null : Math.max(80, temp - tempStep); break;
    case 'DOSE_UP': dose = round1(dose + doseStep); break;
    case 'DOSE_DOWN': dose = round1(Math.max(1, dose - doseStep)); break;
    case 'YIELD_UP': water = round1(water + yieldStep); break;
    case 'YIELD_DOWN': water = round1(Math.max(dose, water - yieldStep)); break;
    case 'BLOOM_LONGER': {
      const b = steps.findIndex((s) => s.type === 'BLOOM');
      steps = steps.map((s, idx) => (idx > b ? { ...s, startS: s.startS + 15 } : s));
      target += 15;
      break;
    }
    default: break;
  }
  const suggestion: Suggestion = { doseG: dose, waterG: water, tempC: temp, grind, steps, targetTimeS: target };
  const changed = dose !== i.doseG || water !== i.waterG || temp !== i.tempC || grind !== i.grind || !sameSteps(steps, inputSteps);
  return { symptom, cause: r.cause, variables: r.variables, change: r.change, suggestion, recipeChanged: changed, grindStepped, timeIsEstimate: timeEstimate };
}

export function diagnose(input: BrewInput, symptoms: Set<Symptom> | Symptom[]): Diagnosis | null {
  const symptom = primarySymptom(symptoms);
  if (!symptom) return null;
  const r = isEspresso(input.method) ? espressoRule(input, symptom) : filterRule(input, symptom);
  return build(input, symptom, r);
}

export function parseSymptoms(raw: string): Symptom[] {
  const all = ['SOUR', 'BITTER', 'WEAK', 'STRONG', 'DRY', 'ASTRINGENT', 'FLAT', 'HOLLOW', 'HARSH', 'MUDDY'];
  const out: Symptom[] = [];
  for (const n of raw.split(',')) if (all.includes(n) && !out.includes(n as Symptom)) out.push(n as Symptom);
  return out;
}
