// Port of CoffeeEngine, TimerEngine state and StepSchedule. Pure functions, unit tested.
import { BrewMethod, BrewStep, isEspresso, STEP_TYPES, StepType } from './models';

export type Solve = 'WATER' | 'COFFEE' | 'RATIO';
export interface Triple3 { doseG: number; waterG: number; ratio: number }

/** Kotlin roundToLong: half up. JS Math.round matches for the values used here. */
export const round1 = (v: number) => Math.round(v * 10) / 10;
export const round2 = (v: number) => Math.round(v * 100) / 100;

export const ratio = (waterG: number, doseG: number): number | null => (doseG > 0 && waterG >= 0 ? waterG / doseG : null);
export const waterFor = (doseG: number, r: number) => doseG * r;
export const doseFor = (waterG: number, r: number): number | null => (r > 0 ? waterG / r : null);

export function solve(target: Solve, doseG: number | null, waterG: number | null, r: number | null): Triple3 | null {
  switch (target) {
    case 'WATER':
      return doseG != null && r != null && doseG > 0 && r > 0 ? { doseG, waterG: waterFor(doseG, r), ratio: r } : null;
    case 'COFFEE':
      return waterG != null && r != null && waterG > 0 && r > 0 ? { doseG: doseFor(waterG, r)!, waterG, ratio: r } : null;
    case 'RATIO':
      return doseG != null && waterG != null && doseG > 0 && waterG > 0 ? { doseG, waterG, ratio: waterG / doseG } : null;
  }
}

/** Filter grounds keep about twice their weight in water. Espresso yield is measured in the cup. */
export const beverageEstimate = (waterG: number, doseG: number, method: BrewMethod) =>
  isEspresso(method) ? waterG : Math.max(0, waterG - 2 * doseG);

export const flowRate = (yieldG: number, timeS: number): number | null => (timeS > 0 ? yieldG / timeS : null);

export function scaleSteps(steps: BrewStep[], oldWaterG: number, newWaterG: number): BrewStep[] {
  if (oldWaterG <= 0 || Math.abs(oldWaterG - newWaterG) < 0.05) return steps;
  const f = newWaterG / oldWaterG;
  return steps.map((s) => ({ ...s, targetWaterG: s.targetWaterG == null ? null : round1(s.targetWaterG * f) }));
}

export const gToOz = (g: number) => g / 28.349523125;
export const ozToG = (oz: number) => oz * 28.349523125;
export const cToF = (c: number) => (c * 9) / 5 + 32;
export const fToC = (f: number) => ((f - 32) * 5) / 9;

/** "1:16.7", "1:2". Trailing ".0" is dropped. */
export function formatRatio(r: number | null | undefined): string {
  if (r == null || !Number.isFinite(r)) return '–';
  const v = round1(r);
  return v === Math.round(v) ? `1:${Math.round(v)}` : `1:${v}`;
}

/** 1 decimal (or 2), without a useless ".0". */
export function formatNumber(v: number, decimals = 1): string {
  const r = decimals >= 2 ? round2(v) : round1(v);
  return r === Math.round(r) ? String(Math.round(r)) : String(r);
}

const pad2 = (n: number) => String(n).padStart(2, '0');

/** mm:ss, or h:mm:ss for long steeps such as cold brew. */
export function formatClock(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return h > 0 ? `${h}:${pad2(m)}:${pad2(sec)}` : `${pad2(m)}:${pad2(sec)}`;
}

/** Seconds with tenths: "28.4". */
export function formatTenths(ms: number): string {
  const t = Math.floor(Math.max(0, ms) / 100);
  return `${Math.floor(t / 10)}.${t % 10}`;
}

export function parseNumber(text: string): number | null {
  const t = text.trim().replace(',', '.');
  if (t === '' || !/^[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?$/.test(t)) return null;
  const v = Number(t);
  return Number.isFinite(v) ? v : null;
}

/** Accepts "3:05", "185", "1:02:00". Returns seconds. */
export function parseClock(text: string): number | null {
  const t = text.trim();
  if (!t) return null;
  const parts = t.split(':');
  if (parts.some((p) => !/^\d+$/.test(p))) return null;
  const n = parts.map(Number);
  switch (n.length) {
    case 1: return n[0];
    case 2: return n[0] * 60 + n[1];
    case 3: return n[0] * 3600 + n[1] * 60 + n[2];
    default: return null;
  }
}

// ---- steps codec, same JSON as kotlinx.serialization with encodeDefaults ------------------------

export function encodeSteps(steps: BrewStep[]): string {
  return JSON.stringify(steps.map((s) => ({ label: s.label, type: s.type, startS: s.startS, targetWaterG: s.targetWaterG, note: s.note })));
}

export function decodeSteps(raw: string | null | undefined): BrewStep[] {
  if (!raw || !raw.trim()) return [];
  try {
    const list = JSON.parse(raw);
    if (!Array.isArray(list)) return [];
    return list.map((o: Record<string, unknown>) => ({
      label: String(o.label ?? ''),
      type: (STEP_TYPES as readonly string[]).includes(String(o.type)) ? (o.type as StepType) : 'POUR',
      startS: Number.isFinite(Number(o.startS)) ? Math.trunc(Number(o.startS)) : 0,
      targetWaterG: o.targetWaterG == null || !Number.isFinite(Number(o.targetWaterG)) ? null : Number(o.targetWaterG),
      note: String(o.note ?? ''),
    }));
  } catch {
    return [];
  }
}

// ---- timer -----------------------------------------------------------------------------------

/**
 * Elapsed time is derived from a clock, never from frames. The web app uses the wall clock (Date.now):
 * on iPhone the monotonic clock stops while the phone sleeps, the wall clock does not.
 */
export interface TimerState {
  running: boolean;
  accumulatedMs: number;
  startedAtMs: number | null;
  laps: number[];
}

export const idleTimer = (): TimerState => ({ running: false, accumulatedMs: 0, startedAtMs: null, laps: [] });

export const elapsedMs = (t: TimerState, now: number) =>
  t.accumulatedMs + (t.running && t.startedAtMs != null ? Math.max(0, now - t.startedAtMs) : 0);

export const hasStarted = (t: TimerState) => t.running || t.accumulatedMs > 0;

export const startTimer = (t: TimerState, now: number): TimerState => (t.running ? t : { ...t, running: true, startedAtMs: now });
export const pauseTimer = (t: TimerState, now: number): TimerState =>
  !t.running ? t : { ...t, running: false, accumulatedMs: elapsedMs(t, now), startedAtMs: null };
export const lapTimer = (t: TimerState, now: number): TimerState => ({ ...t, laps: [...t.laps, elapsedMs(t, now)] });

export const StepSchedule = {
  /** Index of the step active at [elapsedS], or -1 when there is none. */
  indexAt(steps: BrewStep[], elapsedS: number): number {
    let idx = -1;
    for (let i = 0; i < steps.length; i++) {
      if (steps[i].startS <= elapsedS) idx = i;
      else break;
    }
    return idx;
  },

  endOf(steps: BrewStep[], index: number, targetS: number): number {
    if (index >= 0 && index < steps.length - 1) return steps[index + 1].startS;
    return Math.max(targetS, steps[index]?.startS ?? 0);
  },

  /** Cumulative water expected on the scale once step [index] is done. */
  targetWaterAt(steps: BrewStep[], index: number): number | null {
    for (let i = Math.min(index, steps.length - 1); i >= 0; i--) {
      const w = steps[i].targetWaterG;
      if (w != null) return w;
    }
    return null;
  },

  /** Makes the current step [deltaS] longer by pushing every later step. */
  extendCurrent(steps: BrewStep[], elapsedS: number, targetS: number, deltaS: number): [BrewStep[], number] {
    const idx = StepSchedule.indexAt(steps, elapsedS);
    return [steps.map((s, i) => (i > idx ? { ...s, startS: s.startS + deltaS } : s)), targetS + deltaS];
  },

  /** Jumps to the next step now by sliding the rest of the schedule. Null when there is no further step. */
  advanceNow(steps: BrewStep[], elapsedS: number, targetS: number): [BrewStep[], number] | null {
    const next = StepSchedule.indexAt(steps, elapsedS) + 1;
    if (next < 0 || next >= steps.length) return null;
    const delta = Math.trunc(elapsedS) - steps[next].startS;
    const out = steps.map((s, i) => (i >= next ? { ...s, startS: s.startS + delta } : s));
    return [out, Math.max(targetS + delta, out[out.length - 1].startS)];
  },

  normalize(steps: BrewStep[]): BrewStep[] {
    return steps.map((s) => ({ ...s, startS: Math.max(0, s.startS) })).sort((a, b) => a.startS - b.startS);
  },
};

// ---- dates -----------------------------------------------------------------------------------

/** Local calendar day as days since 1970-01-01, like LocalDate.toEpochDay(). */
export function epochDayOf(ms: number): number {
  const d = new Date(ms);
  return Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 86_400_000);
}
export const today = () => epochDayOf(Date.now());
export const epochDayToIso = (day: number) => new Date(day * 86_400_000).toISOString().slice(0, 10);
export const isoToEpochDay = (iso: string): number | null => {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
  return m ? Math.floor(Date.UTC(+m[1], +m[2] - 1, +m[3]) / 86_400_000) : null;
};
export const localIsoDate = (ms = Date.now()) => epochDayToIso(epochDayOf(ms));
