// Maps a recognised sentence to a brew command. English, French and Spanish keywords, like the Android parser.
export type VoiceCommand =
  | { kind: 'START' } | { kind: 'PAUSE' } | { kind: 'NEXT' } | { kind: 'RESET' } | { kind: 'RATIO' }
  | { kind: 'ADD'; grams: number } | { kind: 'UNKNOWN' };

export function parseVoice(raw: string): VoiceCommand {
  const t = raw.toLowerCase().trim();
  if (!t) return { kind: 'UNKNOWN' };
  const has = (...keys: string[]) => keys.some((k) => t.includes(k));
  const num = /(\d+(?:[.,]\d+)?)/.exec(t);
  if (has('ratio')) return { kind: 'RATIO' };
  if (has('add', 'ajoute', 'añade', 'anade', 'agrega') && num) return { kind: 'ADD', grams: Number(num[1].replace(',', '.')) };
  if (has('next', 'suivant', 'siguiente')) return { kind: 'NEXT' };
  if (has('reset', 'réinitialise', 'reinitialise', 'remise à zéro', 'reinicia')) return { kind: 'RESET' };
  if (has('pause', 'stop', 'arrête', 'arrete', 'pausa', 'para')) return { kind: 'PAUSE' };
  if (has('start', 'resume', 'démarre', 'demarre', 'lance', 'reprends', 'empieza', 'inicia', 'continúa', 'continua')) return { kind: 'START' };
  return { kind: 'UNKNOWN' };
}
