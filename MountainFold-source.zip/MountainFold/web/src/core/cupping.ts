// Toulouse Cupping vocabulary and rules, ported 1:1 from the original web app (via the Android port).
// Keys stay in French, exactly as the original stored them, so exports and old data line up.
import { CuppingCoffee, cuppingFinalScore, cuppingUniqueNotes } from './models';

export interface Term { key: string; en: string; es: string }
export const termLabel = (t: Term, lang: string) => (lang === 'en' ? t.en : lang === 'es' ? t.es : t.key);
const t = (fr: string, en: string, es: string): Term => ({ key: fr, en, es });

export interface AromaCategory { id: string; name: Term; color: string; items: Term[] }

export const AROMA_CATEGORIES: AromaCategory[] = [
  {
    id: 'fruity', name: t('Fruité', 'Fruity', 'Frutal'), color: '#CF3E53',
    items: [
      t('Citron', 'Lemon', 'Limón'), t('Orange', 'Orange', 'Naranja'), t('Pamplemousse', 'Grapefruit', 'Pomelo'),
      t('Cerise', 'Cherry', 'Cereza'), t('Fraise', 'Strawberry', 'Fresa'), t('Framboise', 'Raspberry', 'Frambuesa'),
      t('Myrtille', 'Blueberry', 'Arándano'), t('Raisin', 'Grape', 'Uva'), t('Ananas', 'Pineapple', 'Piña'),
      t('Mangue', 'Mango', 'Mango'), t('Passion', 'Passion Fruit', 'Maracuyá'), t('Pêche', 'Peach', 'Melocotón'),
      t('Pomme verte', 'Green Apple', 'Manzana Verde'), t('Poire', 'Pear', 'Pera'),
    ],
  },
  {
    id: 'floral', name: t('Floral', 'Floral', 'Floral'), color: '#E14684',
    items: [
      t('Jasmin', 'Jasmine', 'Jazmín'), t('Rose', 'Rose', 'Rosa'), t("Fleur d'oranger", 'Orange Blossom', 'Azahar'),
      t('Lavande', 'Lavender', 'Lavanda'), t('Hibiscus', 'Hibiscus', 'Hibisco'), t('Violette', 'Violet', 'Violeta'),
      t('Camomille', 'Chamomile', 'Manzanilla'),
    ],
  },
  {
    id: 'spicy', name: t('Épicé', 'Spicy', 'Especiado'), color: '#CC3D42',
    items: [
      t('Cannelle', 'Cinnamon', 'Canela'), t('Clou de girofle', 'Clove', 'Clavo'), t('Muscade', 'Nutmeg', 'Nuez Moscada'),
      t('Poivre', 'Pepper', 'Pimienta'), t('Cardamome', 'Cardamom', 'Cardamomo'), t('Gingembre', 'Ginger', 'Jengibre'),
    ],
  },
  {
    id: 'nutty', name: t('Chocolat / Noix', 'Nutty / Cocoa', 'Frutos Secos / Cacao'), color: '#B57B4E',
    items: [
      t('Chocolat noir', 'Dark Chocolate', 'Choc. Negro'), t('Chocolat au lait', 'Milk Chocolate', 'Choc. con Leche'),
      t('Cacao', 'Cocoa', 'Cacao'), t('Noisette', 'Hazelnut', 'Avellana'), t('Amande', 'Almond', 'Almendra'),
      t('Noix', 'Walnut', 'Nuez'), t('Cacahuète', 'Peanut', 'Cacahuete'),
    ],
  },
  {
    id: 'sweet', name: t('Caramélisé', 'Sweet', 'Dulce'), color: '#E48833',
    items: [
      t('Caramel', 'Caramel', 'Caramelo'), t('Miel', 'Honey', 'Miel'), t('Cassonade', 'Brown Sugar', 'Azúcar Moreno'),
      t("Sirop d'érable", 'Maple Syrup', 'Jarabe de Arce'), t('Mélasse', 'Molasses', 'Melaza'),
    ],
  },
  {
    id: 'cereal', name: t('Céréales / Pain', 'Roasted', 'Tostado'), color: '#DDAF61',
    items: [
      t('Pain grillé', 'Toast', 'Pan Tostado'), t('Biscuit', 'Biscuit', 'Galleta'), t('Céréales', 'Cereal', 'Cereal'),
      t('Malt', 'Malt', 'Malta'), t('Noisette grillée', 'Roasted Hazelnut', 'Avellana Tostada'),
    ],
  },
];

export const ITEM_COLOR_OVERRIDES: Record<string, string> = {
  Citron: '#F5E452', Orange: '#F29635', Pamplemousse: '#F27056',
  Cerise: '#E72D37', Fraise: '#EF474A', Framboise: '#E52E6C', Myrtille: '#6165A4',
  Raisin: '#AEBF43', Ananas: '#F8C739', Mangue: '#F7941D', Passion: '#F2CA1E',
  'Pêche': '#F3965E', 'Pomme verte': '#64AC56', Poire: '#C5B446',
  Jasmin: '#F8F8F3', Rose: '#EF8CA6', Camomille: '#F5C656',
  "Fleur d'oranger": '#FCE6C9', Lavande: '#907DC1', Hibiscus: '#D44C6A', Violette: '#7F5C9E',
  Poivre: '#9D3235', Cannelle: '#C46436', 'Clou de girofle': '#A26947',
  Muscade: '#8C6544', Gingembre: '#D6B563', Cardamome: '#999C63',
  'Chocolat noir': '#462920', 'Chocolat au lait': '#694231', Cacao: '#5D3C2E',
  Noisette: '#9C7349', Amande: '#C7A482', Noix: '#7B6652', 'Cacahuète': '#D3A45C',
  Caramel: '#D17C2D', Miel: '#EAA63F', "Sirop d'érable": '#AD5D2D',
  'Mélasse': '#5E2C22', Cassonade: '#C66940',
  'Pain grillé': '#886A4C', Biscuit: '#E7C888', 'Céréales': '#D7B066',
  Malt: '#D8AF67', 'Noisette grillée': '#B0885D',
};

export const PROCESSING_METHODS = [
  t('Nature', 'Natural', 'Natural'), t('Honey', 'Honey', 'Honey'), t('Lavé', 'Washed', 'Lavado'),
  t('Anaérobie', 'Anaerobic', 'Anaeróbico'), t('Co-Fermenté', 'Co-Fermented', 'Co-Fermentado'),
];
export const ACIDITY_TYPES = [t('Citrique', 'Citric', 'Cítrica'), t('Malique', 'Malic', 'Málica'), t('Tartrique', 'Tartaric', 'Tartárica'), t('Acétique', 'Acetic', 'Acética')];
export const ACIDITY_INTENSITIES = [t('Faible', 'Low', 'Baja'), t('Moyenne', 'Medium', 'Media'), t('Forte', 'High', 'Alta')];
export const BODY_TYPES = [
  t('Aqueux', 'Watery', 'Acuoso'), t('Léger', 'Light', 'Ligero'), t('Moyen', 'Medium', 'Medio'), t('Rond', 'Round', 'Redondo'),
  t('Crémeux', 'Creamy', 'Cremoso'), t('Sirupeux', 'Syrupy', 'Siruposo'), t('Velouté', 'Velvety', 'Aterciopelado'), t('Charnu', 'Juicy', 'Carnoso'),
];

const TERMS = new Map<string, Term>();
for (const c of AROMA_CATEGORIES) { TERMS.set(c.name.key, c.name); c.items.forEach((i) => TERMS.set(i.key, i)); }
[...PROCESSING_METHODS, ...ACIDITY_TYPES, ...ACIDITY_INTENSITIES, ...BODY_TYPES].forEach((x) => TERMS.set(x.key, x));

/** Label for a stored French key. Unknown keys come back unchanged, like the original. */
export const cupLabel = (key: string, lang: string) => { const x = TERMS.get(key); return x ? termLabel(x, lang) : key; };
export const categoryOf = (note: string) => AROMA_CATEGORIES.find((c) => c.items.some((i) => i.key === note)) ?? null;
export const noteColor = (note: string): string | null => ITEM_COLOR_OVERRIDES[note] ?? categoryOf(note)?.color ?? null;
export const CHIP_DEFAULT = '#865328';

/** YIQ contrast rule from the original: dark text on light colours, white on dark ones. */
export function contrastOn(hex: string): string {
  const v = parseInt(hex.replace('#', '').slice(-6), 16);
  const r = (v >> 16) & 0xff;
  const g = (v >> 8) & 0xff;
  const b = v & 0xff;
  return (r * 299 + g * 587 + b * 114) / 1000 >= 128 ? '#1E1B18' : '#FFFFFF';
}

export interface LabMethod { id: string; defaultRatio: number }
export const LAB_METHODS: LabMethod[] = [
  { id: 'v60', defaultRatio: 16 }, { id: 'chemex', defaultRatio: 15 }, { id: 'aeropress', defaultRatio: 14 },
  { id: 'french_press', defaultRatio: 12 }, { id: 'moka', defaultRatio: 10 }, { id: 'kalita', defaultRatio: 16 },
];
export function labMethodName(id: string, lang: string): string {
  switch (id) {
    case 'v60': return 'V60';
    case 'chemex': return 'Chemex';
    case 'aeropress': return 'Aeropress';
    case 'french_press': return lang === 'en' ? 'French Press' : lang === 'es' ? 'Prensa' : 'Piston';
    case 'moka': return 'Moka';
    case 'kalita': return 'Kalita';
    default: return id.charAt(0).toUpperCase() + id.slice(1);
  }
}

// ---- formatting -------------------------------------------------------------------------------

export const CupFormat = {
  /** toFixed(2), like the original. */
  fixed2: (v: number) => v.toFixed(2),
  /** A number the way JavaScript prints it: 8 for 8.0, 8.25 for 8.25. */
  jsNumber: (v: number) => String(v),
  clock: (seconds: number) => {
    const s = Math.max(0, Math.floor(seconds));
    return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
  },
  water: (coffeeG: number, ratio: number) => { const w = coffeeG * ratio; return Number.isFinite(w) ? Math.round(w) : 0; },
  /** Comma or dot, empty means 0 like Number('') in the original. */
  parse: (text: string): number | null => {
    const s = text.trim().replace(',', '.');
    if (s === '') return 0;
    const v = Number(s);
    return Number.isFinite(v) ? v : null;
  },
};

// ---- countdown --------------------------------------------------------------------------------

/**
 * 4 or 6 minutes. In 6 minute mode it rings once when 2 minutes remain (break the crust) and at the end.
 */
export type CupPhase = 'CRUST' | 'TASTE' | 'FINISHED' | 'PAUSED';
export interface CupTimerState { initialS: number; remainingMs: number; running: boolean; endAt: number }
export const CUP_SIX = 360;
export const CUP_CRUST_AT = 120;
export const cupIdle = (): CupTimerState => ({ initialS: 0, remainingMs: 0, running: false, endAt: 0 });
export const cupRemainingS = (s: CupTimerState) => Math.max(0, Math.ceil(s.remainingMs / 1000));
export const cupProgress = (s: CupTimerState) => (s.initialS > 0 ? Math.min(1, Math.max(0, (s.initialS * 1000 - s.remainingMs) / (s.initialS * 1000))) : 0);
export const cupSix = (s: CupTimerState) => s.initialS === CUP_SIX;
export function cupPhase(s: CupTimerState): CupPhase {
  const rem = cupRemainingS(s);
  if (s.running) return cupSix(s) && rem > CUP_CRUST_AT ? 'CRUST' : 'TASTE';
  if (rem === 0 && s.initialS > 0) return 'FINISHED';
  return 'PAUSED';
}
export const cupStart = (minutes: number, now: number): CupTimerState => ({ initialS: minutes * 60, remainingMs: minutes * 60_000, running: true, endAt: now + minutes * 60_000 });
export function cupToggle(s: CupTimerState, now: number): CupTimerState {
  if (s.running) return { ...s, remainingMs: Math.max(0, s.endAt - now), running: false };
  if (s.remainingMs > 0) return { ...s, endAt: now + s.remainingMs, running: true };
  return s;
}
export const cupReset = (s: CupTimerState): CupTimerState => ({ ...s, remainingMs: s.initialS * 1000, running: false });
/** Advances the clock. Returns the alerts crossed since the previous call. */
export function cupTick(s: CupTimerState, now: number): [CupTimerState, ('CRUST' | 'FINISHED')[]] {
  if (!s.running) return [s, []];
  const before = cupRemainingS(s);
  const left = Math.max(0, s.endAt - now);
  const next = { ...s, remainingMs: left, running: left > 0 };
  const alerts: ('CRUST' | 'FINISHED')[] = [];
  if (cupSix(s) && before > CUP_CRUST_AT && cupRemainingS(next) <= CUP_CRUST_AT && left > 0) alerts.push('CRUST');
  if (left === 0) alerts.push('FINISHED');
  return [next, alerts];
}

// ---- flavor wheel -------------------------------------------------------------------------------

export interface Slice { key: string; category: AromaCategory; color: string; startDeg: number; endDeg: number; midDeg: number }
export const SLICES: Slice[] = (() => {
  const all = AROMA_CATEGORIES.flatMap((c) => c.items.map((i) => [c, i] as const));
  const stepDeg = 360 / all.length;
  return all.map(([c, item], i) => ({
    key: item.key, category: c, color: ITEM_COLOR_OVERRIDES[item.key] ?? c.color,
    startDeg: i * stepDeg, endDeg: (i + 1) * stepDeg, midDeg: (i + 0.5) * stepDeg,
  }));
})();
export const WHEEL_STEP = 360 / SLICES.length;

export function wheelActiveIndex(rotationDeg: number, pointerDeg = 0): number {
  let target = (pointerDeg - rotationDeg) % 360;
  if (target < 0) target += 360;
  return Math.min(SLICES.length - 1, Math.max(0, Math.floor(target / WHEEL_STEP)));
}
export function wheelRotationFor(index: number, fromDeg: number, pointerDeg = 0): number {
  const wanted = pointerDeg - SLICES[index].midDeg;
  const turns = Math.round((fromDeg - wanted) / 360);
  return wanted + turns * 360;
}
export function angleDelta(fromDeg: number, toDeg: number): number {
  let d = toDeg - fromDeg;
  while (d > 180) d -= 360;
  while (d < -180) d += 360;
  return d;
}

// ---- CSV ----------------------------------------------------------------------------------------

const quoted = (s: string) => `"${s.replace(/"/g, '""')}"`;
const field = (s: string) => (/[,"\n\r]/.test(s) ? quoted(s) : s);

/** CSV export of the summary table. Columns and order follow the original. */
export function buildCsv(coffees: CuppingCoffee[], headers: string[], yes: string, no: string, label: (k: string) => string): string {
  const lines = [headers.map(field).join(',')];
  for (const c of coffees) {
    lines.push([
      quoted(c.name),
      c.isFavorite ? yes : no,
      field(label(c.process)),
      CupFormat.fixed2(cuppingFinalScore(c)),
      quoted(cuppingUniqueNotes(c).map(label).join(', ')),
      CupFormat.jsNumber(c.fragranceScore), CupFormat.jsNumber(c.flavorScore), CupFormat.jsNumber(c.aftertasteScore),
      CupFormat.jsNumber(c.acidityScore), CupFormat.jsNumber(c.bodyScore), CupFormat.jsNumber(c.balanceScore),
      quoted(c.comments),
    ].join(','));
  }
  return lines.join('\n');
}
