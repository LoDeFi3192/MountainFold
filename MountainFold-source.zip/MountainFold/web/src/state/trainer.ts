// Barista Trainer state, port of the trainer part of MainViewModel.
import { epochDayOf, formatClock, formatRatio, ratio as ratioOf, today } from '../core/coffee';
import { ChangeKind, Cause, parseSymptoms } from '../core/copilot';
import { Brew, isEspresso, METHODS, Symptom, TrainingEvent } from '../core/models';
import { KRandom, shuffledIndices } from '../core/random';
import {
  Breakdown, BrewSignal, DialIn, EventKind, EVENT_KINDS, EXAM_SKILLS, ExamCategory, Lesson, lessonsByLevel, lt, Progress,
  Question, Recommendation, Scenario, scenarioSkill, Skill, SkillTree, TrainContent, TrainEvent, TrainProgress,
  defaultFilterInput, defaultShotInput,
} from '../core/train';
import content from '../data/train-content.json';
import { AppData, putRows } from '../data/db';
import { lang, t } from '../i18n/i18n';
import type { GetFn, SetFn } from './store';
import { unitsOf } from './store';
import type { AppState, QuizItem, QuizRun, TrainScreen, TrainSlice } from './types';

export const TRAIN = content as unknown as TrainContent;
const BY_LEVEL = lessonsByLevel(TRAIN);
export const lessonById = (id: string): Lesson | undefined => TRAIN.lessons.find((l) => l.id === id);

export const trainInitial = (): TrainSlice => ({
  trainStack: [],
  lessonRun: null,
  quiz: null,
  quizResult: null,
  filterSim: defaultFilterInput(),
  shotSim: defaultShotInput(),
  labEspresso: false,
  yieldCalc: ['15', '220', '1.36'],
  milkTemp: 20,
});

// ---- vocabulary shared with the Copilot screens --------------------------------------------------
export const symptomKey = (s: Symptom) => `sym_${s.toLowerCase()}`;
export const CAUSE_KEY: Record<Cause, string> = {
  UNDER_EXTRACTION: 'cause_under', OVER_EXTRACTION: 'cause_over', LOW_STRENGTH: 'cause_weak', HIGH_STRENGTH: 'cause_strong',
  UNEVEN_EXTRACTION: 'cause_uneven', TOO_HOT: 'cause_hot', STALE_COFFEE: 'cause_stale', TOO_MANY_FINES: 'cause_fines', CHANNELING: 'cause_channeling',
};
const CHANGE_SUFFIX: Record<ChangeKind, string> = {
  GRIND_FINER: 'finer', GRIND_COARSER: 'coarser', TEMP_UP: 'temp_up', TEMP_DOWN: 'temp_down', DOSE_UP: 'dose_up', DOSE_DOWN: 'dose_down',
  YIELD_UP: 'yield_up', YIELD_DOWN: 'yield_down', BLOOM_LONGER: 'bloom', AGITATE_LESS: 'agitate', PUCK_PREP: 'puck', FRESHER_COFFEE: 'fresh',
};
export const changeTitleKey = (k: ChangeKind) => `chg_${CHANGE_SUFFIX[k]}`;
export const changeWhyKey = (k: ChangeKind) => `why_${CHANGE_SUFFIX[k]}`;

// ---- derived data ---------------------------------------------------------------------------------
const toCore = (e: TrainingEvent): TrainEvent => ({
  createdAt: e.createdAt, kind: (EVENT_KINDS as readonly string[]).includes(e.kind) ? (e.kind as EventKind) : 'LESSON',
  refId: e.refId, correct: e.correct, total: e.total, xp: e.xp, passed: e.passed, breakdown: e.breakdown,
});

let memoEvents: TrainingEvent[] | null = null;
let memoDay = -1;
let memoProgress: Progress | null = null;
export function progressOf(events: TrainingEvent[]): Progress {
  const day = today();
  if (memoEvents !== events || memoDay !== day || !memoProgress) {
    memoEvents = events;
    memoDay = day;
    memoProgress = TrainProgress.compute(events.map(toCore), BY_LEVEL, day, epochDayOf);
  }
  return memoProgress;
}

export const brewSignals = (brews: Brew[]): BrewSignal[] =>
  brews.map((b) => ({ createdAt: b.createdAt, espresso: isEspresso(b.method as never), symptoms: parseSymptoms(b.symptoms) }));
export const opportunityOf = (brews: Brew[]) => TrainProgress.opportunity(brewSignals(brews));

function prefersEspresso(s: AppState) {
  const list = s.data.brews;
  return list.length === 0 ? isEspresso(s.settings.defaultMethod) : list.filter((b) => b.method === 'ESPRESSO').length * 2 > list.length;
}

export const recommendationsOf = (s: AppState, progress: Progress) =>
  TrainProgress.recommendations(progress, TRAIN.lessons, opportunityOf(s.data.brews), prefersEspresso(s));

// ---- building quiz items ---------------------------------------------------------------------------
function itemOf(q: Question, skill: Skill, r: KRandom): QuizItem {
  const l = lang();
  const order = shuffledIndices(r, q.options.length);
  return {
    id: q.id, skill: (q.skill as Skill) ?? skill, prompt: lt(q.prompt, l), facts: [],
    options: order.map((i) => lt(q.options[i], l)), correct: order.indexOf(q.correct ?? 0), why: lt(q.why, l),
  };
}

function itemOfScenario(s: AppState, sc: Scenario, index: number, r: KRandom): QuizItem {
  const u = unitsOf(s.settings);
  const i = sc.input;
  const espresso = isEspresso(i.method);
  const rr = formatRatio(ratioOf(i.waterG, i.doseG));
  const facts: [string, string][] = [
    [t('method'), i.method === 'CUSTOM' ? t('method_custom') : METHODS[i.method].label],
    [t('dose'), u.w(i.doseG)],
    [t(espresso ? 'yield_label' : 'water'), `${u.w(i.waterG)} · ${rr}`],
  ];
  if (i.tempC != null) facts.push([t('temperature'), u.t(i.tempC)]);
  if (i.timeS != null) {
    const time = espresso ? `${i.timeS} s` : formatClock(i.timeS);
    const target = espresso ? `${i.targetTimeS} s` : formatClock(i.targetTimeS);
    facts.push([t('time'), t('time_vs_target', time, target)]);
  }
  facts.push([t('taste'), t(symptomKey(sc.symptom))]);
  const order = shuffledIndices(r, sc.options.length);
  return {
    id: `dialin_${index}`, skill: scenarioSkill(sc), prompt: t('dialin_prompt'), facts,
    options: order.map((k) => t(changeTitleKey(sc.options[k]))), correct: order.indexOf(0),
    why: `${t(CAUSE_KEY[sc.diagnosis.cause])} ${t(changeWhyKey(sc.diagnosis.change))}`,
  };
}

// ---- brews feed the trainer --------------------------------------------------------------------------
function streakBonus(before: TrainingEvent[], now: number): Omit<TrainingEvent, 'id'> | null {
  const day = epochDayOf(now);
  if (before.some((e) => e.kind !== 'STREAK_BONUS' && epochDayOf(e.createdAt) === day)) return null;
  const events = [...before.map(toCore), { createdAt: now, kind: 'DAILY' as EventKind, refId: '', correct: 0, total: 0, xp: 0, passed: false, breakdown: '' }];
  const streak = TrainProgress.streak(events, day, epochDayOf);
  if (streak === 0 || streak % 7 !== 0) return null;
  return {
    createdAt: now + 1, kind: 'STREAK_BONUS', refId: `streak:${day}`, skill: '', correct: 0, total: 0, durationS: 0,
    xp: TrainProgress.xpFor('STREAK_BONUS', true, false), passed: true, breakdown: '',
  };
}

async function saveEvents(set: SetFn, get: GetFn, setData: ((f: (d: AppData) => Partial<AppData>) => void) | null, events: Omit<TrainingEvent, 'id'>[]) {
  let id = get().data.training.reduce((m, e) => Math.max(m, e.id), 0);
  const rows = events.map((e) => ({ ...e, id: ++id }));
  if (setData) setData((d) => ({ training: [...d.training, ...rows] }));
  else set((s) => ({ data: { ...s.data, training: [...rows, ...s.data.training].sort((a, b) => b.createdAt - a.createdAt) } }));
  await putRows('training', rows);
}

/** BREW to LOG: a tasted, logged brew earns XP and completes a pending brew challenge. */
export async function recordBrewForTraining(get: GetFn, set: SetFn, brew: Brew): Promise<boolean> {
  const now = Date.now();
  const events: Omit<TrainingEvent, 'id'>[] = [];
  const tasted = brew.rating > 0 || [brew.acidity, brew.sweetness, brew.body, brew.balance, brew.clarity].some((x) => x > 0) || brew.symptoms.trim() !== '';
  const pending = get().settings.pendingBrewChallenge;
  const challenge = pending != null && tasted;
  if (challenge) {
    events.push({
      createdAt: now, kind: 'BREW_CHALLENGE', refId: pending!, skill: lessonById(pending!)?.skill ?? '', correct: 0, total: 0, durationS: 0,
      xp: TrainProgress.xpFor('BREW_CHALLENGE', true, false), passed: true, breakdown: '',
    });
    get().setSettings((s) => ({ ...s, pendingBrewChallenge: null }));
  }
  if (tasted) {
    events.push({
      createdAt: now + 1, kind: 'TASTING_LOG', refId: `brew:${brew.id}`, skill: 'SENSORY', correct: 0, total: 0, durationS: 0,
      xp: TrainProgress.xpFor('TASTING_LOG', true, false), passed: true, breakdown: '',
    });
  }
  if (events.length) {
    const bonus = streakBonus(get().data.training, now);
    if (bonus) events.push(bonus);
    await saveEvents(set, get, null, events);
  }
  return challenge;
}

// ---- slice --------------------------------------------------------------------------------------------
export function createTrainSlice(set: SetFn, get: GetFn, setData: (f: (d: AppData) => Partial<AppData>) => void): Partial<AppState> {
  const same = (a: TrainScreen, b: TrainScreen) => a.kind === b.kind && (a.kind !== 'LESSON' || (b as { id: string }).id === a.id);

  function launch(run: QuizRun) {
    if (run.items.length === 0) return;
    set({
      overlays: [], tab: 'TRAIN', quizResult: null, quiz: { ...run, startedAtMs: Date.now() },
      trainStack: [...get().trainStack.filter((s) => s.kind !== 'QUIZ' && s.kind !== 'RESULT'), { kind: 'QUIZ' }],
    });
  }

  const newRun = (kind: EventKind, refId: string, title: string, items: QuizItem[], extra: Partial<QuizRun> = {}): QuizRun => ({
    kind, refId, title, items, answers: items.map(() => null), index: 0, startedAtMs: 0, timeLimitS: null, lessonId: null, ...extra,
  });

  return {
    openTrain(s) {
      set({ overlays: [], tab: 'TRAIN', trainStack: [...get().trainStack.filter((x) => !same(x, s)), s] });
    },
    openLesson(id) {
      if (!lessonById(id)) return;
      set({
        overlays: [], tab: 'TRAIN', quiz: null, quizResult: null, lessonRun: { lessonId: id, page: 0 },
        trainStack: [...get().trainStack.filter((s) => s.kind !== 'LESSON' && s.kind !== 'QUIZ' && s.kind !== 'RESULT'), { kind: 'LESSON', id }],
      });
    },
    startRec(r: Recommendation) {
      if (r.type === 'LESSON') get().openLesson(r.lessonId);
      else if (r.type === 'DIAL_IN') get().startDialIn(r.espresso);
      else get().startExam(r.category);
    },
    leaveTraining() { set({ trainStack: [], quiz: null, quizResult: null, lessonRun: null }); },
    trainBack() {
      const stack = get().trainStack;
      const top = stack[stack.length - 1];
      if (!top) return;
      if (top.kind === 'LESSON') {
        const run = get().lessonRun;
        if (run && run.page > 0) set({ lessonRun: { ...run, page: run.page - 1 } });
        else set({ trainStack: stack.slice(0, -1), lessonRun: null });
      } else if (top.kind === 'QUIZ') set({ quiz: null, trainStack: stack.slice(0, -1) });
      else if (top.kind === 'RESULT') get().closeResult();
      else set({ trainStack: stack.slice(0, -1) });
    },
    lessonPage(delta) {
      const run = get().lessonRun;
      const lesson = run && lessonById(run.lessonId);
      if (!run || !lesson) return;
      const count = lessonPageCount(lesson);
      set({ lessonRun: { ...run, page: Math.min(count - 1, Math.max(0, run.page + delta)) } });
    },

    startLessonQuiz(id) {
      const lesson = lessonById(id);
      if (!lesson) return;
      const r = KRandom.fresh();
      launch(newRun('LESSON', lesson.id, lt(lesson.title, lang()), (lesson.questions ?? []).map((q) => itemOf(q, lesson.skill, r)), { lessonId: lesson.id }));
    },
    startDialIn(espresso) {
      const r = KRandom.fresh();
      const scenarios = DialIn.session(r, espresso, 5);
      launch(newRun('DIAL_IN', espresso ? SkillTree.DIAL_IN_ESPRESSO : SkillTree.DIAL_IN_FILTER, t(espresso ? 'train_dialin_espresso' : 'train_dialin_filter'),
        scenarios.map((s, i) => itemOfScenario(get(), s, i, r))));
    },
    /** One question a day, the same all day and on every device. Seeded by the date like the Android app. */
    startDaily() {
      const day = today();
      const r = KRandom.ofLong(day);
      let single: QuizItem;
      if (r.nextIntBelow(3) === 0 && TRAIN.bank.length > 0) {
        const q = r.pick(TRAIN.bank);
        single = itemOf(q, (q.skill as Skill) ?? 'EXTRACTION', r);
      } else {
        const sc = DialIn.generate(r, r.nextIntBelow(3) === 0);
        single = itemOfScenario(get(), sc, 0, r);
      }
      launch(newRun('DAILY', SkillTree.dayRef(day), t('train_daily'), [single]));
    },
    startLevelTest(level) {
      const r = KRandom.fresh();
      const lessons = TRAIN.lessons.filter((l) => l.level === level);
      const picked = r.shuffled(lessons.flatMap((l) => r.shuffled(l.questions ?? []).slice(0, 2).map((q) => itemOf(q, l.skill, r)))).slice(0, 6);
      launch(newRun('LEVEL_TEST', SkillTree.levelRef(level), t('train_level_test', level), picked));
    },
    startExam(category: ExamCategory) {
      const r = KRandom.fresh();
      let items: QuizItem[];
      if (category === 'TROUBLESHOOTING') {
        items = [
          ...DialIn.session(r, null, 8).map((s, i) => itemOfScenario(get(), s, i, r)),
          ...TRAIN.bank.filter((q) => q.id === 'bank_bitter_dry' || q.id === 'bank_weak_bitter').map((q) => itemOf(q, (q.skill as Skill) ?? 'EXTRACTION', r)),
        ];
      } else {
        const skills = EXAM_SKILLS[category];
        const fromLessons = TRAIN.lessons.filter((l) => skills.includes(l.skill)).flatMap((l) => (l.questions ?? []).map((q) => itemOf(q, l.skill, r)));
        const fromBank = TRAIN.bank.filter((q) => q.skill && skills.includes(q.skill as Skill)).map((q) => itemOf(q, q.skill as Skill, r));
        items = r.shuffled([...fromLessons, ...fromBank]).slice(0, 10);
      }
      launch(newRun('EXAM', category, t('train_exam'), r.shuffled(items), { timeLimitS: items.length * 30 }));
    },

    answer(i) {
      const run = get().quiz;
      if (!run) return;
      if (run.timeLimitS == null && run.answers[run.index] != null) return;
      const answers = run.answers.slice();
      answers[run.index] = i;
      set({ quiz: { ...run, answers } });
    },
    nextQuestion() {
      const run = get().quiz;
      if (!run) return;
      if (run.index === run.items.length - 1) get().finishQuiz();
      else set({ quiz: { ...run, index: run.index + 1 } });
    },
    previousQuestion() {
      const run = get().quiz;
      if (run && run.timeLimitS != null && run.index > 0) set({ quiz: { ...run, index: run.index - 1 } });
    },
    finishQuiz() {
      const run = get().quiz;
      if (!run || get().quizResult?.run === run) return;
      const correct = run.items.filter((it, i) => run.answers[i] === it.correct).length;
      const total = run.items.length;
      const passed = TrainProgress.passed(run.kind, correct, total);
      const duration = Math.max(0, Math.floor((Date.now() - run.startedAtMs) / 1000));
      const results: [Skill, boolean][] = run.items.map((it, i) => [it.skill, run.answers[i] === it.correct]);
      const before = get().data.training;
      const progressBefore = progressOf(before);
      const firstValidation = run.kind === 'LESSON' && !progressBefore.validated.has(run.refId);
      const xp = TrainProgress.xpFor(run.kind, passed, firstValidation);
      const now = Date.now();
      const skills = [...new Set(results.map((r) => r[0]))];
      const event: Omit<TrainingEvent, 'id'> = {
        createdAt: now, kind: run.kind, refId: run.refId, skill: skills.length === 1 ? skills[0] : '',
        correct, total, durationS: duration, xp, passed, breakdown: Breakdown.encode(results),
      };
      const bonus = streakBonus(before, now);
      const groups = new Map<Skill, boolean[]>();
      results.forEach(([s, ok]) => { if (!groups.has(s)) groups.set(s, []); groups.get(s)!.push(ok); });
      const weak = [...groups.entries()].filter(([, v]) => v.filter(Boolean).length * 10 < v.length * 7).map(([k]) => k);
      const after = [event, ...(bonus ? [bonus] : [])];
      const preview = [...after.map((e, i) => ({ ...e, id: -1 - i })), ...before];
      const recommendations = recommendationsOf(get(), progressOf(preview))
        .filter((r) => !(r.type === 'LESSON' && r.lessonId === run.lessonId && passed));
      set({
        quizResult: {
          run, correct, total, passed, xp: xp + (bonus?.xp ?? 0), durationS: duration, weak, recommendations,
          streakBonus: bonus != null, lessonValidated: run.kind === 'LESSON' && passed,
        },
        trainStack: [...get().trainStack.filter((s) => s.kind !== 'QUIZ'), { kind: 'RESULT' }],
      });
      void saveEvents(set, get, setData, after);
    },
    closeResult() {
      const lessonId = get().quizResult?.run.lessonId;
      let stack = get().trainStack.filter((s) => s.kind !== 'RESULT');
      const patch: Partial<AppState> = { quiz: null, quizResult: null };
      if (lessonId) { stack = stack.filter((s) => s.kind !== 'LESSON'); patch.lessonRun = null; }
      set({ ...patch, trainStack: stack });
    },
    acceptBrewChallenge(lessonId) {
      get().setSettings((s) => ({ ...s, pendingBrewChallenge: lessonId }));
      get().closeResult();
      set({ tab: 'BREW' });
      get().say('msg_brew_challenge_set');
    },
    cancelBrewChallenge() { get().setSettings((s) => ({ ...s, pendingBrewChallenge: null })); },
  };

}

/** Lesson pages on a compact screen: one per theory block, one for the simulation, one to validate. */
export const lessonPageCount = (l: Lesson) => (l.blocks?.length ?? 0) + (l.sim && l.sim !== 'NONE' ? 1 : 0) + 1;
export type LessonPage = { kind: 'THEORY'; index: number } | { kind: 'SIM' } | { kind: 'VALIDATE' };
export function lessonPageOf(l: Lesson, page: number): LessonPage {
  const blocks = l.blocks?.length ?? 0;
  if (page < blocks) return { kind: 'THEORY', index: page };
  if (page === blocks && l.sim && l.sim !== 'NONE') return { kind: 'SIM' };
  return { kind: 'VALIDATE' };
}
const HOME_SCREEN: TrainScreen = { kind: 'HOME' };
/** Stable reference for the empty stack, so store selectors do not see a new object on every read. */
export const currentTrainScreen = (s: Pick<AppState, 'trainStack'>): TrainScreen => s.trainStack[s.trainStack.length - 1] ?? HOME_SCREEN;
export const isTrainDesk = (sc: TrainScreen) => sc.kind === 'LESSON' || sc.kind === 'QUIZ' || sc.kind === 'LAB';
export { lt };
