// Toulouse Cupping module state, port of CuppingController. Edits are saved after a 250 ms pause,
// the way the original saved to localStorage, and flushed when the app goes to the background.
import { localIsoDate } from '../core/coffee';
import {
  CupFormat, cupIdle, cupReset, cupStart, cupTick, cupToggle, LAB_METHODS,
} from '../core/cupping';
import type { CuppingCoffee, CuppingSession, LabRecipe } from '../core/models';
import { AppData, deleteRow, deleteRows, putRow, putRows } from '../data/db';
import { t } from '../i18n/i18n';
import { haptic, sounds } from '../platform/device';
import type { GetFn, SetFn } from './store';
import type { AppState, CupSlice, LabDraft } from './types';

const uuid = (): string => (typeof globalThis.crypto?.randomUUID === 'function' ? globalThis.crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);
export const defaultLab = (): LabDraft => ({ method: 'v60', coffee: '20', ratio: '16', grind: '', rating: 8, notes: '' });
export const labCoffeeG = (d: LabDraft) => CupFormat.parse(d.coffee) ?? 0;
export const labRatio = (d: LabDraft) => CupFormat.parse(d.ratio) ?? 0;
export const labWater = (d: LabDraft) => CupFormat.water(labCoffeeG(d), labRatio(d));

export const cupInitial = (): CupSlice => ({
  cupSession: null,
  cupCoffees: [],
  cupActive: 0,
  cupScreen: 'MAIN',
  cupMenuOpen: false,
  cupInviteOpen: false,
  cupTimerOpen: false,
  cupConfirmNew: false,
  cupShortcutPrompt: false,
  cupPendingDelete: null,
  cupPendingDeleteSession: null,
  cupPendingDeleteRecipe: null,
  wheelRotation: 0,
  cupTimer: cupIdle(),
  lab: defaultLab(),
  labHistory: false,
  labRunning: false,
  labStartedAt: 0,
  labBaseMs: 0,
});

export function createCupSlice(set: SetFn, get: GetFn, setData: (f: (d: AppData) => Partial<AppData>) => void): Partial<AppState> {
  let saveTimer: ReturnType<typeof setTimeout> | null = null;
  let timerTicker: ReturnType<typeof setInterval> | null = null;

  const newCoffee = (name: string): CuppingCoffee => ({
    id: uuid(), sessionId: '', position: 0, name, isLocked: false, isFavorite: false, timestamp: Date.now(), process: '',
    fragranceScore: 8, fragranceNotes: [], flavorScore: 8, flavorNotes: [], aftertasteScore: 8, acidityScore: 8,
    acidityType: '', acidityIntensity: '', bodyScore: 8, bodyType: '', balanceScore: 8, comments: '',
  });

  /** Same as the Android DAO transaction: the session row, then its coffees with their positions. */
  async function writeSession(s: CuppingSession, coffees: CuppingCoffee[]) {
    const rows = coffees.map((c, i) => ({ ...c, sessionId: s.id, position: i }));
    const old = get().data.cuppingCoffees.filter((c) => c.sessionId === s.id && !rows.some((r) => r.id === c.id)).map((c) => c.id);
    setData((d) => ({
      cuppingSessions: [...d.cuppingSessions.filter((x) => x.id !== s.id), s],
      cuppingCoffees: [...d.cuppingCoffees.filter((c) => c.sessionId !== s.id), ...rows],
    }));
    await putRow('cuppingSessions', s);
    if (old.length) await deleteRows('cuppingCoffees', old);
    await putRows('cuppingCoffees', rows);
  }

  function persist() {
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(() => { saveTimer = null; void writeNow(); }, 250);
  }

  async function writeNow() {
    const s = get().cupSession;
    if (s) await writeSession(s, get().cupCoffees);
  }

  function show(s: CuppingSession, list: CuppingCoffee[]) {
    set({ cupSession: s, cupCoffees: list, cupActive: 0 });
  }

  async function startSession(openInfo: boolean) {
    await get().cupFlush();
    const s: CuppingSession = {
      id: uuid(), createdAt: Date.now(), name: t('cup_new_session'), location: '', dateIso: localIsoDate(),
      originNotes: '', roasterNotes: '', importerNotes: '',
    };
    const list = [newCoffee(t('cup_default_coffee'))];
    await writeSession(s, list);
    get().setSettings((x) => ({ ...x, cuppingSessionId: s.id }));
    show(s, list.map((c, i) => ({ ...c, sessionId: s.id, position: i })));
    if (openInfo) set({ cupScreen: 'INFO' });
  }

  function replace(c: CuppingCoffee) {
    set({ cupCoffees: get().cupCoffees.map((x) => (x.id === c.id ? c : x)) });
    persist();
  }

  const active = () => get().cupCoffees[get().cupActive];

  function syncTimerTicker() {
    const running = get().cupTimer.running;
    if (running && !timerTicker) timerTicker = setInterval(() => get().cupTick(), 100);
    else if (!running && timerTicker) { clearInterval(timerTicker); timerTicker = null; }
  }

  if (typeof document !== 'undefined') {
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') void get().cupFlush();
      else get().cupTick();
    });
    window.addEventListener('pagehide', () => { void get().cupFlush(); });
  }

  return {
    async cupReload() {
      if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
      const { settings, data } = get();
      const found = data.cuppingSessions.find((s) => s.id === settings.cuppingSessionId) ?? data.cuppingSessions[0];
      if (!found) { await startSession(false); return; }
      const coffees = data.cuppingCoffees.filter((c) => c.sessionId === found.id).sort((a, b) => a.position - b.position);
      show(found, coffees.length ? coffees : [{ ...newCoffee(t('cup_default_coffee')), sessionId: found.id }]);
      if (settings.cuppingSessionId !== found.id) get().setSettings((s) => ({ ...s, cuppingSessionId: found.id }));
    },

    /** "Nouvelle session": the original wiped the table. Here the old session is kept in the archive. */
    cupNewSession() {
      set({ cupConfirmNew: false, cupShortcutPrompt: false, cupMenuOpen: false });
      void startSession(true);
    },

    async cupOpenSession(id) {
      await get().cupFlush();
      const s = get().data.cuppingSessions.find((x) => x.id === id);
      if (!s) return;
      const coffees = get().data.cuppingCoffees.filter((c) => c.sessionId === id).sort((a, b) => a.position - b.position);
      show(s, coffees.length ? coffees : [{ ...newCoffee(t('cup_default_coffee')), sessionId: id }]);
      get().setSettings((x) => ({ ...x, cuppingSessionId: id }));
      set({ cupScreen: 'MAIN' });
    },

    cupDeleteSession(s) {
      set({ cupPendingDeleteSession: null });
      if (s.id === get().cupSession?.id) return;
      const ids = get().data.cuppingCoffees.filter((c) => c.sessionId === s.id).map((c) => c.id);
      setData((d) => ({ cuppingSessions: d.cuppingSessions.filter((x) => x.id !== s.id), cuppingCoffees: d.cuppingCoffees.filter((c) => c.sessionId !== s.id) }));
      void deleteRows('cuppingCoffees', ids);
      void deleteRow('cuppingSessions', s.id);
    },

    cupSelect(i) { if (i >= 0 && i < get().cupCoffees.length) set({ cupActive: i }); },

    cupUpdateSession(f) {
      const s = get().cupSession;
      if (!s) return;
      set({ cupSession: f(s) });
      persist();
    },

    /** Edits the active coffee. Ignored while it is validated, exactly like the original form. */
    cupEdit(f) {
      const c = active();
      if (!c || c.isLocked) return;
      replace(f(c));
    },
    cupToggleFavorite() { const c = active(); if (c) replace({ ...c, isFavorite: !c.isFavorite }); },
    cupLock() { const c = active(); if (c) replace({ ...c, isLocked: true }); },
    cupUnlock() { const c = active(); if (c) replace({ ...c, isLocked: false }); },
    cupResetNotes() {
      const c = active();
      if (c) replace({ ...c, fragranceScore: 8, flavorScore: 8, aftertasteScore: 8, acidityScore: 8, bodyScore: 8, balanceScore: 8 });
    },
    cupAddCoffee() {
      const list = get().cupCoffees;
      const c = { ...newCoffee(t('cup_coffee_n', list.length + 1)), sessionId: get().cupSession?.id ?? '' };
      set({ cupCoffees: [...list, c], cupActive: list.length });
      persist();
    },
    cupDeleteCoffee(c) {
      set({ cupPendingDelete: null });
      const list = get().cupCoffees;
      if (list.length <= 1) return;
      const next = list.filter((x) => x.id !== c.id);
      set({ cupCoffees: next, cupActive: Math.min(get().cupActive, next.length - 1) });
      persist();
    },
    async cupFlush() {
      if (saveTimer) {
        clearTimeout(saveTimer);
        saveTimer = null;
        await writeNow();
      }
    },

    // ---- timer ----------------------------------------------------------------------------
    cupStartTimer(min) { set({ cupTimer: cupStart(min, Date.now()) }); syncTimerTicker(); },
    cupToggleTimer() { set({ cupTimer: cupToggle(get().cupTimer, Date.now()) }); syncTimerTicker(); },
    cupResetTimer() { set({ cupTimer: cupReset(get().cupTimer) }); syncTimerTicker(); },
    cupTick() {
      const [next, alerts] = cupTick(get().cupTimer, Date.now());
      if (next !== get().cupTimer) set({ cupTimer: next });
      for (const a of alerts) {
        if (a === 'CRUST') { sounds.crust(); haptic('crust'); } else { sounds.finished(); haptic('finished'); }
      }
      syncTimerTicker();
    },

    // ---- Brewing Lab ------------------------------------------------------------------------
    labPickMethod(id) {
      const m = LAB_METHODS.find((x) => x.id === id);
      if (m) set({ lab: { ...get().lab, method: id, ratio: String(m.defaultRatio) } });
    },
    labToggleTimer() {
      const s = get();
      if (s.labRunning) set({ labRunning: false, labBaseMs: s.labBaseMs + (Date.now() - s.labStartedAt) });
      else set({ labRunning: true, labStartedAt: Date.now() });
    },
    labResetTimer() { set({ labRunning: false, labBaseMs: 0, labStartedAt: 0 }); },
    labSave() {
      const s = get();
      const d = s.lab;
      const seconds = Math.floor((s.labBaseMs + (s.labRunning ? Date.now() - s.labStartedAt : 0)) / 1000);
      const r: LabRecipe = {
        id: uuid(), timestamp: Date.now(), method: d.method, coffeeWeight: labCoffeeG(d), ratio: labRatio(d), waterWeight: labWater(d),
        grindSize: d.grind, totalTime: seconds, rating: d.rating, notes: d.notes,
      };
      setData((x) => ({ labRecipes: [...x.labRecipes, r] }));
      void putRow('labRecipes', r);
      get().say('cup_saved');
    },
    /** Loads a saved recipe back into the form. Unlike the original, the saved ratio is kept. */
    labLoad(r) {
      set({
        lab: { method: r.method, coffee: CupFormat.jsNumber(r.coffeeWeight), ratio: CupFormat.jsNumber(r.ratio), grind: r.grindSize, rating: r.rating, notes: r.notes },
        labRunning: false, labStartedAt: 0, labBaseMs: r.totalTime * 1000, labHistory: false,
      });
    },
    labDelete(r) {
      set({ cupPendingDeleteRecipe: null });
      setData((x) => ({ labRecipes: x.labRecipes.filter((y) => y.id !== r.id) }));
      void deleteRow('labRecipes', r.id);
    },

    cupCanGoBack() { const s = get(); return s.cupScreen !== 'MAIN' || s.labHistory; },
    cupBack() {
      const s = get();
      if (s.cupScreen === 'LAB' && s.labHistory) { set({ labHistory: false }); return true; }
      if (s.cupScreen !== 'MAIN') { set({ cupScreen: 'MAIN' }); return true; }
      return false;
    },
  };
}

export const labSeconds = (s: Pick<AppState, 'labRunning' | 'labBaseMs' | 'labStartedAt'>, now: number) =>
  Math.floor((s.labBaseMs + (s.labRunning ? now - s.labStartedAt : 0)) / 1000);
