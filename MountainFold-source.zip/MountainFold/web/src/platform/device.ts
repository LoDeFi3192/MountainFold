// Browser and iOS glue: screen wake lock, haptics, beeps, files, speech, install state.
// Each feature checks support first, so nothing breaks on a browser that lacks it.

// ---- screen wake lock (Safari 16.4+, Chromium) ------------------------------------------------
type Sentinel = { release: () => Promise<void>; released?: boolean; addEventListener?: (t: string, f: () => void) => void };
let sentinel: Sentinel | null = null;
let wanted = false;

export const wakeLockSupported = () => typeof navigator !== 'undefined' && 'wakeLock' in navigator;

async function acquire() {
  if (!wanted || sentinel || document.visibilityState !== 'visible' || !wakeLockSupported()) return;
  try {
    const s = (await (navigator as unknown as { wakeLock: { request: (t: string) => Promise<Sentinel> } }).wakeLock.request('screen')) as Sentinel;
    sentinel = s;
    s.addEventListener?.('release', () => { if (sentinel === s) sentinel = null; });
  } catch {
    sentinel = null;
  }
}

export function setKeepAwake(on: boolean) {
  wanted = on;
  if (on) void acquire();
  else if (sentinel) {
    const s = sentinel;
    sentinel = null;
    void s.release().catch(() => undefined);
  }
}

if (typeof document !== 'undefined') {
  // iOS and Chromium drop the lock when the page is hidden; take it back when we return.
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') void acquire(); });
}

// ---- haptics -----------------------------------------------------------------------------------
export type Haptic = 'tick' | 'step' | 'done' | 'crust' | 'finished';
const PATTERNS: Record<Haptic, number | number[]> = {
  tick: 12, step: 45, done: [0, 60, 90, 60], crust: [0, 200, 100, 200], finished: [0, 200, 100, 200, 100, 500],
};
let switchLabel: HTMLLabelElement | null = null;

/** Android browsers vibrate. Safari on iPhone has no vibration API; a switch control gives a light tap (iOS 18+), only during a touch. */
export function haptic(kind: Haptic) {
  try {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
      navigator.vibrate(PATTERNS[kind]);
      return;
    }
    if (!isIOS()) return;
    if (!switchLabel) {
      switchLabel = document.createElement('label');
      switchLabel.setAttribute('aria-hidden', 'true');
      switchLabel.style.cssText = 'position:fixed;left:-100px;top:0;width:1px;height:1px;overflow:hidden;opacity:0;pointer-events:none';
      const input = document.createElement('input');
      input.type = 'checkbox';
      input.setAttribute('switch', '');
      input.tabIndex = -1;
      switchLabel.appendChild(input);
      document.body.appendChild(switchLabel);
    }
    switchLabel.click();
  } catch {
    /* no haptics here */
  }
}

// ---- beeps (Web Audio) ----------------------------------------------------------------------------
let ctx: AudioContext | null = null;

function audio(): AudioContext | null {
  try {
    if (!ctx) {
      const C = (window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext);
      if (!C) return null;
      ctx = new C();
    }
    if (ctx.state === 'suspended') void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

/** iOS only lets audio start inside a touch. The first touch anywhere unlocks it for the session. */
export function unlockAudioOnFirstTouch() {
  const unlock = () => {
    const c = audio();
    if (c) {
      const b = c.createBuffer(1, 1, 22050);
      const s = c.createBufferSource();
      s.buffer = b;
      s.connect(c.destination);
      s.start(0);
    }
    window.removeEventListener('pointerdown', unlock, true);
    window.removeEventListener('touchend', unlock, true);
  };
  window.addEventListener('pointerdown', unlock, true);
  window.addEventListener('touchend', unlock, true);
}

interface Beep { at: number; freq: number; duration: number; peak?: number }

/** Sine beeps with an exponential fade from peak to 0.01, the envelope of the original cupping app. */
export function beeps(list: Beep[]) {
  const c = audio();
  if (!c) return;
  const t0 = c.currentTime + 0.02;
  for (const b of list) {
    const osc = c.createOscillator();
    const gain = c.createGain();
    osc.type = 'sine';
    osc.frequency.value = b.freq;
    gain.gain.setValueAtTime(b.peak ?? 0.5, t0 + b.at);
    gain.gain.exponentialRampToValueAtTime(0.01, t0 + b.at + b.duration);
    osc.connect(gain);
    gain.connect(c.destination);
    osc.start(t0 + b.at);
    osc.stop(t0 + b.at + b.duration);
  }
}

export const sounds = {
  step: () => beeps([{ at: 0, freq: 1320, duration: 0.12, peak: 0.35 }]),
  target: () => beeps([{ at: 0, freq: 1320, duration: 0.15, peak: 0.35 }, { at: 0.2, freq: 1760, duration: 0.3, peak: 0.35 }]),
  crust: () => beeps([{ at: 0, freq: 880, duration: 1 }]),
  finished: () => beeps([{ at: 0, freq: 880, duration: 1 }, { at: 0.2, freq: 880, duration: 1 }, { at: 0.4, freq: 1100, duration: 1.5 }]),
};

// ---- files --------------------------------------------------------------------------------------

/**
 * Saves a file the iOS way: the share sheet (Save to Files, AirDrop, Mail, Print) when available,
 * a download link otherwise. Returns false when the user cancelled or nothing worked.
 */
/**
 * Saves a file. On iPhone and iPad the share sheet is the only way to reach Files. Safari refuses
 * navigator.share once the tap that started the export is too old (a PDF build, a database read):
 * then [askTap] receives a function to call from a fresh tap, and the result is 'pending'.
 */
export async function saveFile(blob: Blob, filename: string, askTap?: (shareNow: () => void) => void): Promise<boolean | 'pending'> {
  const file = new File([blob], filename, { type: blob.type });
  const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
  if (isIOS() && nav.canShare && nav.canShare({ files: [file] }) && nav.share) {
    try {
      await nav.share({ files: [file] });
      return true;
    } catch (e) {
      const name = (e as DOMException)?.name;
      if (name === 'AbortError') return false;
      if (name === 'NotAllowedError' && askTap) {
        askTap(() => { void nav.share({ files: [file] }).catch(() => undefined); });
        return 'pending';
      }
    }
  }
  try {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30_000);
    return true;
  } catch {
    return false;
  }
}

export function pickFile(accept: string): Promise<File | null> {
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = accept;
    input.style.display = 'none';
    input.onchange = () => { resolve(input.files?.[0] ?? null); input.remove(); };
    document.body.appendChild(input);
    input.click();
  });
}

export const blobToDataUrl = (b: Blob) =>
  new Promise<string>((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(String(r.result)); r.onerror = reject; r.readAsDataURL(b); });

export async function dataUrlToBlob(url: string): Promise<Blob> {
  const res = await fetch(url);
  return res.blob();
}

/** Downscales a picked photo to 1600 px, JPEG 86 %, so the library never depends on the camera roll. */
export async function downscalePhoto(file: File, max = 1600): Promise<Blob | null> {
  try {
    const bmp = await createImageBitmap(file);
    const scale = Math.min(1, max / Math.max(bmp.width, bmp.height));
    const w = Math.round(bmp.width * scale);
    const h = Math.round(bmp.height * scale);
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    canvas.getContext('2d')!.drawImage(bmp, 0, 0, w, h);
    return await new Promise((resolve) => canvas.toBlob((b) => resolve(b), 'image/jpeg', 0.86));
  } catch {
    return null;
  }
}

// ---- speech ------------------------------------------------------------------------------------
type Recognizer = { lang: string; interimResults: boolean; maxAlternatives: number; start: () => void; onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null; onerror: (() => void) | null };

export function speechSupported(): boolean {
  const w = window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown };
  return !!(w.SpeechRecognition || w.webkitSpeechRecognition);
}

export function listen(lang: string, onText: (text: string) => void) {
  const w = window as unknown as { SpeechRecognition?: new () => Recognizer; webkitSpeechRecognition?: new () => Recognizer };
  const C = w.SpeechRecognition || w.webkitSpeechRecognition;
  if (!C) return;
  try {
    const r = new C();
    r.lang = lang === 'fr' ? 'fr-FR' : lang === 'es' ? 'es-ES' : 'en-US';
    r.interimResults = false;
    r.maxAlternatives = 1;
    r.onresult = (e) => { const text = e.results[0]?.[0]?.transcript; if (text) onText(text); };
    r.onerror = () => undefined;
    r.start();
  } catch {
    /* microphone refused */
  }
}

// ---- platform ------------------------------------------------------------------------------------
export function isIOS(): boolean {
  if (typeof navigator === 'undefined') return false;
  const ua = navigator.userAgent;
  return /iPad|iPhone|iPod/.test(ua) || (ua.includes('Macintosh') && navigator.maxTouchPoints > 1);
}

export function isStandalone(): boolean {
  try {
    return window.matchMedia('(display-mode: standalone)').matches || (navigator as unknown as { standalone?: boolean }).standalone === true;
  } catch {
    return false;
  }
}

export const prefersReducedMotion = () => {
  try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { return false; }
};
