import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './ui/styles.css';
import { App } from './ui/App';
import { useApp } from './state/store';
import { unlockAudioOnFirstTouch } from './platform/device';
import { t } from './i18n/i18n';

unlockAudioOnFirstTouch();
void useApp.getState().init();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

// Offline cache. A new version waits until the user taps Reload, so a brew in progress is never interrupted.
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  void import('virtual:pwa-register').then(({ registerSW }) => {
    const update = registerSW({
      onNeedRefresh() {
        useApp.setState({ message: { text: t('web_update_ready'), nonce: Date.now(), action: { label: t('web_reload'), run: () => void update(true) } } });
      },
    });
  });
}
