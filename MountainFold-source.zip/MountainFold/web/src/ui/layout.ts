// Posture for the web: the iPhone in portrait is the Fold closed, the iPad is the Fold open, and a phone
// lying sideways on the counter plays the Flex role. A foldable in Chrome reports its fold through
// viewport segments, which is honoured too.
import { useEffect, useState } from 'react';
import type { LayoutOverride } from '../core/models';

export type Posture = 'CLOSED' | 'OPEN' | 'FLEX';
export interface LayoutInfo {
  posture: Posture;
  width: number;
  height: number;
  landscape: boolean;
  /** FLEX that comes from a phone held sideways, not from a fold or the setting. */
  phoneSideways: boolean;
  /** Direction of the counter split: side by side when the screen is wider than tall. */
  rowSplit: boolean;
}

const OPEN_MIN_WIDTH = 600;
const OPEN_MIN_SIDE = 520;

function mq(q: string): boolean {
  try { return window.matchMedia(q).matches; } catch { return false; }
}

export function resolveLayout(width: number, height: number, override: LayoutOverride, tabletop = false): LayoutInfo {
  const landscape = width > height;
  const sideways = landscape && height < OPEN_MIN_SIDE;
  let auto: Posture = 'CLOSED';
  if (tabletop) auto = 'FLEX';
  else if (width >= OPEN_MIN_WIDTH && Math.min(width, height) >= OPEN_MIN_SIDE) auto = 'OPEN';
  else if (sideways) auto = 'FLEX';
  const posture = override === 'AUTO' ? auto : override;
  return {
    posture, width, height, landscape,
    phoneSideways: override === 'AUTO' && !tabletop && auto === 'FLEX',
    rowSplit: tabletop ? false : landscape,
  };
}

export function useLayout(override: LayoutOverride): LayoutInfo {
  const read = () => resolveLayout(window.innerWidth, window.innerHeight, override, mq('(vertical-viewport-segments: 2)') || mq('(device-posture: folded)'));
  const [info, setInfo] = useState<LayoutInfo>(read);
  useEffect(() => {
    const update = () => setInfo(read());
    update();
    window.addEventListener('resize', update);
    window.addEventListener('orientationchange', update);
    window.visualViewport?.addEventListener('resize', update);
    return () => {
      window.removeEventListener('resize', update);
      window.removeEventListener('orientationchange', update);
      window.visualViewport?.removeEventListener('resize', update);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [override]);
  return info;
}
