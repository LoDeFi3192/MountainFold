// Toulouse Cupping. Phone = the original phone layout. Tablet = session, coffees, timer and tools on the
// left, scoring on the right. Counter = timer first, scoring second.
import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import {
  ACIDITY_INTENSITIES, ACIDITY_TYPES, BODY_TYPES, CupFormat, cupPhase, cupProgress, cupRemainingS, cupSix, PROCESSING_METHODS,
} from '../../core/cupping';
import { CuppingCoffee, cuppingFinalScore } from '../../core/models';
import { shortDate, shortDateIso, t } from '../../i18n/i18n';
import { useApp } from '../../state/store';
import type { CupScreen } from '../../state/types';
import { Btn, ConfirmDialog, Dialog, FlexSplit, Icon, IconButton, Menu, Scroll, TcIcon, TextField, TimerText, TwoPane, useMenu } from '../components';
import { LabDeskTop, LabForm, LabHistoryPane, SummaryPage } from './CupPages';
import {
  AromaSelector, ChoiceChips, CollapsibleSection, FloatingLabelField, HEART, PageHeader, SmallCapsLabel, TcCard, TcLogo, TcSectionTitle, TcSlider, TimerRing,
} from './parts';
import { FlavorWheelFull, WheelInfo, WheelSiblings, WheelSurface } from './Wheel';

export const isCupDesk = (s: CupScreen) => s === 'MAIN' || s === 'WHEEL' || s === 'LAB';
/** Hides the bottom bar on the screens that were full-screen pages in the original. */
export const cupHidesBar = (s: CupScreen) => s === 'WHEEL' || s === 'INFO';

// ---- entry points --------------------------------------------------------------------------------------
export function CuppingTab({ wide }: { wide: boolean }) {
  const session = useApp((s) => s.cupSession);
  const screen = useApp((s) => s.cupScreen);
  const labHistory = useApp((s) => s.labHistory);
  const set = useApp((s) => s.set);
  if (!session) return null;
  let body;
  switch (screen) {
    case 'MAIN':
      body = wide
        ? <TwoPane leftWeight={0.42} rightLow={false} left={<CupOverview />} right={<FormPane />} />
        : <div className="page"><CupHeader /><CoffeeTabs /><FormPane showSummary /></div>;
      break;
    case 'SUMMARY': body = <SummaryPage wide={wide} />; break;
    case 'WHEEL':
      body = wide ? (
        <TwoPane rightLow={false}
          left={<div className="page"><WheelSurface pointerDeg={0} geometry={(w, h) => ({ cx: 0, cy: h / 2, r: Math.min(w * 0.9, h * 0.46) })} /></div>}
          right={
            <div className="page" style={{ padding: 24 }}>
              <div style={{ alignSelf: 'flex-end' }}><Btn onClick={() => set({ cupScreen: 'MAIN' })}>{t('cup_close')}</Btn></div>
              <div className="center col" style={{ flex: 1 }}><WheelInfo pointerDeg={0} alignEnd={false} nameSize={56} /><WheelSiblings pointerDeg={0} /></div>
            </div>
          } />
      ) : <FlavorWheelFull onClose={() => set({ cupScreen: 'MAIN' })} />;
      break;
    case 'LAB':
      body = wide
        ? <TwoPane rightLow={false} left={<LabHistoryPane standalone />} right={<LabForm showHistoryButton={false} />} />
        : labHistory ? <LabHistoryPane standalone={false} /> : <LabForm showHistoryButton />;
      break;
    case 'INFO': body = wide ? <TwoPane leftWeight={0.42} rightLow={false} left={<CupOverview />} right={<SessionInfoPage />} /> : <SessionInfoPage />; break;
    case 'SESSIONS': body = <SessionsPage wide={wide} />; break;
  }
  return <>{body}<CuppingDialogs /></>;
}

/** Counter: info first (top or left), hands-on controls second, for a cupping table. */
export function CuppingDesk({ row }: { row: boolean }) {
  const session = useApp((s) => s.cupSession);
  const screen = useApp((s) => s.cupScreen);
  const labHistory = useApp((s) => s.labHistory);
  const set = useApp((s) => s.set);
  if (!session) return null;
  const padTop = row ? 'calc(var(--sat) + 12px) 24px calc(var(--sab) + 12px) calc(var(--sal) + 24px)' : 'calc(var(--sat) + 12px) 24px 12px';
  const pointer = row ? 180 : 270;
  const top = (
    <div className="col" style={{ flex: 1, minHeight: 0, padding: padTop, position: 'relative' }}>
      {screen === 'WHEEL' ? (
        <>
          <div style={{ position: 'absolute', top: 'calc(var(--sat) + 12px)', right: 24 }}><Btn onClick={() => set({ cupScreen: 'MAIN' })}>{t('cup_close')}</Btn></div>
          <div className="center" style={{ flex: 1 }}><WheelInfo pointerDeg={pointer} nameSize={64} alignEnd={false} /></div>
        </>
      ) : screen === 'LAB' ? <LabDeskTop /> : <MainDeskTop row={row} />}
    </div>
  );
  const bottom = (
    <div className="col" style={{ flex: 1, minHeight: 0, paddingBottom: row ? 'var(--sab)' : 'var(--sab)', paddingRight: row ? 'var(--sar)' : undefined, paddingTop: row ? 'var(--sat)' : undefined }}>
      {screen === 'WHEEL'
        ? <WheelSurface pointerDeg={pointer} geometry={(w, h) => (row ? { cx: w, cy: h / 2, r: Math.min(w * 0.9, (h / 2) * 0.95) } : { cx: w / 2, cy: h, r: Math.min(h * 0.9, (w / 2) * 0.95) })} />
        : screen === 'LAB' ? (labHistory ? <LabHistoryPane standalone={false} /> : <LabForm showHistoryButton desk />)
          : <div className="col" style={{ flex: 1, minHeight: 0 }}><CoffeeTabs /><FormPane showSummary showTimer={false} /></div>}
    </div>
  );
  return <><FlexSplit row={row} first={top} second={bottom} /><CuppingDialogs /></>;
}

// ---- header, menu, coffee tabs ---------------------------------------------------------------------------
export function CupHeader() {
  const menu = useMenu();
  return (
    <>
      <div style={{ background: 'var(--surface-container)', flex: '0 0 auto' }}>
        <div className="row" style={{ height: 60, padding: '0 12px', position: 'relative' }}>
          <TcLogo size={48} />
          <h1 className="headline-small ellipsis" style={{ margin: 0, position: 'absolute', left: 68, right: 68, textAlign: 'center', fontSize: 24 }}>{t('cup_title')}</h1>
          <span className="grow" />
          <button type="button" className="icon-btn" aria-label={t('cup_menu')} onClick={menu.open}><Icon name="menu" /></button>
        </div>
      </div>
      <hr className="divider" style={{ background: 'color-mix(in srgb, var(--outline) 5%, transparent)' }} />
      {menu.anchor && <CupMenu anchor={menu.anchor} onDismiss={menu.close} />}
    </>
  );
}

function CupMenu({ anchor, onDismiss }: { anchor: HTMLElement; onDismiss: () => void }) {
  const settings = useApp((s) => s.settings);
  const lang = useApp((s) => s.lang);
  const s = useApp.getState();
  const systemDark = typeof window !== 'undefined' && window.matchMedia?.('(prefers-color-scheme: dark)').matches;
  const dark = settings.themeMode === 'DARK' || (settings.themeMode === 'SYSTEM' && systemDark);
  const tile = { margin: '0 12px', borderRadius: 8, background: 'color-mix(in srgb, var(--surface-variant) 30%, transparent)', padding: '8px 12px' };
  const item = (icon: string, label: string, screen: CupScreen | null, extra?: () => void, color?: string) => ({
    label, color, icon: <TcIcon name={icon} size={20} style={{ color: color ?? 'var(--on-surface-variant)' }} />,
    onClick: () => { if (screen) s.set({ cupScreen: screen }); extra?.(); },
  });
  const header = (
    <>
      <div className="label-medium upper" style={{ color: 'var(--on-surface-variant)', padding: '8px 16px' }}>{t('cup_preferences')}</div>
      <div className="row gap8" role="switch" aria-checked={dark} style={{ ...tile, cursor: 'pointer' }} onClick={() => s.setSettings((x) => ({ ...x, themeMode: dark ? 'LIGHT' : 'DARK' }))}>
        <TcIcon name={dark ? 'Moon' : 'Sun'} size={18} />
        <span className="label-large grow">{t(dark ? 'cup_dark_mode' : 'cup_light_mode')}</span>
        <span className={`switch ${dark ? 'on' : ''}`} style={{ transform: 'scale(.7)' }} />
      </div>
      <div className="row gap8" style={{ ...tile, marginTop: 8 }}>
        <TcIcon name="Translate" size={20} style={{ color: 'var(--on-surface-variant)' }} />
        <span className="label-large grow">{t('language')}</span>
        <div className="row" style={{ gap: 4, background: 'var(--surface-container)', borderRadius: 8, padding: 4 }}>
          {(['fr', 'en', 'es'] as const).map((code) => (
            <button key={code} type="button" aria-pressed={lang === code} onClick={() => { onDismiss(); s.setLanguage(code); }}
              className="label-small" style={{ border: 0, borderRadius: 4, padding: '4px 8px', fontWeight: 700, cursor: 'pointer', background: lang === code ? 'var(--primary)' : 'transparent', color: lang === code ? 'var(--on-primary)' : 'var(--on-surface-variant)' }}>
              {code.toUpperCase()}
            </button>
          ))}
        </div>
      </div>
      <hr className="divider" style={{ margin: '8px 16px' }} />
    </>
  );
  return (
    <Menu anchor={anchor} onDismiss={onDismiss} minWidth={280} header={header} items={[
      item('InfoSession', t('cup_session_info'), 'INFO'),
      item('Brew', t('cup_brewing_mode'), 'LAB'),
      item('QrCode', t('cup_invite'), null, () => s.set({ cupInviteOpen: true })),
      item('Wheel', t('cup_flavor_wheel'), 'WHEEL'),
      item('SummaryTable', t('cup_summary'), 'SUMMARY'),
      item('Calendar', t('cup_sessions'), 'SESSIONS'),
      'divider',
      item('DeleteSession', t('cup_new_session'), null, () => s.set({ cupConfirmNew: true }), 'var(--error)'),
    ]} />
  );
}

/** Horizontal coffee tabs with the heart and lock marks, then "+ New". The active tab scrolls into view. */
export function CoffeeTabs() {
  const coffees = useApp((s) => s.cupCoffees);
  const active = useApp((s) => s.cupActive);
  const s = useApp.getState();
  useEffect(() => {
    document.querySelector(`[data-cup-tab="${active}"]`)?.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
  }, [active, coffees.length]);
  return (
    <>
      <div className="hscroll row gap12" style={{ flex: '0 0 auto', padding: '12px 16px', background: 'var(--surface)' }} role="tablist">
        {coffees.map((c, i) => {
          const on = i === active;
          return (
            <button key={c.id} type="button" role="tab" aria-selected={on} data-cup-tab={i} onClick={() => s.cupSelect(i)}
              className="label-large" style={{ flex: '0 0 auto', border: 0, borderRadius: 18, minHeight: 36, padding: '6px 16px', fontWeight: 700, cursor: 'pointer', whiteSpace: 'nowrap',
                background: on ? 'var(--secondary-container)' : 'transparent', color: on ? 'var(--on-secondary-container)' : 'color-mix(in srgb, var(--on-surface-variant) 80%, transparent)', transform: on ? 'scale(1.05)' : undefined }}>
              {c.isFavorite && <span style={{ color: HEART }}>♥ </span>}{c.name}{c.isLocked ? ' 🔒' : ''}
            </button>
          );
        })}
        <button type="button" onClick={s.cupAddCoffee} className="label-large"
          style={{ flex: '0 0 auto', borderRadius: 18, minHeight: 36, padding: '6px 16px', fontWeight: 700, cursor: 'pointer', background: 'transparent', color: 'var(--primary)', border: '1px solid var(--outline)', whiteSpace: 'nowrap' }}>
          {t('cup_new_coffee_btn')}
        </button>
      </div>
      <hr className="divider" style={{ background: 'color-mix(in srgb, var(--outline) 10%, transparent)' }} />
    </>
  );
}

// ---- coffee form ---------------------------------------------------------------------------------------------
export function FormPane({ showSummary, showTimer = true }: { showSummary?: boolean; showTimer?: boolean }) {
  const coffees = useApp((s) => s.cupCoffees);
  const active = useApp((s) => s.cupActive);
  const set = useApp((s) => s.set);
  const c = coffees[active];
  if (!c) return null;
  return (
    <div className="relative" style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' }}>
      <Scroll style={{ padding: '16px 16px 128px' }}>
        <CoffeeForm key={c.id} c={c} />
        {showSummary && (
          <Btn elevated onClick={() => set({ cupScreen: 'SUMMARY' })} style={{ width: '100%', minHeight: 48, marginTop: 16, font: '700 17px/23px var(--font-title)' }}>{t('cup_see_summary')}</Btn>
        )}
      </Scroll>
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 16, display: 'flex', justifyContent: 'center', pointerEvents: 'none' }}>
        <div style={{ pointerEvents: 'auto' }}><ScoreBar c={c} showTimer={showTimer} /></div>
      </div>
    </div>
  );
}

function CoffeeForm({ c }: { c: CuppingCoffee }) {
  const lang = useApp((s) => s.lang);
  const count = useApp((s) => s.cupCoffees.length);
  const s = useApp.getState();
  const enabled = !c.isLocked;
  const score = t('cup_score');
  const edit = (f: (x: CuppingCoffee) => CuppingCoffee) => s.cupEdit(f);
  return (
    <>
      <div style={{ background: 'var(--surface-container-high)', borderRadius: 16, boxShadow: '0 1px 2px rgba(0,0,0,.12)', padding: 20, marginBottom: 24, position: 'relative' }}>
        <div style={{ paddingTop: 8, paddingRight: enabled && count > 1 ? 40 : 0 }}>
          <FloatingLabelField value={c.name} onChange={(v) => edit((x) => ({ ...x, name: v }))} label={t('cup_coffee_name')} enabled={enabled} />
        </div>
        <div className="row mt12">
          <span className="body-small grow muted">{t('cup_date_line', shortDate(c.timestamp))}</span>
          {c.isLocked && <span className="label-small" style={{ fontWeight: 700, borderRadius: 12, padding: '4px 12px', background: 'var(--secondary-container)', color: 'var(--on-secondary-container)' }}>🔒 {t('cup_validated')}</span>}
        </div>
        {enabled && count > 1 && (
          <div style={{ position: 'absolute', top: 8, right: 8 }}>
            <IconButton label={t('cup_delete_coffee')} onClick={() => s.set({ cupPendingDelete: c })}><TcIcon name="DeleteSession" /></IconButton>
          </div>
        )}
      </div>
      <CollapsibleSection title={t('cup_fragrance')} icon="Fragrance" score={c.fragranceScore} onScore={(v) => edit((x) => ({ ...x, fragranceScore: v }))} enabled={enabled} label={score}>
        <div className="label-medium muted" style={{ paddingBottom: 12 }}>{t('cup_notes_olfactory')}</div>
        <AromaSelector selected={c.fragranceNotes} onChange={(n) => edit((x) => ({ ...x, fragranceNotes: n }))} enabled={enabled} lang={lang} />
      </CollapsibleSection>
      <CollapsibleSection title={t('cup_flavor')} icon="Flavor" score={c.flavorScore} onScore={(v) => edit((x) => ({ ...x, flavorScore: v }))} enabled={enabled} label={score}>
        <div className="label-medium muted" style={{ paddingBottom: 12 }}>{t('cup_notes_mouth')}</div>
        <AromaSelector selected={c.flavorNotes} onChange={(n) => edit((x) => ({ ...x, flavorNotes: n }))} enabled={enabled} lang={lang} />
      </CollapsibleSection>
      <TcCard>
        <TcSectionTitle text={t('cup_process')} icon="Process" />
        <ChoiceChips options={PROCESSING_METHODS} value={c.process} enabled={enabled} lang={lang} onPick={(v) => edit((x) => ({ ...x, process: v }))} />
      </TcCard>
      <TcCard>
        <TcSectionTitle text={t('cup_aftertaste')} icon="Aftertaste" />
        <TcSlider label={score} value={c.aftertasteScore} onChange={(v) => edit((x) => ({ ...x, aftertasteScore: v }))} enabled={enabled} />
      </TcCard>
      <CollapsibleSection title={t('cup_acidity')} icon="Acidity" score={c.acidityScore} onScore={(v) => edit((x) => ({ ...x, acidityScore: v }))} enabled={enabled} label={score}>
        <SmallCapsLabel text={t('cup_type')} />
        <ChoiceChips options={ACIDITY_TYPES} value={c.acidityType} enabled={enabled} lang={lang} onPick={(v) => edit((x) => ({ ...x, acidityType: v }))} />
        <div style={{ height: 24 }} />
        <SmallCapsLabel text={t('cup_intensity')} />
        <ChoiceChips options={ACIDITY_INTENSITIES} value={c.acidityIntensity} enabled={enabled} lang={lang} onPick={(v) => edit((x) => ({ ...x, acidityIntensity: v }))} />
      </CollapsibleSection>
      <CollapsibleSection title={t('cup_body')} icon="Body" score={c.bodyScore} onScore={(v) => edit((x) => ({ ...x, bodyScore: v }))} enabled={enabled} label={score}>
        <SmallCapsLabel text={t('cup_texture')} />
        <ChoiceChips options={BODY_TYPES} value={c.bodyType} enabled={enabled} lang={lang} onPick={(v) => edit((x) => ({ ...x, bodyType: v }))} />
      </CollapsibleSection>
      <TcCard>
        <TcSectionTitle text={t('cup_balance')} icon="Balance" />
        <TcSlider label={score} value={c.balanceScore} onChange={(v) => edit((x) => ({ ...x, balanceScore: v }))} enabled={enabled} />
      </TcCard>
      <TcCard>
        <TcSectionTitle text={t('cup_comments')} icon="Comment" />
        <TextField value={c.comments} onChange={(v) => edit((x) => ({ ...x, comments: v }))} placeholder={t('cup_comments_placeholder')} multiline minRows={4} disabled={!enabled}
          style={{ background: 'var(--surface-container)', borderRadius: '8px 8px 0 0' }} />
      </TcCard>
    </>
  );
}

/** Floating bar: favourite, live score, timer, then Validate or the Modify split button. */
function ScoreBar({ c, showTimer }: { c: CuppingCoffee; showTimer: boolean }) {
  const count = useApp((s) => s.cupCoffees.length);
  const s = useApp.getState();
  const menu = useMenu();
  return (
    <div className="row" style={{ background: 'var(--surface-container-high)', borderRadius: 40, boxShadow: '0 3px 10px rgba(0,0,0,.18)', border: '1px solid color-mix(in srgb, var(--outline) 10%, transparent)', padding: '8px 8px 8px 12px' }}>
      <IconButton label={t('cup_favorite')} onClick={s.cupToggleFavorite} color={c.isFavorite ? HEART : undefined}>
        <TcIcon name={c.isFavorite ? 'HeartFilled' : 'Heart'} size={28} />
      </IconButton>
      <span style={{ width: 1, height: 32, background: 'var(--outline-variant)' }} />
      <div className="col" style={{ padding: '0 12px', minWidth: 72, alignItems: 'center' }}>
        <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1, color: 'var(--on-surface-variant)', textTransform: 'uppercase' }}>{t('cup_score')}</span>
        <span className="headline-small tnum" style={{ color: 'var(--primary)' }}>{CupFormat.fixed2(cuppingFinalScore(c))}</span>
      </div>
      {showTimer && <IconButton label={t('cup_timer')} onClick={() => s.set({ cupTimerOpen: true })}><TcIcon name="Timer" /></IconButton>}
      <span style={{ width: 8 }} />
      {!c.isLocked ? (
        <Btn onClick={s.cupLock} style={{ minHeight: 48, padding: '0 24px' }}>{t('cup_validate')}</Btn>
      ) : (
        <div className="row" style={{ height: 48, borderRadius: 24, overflow: 'hidden', background: 'var(--secondary-container)' }}>
          <button type="button" onClick={s.cupUnlock} className="label-large" style={{ border: 0, background: 'transparent', color: 'var(--on-secondary-container)', height: '100%', padding: '0 20px', cursor: 'pointer' }}>{t('cup_modify')}</button>
          <span style={{ width: 1, height: '100%', background: 'rgba(255,255,255,.2)' }} />
          <button type="button" className="icon-btn" aria-label={t('cup_more_actions')} onClick={menu.open} style={{ color: 'var(--on-secondary-container)' }}><Icon name="arrow_drop_down" /></button>
          {menu.anchor && (
            <Menu anchor={menu.anchor} onDismiss={menu.close} items={[
              { label: t('cup_reset_notes'), onClick: s.cupResetNotes },
              ...(count > 1 ? [{ label: t('cup_delete_coffee'), color: 'var(--error)', onClick: () => s.set({ cupPendingDelete: c }) }] : []),
            ]} />
          )}
        </div>
      )}
    </div>
  );
}

// ---- tablet: left pane -------------------------------------------------------------------------------------------
function InfoLine({ icon, text }: { icon: string; text: string }) {
  return (
    <div className="row" style={{ paddingTop: 10, gap: 10 }}>
      <TcIcon name={icon} size={18} style={{ color: 'var(--on-surface-variant)' }} />
      <span className="body-medium clamp2">{text}</span>
    </div>
  );
}

function ToolTile({ icon, label, onClick }: { icon: string; label: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="col" style={{ width: 120, alignItems: 'center', borderRadius: 16, background: 'var(--surface-container-high)', padding: 12, border: 0, cursor: 'pointer', color: 'var(--on-surface)' }}>
      <TcIcon name={icon} size={28} style={{ color: 'var(--primary)' }} />
      <span className="label-medium clamp2 mt6" style={{ textAlign: 'center' }}>{label}</span>
    </button>
  );
}

/** KNOW side of the workstation: session card, the table of coffees, the timer and every tool one tap away. */
function CupOverview() {
  const session = useApp((s) => s.cupSession)!;
  const coffees = useApp((s) => s.cupCoffees);
  const active = useApp((s) => s.cupActive);
  const s = useApp.getState();
  return (
    <div className="page">
      <CupHeader />
      <Scroll style={{ padding: 16 }}>
        <button type="button" onClick={() => s.set({ cupScreen: 'INFO' })} style={{ display: 'block', width: '100%', textAlign: 'left', border: 0, cursor: 'pointer', color: 'inherit', background: 'var(--surface-container-low)', borderRadius: 16, boxShadow: '0 1px 2px rgba(0,0,0,.12)', padding: 16, marginBottom: 16 }}>
          <TcSectionTitle text={t('cup_session_info')} icon="InfoSession" style={{ paddingBottom: 0 }} />
          <InfoLine icon="Calendar" text={shortDateIso(session.dateIso)} />
          <InfoLine icon="Location" text={session.location.trim() || t('cup_no_location')} />
          {session.originNotes.trim() && <InfoLine icon="Globe" text={session.originNotes} />}
          {session.roasterNotes.trim() && <InfoLine icon="Flame" text={session.roasterNotes} />}
          {session.importerNotes.trim() && <InfoLine icon="Box" text={session.importerNotes} />}
        </button>
        <TcCard>
          <TcSectionTitle text={t('tab_coffee')} icon="SummaryTable" />
          {coffees.map((c, i) => {
            const on = i === active;
            return (
              <button key={c.id} type="button" onClick={() => s.cupSelect(i)} className="row"
                style={{ width: '100%', border: 0, cursor: 'pointer', textAlign: 'left', borderRadius: 12, minHeight: 48, padding: '8px 12px', background: on ? 'var(--secondary-container)' : 'transparent', color: on ? 'var(--on-secondary-container)' : 'var(--on-surface)' }}>
                <span className="label-large muted" style={{ width: 24 }}>{i + 1}</span>
                {c.isFavorite && <span style={{ color: HEART }}>♥&nbsp;</span>}
                <span className="title-small grow ellipsis">{c.name}{c.isLocked ? ' 🔒' : ''}</span>
                <span className="title-medium tnum" style={{ color: 'var(--primary)' }}>{CupFormat.fixed2(cuppingFinalScore(c))}</span>
              </button>
            );
          })}
          <div className="mt8"><Btn kind="outlined" onClick={s.cupAddCoffee}>{t('cup_new_coffee_btn')}</Btn></div>
        </TcCard>
        <TcCard>
          <TcSectionTitle text={t('cup_timer')} icon="Timer" />
          <TimerPanel ring={180} horizontal={false} />
        </TcCard>
        <div className="row wrap gap8">
          <ToolTile icon="Wheel" label={t('cup_flavor_wheel')} onClick={() => s.set({ cupScreen: 'WHEEL' })} />
          <ToolTile icon="SummaryTable" label={t('cup_summary')} onClick={() => s.set({ cupScreen: 'SUMMARY' })} />
          <ToolTile icon="Brew" label={t('cup_brewing_mode')} onClick={() => s.set({ cupScreen: 'LAB' })} />
          <ToolTile icon="QrCode" label={t('cup_invite')} onClick={() => s.set({ cupInviteOpen: true })} />
          <ToolTile icon="Calendar" label={t('cup_sessions')} onClick={() => s.set({ cupScreen: 'SESSIONS' })} />
        </div>
        <div style={{ height: 24 }} />
      </Scroll>
    </div>
  );
}

// ---- counter: top of the main desk ------------------------------------------------------------------------------
function MainDeskTop({ row }: { row: boolean }) {
  const coffees = useApp((s) => s.cupCoffees);
  const active = useApp((s) => s.cupActive);
  const set = useApp((s) => s.set);
  const c = coffees[active];
  const h = typeof window !== 'undefined' ? window.innerHeight : 600;
  const w = typeof window !== 'undefined' ? window.innerWidth : 800;
  const paneW = row ? w / 2 : w;
  const paneH = row ? h : h / 2;
  const ring = Math.min(300, Math.max(140, row ? Math.min(paneW - 64, paneH * 0.45) : Math.min(paneH * 0.78, paneW - 520)));
  if (row) {
    return (
      <Scroll className="col gap16" style={{ alignItems: 'center' }}>
        <TimerPanel ring={ring} horizontal={false} />
        {c && <DeskScore c={c} onSummary={() => set({ cupScreen: 'SUMMARY' })} center />}
      </Scroll>
    );
  }
  return (
    <div className="row gap24" style={{ flex: 1 }}>
      <TimerPanel ring={ring} horizontal />
      {c && <DeskScore c={c} onSummary={() => set({ cupScreen: 'SUMMARY' })} />}
    </div>
  );
}

function DeskScore({ c, onSummary, center }: { c: CuppingCoffee; onSummary: () => void; center?: boolean }) {
  return (
    <div className="col grow" style={{ alignItems: center ? 'center' : 'flex-end' }}>
      <div className="row">
        {c.isFavorite && <span className="title-large" style={{ color: HEART }}>♥&nbsp;</span>}
        <span className="title-large ellipsis">{c.name}</span>
      </div>
      <span className="label-medium upper muted mt8">{t('cup_score')}</span>
      <span className="display-medium tnum" style={{ color: 'var(--primary)' }}>{CupFormat.fixed2(cuppingFinalScore(c))}</span>
      <Btn kind="text" onClick={onSummary}>{t('cup_summary')}</Btn>
    </div>
  );
}

// ---- session info, archive ---------------------------------------------------------------------------------------
function InfoField({ label, value, placeholder, icon, tint, onChange }: { label: string; value: string; placeholder: string; icon: string; tint: string; onChange: (v: string) => void }) {
  return (
    <div className="col">
      <span className="label-large muted" style={{ fontWeight: 700, paddingBottom: 8 }}>{label}</span>
      <div className="row" style={{ borderRadius: 12, background: 'var(--surface-container-high)', boxShadow: 'inset 0 0 0 1px color-mix(in srgb, var(--outline) 30%, transparent)', padding: '0 16px', minHeight: 56, gap: 12 }}>
        <TcIcon name={icon} style={{ color: tint }} />
        <input aria-label={label} value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} enterKeyHint="next"
          className="body-large" style={{ flex: 1, minWidth: 0, border: 0, outline: 'none', background: 'transparent', color: 'var(--on-surface)', fontSize: 16 }} />
      </div>
    </div>
  );
}

function SessionInfoPage() {
  const session = useApp((s) => s.cupSession)!;
  const s = useApp.getState();
  const up = (patch: Partial<typeof session>) => s.cupUpdateSession((x) => ({ ...x, ...patch }));
  return (
    <div className="page" style={{ background: 'var(--surface)' }}>
      <div className="row" style={{ background: 'var(--surface-container)', padding: 16 }}>
        <h2 className="headline-small grow" style={{ margin: 0, color: 'var(--primary)' }}>{t('cup_session_info')}</h2>
        <IconButton icon="close" label={t('cup_close')} onClick={() => s.set({ cupScreen: 'MAIN' })} />
      </div>
      <Scroll style={{ padding: 24 }}>
        <div className="col gap24" style={{ maxWidth: 448, margin: '0 auto' }}>
          <InfoField label={t('cup_tasting_location')} value={session.location} placeholder={t('cup_location_ph')} icon="Location" tint="var(--primary)" onChange={(v) => up({ location: v })} />
          <div className="col">
            <span className="label-large muted" style={{ fontWeight: 700, paddingBottom: 8 }}>{t('cup_session_date')}</span>
            <div className="row" style={{ borderRadius: 12, background: 'var(--surface-container-high)', boxShadow: 'inset 0 0 0 1px color-mix(in srgb, var(--outline) 30%, transparent)', padding: '0 16px', minHeight: 56, gap: 12, position: 'relative' }}>
              <TcIcon name="Calendar" style={{ color: 'var(--primary)' }} />
              <span className="body-large">{shortDateIso(session.dateIso)}</span>
              <input type="date" aria-label={t('cup_session_date')} value={session.dateIso} onChange={(e) => e.target.value && up({ dateIso: e.target.value })}
                style={{ position: 'absolute', inset: 0, opacity: 0, width: '100%', height: '100%', cursor: 'pointer', fontSize: 16 }} />
            </div>
          </div>
          <hr className="divider" style={{ background: 'color-mix(in srgb, var(--outline) 10%, transparent)' }} />
          <span className="title-medium">{t('cup_general_notes')}</span>
          <InfoField label={t('cup_origins')} value={session.originNotes} placeholder={t('cup_origins_ph')} icon="Globe" tint="var(--on-surface-variant)" onChange={(v) => up({ originNotes: v })} />
          <InfoField label={t('cup_roaster')} value={session.roasterNotes} placeholder={t('cup_roaster_ph')} icon="Flame" tint="var(--on-surface-variant)" onChange={(v) => up({ roasterNotes: v })} />
          <InfoField label={t('cup_importer')} value={session.importerNotes} placeholder={t('cup_importer_ph')} icon="Box" tint="var(--on-surface-variant)" onChange={(v) => up({ importerNotes: v })} />
          <div style={{ height: 48 }} />
        </div>
      </Scroll>
      <div style={{ background: 'var(--surface-container)', padding: 16 }}>
        <Btn onClick={() => s.set({ cupScreen: 'MAIN' })} style={{ width: '100%', minHeight: 56, font: '700 17px/23px var(--font-title)' }}>{t('cup_validate')}</Btn>
      </div>
    </div>
  );
}

/** Archive of past sessions. The original kept only one; here nothing is lost when a new one starts. */
function SessionsPage({ wide }: { wide: boolean }) {
  const sessions = useApp((s) => s.data.cuppingSessions);
  const all = useApp((s) => s.data.cuppingCoffees);
  const current = useApp((s) => s.cupSession);
  const currentCoffees = useApp((s) => s.cupCoffees);
  const s = useApp.getState();
  return (
    <div className="page">
      <PageHeader title={t('cup_sessions')} onBack={() => s.set({ cupScreen: 'MAIN' })} />
      <Scroll style={{ padding: 16 }}>
        <div style={{ maxWidth: wide ? 720 : 600, margin: '0 auto' }}>
          {sessions.map((x) => {
            const isCurrent = x.id === current?.id;
            const list = isCurrent ? currentCoffees : all.filter((c) => c.sessionId === x.id);
            const best = list.reduce<CuppingCoffee | null>((m, c) => (!m || cuppingFinalScore(c) > cuppingFinalScore(m) ? c : m), null);
            return (
              <div key={x.id} role="button" tabIndex={0} onClick={() => void s.cupOpenSession(x.id)} className="row"
                style={{ borderRadius: 16, padding: 16, marginBottom: 12, cursor: 'pointer', background: isCurrent ? 'var(--secondary-container)' : 'var(--surface-container-low)' }}>
                <div className="col grow">
                  <div className="row gap8">
                    <span className="title-medium">{shortDateIso(x.dateIso)}</span>
                    {isCurrent && <span className="label-small" style={{ background: 'var(--primary)', color: 'var(--on-primary)', borderRadius: 10, padding: '2px 8px' }}>{t('cup_current')}</span>}
                  </div>
                  <span className="body-medium muted">{x.location.trim() || t('cup_no_location')}</span>
                  <span className="body-small muted ellipsis">{t('cup_coffees_count', list.length)}{best ? ` · ${t('cup_best', `${best.name} ${CupFormat.fixed2(cuppingFinalScore(best))}`)}` : ''}</span>
                </div>
                {!isCurrent && <IconButton label={t('delete')} color="var(--error)" onClick={() => s.set({ cupPendingDeleteSession: x })}><TcIcon name="DeleteSession" /></IconButton>}
              </div>
            );
          })}
        </div>
      </Scroll>
    </div>
  );
}

// ---- dialogs -------------------------------------------------------------------------------------------------------
export function CuppingDialogs() {
  const s = useApp();
  return (
    <>
      {s.cupTimerOpen && (
        <Dialog title={<span style={{ color: 'var(--primary)' }}>{t('cup_timer')}</span>} titleCenter bg="var(--surface)" onDismiss={() => s.set({ cupTimerOpen: false })}
          actions={<Btn kind="text" onClick={() => s.set({ cupTimerOpen: false })}>{t('cup_close')}</Btn>}>
          <TimerPanel ring={240} horizontal={false} />
        </Dialog>
      )}
      {s.cupInviteOpen && <InviteDialog />}
      {s.cupConfirmNew && <ConfirmDialog title={t('cup_new_session')} body={t('cup_confirm_reset')} confirm={t('cup_new_session')} onConfirm={s.cupNewSession} onDismiss={() => s.set({ cupConfirmNew: false })} />}
      {s.cupShortcutPrompt && <ConfirmDialog title={t('cup_new_session')} body={t('cup_shortcut_detected')} confirm={t('cup_new_session')} onConfirm={s.cupNewSession} onDismiss={() => s.set({ cupShortcutPrompt: false })} />}
      {s.cupPendingDelete && <ConfirmDialog title={t('cup_delete_coffee')} body={t('cup_delete_confirm')} confirm={t('delete')} onConfirm={() => s.cupDeleteCoffee(s.cupPendingDelete!)} onDismiss={() => s.set({ cupPendingDelete: null })} />}
      {s.cupPendingDeleteRecipe && <ConfirmDialog title={t('delete')} body={t('cup_confirm_delete_recipe')} confirm={t('delete')} onConfirm={() => s.labDelete(s.cupPendingDeleteRecipe!)} onDismiss={() => s.set({ cupPendingDeleteRecipe: null })} />}
      {s.cupPendingDeleteSession && <ConfirmDialog title={t('delete')} body={t('cup_delete_session_confirm')} confirm={t('delete')} onConfirm={() => s.cupDeleteSession(s.cupPendingDeleteSession!)} onDismiss={() => s.set({ cupPendingDeleteSession: null })} />}
    </>
  );
}

/** QR code for guests, generated on the device like the Android port (the original called api.qrserver.com). */
function InviteDialog() {
  const url = useApp((s) => s.settings.cuppingInviteUrl);
  const s = useApp.getState();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(url);
  const [img, setImg] = useState<string | null>(null);
  useEffect(() => {
    let alive = true;
    QRCode.toDataURL(url.trim() || ' ', { margin: 1, errorCorrectionLevel: 'M', width: 384, color: { dark: '#4D2900', light: '#FFFFFF' } })
      .then((d) => { if (alive) setImg(d); }).catch(() => setImg(null));
    return () => { alive = false; };
  }, [url]);
  let host = url;
  try { host = new URL(url).host || url; } catch { /* keep the raw text */ }
  const close = () => s.set({ cupInviteOpen: false });
  return (
    <Dialog title={<span style={{ color: 'var(--primary)' }}>{t('cup_invite')}</span>} titleCenter bg="var(--surface-container)" onDismiss={close}
      actions={<Btn kind="tonal" onClick={close} style={{ width: '100%' }}>{t('cup_close')}</Btn>}>
      <div className="col" style={{ alignItems: 'center', textAlign: 'center' }}>
        <span className="body-medium muted">{t('cup_invite_body')}</span>
        <div style={{ marginTop: 24, background: '#fff', borderRadius: 12, padding: 16 }}>
          {img && <img src={img} alt={url} width={192} height={192} style={{ display: 'block' }} />}
        </div>
        <span className="label-small mt16" style={{ color: 'var(--outline)' }}>{t('cup_link', host)}</span>
        {editing ? (
          <div className="col gap8 mt12" style={{ width: '100%' }}>
            <TextField value={draft} onChange={setDraft} label={t('cup_invite_url')} inputMode="url" bg="var(--surface-container)" />
            <Btn kind="text" onClick={() => { const c = draft.trim(); if (c) s.setSettings((x) => ({ ...x, cuppingInviteUrl: c })); setEditing(false); }}>{t('save')}</Btn>
          </div>
        ) : <Btn kind="text" onClick={() => { setDraft(url); setEditing(true); }}>{t('cup_edit_link')}</Btn>}
      </div>
    </Dialog>
  );
}

/** Countdown ring, phase label, the 4 and 6 minute presets and the controls. */
export function TimerPanel({ ring, horizontal }: { ring: number; horizontal: boolean }) {
  const st = useApp((s) => s.cupTimer);
  const s = useApp.getState();
  const phase = cupPhase(st);
  const phaseText = phase === 'CRUST' ? t('cup_crust') : phase === 'TASTE' ? t('cup_taste') : phase === 'FINISHED' ? t('cup_finished') : t('pause');
  const ringBlock = (
    <TimerRing progress={cupProgress(st)} sixMinute={cupSix(st)} size={ring}>
      <TimerText text={CupFormat.clock(cupRemainingS(st))} size={ring * 0.23} />
      <span className="label-medium upper" style={{ letterSpacing: 2, color: 'var(--on-surface-variant)', marginTop: ring * 0.02 }}>{phaseText}</span>
    </TimerRing>
  );
  const preset = (minutes: number, sub: string, selected: boolean) => (
    <button type="button" onClick={() => s.cupStartTimer(minutes)} className="col"
      style={{ flex: '1 1 0', alignItems: 'center', borderRadius: 12, padding: '12px 16px', border: 0, cursor: 'pointer',
        background: selected ? 'var(--primary)' : 'var(--secondary-container)', color: selected ? 'var(--on-primary)' : 'var(--on-secondary-container)',
        boxShadow: selected ? 'inset 0 0 0 2px color-mix(in srgb, var(--primary) 50%, transparent)' : undefined }}>
      <span className="label-large" style={{ fontWeight: 700 }}>{t('cup_minutes', minutes)}</span>
      <span style={{ fontSize: 10, opacity: 0.7 }}>{sub}</span>
    </button>
  );
  const controls = (
    <div className="col gap16" style={{ width: horizontal ? 260 : '100%', flex: '0 0 auto' }}>
      <div className="row gap12">{preset(4, t('cup_crust'), st.initialS === 240)}{preset(6, t('cup_taste'), st.initialS === 360)}</div>
      {st.initialS > 0 && (
        <div className="row gap16">
          <Btn kind="tonal" onClick={s.cupResetTimer} style={{ flex: '1 1 0', padding: '8px 12px' }}>{t('cup_reset')}</Btn>
          <Btn onClick={s.cupToggleTimer} style={{ flex: '2 1 0', padding: '8px 12px' }}>{t(st.running ? 'pause' : 'cup_resume')}</Btn>
        </div>
      )}
    </div>
  );
  return horizontal
    ? <div className="row gap24">{ringBlock}{controls}</div>
    : <div className="col gap24" style={{ alignItems: 'center', width: '100%' }}>{ringBlock}{controls}</div>;
}

