// Building blocks of the Toulouse Cupping screens, matching the original app's look.
import { CSSProperties, ReactNode, useRef, useState } from 'react';
import { AROMA_CATEGORIES, CHIP_DEFAULT, contrastOn, CupFormat, cupLabel, noteColor, Term, termLabel } from '../../core/cupping';
import { t } from '../../i18n/i18n';
import { haptic } from '../../platform/device';
import { useApp } from '../../state/store';
import { Btn, Icon, TcIcon } from '../components';

export const HEART = '#EF4444';

/** M3 card of the original: low container, 16 px corners, 16 px padding. */
export function TcCard({ children, padding = 16, style }: { children: ReactNode; padding?: number; style?: CSSProperties }) {
  return (
    <div style={{ background: 'var(--surface-container-low)', borderRadius: 16, boxShadow: '0 1px 2px rgba(0,0,0,.12)', padding, marginBottom: 16, ...style }}>
      {children}
    </div>
  );
}

export function TcSectionTitle({ text, icon, style }: { text: string; icon?: string; style?: CSSProperties }) {
  return (
    <div className="row" style={{ paddingBottom: 16, gap: 12, ...style }}>
      {icon && <TcIcon name={icon} size={24} style={{ color: 'var(--primary)' }} />}
      <span className="title-medium" style={{ color: 'var(--on-surface)' }}>{text}</span>
    </div>
  );
}

export const TcLogo = ({ size }: { size: number }) => <TcIcon name="AppLogo" size={size} />;

/**
 * The pill slider of the original: 44 px track filled from the left, a dot per step, a centre mark,
 * the value with two decimals. Tap or drag sideways anywhere on the track; vertical drags still scroll.
 */
export function TcSlider({ label, value, onChange, min = 6, max = 10, step = 0.25, enabled = true, centered = true }: {
  label: string; value: number; onChange: (v: number) => void; min?: number; max?: number; step?: number; enabled?: boolean; centered?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [dragging, setDragging] = useState(false);
  const gesture = useRef<{ x: number; y: number; id: number; mode: 'idle' | 'drag' | 'cancel' } | null>(null);
  const haptics = useApp((s) => s.settings.haptics);
  const snap = (v: number) => Math.min(max, Math.max(min, min + Math.round((v - min) / step) * step));
  const setFromX = (clientX: number) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    if (r.width <= 0) return;
    const v = snap(min + Math.min(1, Math.max(0, (clientX - r.left) / r.width)) * (max - min));
    if (v !== value) { if (haptics) haptic('tick'); onChange(v); }
  };
  const fill = Math.min(1, Math.max(0, (value - min) / (max - min)));
  const count = Math.round((max - min) / step);
  const shown = CupFormat.fixed2(value);
  return (
    <div className="col" style={{ paddingTop: 8, paddingBottom: 24 }}>
      <div className="row-bottom" style={{ padding: '0 4px 8px' }}>
        <span className="label-large grow" style={{ color: dragging ? 'var(--primary)' : 'var(--on-surface)' }}>{label}</span>
        <span className="title-medium tnum" style={{ color: dragging ? 'var(--primary)' : 'var(--on-surface-variant)' }}>{shown}</span>
      </div>
      <div ref={ref} role="slider" tabIndex={enabled ? 0 : -1} aria-label={label} aria-valuemin={min} aria-valuemax={max} aria-valuenow={value} aria-valuetext={shown} aria-disabled={!enabled}
        onKeyDown={(e) => {
          if (!enabled) return;
          if (e.key === 'ArrowRight' || e.key === 'ArrowUp') { e.preventDefault(); onChange(snap(value + step)); }
          if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') { e.preventDefault(); onChange(snap(value - step)); }
        }}
        onPointerDown={(e) => { if (!enabled) return; gesture.current = { x: e.clientX, y: e.clientY, id: e.pointerId, mode: 'idle' }; }}
        onPointerMove={(e) => {
          const g = gesture.current;
          if (!g || g.id !== e.pointerId || g.mode === 'cancel') return;
          const dx = e.clientX - g.x;
          const dy = e.clientY - g.y;
          if (g.mode === 'idle') {
            if (Math.abs(dy) > 8 && Math.abs(dy) > Math.abs(dx)) { g.mode = 'cancel'; return; }
            if (Math.abs(dx) > 6) { g.mode = 'drag'; setDragging(true); try { ref.current?.setPointerCapture(e.pointerId); } catch { /* old Safari */ } }
          }
          if (g.mode === 'drag') setFromX(e.clientX);
        }}
        onPointerUp={(e) => {
          const g = gesture.current;
          if (g && g.mode === 'idle') setFromX(e.clientX);
          gesture.current = null;
          setDragging(false);
        }}
        onPointerCancel={() => { gesture.current = null; setDragging(false); }}
        style={{
          position: 'relative', height: 44, borderRadius: 22, overflow: 'hidden', background: 'var(--surface-container-highest)', touchAction: 'pan-y',
          transform: dragging ? 'scale(1.02)' : undefined, transition: 'transform .3s', cursor: enabled ? 'pointer' : 'default', opacity: enabled ? 1 : 0.6,
        }}>
        <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${fill * 100}%`, background: 'color-mix(in srgb, var(--primary) 90%, transparent)' }} />
        {count >= 2 && count <= 50 && Array.from({ length: count - 1 }, (_, i) => {
          const pct = (i + 1) / count;
          return <span key={i} style={{ position: 'absolute', top: 'calc(50% - 1px)', left: `calc(${pct * 100}% - 1px)`, width: 2, height: 2, borderRadius: 1,
            background: pct <= fill ? 'color-mix(in srgb, var(--on-primary) 30%, transparent)' : 'color-mix(in srgb, var(--on-surface-variant) 20%, transparent)' }} />;
        })}
        {centered && <span style={{ position: 'absolute', left: 'calc(50% - 1px)', top: 0, bottom: 0, width: 2, background: 'color-mix(in srgb, var(--surface) 30%, transparent)' }} />}
      </div>
      <div className="row" style={{ padding: '4px 8px 0' }}>
        <span className="label-small grow" style={{ color: 'color-mix(in srgb, var(--on-surface-variant) 50%, transparent)' }}>{CupFormat.jsNumber(min)}</span>
        <span className="label-small" style={{ color: 'color-mix(in srgb, var(--on-surface-variant) 50%, transparent)' }}>{CupFormat.jsNumber(max)}</span>
      </div>
    </div>
  );
}

/** Filter chip of the original: coloured when selected, check mark, optional dot and delete cross. */
export function TcChip({ label, selected, color, enabled = true, dot, onClick, onDelete, deleteLabel }: {
  label: string; selected: boolean; color?: string | null; enabled?: boolean; dot?: string | null; onClick?: () => void; onDelete?: () => void; deleteLabel?: string;
}) {
  const bg = selected ? color ?? CHIP_DEFAULT : 'var(--surface-container-high)';
  const fg = selected ? contrastOn(color ?? CHIP_DEFAULT) : 'var(--on-surface-variant)';
  const active = enabled && !!onClick;
  return (
    <span role={onClick ? 'checkbox' : undefined} aria-checked={onClick ? selected : undefined} tabIndex={active ? 0 : undefined}
      onClick={active ? onClick : undefined} onKeyDown={(e) => { if (active && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); onClick!(); } }}
      style={{
        display: 'inline-flex', alignItems: 'center', minHeight: 36, padding: '6px 16px', borderRadius: 8, background: bg, color: fg,
        boxShadow: selected ? undefined : 'inset 0 0 0 1px var(--outline-variant)', opacity: active || onDelete ? 1 : 0.6, cursor: active ? 'pointer' : 'default',
        userSelect: 'none', WebkitUserSelect: 'none', whiteSpace: 'nowrap',
      }}>
      {selected ? <Icon name="check" size={16} style={{ marginRight: 6 }} />
        : dot ? <span style={{ width: 8, height: 8, borderRadius: 4, marginRight: 8, background: dot, opacity: 0.8 }} /> : null}
      <span className="label-large">{label}</span>
      {onDelete && enabled && (
        <button type="button" aria-label={deleteLabel} onClick={(e) => { e.stopPropagation(); onDelete(); }}
          style={{ marginLeft: 8, width: 24, height: 24, borderRadius: 12, border: 0, background: 'transparent', color: fg, cursor: 'pointer', font: '700 17px/1 var(--font-title)' }}>×</button>
      )}
    </span>
  );
}

/** Card with a title, a score slider and a hidden detail block, as in the original form. */
export function CollapsibleSection({ title, icon, score, onScore, enabled, label, children }: {
  title: string; icon: string; score: number; onScore: (v: number) => void; enabled: boolean; label: string; children: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  return (
    <TcCard>
      <div className="row">
        <TcSectionTitle text={title} icon={icon} style={{ flex: 1, paddingTop: 16 }} />
        <button type="button" className="icon-btn" aria-label={t(open ? 'cup_hide_details' : 'cup_show_details')} aria-expanded={open} onClick={() => setOpen(!open)}>
          <Icon name="keyboard_arrow_down" style={{ transform: open ? 'rotate(180deg)' : undefined, transition: 'transform .3s' }} />
        </button>
      </div>
      <TcSlider label={label} value={score} onChange={onScore} enabled={enabled} />
      {open && <div>{children}</div>}
    </TcCard>
  );
}

export const SmallCapsLabel = ({ text }: { text: string }) => <div className="label-small" style={{ color: 'var(--on-surface-variant)', paddingBottom: 12 }}>{text}</div>;

/** Single choice chips for process, acidity and body. Selecting again keeps the choice, like the original. */
export function ChoiceChips({ options, value, enabled, lang, onPick }: { options: Term[]; value: string; enabled: boolean; lang: string; onPick: (k: string) => void }) {
  return (
    <div className="row wrap gap8">
      {options.map((o) => <TcChip key={o.key} label={termLabel(o, lang)} selected={value === o.key} enabled={enabled} onClick={() => onPick(o.key)} />)}
    </div>
  );
}

/** Aroma picker: selected notes on top, then one accordion per family. Hidden while the coffee is validated. */
export function AromaSelector({ selected, onChange, enabled, lang }: { selected: string[]; onChange: (n: string[]) => void; enabled: boolean; lang: string }) {
  const [expanded, setExpanded] = useState<string | null>(null);
  const toggle = (note: string) => { if (enabled) onChange(selected.includes(note) ? selected.filter((x) => x !== note) : [...selected, note]); };
  const any = selected.length > 0;
  return (
    <div className="col gap12">
      <div className="row wrap gap8" style={{
        minHeight: 44, borderRadius: 12, padding: 12, background: any ? 'var(--surface-container-high)' : 'var(--surface-container-low)',
        border: `1px dashed ${any ? 'color-mix(in srgb, var(--primary) 30%, transparent)' : 'color-mix(in srgb, var(--outline-variant) 30%, transparent)'}`,
      }}>
        {!any && <span className="body-small italic" style={{ color: 'color-mix(in srgb, var(--on-surface-variant) 70%, transparent)', padding: '4px 0' }}>{t('cup_no_aroma')}</span>}
        {selected.map((n) => {
          const l = cupLabel(n, lang);
          return <TcChip key={n} label={l} selected color={noteColor(n)} enabled={enabled} onDelete={() => toggle(n)} deleteLabel={t('cup_remove_note', l)} />;
        })}
      </div>
      {enabled && (
        <div className="col gap8">
          {AROMA_CATEGORIES.map((cat) => {
            const isOpen = expanded === cat.id;
            const count = cat.items.filter((i) => selected.includes(i.key)).length;
            return (
              <div key={cat.id} style={{ borderRadius: 12, overflow: 'hidden', border: `1px solid ${isOpen ? 'var(--primary)' : 'color-mix(in srgb, var(--outline-variant) 30%, transparent)'}`, background: isOpen ? 'var(--surface-container-high)' : 'var(--surface-container-low)' }}>
                <button type="button" aria-expanded={isOpen} onClick={() => setExpanded(isOpen ? null : cat.id)}
                  className="row" style={{ width: '100%', padding: 12, border: 0, background: 'transparent', cursor: 'pointer', color: 'var(--on-surface)', textAlign: 'left' }}>
                  <span style={{ width: 12, height: 12, borderRadius: 6, background: cat.color, flex: '0 0 auto' }} />
                  <span className="body-large grow" style={{ fontWeight: 500, marginLeft: 12 }}>{termLabel(cat.name, lang)}</span>
                  {count > 0 && <span className="label-small" style={{ background: 'var(--primary)', color: 'var(--on-primary)', borderRadius: 10, padding: '2px 8px', marginRight: 12 }}>{count}</span>}
                  <span style={{ fontSize: 12, color: 'var(--on-surface-variant)', transform: isOpen ? 'rotate(180deg)' : undefined, transition: 'transform .3s' }}>▼</span>
                </button>
                {isOpen && (
                  <div className="row wrap gap8" style={{ padding: 12, background: 'var(--surface-container)' }}>
                    {cat.items.map((item) => {
                      const c = noteColor(item.key);
                      return <TcChip key={item.key} label={termLabel(item, lang)} selected={selected.includes(item.key)} color={c} dot={c} onClick={() => toggle(item.key)} />;
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/** Underlined name field with a floating label, as at the top of the original coffee card. */
export function FloatingLabelField({ value, onChange, label, enabled }: { value: string; onChange: (v: string) => void; label: string; enabled: boolean }) {
  const [focused, setFocused] = useState(false);
  const floated = focused || value !== '';
  return (
    <label className="col" style={{ cursor: enabled ? 'text' : 'default' }}>
      <span className={floated ? 'label-small' : 'body-large'} style={{ color: floated ? 'var(--primary)' : 'var(--on-surface-variant)', paddingBottom: floated ? 2 : 0, transition: 'all .15s' }}>{label}</span>
      <input value={value} disabled={!enabled} onChange={(e) => onChange(e.target.value)} onFocus={() => setFocused(true)} onBlur={() => setFocused(false)}
        className="headline-small" style={{ border: 0, outline: 'none', background: 'transparent', color: 'var(--on-surface)', padding: '0 0 4px', width: '100%', fontSize: 24 }} />
      <span style={{ height: focused ? 2 : 1, background: focused ? 'var(--primary)' : 'var(--outline)' }} />
    </label>
  );
}

/** The circular cupping countdown, with the crust mark at 4 of 6 minutes. */
export function TimerRing({ progress, sixMinute, size, children }: { progress: number; sixMinute: boolean; size: number; children: ReactNode }) {
  const r = 90;
  const c = 2 * Math.PI * r;
  const a = ((-90 + 240) * Math.PI) / 180;
  return (
    <div style={{ position: 'relative', width: size, height: size, flex: '0 0 auto' }}>
      <svg viewBox="0 0 200 200" width={size} height={size} style={{ position: 'absolute', inset: 0 }}>
        <circle cx="100" cy="100" r={r} fill="none" stroke="var(--surface-container-high)" strokeWidth="8" />
        {sixMinute && <line x1={100 + Math.cos(a) * 90} y1={100 + Math.sin(a) * 90} x2={100 + Math.cos(a) * 75} y2={100 + Math.sin(a) * 75} stroke="color-mix(in srgb, var(--on-surface-variant) 50%, transparent)" strokeWidth="4" />}
        {progress > 0 && <circle cx="100" cy="100" r={r} fill="none" stroke="var(--primary)" strokeWidth="8" strokeLinecap="round" strokeDasharray={`${c * progress} ${c}`} transform="rotate(-90 100 100)" />}
      </svg>
      <div className="center" style={{ position: 'absolute', inset: 0, flexDirection: 'column' }}>{children}</div>
    </div>
  );
}

export function PageHeader({ title, onBack }: { title: string; onBack: () => void }) {
  return (
    <>
      <div className="row" style={{ background: 'var(--surface)', padding: '8px 16px', flex: '0 0 auto' }}>
        <h2 className="headline-small grow" style={{ margin: 0, color: 'var(--primary)' }}>{title}</h2>
        <Btn kind="outlined" icon="arrow_back" onClick={onBack}>{t('back')}</Btn>
      </div>
      <hr className="divider" style={{ background: 'color-mix(in srgb, var(--outline) 10%, transparent)' }} />
    </>
  );
}

