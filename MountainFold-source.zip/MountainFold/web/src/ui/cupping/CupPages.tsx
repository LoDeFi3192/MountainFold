// Summary table with CSV, print and PDF exports, and the Brewing Lab notebook.
import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { buildCsv, CupFormat, cupLabel, LAB_METHODS, labMethodName } from '../../core/cupping';
import { CuppingCoffee, cuppingFinalScore, cuppingUniqueNotes, CuppingSession, LabRecipe } from '../../core/models';
import { localIsoDate } from '../../core/coffee';
import { shortDate, shortDateIso, t } from '../../i18n/i18n';
import { saveFile } from '../../platform/device';
import { useApp } from '../../state/store';
import { labSeconds, labWater } from '../../state/cupping';
import { Btn, IconButton, Scroll, TcIcon, TextField, useNow } from '../components';
import { HEART, PageHeader, TcCard, TcSectionTitle, TcSlider } from './parts';

// ---- summary -----------------------------------------------------------------------------------------------
function headers(pdf: boolean) {
  const base = [t('cup_coffee_name'), t('cup_fav'), t('cup_process'), t('cup_score'), t(pdf ? 'cup_sensory_profile' : 'cup_notes_col'),
    t('cup_fragrance'), t('cup_flavor'), t('cup_aftertaste'), t('cup_acidity'), t('cup_body'), t('cup_balance')];
  return pdf ? base : [...base, t('cup_comments')];
}

function reportTexts(s: CuppingSession) {
  const meta = [s.originNotes.trim() ? `${t('cup_origins')}: ${s.originNotes}` : null, s.roasterNotes.trim() ? `${t('cup_roaster')}: ${s.roasterNotes}` : null].filter(Boolean).join(' | ');
  return {
    title: t('cup_report_title'),
    subtitle: t('cup_report_line', t('cup_date'), shortDateIso(s.dateIso)),
    location: s.location.trim() ? `${t('cup_location')}: ${s.location}` : null,
    meta: meta || null,
  };
}

/** PDF laid out like the original jsPDF + autoTable report: A4 landscape, brown header row, striped body, page numbers. */
async function buildPdf(session: CuppingSession, coffees: CuppingCoffee[], lang: string): Promise<Blob> {
  const [{ jsPDF }, { autoTable }] = await Promise.all([import('jspdf'), import('jspdf-autotable')]);
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const tx = reportTexts(session);
  doc.setFontSize(22);
  doc.setTextColor(141, 110, 77);
  doc.text(tx.title, 14, 20);
  doc.setFontSize(10);
  doc.setTextColor(100);
  doc.text(tx.subtitle, 14, 28);
  if (tx.location) doc.text(tx.location, 14, 33);
  let y = 33;
  if (tx.meta) { y += 5; doc.text(tx.meta, 14, y); }
  const label = (k: string) => cupLabel(k, lang);
  const body = coffees.map((c) => [
    c.name, c.isFavorite ? '♥' : '-', c.process ? label(c.process) : '-', CupFormat.fixed2(cuppingFinalScore(c)),
    cuppingUniqueNotes(c).map(label).join(', '), CupFormat.jsNumber(c.fragranceScore), CupFormat.jsNumber(c.flavorScore),
    CupFormat.jsNumber(c.aftertasteScore), CupFormat.jsNumber(c.acidityScore), CupFormat.jsNumber(c.bodyScore), CupFormat.jsNumber(c.balanceScore),
  ]);
  autoTable(doc, {
    head: [headers(true)],
    body,
    startY: y + 10,
    theme: 'striped',
    headStyles: { fillColor: [141, 110, 77], textColor: [255, 255, 255], fontStyle: 'bold' },
    // Horizontal padding a little tighter than the original, so "Fav" and "Arrière-goût" keep their words.
    styles: { fontSize: 9, cellPadding: { top: 3, bottom: 3, left: 2, right: 2 }, overflow: 'linebreak' },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 30 }, 1: { halign: 'center', textColor: [220, 50, 50], cellWidth: 12 }, 2: { cellWidth: 22 },
      3: { fontStyle: 'bold', halign: 'center', cellWidth: 15 }, 4: { cellWidth: 'auto' },
      5: { cellWidth: 23 }, 6: { cellWidth: 23 }, 7: { cellWidth: 23 }, 8: { cellWidth: 23 }, 9: { cellWidth: 23 }, 10: { cellWidth: 23 },
    },
    // The built-in PDF fonts have no heart glyph: draw it.
    didParseCell: (d) => { if (d.section === 'body' && d.column.index === 1 && d.cell.raw === '♥') d.cell.text = ['']; },
    didDrawCell: (d) => {
      if (d.section !== 'body' || d.column.index !== 1 || d.cell.raw !== '♥') return;
      const cx = d.cell.x + d.cell.width / 2;
      const cy = d.cell.y + d.cell.height / 2;
      const r = 1.1;
      doc.setFillColor(220, 50, 50);
      doc.circle(cx - r * 0.85, cy - r * 0.4, r, 'F');
      doc.circle(cx + r * 0.85, cy - r * 0.4, r, 'F');
      doc.triangle(cx - r * 1.85, cy - r * 0.15, cx + r * 1.85, cy - r * 0.15, cx, cy + r * 1.9, 'F');
    },
  });
  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(150);
    doc.text(t('cup_page_of', i, pages), doc.internal.pageSize.getWidth() - 20, doc.internal.pageSize.getHeight() - 10, { align: 'right' });
  }
  return doc.output('blob');
}

/** What window.print() shows: the report table only, as the original's print stylesheet did. */
function PrintReport({ session, coffees, lang }: { session: CuppingSession; coffees: CuppingCoffee[]; lang: string }) {
  const tx = reportTexts(session);
  return createPortal(
    <div className="print-only print-report">
      <h1>{tx.title}</h1>
      <p>{tx.subtitle}</p>
      {tx.location && <p>{tx.location}</p>}
      {tx.meta && <p>{tx.meta}</p>}
      <table>
        <thead><tr>{headers(true).map((h, i) => <th key={i}>{h}</th>)}</tr></thead>
        <tbody>
          {coffees.map((c) => (
            <tr key={c.id}>
              <td style={{ fontWeight: 'bold' }}>{c.name}</td>
              <td style={{ color: 'rgb(220,50,50)', textAlign: 'center' }}>{c.isFavorite ? '♥' : '-'}</td>
              <td>{c.process ? cupLabel(c.process, lang) : '-'}</td>
              <td style={{ fontWeight: 'bold', textAlign: 'center' }}>{CupFormat.fixed2(cuppingFinalScore(c))}</td>
              <td>{cuppingUniqueNotes(c).map((n) => cupLabel(n, lang)).join(', ')}</td>
              {[c.fragranceScore, c.flavorScore, c.aftertasteScore, c.acidityScore, c.bodyScore, c.balanceScore].map((v, i) => <td key={i}>{CupFormat.jsNumber(v)}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>,
    document.body,
  );
}

export function SummaryPage({ wide }: { wide: boolean }) {
  const session = useApp((s) => s.cupSession);
  const coffees = useApp((s) => s.cupCoffees);
  const lang = useApp((s) => s.lang);
  const s = useApp.getState();
  const [busy, setBusy] = useState(false);
  // Loads the PDF code while the table is on screen, so the export starts right after the tap.
  useEffect(() => { void import('jspdf'); void import('jspdf-autotable'); }, []);
  if (!session) return null;
  const today = localIsoDate();
  const csv = async () => {
    const text = '﻿' + buildCsv(coffees, headers(false), t('cup_yes'), t('cup_no'), (k) => cupLabel(k, lang));
    const ok = await saveFile(new Blob([text], { type: 'text/csv;charset=utf-8' }), `cupping_session_${today}.csv`, s.askSave);
    if (ok === true) s.say('cup_file_saved');
  };
  const pdf = async () => {
    setBusy(true);
    try {
      const blob = await buildPdf(session, coffees, lang);
      const ok = await saveFile(blob, `cupping_rapport_${today}.pdf`, s.askSave);
      if (ok === true) s.say('cup_file_saved');
    } catch {
      s.say('cup_file_failed');
    } finally {
      setBusy(false);
    }
  };
  const buttons = (full: boolean) => {
    const st = full ? { width: '100%' } : undefined;
    return (
      <>
        <Btn kind="outlined" onClick={() => void csv()} style={st}>📥 {t('cup_csv')}</Btn>
        <Btn kind="tonal" onClick={() => window.print()} style={st}>🖨️ {t('cup_print')}</Btn>
        <Btn onClick={() => void pdf()} disabled={busy} style={st}><TcIcon name="Printer" size={20} /> {t('cup_pdf')}</Btn>
      </>
    );
  };
  return (
    <div className="page">
      <PageHeader title={t('cup_summary')} onBack={() => s.set({ cupScreen: 'MAIN' })} />
      <Scroll style={{ padding: 16 }}>
        {wide ? <SummaryTable coffees={coffees} lang={lang} /> : coffees.map((c) => <SummaryCard key={c.id} c={c} lang={lang} />)}
        <div style={{ height: 32 }} />
        {wide ? <div className="row gap16" style={{ justifyContent: 'center' }}>{buttons(false)}</div> : <div className="col gap12">{buttons(true)}</div>}
        <div style={{ height: 32 }} />
      </Scroll>
      <PrintReport session={session} coffees={coffees} lang={lang} />
    </div>
  );
}

function NoteTags({ notes, lang }: { notes: string[]; lang: string }) {
  if (!notes.length) return null;
  return (
    <div className="row wrap" style={{ gap: 4 }}>
      {notes.map((n) => (
        <span key={n} className="label-small" style={{ borderRadius: 4, padding: '2px 8px', color: 'var(--on-surface-variant)', background: 'var(--surface-container-highest)', boxShadow: 'inset 0 0 0 1px color-mix(in srgb, var(--outline) 10%, transparent)' }}>
          {cupLabel(n, lang)}
        </span>
      ))}
    </div>
  );
}

function SummaryCard({ c, lang }: { c: CuppingCoffee; lang: string }) {
  const cells: [string, number][] = [
    [t('cup_fragrance'), c.fragranceScore], [t('cup_flavor'), c.flavorScore], [t('cup_acidity'), c.acidityScore],
    [t('cup_body'), c.bodyScore], [t('cup_aftertaste'), c.aftertasteScore], [t('cup_balance'), c.balanceScore],
  ];
  return (
    <div style={{ borderRadius: 16, overflow: 'hidden', marginBottom: 16, boxShadow: '0 1px 2px rgba(0,0,0,.12)', border: '1px solid color-mix(in srgb, var(--outline) 10%, transparent)', background: 'var(--surface-container-low)' }}>
      <div className="row" style={{ background: 'var(--surface-container-high)', padding: 16, gap: 8 }}>
        {c.isFavorite && <TcIcon name="HeartFilled" size={20} style={{ color: HEART }} />}
        <span className="title-medium grow ellipsis">{c.name}</span>
        <div className="col" style={{ alignItems: 'flex-end' }}>
          <span style={{ fontSize: 10, fontWeight: 700, color: 'var(--on-surface-variant)', textTransform: 'uppercase' }}>{t('cup_score')}</span>
          <span className="headline-small tnum" style={{ color: 'var(--primary)' }}>{CupFormat.fixed2(cuppingFinalScore(c))}</span>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, padding: 16 }}>
        {cells.map(([l, v]) => (
          <div key={l} className="col" style={{ alignItems: 'center', minWidth: 0 }}>
            <span className="ellipsis" style={{ fontSize: 10, color: 'var(--on-surface-variant)', textTransform: 'uppercase', maxWidth: '100%' }}>{l}</span>
            <span className="title-medium">{CupFormat.jsNumber(v)}</span>
          </div>
        ))}
      </div>
      <div style={{ background: 'var(--surface)', padding: 16 }}>
        {c.process && (
          <div className="row gap8" style={{ paddingBottom: 8 }}>
            <span className="label-small" style={{ fontWeight: 700, color: 'var(--on-surface-variant)' }}>{t('cup_process')}:</span>
            <span className="label-small" style={{ color: 'var(--primary)', background: 'color-mix(in srgb, var(--primary) 10%, transparent)', borderRadius: 4, padding: '2px 8px' }}>{cupLabel(c.process, lang)}</span>
          </div>
        )}
        <NoteTags notes={cuppingUniqueNotes(c)} lang={lang} />
        {c.comments.trim() && <p className="body-medium italic" style={{ margin: '8px 0 0', color: 'color-mix(in srgb, var(--on-surface-variant) 80%, transparent)' }}>"{c.comments}"</p>}
      </div>
    </div>
  );
}

/** Desktop table of the original: sticky name column, horizontal scroll for the rest. */
function SummaryTable({ coffees, lang }: { coffees: CuppingCoffee[]; lang: string }) {
  const cols: [string, number][] = [
    [t('cup_fav'), 56], [t('cup_process'), 120], [t('cup_score'), 88], [t('cup_aroma_profile'), 260], [t('cup_fragrance'), 124], [t('cup_flavor'), 124],
    [t('cup_aftertaste'), 124], [t('cup_acidity'), 124], [t('cup_body'), 124], [t('cup_balance'), 124],
  ];
  const sticky = { position: 'sticky' as const, left: 0, zIndex: 1, boxShadow: '2px 0 5px -2px rgba(0,0,0,.1)' };
  return (
    <div className="hscroll" style={{ borderRadius: 12, background: 'var(--surface-container-low)', boxShadow: '0 2px 6px rgba(0,0,0,.12)', border: '1px solid color-mix(in srgb, var(--outline) 10%, transparent)' }}>
      <table style={{ borderCollapse: 'collapse', minWidth: '100%' }}>
        <thead>
          <tr style={{ background: 'var(--surface-container-high)' }}>
            <th className="label-medium upper" style={{ ...sticky, background: 'var(--surface-container-high)', minWidth: 170, padding: '12px 16px', textAlign: 'left' }}>{t('cup_coffee_name')}</th>
            {cols.map(([l, w], i) => <th key={i} className="label-medium upper" style={{ minWidth: w, padding: 12, textAlign: i === 3 ? 'left' : 'center' }}>{l}</th>)}
          </tr>
        </thead>
        <tbody>
          {coffees.map((c) => (
            <tr key={c.id} style={{ background: 'var(--surface)', borderTop: '1px solid color-mix(in srgb, var(--outline) 10%, transparent)' }}>
              <td className="title-small" style={{ ...sticky, background: 'var(--surface)', padding: '12px 16px', whiteSpace: 'nowrap' }}>{c.name}</td>
              <td style={{ textAlign: 'center', padding: 8 }}>{c.isFavorite && <TcIcon name="HeartFilled" size={20} style={{ color: HEART, display: 'inline-block' }} />}</td>
              <td className="body-small" style={{ textAlign: 'center', padding: 8 }}>{c.process ? cupLabel(c.process, lang) : '-'}</td>
              <td className="title-small tnum" style={{ textAlign: 'center', color: 'var(--primary)', background: 'color-mix(in srgb, var(--primary) 6%, transparent)', padding: 8 }}>{CupFormat.fixed2(cuppingFinalScore(c))}</td>
              <td style={{ padding: '10px 12px' }}><NoteTags notes={cuppingUniqueNotes(c)} lang={lang} /></td>
              {[c.fragranceScore, c.flavorScore, c.aftertasteScore, c.acidityScore, c.bodyScore, c.balanceScore].map((v, i) => (
                <td key={i} className="body-medium" style={{ textAlign: 'center', padding: 8 }}>{CupFormat.jsNumber(v)}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ---- Brewing Lab ------------------------------------------------------------------------------------------------
const labIcon = (id: string) => (id === 'chemex' ? 'Chemex' : id === 'aeropress' ? 'Aeropress' : id === 'french_press' ? 'FrenchPress' : id === 'moka' ? 'Moka' : 'V60');

function LabTitle() {
  const set = useApp((s) => s.set);
  return (
    <div className="row" style={{ paddingBottom: 24 }}>
      <span className="headline-small grow" style={{ color: 'var(--primary)' }}>☕ {t('cup_brewing_lab')}</span>
      <Btn kind="outlined" onClick={() => set({ cupScreen: 'MAIN' })}>{t('back')}</Btn>
    </div>
  );
}

function LabNumber({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="col grow">
      <span className="label-medium muted" style={{ paddingBottom: 4 }}>{label}</span>
      <input value={value} inputMode="decimal" aria-label={label} onChange={(e) => onChange(e.target.value.replace(/[^0-9.,]/g, ''))}
        className="headline-small" style={{ textAlign: 'center', fontWeight: 700, border: 0, outline: 'none', borderRadius: 12, background: 'var(--surface-container-highest)', color: 'var(--on-surface)', padding: '12px 8px', width: '100%', boxShadow: 'inset 0 0 0 1px var(--outline)' }} />
    </label>
  );
}

function WaterBox({ water, big }: { water: number; big?: boolean }) {
  return (
    <div className="col" style={{ alignItems: 'center', borderRadius: 12, background: 'var(--secondary-container)', padding: 16 }}>
      <span className="label-large" style={{ color: 'var(--on-secondary-container)' }}>{t('cup_water_required')}</span>
      <span className="tnum" style={{ font: `700 ${big ? 64 : 45}px/1.1 var(--font-display)`, color: 'var(--primary)' }}>{water}g</span>
    </div>
  );
}

function LabStopwatch({ size }: { size: number }) {
  const running = useApp((s) => s.labRunning);
  const base = useApp((s) => s.labBaseMs);
  const started = useApp((s) => s.labStartedAt);
  const s = useApp.getState();
  const now = useNow(running, 200);
  const secs = labSeconds({ labRunning: running, labBaseMs: base, labStartedAt: started }, now);
  return (
    <div className="col" style={{ alignItems: 'center' }}>
      <span className="timer" style={{ fontSize: size, paddingBottom: 16 }}>{CupFormat.clock(secs)}</span>
      <div className="row gap16">
        {running ? <Btn kind="outlined" onClick={s.labToggleTimer} style={{ width: 128 }}>{t('pause')}</Btn> : <Btn onClick={s.labToggleTimer} style={{ width: 128 }}>{t('start')}</Btn>}
        <Btn kind="tonal" onClick={s.labResetTimer}>{t('cup_reset')}</Btn>
      </div>
    </div>
  );
}

export function LabForm({ showHistoryButton, desk }: { showHistoryButton: boolean; desk?: boolean }) {
  const d = useApp((s) => s.lab);
  const lang = useApp((s) => s.lang);
  const s = useApp.getState();
  const up = (patch: Partial<typeof d>) => s.set({ lab: { ...useApp.getState().lab, ...patch } });
  return (
    <Scroll style={{ padding: 16 }}>
      {!desk && showHistoryButton && <LabTitle />}
      <div className="hscroll row gap16" style={{ padding: '8px 4px', marginBottom: 16 }}>
        {LAB_METHODS.map((m) => {
          const on = d.method === m.id;
          return (
            <button key={m.id} type="button" role="radio" aria-checked={on} onClick={() => s.labPickMethod(m.id)} className="col"
              style={{ minWidth: 80, alignItems: 'center', padding: 12, borderRadius: 16, border: 0, cursor: 'pointer', flex: '0 0 auto',
                background: on ? 'var(--primary)' : 'var(--surface-container-high)', color: on ? 'var(--on-primary)' : 'var(--on-surface-variant)',
                boxShadow: on ? '0 2px 6px rgba(0,0,0,.2)' : undefined, transform: on ? 'scale(1.05)' : undefined }}>
              <TcIcon name={labIcon(m.id)} size={32} />
              <span className="label-medium mt8" style={{ fontWeight: 700 }}>{labMethodName(m.id, lang)}</span>
            </button>
          );
        })}
      </div>
      <TcCard>
        <TcSectionTitle text={t('cup_recipe')} />
        <div className="row-bottom" style={{ paddingBottom: 16 }}>
          <LabNumber label={t('cup_coffee_weight')} value={d.coffee} onChange={(v) => up({ coffee: v })} />
          <span className="headline-small" style={{ padding: '14px 16px', color: 'color-mix(in srgb, var(--on-surface) 50%, transparent)' }}>×</span>
          <LabNumber label={t('cup_ratio')} value={d.ratio} onChange={(v) => up({ ratio: v })} />
        </div>
        {!desk && <WaterBox water={labWater(d)} />}
        <div className="label-medium muted" style={{ paddingTop: 16, paddingBottom: 4 }}>{t('cup_grind_size')}</div>
        <TextField value={d.grind} onChange={(v) => up({ grind: v })} placeholder={t('cup_grind_placeholder')} bg="var(--surface-container-low)" />
      </TcCard>
      {!desk && <TcCard><LabStopwatch size={57} /></TcCard>}
      <TcCard>
        <TcSectionTitle text={t('cup_cup_result')} icon="Comment" />
        <TcSlider label={t('cup_global_rating')} value={d.rating} onChange={(v) => up({ rating: v })} min={1} max={10} step={0.5} />
        <TextField value={d.notes} onChange={(v) => up({ notes: v })} placeholder={t('cup_notes_placeholder')} multiline minRows={4}
          style={{ background: 'var(--surface-container-highest)', borderRadius: 8 }} />
      </TcCard>
      <div className="row gap12" style={{ paddingBottom: 24 }}>
        {showHistoryButton && <Btn kind="tonal" onClick={() => s.set({ labHistory: true })} style={{ flex: '1 1 0' }}>📂 {t('cup_history')}</Btn>}
        <Btn onClick={s.labSave} style={{ flex: '1 1 0' }}>💾 {t('save')}</Btn>
      </div>
    </Scroll>
  );
}

/** Counter top half of the Lab: water to pour and the stopwatch, readable from the counter. */
export function LabDeskTop() {
  const d = useApp((s) => s.lab);
  const lang = useApp((s) => s.lang);
  const set = useApp((s) => s.set);
  const h = typeof window !== 'undefined' ? window.innerHeight : 600;
  const clock = Math.min(120, Math.max(40, h * 0.5 * 0.32));
  return (
    <div className="row gap24" style={{ flex: 1, flexWrap: 'wrap', alignContent: 'center' }}>
      <div className="col grow" style={{ minWidth: 240 }}>
        <div className="row gap8" style={{ paddingBottom: 12 }}>
          <TcIcon name={labIcon(d.method)} size={28} style={{ color: 'var(--primary)' }} />
          <span className="title-large grow">{labMethodName(d.method, lang)}</span>
          <Btn kind="outlined" onClick={() => set({ cupScreen: 'MAIN' })}>{t('back')}</Btn>
        </div>
        <WaterBox water={labWater(d)} big />
      </div>
      <div className="grow" style={{ minWidth: 240 }}><LabStopwatch size={clock} /></div>
    </div>
  );
}

export function LabHistoryPane({ standalone }: { standalone: boolean }) {
  const recipes = useApp((s) => s.data.labRecipes);
  const set = useApp((s) => s.set);
  return (
    <Scroll style={{ padding: 16 }}>
      {standalone && <LabTitle />}
      <div className="title-medium" style={{ paddingBottom: 16 }}>{t('cup_history')}</div>
      {recipes.length === 0 && <span className="body-medium italic" style={{ color: 'color-mix(in srgb, var(--on-surface-variant) 60%, transparent)' }}>{t('cup_no_recipes')}</span>}
      {recipes.map((r) => <LabCard key={r.id} r={r} />)}
      {!standalone && <Btn kind="tonal" onClick={() => set({ labHistory: false })} style={{ width: '100%', marginTop: 16 }}>{t('cup_close_history')}</Btn>}
    </Scroll>
  );
}

function LabCard({ r }: { r: LabRecipe }) {
  const lang = useApp((s) => s.lang);
  const s = useApp.getState();
  return (
    <div role="button" tabIndex={0} onClick={() => s.labLoad(r)} style={{ background: 'var(--surface-container-low)', borderRadius: 16, boxShadow: '0 1px 2px rgba(0,0,0,.12)', padding: 16, marginBottom: 12, cursor: 'pointer' }}>
      <div className="row-top">
        <div className="col grow">
          <div className="row gap8">
            <span className="title-medium" style={{ color: 'var(--primary)' }}>{labMethodName(r.method, lang)}</span>
            <span className="label-small" style={{ fontWeight: 700, color: 'var(--primary)', background: 'color-mix(in srgb, var(--primary) 10%, transparent)', borderRadius: 10, padding: '2px 8px' }}>{CupFormat.jsNumber(r.rating)}/10</span>
          </div>
          <span className="body-small muted">{shortDate(r.timestamp)}</span>
        </div>
        <IconButton label={t('cup_confirm_delete_recipe')} color="var(--error)" onClick={() => s.set({ cupPendingDeleteRecipe: r })}><TcIcon name="DeleteSession" size={20} /></IconButton>
      </div>
      <div className="col gap4 mt8 body-small muted">
        <div className="row"><span className="grow">☕ {CupFormat.jsNumber(r.coffeeWeight)}g</span><span className="grow">💧 {r.waterWeight}g (1:{CupFormat.jsNumber(r.ratio)})</span></div>
        <div className="row"><span className="grow">⏱️ {CupFormat.clock(r.totalTime)}</span><span className="grow ellipsis">⚙️ {r.grindSize.trim() || '-'}</span></div>
      </div>
      {r.notes.trim() && (
        <>
          <hr className="divider mt8" style={{ background: 'color-mix(in srgb, var(--outline) 10%, transparent)' }} />
          <p className="body-small italic ellipsis" style={{ margin: '8px 0 0', color: 'color-mix(in srgb, var(--on-surface) 80%, transparent)' }}>"{r.notes}"</p>
        </>
      )}
    </div>
  );
}
