// The spinning flavor wheel. Drag to turn; it keeps spinning and slows down (x0.92 per frame), like the original.
import { CSSProperties, useEffect, useLayoutEffect, useRef } from 'react';
import { angleDelta, contrastOn, cupLabel, ITEM_COLOR_OVERRIDES, SLICES, termLabel, wheelActiveIndex, wheelRotationFor } from '../../core/cupping';
import { t } from '../../i18n/i18n';
import { haptic, prefersReducedMotion } from '../../platform/device';
import { useApp } from '../../state/store';
import { Btn } from '../components';
import { TcChip } from './parts';

/** [center] and [radius] are fractions resolved against the canvas size by [geometry]. */
export function WheelSurface({ geometry, pointerDeg, style }: {
  geometry: (w: number, h: number) => { cx: number; cy: number; r: number }; pointerDeg: number; style?: CSSProperties;
}) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const rotation = useApp((s) => s.wheelRotation);
  const lang = useApp((s) => s.lang);
  const haptics = useApp((s) => s.settings.haptics);
  const set = useApp((s) => s.set);
  const motion = useRef<{ raf: number; last: number; velocity: number; prevAngle: number; dragging: boolean }>({ raf: 0, last: 0, velocity: 0, prevAngle: 0, dragging: false });
  const sizeRef = useRef({ w: 0, h: 0 });
  const active = wheelActiveIndex(rotation, pointerDeg);
  const lastActive = useRef(active);

  useEffect(() => {
    if (active !== lastActive.current) { lastActive.current = active; if (haptics) haptic('tick'); }
  }, [active, haptics]);

  const draw = () => {
    const c = canvas.current;
    if (!c) return;
    const { w, h } = sizeRef.current;
    const dpr = window.devicePixelRatio || 1;
    const ctx = c.getContext('2d');
    if (!ctx || w === 0) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    const { cx, cy, r } = geometry(w, h);
    const css = getComputedStyle(document.documentElement);
    const surface = css.getPropertyValue('--surface').trim() || '#fff';
    const high = css.getPropertyValue('--surface-container-high').trim() || '#eee';
    const primary = css.getPropertyValue('--primary').trim() || '#8D6E4D';
    const onSurface = css.getPropertyValue('--on-surface').trim() || '#000';
    const rot = useApp.getState().wheelRotation;
    const rad = (d: number) => (d * Math.PI) / 180;
    for (const s of SLICES) {
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, r, rad(s.startDeg + rot), rad(s.endDeg + rot));
      ctx.closePath();
      ctx.fillStyle = s.color;
      ctx.fill();
      ctx.lineWidth = Math.max(1, r * 0.004);
      ctx.strokeStyle = surface;
      ctx.stroke();
    }
    ctx.font = `700 ${Math.round(r * 0.05)}px 'Open Sans', system-ui, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (const s of SLICES) {
      const a = s.midDeg + rot;
      const tx = cx + r * 0.7 * Math.cos(rad(a));
      const ty = cy + r * 0.7 * Math.sin(rad(a));
      const norm = ((a % 360) + 360) % 360;
      // Labels on the left half are turned round so they never read upside down.
      const textAngle = norm > 90 && norm < 270 ? a + 180 : a;
      ctx.save();
      ctx.translate(tx, ty);
      ctx.rotate(rad(textAngle));
      ctx.fillStyle = contrastOn(s.color);
      ctx.fillText(cupLabel(s.key, lang), 0, 0);
      ctx.restore();
    }
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.2, 0, Math.PI * 2); ctx.fillStyle = high; ctx.fill();
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.04, 0, Math.PI * 2); ctx.fillStyle = primary; ctx.fill();
    // Pointer: a triangle whose tip touches the rim, and a faint line going outwards.
    const p = rad(pointerDeg);
    const dx = Math.cos(p);
    const dy = Math.sin(p);
    const tipX = cx + dx * (r - 2);
    const tipY = cy + dy * (r - 2);
    const bx = tipX + dx * 25;
    const by = tipY + dy * 25;
    ctx.beginPath();
    ctx.moveTo(tipX, tipY);
    ctx.lineTo(bx - dy * 15, by + dx * 15);
    ctx.lineTo(bx + dy * 15, by - dx * 15);
    ctx.closePath();
    ctx.fillStyle = onSurface;
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(bx, by);
    ctx.lineTo(bx + dx * w * 0.1, by + dy * w * 0.1);
    ctx.lineWidth = 2;
    ctx.strokeStyle = onSurface;
    ctx.globalAlpha = 0.2;
    ctx.stroke();
    ctx.globalAlpha = 1;
  };

  useLayoutEffect(() => {
    const c = canvas.current;
    if (!c) return;
    const resize = () => {
      const rect = c.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      sizeRef.current = { w: rect.width, h: rect.height };
      c.width = Math.round(rect.width * dpr);
      c.height = Math.round(rect.height * dpr);
      draw();
    };
    resize();
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(resize) : null;
    ro?.observe(c);
    return () => ro?.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => { draw(); });
  useEffect(() => () => cancelAnimationFrame(motion.current.raf), []);

  const angleOf = (e: React.PointerEvent) => {
    const rect = canvas.current!.getBoundingClientRect();
    const { cx, cy } = geometry(rect.width, rect.height);
    return (Math.atan2(e.clientY - rect.top - cy, e.clientX - rect.left - cx) * 180) / Math.PI;
  };

  const step = (index: number) => set({ wheelRotation: wheelRotationFor((index + SLICES.length) % SLICES.length, useApp.getState().wheelRotation, pointerDeg) });
  const slice = SLICES[active];
  return (
    <canvas ref={canvas} role="img" tabIndex={0}
      aria-label={t('cup_wheel_cd', termLabel(slice.category.name, lang), cupLabel(slice.key, lang))}
      onKeyDown={(e) => { if (e.key === 'ArrowDown' || e.key === 'ArrowRight') step(active + 1); if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') step(active - 1); }}
      style={{ width: '100%', height: '100%', display: 'block', touchAction: 'none', ...style }}
      onPointerDown={(e) => {
        cancelAnimationFrame(motion.current.raf);
        motion.current.dragging = true;
        motion.current.prevAngle = angleOf(e);
        motion.current.velocity = 0;
        try { canvas.current?.setPointerCapture(e.pointerId); } catch { /* ignore */ }
      }}
      onPointerMove={(e) => {
        if (!motion.current.dragging) return;
        const a = angleOf(e);
        const d = angleDelta(motion.current.prevAngle, a);
        motion.current.prevAngle = a;
        motion.current.velocity = d;
        set({ wheelRotation: useApp.getState().wheelRotation + d });
      }}
      onPointerUp={() => {
        motion.current.dragging = false;
        if (prefersReducedMotion()) return;
        let v = motion.current.velocity;
        let lastT = 0;
        const frame = (tm: number) => {
          const frames = lastT === 0 ? 1 : Math.min(4, Math.max(0.25, (tm - lastT) / 16.6667));
          lastT = tm;
          set({ wheelRotation: useApp.getState().wheelRotation + v * frames });
          v *= Math.pow(0.92, frames);
          if (Math.abs(v) > 0.05) motion.current.raf = requestAnimationFrame(frame);
        };
        if (Math.abs(v) > 0.05) motion.current.raf = requestAnimationFrame(frame);
      }}
      onPointerCancel={() => { motion.current.dragging = false; }}
    />
  );
}

/** Family pill, aroma name in its own colour and the short colour bar. */
export function WheelInfo({ pointerDeg, nameSize = 48, alignEnd = true, style }: { pointerDeg: number; nameSize?: number; alignEnd?: boolean; style?: CSSProperties }) {
  const rotation = useApp((s) => s.wheelRotation);
  const lang = useApp((s) => s.lang);
  const s = SLICES[wheelActiveIndex(rotation, pointerDeg)];
  return (
    <div className="col" style={{ alignItems: alignEnd ? 'flex-end' : 'center', pointerEvents: 'none', ...style }}>
      <span className="label-medium upper" style={{ letterSpacing: 2, color: 'var(--on-surface-variant)', background: 'var(--surface-container-high)', borderRadius: 16, padding: '4px 16px', marginBottom: 8, boxShadow: 'inset 0 0 0 1px color-mix(in srgb, var(--outline) 20%, transparent)' }}>
        {termLabel(s.category.name, lang)}
      </span>
      <span style={{ font: `900 ${nameSize}px/${nameSize * 1.1}px var(--font-display)`, color: s.color, textAlign: alignEnd ? 'right' : 'center', textShadow: '0 1px 0 rgba(0,0,0,.08)' }}>{cupLabel(s.key, lang)}</span>
      <span style={{ margin: '24px 0', width: 96, height: 8, borderRadius: 4, background: 'color-mix(in srgb, var(--on-surface) 10%, transparent)', overflow: 'hidden' }}>
        <span style={{ display: 'block', width: '60%', height: 8, borderRadius: 4, background: s.color }} />
      </span>
    </div>
  );
}

/** Other aromas of the active family, shown beside the wheel on the big screen. */
export function WheelSiblings({ pointerDeg }: { pointerDeg: number }) {
  const rotation = useApp((s) => s.wheelRotation);
  const lang = useApp((s) => s.lang);
  const set = useApp((s) => s.set);
  const s = SLICES[wheelActiveIndex(rotation, pointerDeg)];
  return (
    <div className="row wrap gap8" style={{ justifyContent: 'center', maxWidth: 420 }}>
      {s.category.items.map((item) => {
        const c = ITEM_COLOR_OVERRIDES[item.key] ?? s.category.color;
        return <TcChip key={item.key} label={termLabel(item, lang)} selected={item.key === s.key} color={c} dot={c}
          onClick={() => set({ wheelRotation: wheelRotationFor(SLICES.findIndex((x) => x.key === item.key), useApp.getState().wheelRotation, pointerDeg) })} />;
      })}
    </div>
  );
}

/** Full-screen wheel: centre on the left edge, radius 36.5 % of the height, arrow on the right of the rim. */
export function FlavorWheelFull({ onClose }: { onClose: () => void }) {
  return (
    <div className="page" style={{ background: 'var(--surface)' }}>
      <WheelSurface pointerDeg={0} geometry={(w, h) => ({ cx: 0, cy: h / 2, r: Math.min(0.365 * h, w * 0.9) })} style={{ position: 'absolute', inset: 0 }} />
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', background: 'linear-gradient(to right, transparent 0%, transparent 50%, color-mix(in srgb, var(--surface) 90%, transparent) 100%)' }} />
      <WheelInfo pointerDeg={0} style={{ position: 'absolute', top: 128, right: 24, width: '62%' }} />
      <div style={{ position: 'absolute', top: 24, right: 24 }}><Btn onClick={onClose}>{t('cup_close')}</Btn></div>
    </div>
  );
}
