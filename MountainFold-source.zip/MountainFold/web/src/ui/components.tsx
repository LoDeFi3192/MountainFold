// Shared building blocks: the web twins of ui/components/Components.kt.
import React, { CSSProperties, ReactNode, useEffect, useId, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { MATERIAL, TC } from './icons.data';
import { formatClock } from '../core/coffee';
import type { BrewStep } from '../core/models';
import { t } from '../i18n/i18n';
import { useApp } from '../state/store';
import { unitsOf } from '../state/store';
import { getPhoto } from '../data/db';

export const useUnits = () => {
  const s = useApp((x) => x.settings);
  return unitsOf(s);
};

// ---- icons --------------------------------------------------------------------------------------
export function Icon({ name, size = 24, style, className }: { name: string; size?: number; style?: CSSProperties; className?: string }) {
  const inner = MATERIAL[name] ?? '';
  return (
    <svg className={`icon ${className ?? ''}`} width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"
      style={{ width: size, height: size, ...style }} dangerouslySetInnerHTML={{ __html: inner }} />
  );
}

/** Icons of the original Toulouse Cupping app, drawn from their own SVG paths. */
export function TcIcon({ name, size = 24, style, className }: { name: string; size?: number; style?: CSSProperties; className?: string }) {
  const def = TC[name];
  if (!def) return null;
  const r = def.root;
  return (
    <svg className={`icon ${className ?? ''}`} width={size} height={size} viewBox={r.viewBox ?? '0 0 24 24'} aria-hidden="true"
      fill={r.fill ?? 'currentColor'} stroke={r.stroke} strokeWidth={r.strokeWidth} strokeLinecap={r.strokeLinecap as never}
      strokeLinejoin={r.strokeLinejoin as never} style={{ width: size, height: size, ...style }} dangerouslySetInnerHTML={{ __html: def.inner }} />
  );
}

// ---- text that shrinks before it truncates (long translations, large text) -----------------------
export function FitText({ text, className, min = 9 }: { text: string; className?: string; min?: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const fit = () => {
      el.style.fontSize = '';
      let size = parseFloat(getComputedStyle(el).fontSize);
      let guard = 0;
      while (el.scrollWidth > el.clientWidth + 0.5 && size > min && guard++ < 40) {
        size -= 0.5;
        el.style.fontSize = `${size}px`;
      }
    };
    fit();
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(fit) : null;
    ro?.observe(el.parentElement ?? el);
    return () => ro?.disconnect();
  }, [text, min]);
  return <span ref={ref} className={`label ${className ?? ''}`}>{text}</span>;
}

// ---- buttons --------------------------------------------------------------------------------------
type BtnKind = 'filled' | 'tonal' | 'outlined' | 'text';
export function Btn({ kind = 'filled', icon, children, onClick, disabled, className, style, title, danger, elevated }: {
  kind?: BtnKind; icon?: string; children?: ReactNode; onClick?: () => void; disabled?: boolean; className?: string; style?: CSSProperties; title?: string; danger?: boolean; elevated?: boolean;
}) {
  return (
    <button type="button" className={`btn ${kind} ${danger ? 'danger' : ''} ${elevated ? 'elevated' : ''} ${className ?? ''}`} onClick={onClick} disabled={disabled} style={style} title={title}>
      {icon && <Icon name={icon} size={18} />}
      {children}
    </button>
  );
}

/** Large, table-friendly action. Height is generous so it can be hit without holding the phone. */
export function BigButton({ text, onClick, icon, primary, disabled, minHeight = 64, large, className, style, tcIcon }: {
  text: string; onClick?: () => void; icon?: string; tcIcon?: string; primary?: boolean; disabled?: boolean; minHeight?: number; large?: boolean; className?: string; style?: CSSProperties;
}) {
  return (
    <button type="button" className={`big-btn ${primary ? 'primary' : ''} ${large ? 'large' : ''} ${className ?? ''}`} onClick={onClick} disabled={disabled}
      style={{ minHeight, ...style }}>
      {icon && <Icon name={icon} size={large ? 30 : 22} />}
      {tcIcon && <TcIcon name={tcIcon} size={large ? 30 : 22} />}
      <FitText text={text} min={8} />
    </button>
  );
}

export function IconButton({ icon, label, onClick, tonal, disabled, size = 48, color, children, style }: {
  icon?: string; label: string; onClick?: () => void; tonal?: boolean; disabled?: boolean; size?: number; color?: string; children?: ReactNode; style?: CSSProperties;
}) {
  return (
    <button type="button" className={`icon-btn ${tonal ? 'tonal' : ''}`} aria-label={label} title={label} onClick={(e) => { e.stopPropagation(); onClick?.(); }} disabled={disabled}
      style={{ width: size, height: size, color, ...style }}>
      {icon ? <Icon name={icon} /> : children}
    </button>
  );
}

// ---- chips, segmented -------------------------------------------------------------------------------
export function Chip({ selected, onClick, children }: { selected: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button type="button" className="chip" aria-pressed={selected} onClick={onClick}>
      {selected && <Icon name="check" size={18} />}
      {children}
    </button>
  );
}

export function Segmented<T extends string | number | boolean>({ options, value, onChange }: { options: [T, string][]; value: T; onChange: (v: T) => void }) {
  return (
    <div className="segmented" role="radiogroup">
      {options.map(([v, label]) => (
        <button key={String(v)} type="button" role="radio" aria-checked={v === value} aria-pressed={v === value} onClick={() => onChange(v)}>
          {v === value && <Icon name="check" size={18} />}
          <span className="ellipsis">{label}</span>
        </button>
      ))}
    </div>
  );
}

// ---- fields ----------------------------------------------------------------------------------------
export function TextField({ value, onChange, label, suffix, error, multiline, minRows = 1, numeric, className, style, placeholder, disabled, inputMode, bg, type }: {
  value: string; onChange: (v: string) => void; label?: string; suffix?: string; error?: boolean; multiline?: boolean; minRows?: number;
  numeric?: boolean; className?: string; style?: CSSProperties; placeholder?: string; disabled?: boolean; inputMode?: React.HTMLAttributes<HTMLInputElement>['inputMode']; bg?: string; type?: string;
}) {
  const id = useId();
  const [focused, setFocused] = useState(false);
  const floated = focused || value !== '' || !!placeholder;
  const taRef = useRef<HTMLTextAreaElement>(null);
  useLayoutEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = 'auto';
    ta.style.height = `${Math.max(ta.scrollHeight, minRows * 24)}px`;
  }, [value, minRows]);
  const cls = `field ${focused ? 'focused' : ''} ${floated && label ? 'floated' : ''} ${error ? 'error' : ''} ${multiline ? 'multiline' : ''} ${className ?? ''}`;
  return (
    <div className={cls} style={{ ...style, ...(bg ? ({ '--field-bg': bg } as CSSProperties) : {}) }}>
      <div className="box">
        {label && <label htmlFor={id}>{label}</label>}
        {multiline ? (
          <textarea id={id} ref={taRef} rows={minRows} value={value} placeholder={placeholder} disabled={disabled}
            onFocus={() => setFocused(true)} onBlur={() => setFocused(false)} onChange={(e) => onChange(e.target.value)} />
        ) : (
          <input id={id} value={value} placeholder={placeholder} disabled={disabled} type={type ?? 'text'}
            inputMode={inputMode ?? (numeric ? 'decimal' : undefined)} autoComplete="off" autoCorrect={numeric ? 'off' : undefined}
            onFocus={() => setFocused(true)} onBlur={() => setFocused(false)}
            onChange={(e) => onChange(numeric ? e.target.value.replace(/[^0-9.,:]/g, '') : e.target.value)} />
        )}
        {suffix && <span className="suffix">{suffix}</span>}
      </div>
    </div>
  );
}

export const NumField = (p: { value: string; onChange: (v: string) => void; label: string; suffix?: string; error?: boolean; className?: string; style?: CSSProperties; bg?: string }) =>
  <TextField {...p} numeric />;

/** A field that opens the native picker: on iPhone that is the familiar wheel. */
export function SelectField<T>({ label, value, options, optionLabel, onSelect, className, style, bg }: {
  label: string; value: T; options: T[]; optionLabel: (o: T) => string; onSelect: (o: T) => void; className?: string; style?: CSSProperties; bg?: string;
}) {
  const id = useId();
  const index = options.findIndex((o) => o === value);
  return (
    <div className={`field floated ${className ?? ''}`} style={{ ...style, ...(bg ? ({ '--field-bg': bg } as CSSProperties) : {}) }}>
      <div className="box">
        <label htmlFor={id}>{label}</label>
        <select id={id} value={index < 0 ? '' : String(index)} onChange={(e) => { const i = Number(e.target.value); if (i >= 0) onSelect(options[i]); }}>
          {index < 0 && <option value="">{t('pick_one')}</option>}
          {options.map((o, i) => <option key={i} value={String(i)}>{optionLabel(o)}</option>)}
        </select>
        <span className="trailing"><Icon name="expand_more" /></span>
      </div>
    </div>
  );
}

export function SwitchRow({ title, subtitle, checked, onChange, disabled }: { title: string; subtitle?: string; checked: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <div className="switch-row" role="switch" aria-checked={checked} aria-disabled={disabled} tabIndex={0}
      onClick={() => !disabled && onChange(!checked)} onKeyDown={(e) => { if (!disabled && (e.key === ' ' || e.key === 'Enter')) { e.preventDefault(); onChange(!checked); } }}>
      <div className="col grow">
        <span className="body-large">{title}</span>
        {subtitle && <span className="body-medium muted">{subtitle}</span>}
      </div>
      <span className={`switch ${checked ? 'on' : ''} ${disabled ? 'disabled' : ''}`} />
    </div>
  );
}

export function SliderRow({ label, valueText, value, min, max, step, onChange, startLabel, endLabel }: {
  label: string; valueText: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void; startLabel?: string; endLabel?: string;
}) {
  const p = ((value - min) / (max - min)) * 100;
  return (
    <div className="col">
      <div className="row">
        <span className="body-large grow">{label}</span>
        <span className="title-medium">{valueText}</span>
      </div>
      <input className="slider" type="range" aria-label={label} min={min} max={max} step={step} value={value}
        style={{ '--p': `${p}%` } as CSSProperties} onChange={(e) => onChange(Number(e.target.value))} />
      {startLabel && endLabel && (
        <div className="row"><span className="label-small muted grow">{startLabel}</span><span className="label-small muted">{endLabel}</span></div>
      )}
    </div>
  );
}

// ---- display ------------------------------------------------------------------------------------------
export function TimerText({ text, size, color, className, style }: { text: string; size: number; color?: string; className?: string; style?: CSSProperties }) {
  return <span className={`timer ${className ?? ''}`} role="timer" aria-label={t('cd_timer', text)} style={{ fontSize: size, color: color ?? 'var(--on-surface)', ...style }}>{text}</span>;
}

/** Picks the largest text size that fits its box, so the clock reads from across the counter. */
export function FitTimer({ text, heightFraction = 0.9, className }: { text: string; heightFraction?: number; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState(64);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const measure = () => {
      const chars = Math.max(4, text.length);
      const byWidth = el.clientWidth / (chars * 0.58);
      const byHeight = el.clientHeight * heightFraction;
      setSize(Math.min(260, Math.max(40, Math.min(byWidth, byHeight))));
    };
    measure();
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(measure) : null;
    ro?.observe(el);
    return () => ro?.disconnect();
  }, [text.length, heightFraction]);
  return <div ref={ref} className={`center ${className ?? ''}`} style={{ flex: '1 1 auto', minHeight: 0, width: '100%' }}><TimerText text={text} size={size} /></div>;
}

export function Stat({ label, value, valueClass = 'title-large', style }: { label: string; value: string; valueClass?: string; style?: CSSProperties }) {
  return (
    <div className="stat" style={style}>
      <span className="k">{label}</span>
      <span className={`v ${valueClass}`}>{value}</span>
    </div>
  );
}

export const SectionTitle = ({ text, style }: { text: string; style?: CSSProperties }) => <div className="section-title" style={style}>{text}</div>;

export function ScreenHeader({ title, onBack, children }: { title: string; onBack?: () => void; children?: ReactNode }) {
  return (
    <div className="header">
      {onBack ? <IconButton icon="arrow_back" label={t('back')} onClick={onBack} /> : <span className="spacer" />}
      <h1 className="title headline-small ellipsis" style={{ margin: 0 }}>{title}</h1>
      {children}
    </div>
  );
}

export function EmptyState({ icon, title, body, actionLabel, onAction }: { icon: string; title: string; body: string; actionLabel?: string; onAction?: () => void }) {
  return (
    <div className="empty">
      <Icon name={icon} size={40} />
      <span className="title-large">{title}</span>
      <span className="body-medium muted">{body}</span>
      {actionLabel && onAction && <Btn className="mt16" onClick={onAction}>{actionLabel}</Btn>}
    </div>
  );
}

export function ListRow({ title, subtitle, selected, leading, trailing, onClick, style }: {
  title: string; subtitle?: string | null; selected?: boolean; leading?: ReactNode; trailing?: ReactNode; onClick?: () => void; style?: CSSProperties;
}) {
  const inner = (
    <>
      {leading}
      <div className="col grow">
        <span className="title-medium ellipsis">{title}</span>
        {subtitle && <span className="sub body-medium clamp2">{subtitle}</span>}
      </div>
      {trailing}
    </>
  );
  return onClick
    ? <div role="button" tabIndex={0} className={`list-row clickable ${selected ? 'selected' : ''}`} onClick={onClick} style={style}
        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onClick(); } }}>{inner}</div>
    : <div className={`list-row ${selected ? 'selected' : ''}`} style={style}>{inner}</div>;
}

export function Progress({ value, thin, done, style }: { value: number; thin?: boolean; done?: boolean; style?: CSSProperties }) {
  return (
    <div className={`progress ${thin ? 'thin' : ''} ${done ? 'done' : ''}`} style={style} role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(value * 100)}>
      <div style={{ width: `${Math.min(100, Math.max(0, value * 100))}%` }} />
    </div>
  );
}

export function StarRating({ value, onChange, size = 40 }: { value: number; onChange?: (v: number) => void; size?: number }) {
  return (
    <div className="stars" role={onChange ? 'radiogroup' : 'img'} aria-label={t('cd_rating', value)}>
      {[1, 2, 3, 4, 5].map((i) => {
        const filled = i <= value;
        const icon = <Icon name={filled ? 'star' : 'star_border'} size={onChange ? size * 0.8 : size} style={{ color: filled ? 'var(--primary)' : 'var(--outline)' }} />;
        return onChange
          ? <button key={i} type="button" aria-label={`${i}`} style={{ width: Math.max(size, 48), height: Math.max(size, 48) }} onClick={() => onChange(value === i ? i - 1 : i)}>{icon}</button>
          : <span key={i}>{icon}</span>;
      })}
    </div>
  );
}

export function LevelRow({ label, value, onChange }: { label: string; value: number; onChange?: (v: number) => void }) {
  return (
    <div className="row" style={{ minHeight: onChange ? 48 : 32 }}>
      <span className="body-medium grow">{label}</span>
      <div className="row" style={{ gap: onChange ? 0 : 6 }}>
        {[1, 2, 3, 4, 5].map((i) => onChange
          ? <button key={i} type="button" className="dot-level" aria-label={`${label} ${i}`} onClick={() => onChange(value === i ? i - 1 : i)}><span className={i <= value ? 'on' : ''} /></button>
          : <span key={i} className={`dot-small ${i <= value ? 'on' : ''}`} />)}
      </div>
    </div>
  );
}

/** Recipe steps as a timeline. The active step is lifted on a tonal surface. */
export function StepList({ steps, currentIndex, targetS, started = true, showNotes = true }: { steps: BrewStep[]; currentIndex: number; targetS: number; started?: boolean; showNotes?: boolean }) {
  const u = useUnits();
  return (
    <div className="col gap4">
      {steps.map((s, i) => {
        const active = started && i === currentIndex;
        const done = started && i < currentIndex;
        return (
          <div key={i} className={`step-row ${active ? 'active' : ''} ${done ? 'done' : ''}`}>
            <span className="clock">{formatClock(s.startS)}</span>
            <div className="col grow">
              <span className="title-medium">{s.label}</span>
              {showNotes && s.note.trim() && <span className="body-medium mt4">{s.note}</span>}
            </div>
            {s.targetWaterG != null && <span className="title-medium" style={{ paddingLeft: 8, whiteSpace: 'nowrap' }}>→ {u.w(s.targetWaterG)}</span>}
          </div>
        );
      })}
      <div className="row" style={{ padding: '8px 12px' }}>
        <span className="clock muted" style={{ width: 72, font: '700 17px/23px var(--font-display)', fontVariantNumeric: 'tabular-nums' }}>{formatClock(targetS)}</span>
        <span className="title-medium muted">{t('target')}</span>
      </div>
    </div>
  );
}

// ---- panes ---------------------------------------------------------------------------------------------
/** Two panes side by side. LEFT = KNOW, RIGHT = DO. */
export function TwoPane({ left, right, leftWeight = 0.5, rightLow = true }: { left: ReactNode; right: ReactNode; leftWeight?: number; rightLow?: boolean }) {
  return (
    <div className="two-pane">
      <div className="pane" style={{ flex: `${leftWeight} 1 0` }}>{left}</div>
      <div className={`pane ${rightLow ? 'pane-low' : ''}`} style={{ flex: `${1 - leftWeight} 1 0` }}>{right}</div>
    </div>
  );
}

/** Counter split: information first (top or left), controls second (bottom or right). */
export function FlexSplit({ first, second, row }: { first: ReactNode; second: ReactNode; row: boolean }) {
  return (
    <div className={`split ${row ? 'split-row' : 'split-col'}`}>
      <div className="half" style={{ background: 'var(--surface)' }}>{first}</div>
      <div className="half" style={{ background: 'var(--surface-container)' }}>{second}</div>
    </div>
  );
}

export const Scroll = ({ children, className, style }: { children: ReactNode; className?: string; style?: CSSProperties }) =>
  <div className={`scroll flex1 ${className ?? ''}`} style={style}>{children}</div>;

// ---- dialogs and menus ----------------------------------------------------------------------------------
export function Dialog({ title, children, actions, onDismiss, maxWidth = 420, titleCenter, bg }: {
  title?: ReactNode; children?: ReactNode; actions?: ReactNode; onDismiss: () => void; maxWidth?: number; titleCenter?: boolean; bg?: string;
}) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') onDismiss(); };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [onDismiss]);
  return createPortal(
    <div className="scrim" onClick={onDismiss}>
      <div className="dialog" role="dialog" aria-modal="true" style={{ maxWidth, background: bg }} onClick={(e) => e.stopPropagation()}>
        {title && <div className="headline-small" style={{ textAlign: titleCenter ? 'center' : undefined }}>{title}</div>}
        {children && <div className="dialog-body body-medium muted" style={{ color: 'var(--on-surface-variant)' }}>{children}</div>}
        {actions && <div className="dialog-actions">{actions}</div>}
      </div>
    </div>,
    document.body,
  );
}

export function ConfirmDialog({ title, body, confirm, onConfirm, onDismiss }: { title: string; body: string; confirm: string; onConfirm: () => void; onDismiss: () => void }) {
  return (
    <Dialog title={title} onDismiss={onDismiss} actions={<><Btn kind="text" onClick={onDismiss}>{t('cancel')}</Btn><Btn kind="text" onClick={onConfirm}>{confirm}</Btn></>}>
      {body}
    </Dialog>
  );
}

export interface MenuItem { label: string; onClick: () => void; icon?: ReactNode; color?: string }

/** Popup menu anchored to the element that opened it. */
export function Menu({ anchor, items, onDismiss, header, minWidth = 200 }: { anchor: HTMLElement | null; items: (MenuItem | 'divider')[]; onDismiss: () => void; header?: ReactNode; minWidth?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<CSSProperties>({ visibility: 'hidden' });
  useLayoutEffect(() => {
    const m = ref.current;
    if (!m || !anchor) return;
    const a = anchor.getBoundingClientRect();
    const w = m.offsetWidth;
    const h = m.offsetHeight;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    let left = a.right - w;
    if (left < 8) left = Math.min(a.left, vw - w - 8);
    let top = a.bottom + 4;
    if (top + h > vh - 8) top = Math.max(8, a.top - h - 4);
    setPos({ left: Math.max(8, left), top });
  }, [anchor]);
  return createPortal(
    <>
      <div className="menu-scrim" onClick={onDismiss} />
      <div ref={ref} className="menu" role="menu" style={{ ...pos, minWidth }}>
        {header}
        {items.map((it, i) => it === 'divider'
          ? <hr key={i} className="divider" style={{ margin: '8px 16px' }} />
          : <button key={i} type="button" role="menuitem" style={{ color: it.color }} onClick={() => { onDismiss(); it.onClick(); }}>{it.icon}{it.label}</button>)}
      </div>
    </>,
    document.body,
  );
}

export function useMenu() {
  const [anchor, setAnchor] = useState<HTMLElement | null>(null);
  return { anchor, open: (e: React.MouseEvent<HTMLElement>) => setAnchor(e.currentTarget), close: () => setAnchor(null) };
}

// ---- clocks ----------------------------------------------------------------------------------------------
/** Re-renders every [ms] while [active]. Time itself always comes from Date.now(). */
export function useNow(active: boolean, ms = 200): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    setNow(Date.now());
    if (!active) return;
    const id = setInterval(() => setNow(Date.now()), ms);
    return () => clearInterval(id);
  }, [active, ms]);
  return now;
}

/** Photos picked in this browser live in IndexedDB. Paths from the Android app point to files on the phone. */
export const isWebPhoto = (p: string | null | undefined): p is string => !!p && p.startsWith('idb:');

export function usePhoto(path: string | null | undefined): string | null {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let revoke: string | null = null;
    let alive = true;
    setUrl(null);
    if (path && path.startsWith('idb:')) {
      void getPhoto(path).then((b) => {
        if (!alive || !b) return;
        revoke = URL.createObjectURL(b);
        setUrl(revoke);
      });
    }
    return () => { alive = false; if (revoke) URL.revokeObjectURL(revoke); };
  }, [path]);
  return url;
}

export function CoffeePhoto({ path, size, ratio, alt }: { path: string | null; size?: number; ratio?: string; alt?: string }) {
  const url = usePhoto(path);
  return (
    <div className="photo" style={size ? { width: size, height: size } : { width: '100%', aspectRatio: ratio ?? '16 / 9' }}>
      {url && <img src={url} alt={alt ?? ''} />}
    </div>
  );
}
