import { useApp } from '../state/store';
import { elapsedMs, formatClock, formatTenths, hasStarted, ratio as ratioOf, StepSchedule } from '../core/coffee';
import { isEspresso, SessionRecipe, BrewStep } from '../core/models';
import type { BrewSession } from '../state/types';
import { useNow } from './components';

/** Everything a brew screen needs, derived from the session and the clock. */
export interface BrewUi {
  recipe: SessionRecipe;
  state: BrewSession;
  elapsedMs: number;
  elapsedS: number;
  pouredG: number;
  steps: BrewStep[];
  espresso: boolean;
  stepIndex: number;
  step: BrewStep | null;
  next: BrewStep | null;
  stepRemainingS: number;
  progress: number;
  targetWaterNow: number;
  ratio: number | null;
  liveRatio: number | null;
  timeText: string;
  targetText: string;
  running: boolean;
  started: boolean;
  laps: number[];
}

export function useBrewUi(): BrewUi | null {
  const session = useApp((s) => s.session);
  const recipe = session.recipe;
  const espresso = recipe ? isEspresso(recipe.method) : false;
  const now = useNow(session.timer.running, espresso ? 50 : 200);
  if (!recipe) return null;
  const quantum = espresso ? 100 : 200;
  const raw = elapsedMs(session.timer, now);
  const ms = session.timer.running ? Math.floor(raw / quantum) * quantum : raw;
  const elapsedS = ms / 1000;
  const steps = recipe.steps;
  const stepIndex = StepSchedule.indexAt(steps, elapsedS);
  const stepEndS = StepSchedule.endOf(steps, stepIndex, recipe.targetTimeS);
  const pouredG = session.pouredG;
  return {
    recipe, state: session, elapsedMs: ms, elapsedS, pouredG, steps, espresso, stepIndex,
    step: steps[stepIndex] ?? null,
    next: steps[stepIndex + 1] ?? null,
    stepRemainingS: Math.ceil(Math.max(0, stepEndS - elapsedS)),
    progress: recipe.targetTimeS > 0 ? Math.min(1, Math.max(0, elapsedS / recipe.targetTimeS)) : 0,
    targetWaterNow: StepSchedule.targetWaterAt(steps, Math.max(0, stepIndex)) ?? recipe.waterG,
    ratio: ratioOf(recipe.waterG, recipe.doseG),
    liveRatio: pouredG > 0 ? ratioOf(pouredG, recipe.doseG) : null,
    timeText: espresso ? formatTenths(ms) : formatClock(ms / 1000),
    targetText: espresso ? `${recipe.targetTimeS} s` : formatClock(recipe.targetTimeS),
    running: session.timer.running,
    started: hasStarted(session.timer),
    laps: session.timer.laps,
  };
}
