// Barista Trainer: learn, practice, brew, taste, log, analyze, improve, train again.
import { ReactNode, useEffect } from 'react';
import { formatClock, formatNumber, formatRatio, parseNumber, ratio as ratioOf } from '../../core/coffee';
import { methodFromKey, METHODS } from '../../core/models';
import { methodLabel } from '../../core/seed';
import {
  BaristaTitle, EXAM_CATEGORIES, EventKind, ExamCategory, ExtractionSim, Lesson, Progress, Recommendation, SCHOOL_CATEGORIES, SimKind, SimResult,
  Skill, SKILLS, taskKey, TreeTask, defaultFilterInput, defaultShotInput,
} from '../../core/train';
import { daysText, formatDate, t } from '../../i18n/i18n';
import { useApp } from '../../state/store';
import {
  currentTrainScreen, lessonById, lessonPageCount, lessonPageOf, lt, opportunityOf, progressOf, recommendationsOf, symptomKey, TRAIN,
} from '../../state/trainer';
import type { QuizResult, QuizRun } from '../../state/types';
import {
  BigButton, Btn, EmptyState, FlexSplit, Icon, IconButton, ListRow, NumField, Progress as Bar, Scroll, ScreenHeader, SectionTitle, Segmented,
  SliderRow, Stat, SwitchRow, TimerText, TwoPane, useNow, useUnits,
} from '../components';

// ---- labels ---------------------------------------------------------------------------------------------
export const skillLabel = (s: Skill) => t(`skill_${s.toLowerCase()}`);
const categoryLabel = (c: string) => t(`cat_${c.toLowerCase()}`);
const levelTitle = (n: number) => t(`level_${Math.min(9, Math.max(1, n))}`);
const titleLabel = (b: BaristaTitle) => t(`title_${b.toLowerCase()}`);
const examLabel = (c: ExamCategory) => t(`exam_${c.toLowerCase()}`);
const KIND_KEY: Record<EventKind, string> = {
  LESSON: 'kind_lesson', DIAL_IN: 'kind_dialin', DAILY: 'kind_daily', LEVEL_TEST: 'kind_level_test', EXAM: 'kind_exam',
  BREW_CHALLENGE: 'brew_challenge', TASTING_LOG: 'kind_tasting', STREAK_BONUS: 'kind_streak',
};
const kindLabel = (k: EventKind) => t(KIND_KEY[k]);
const taskLabel = (task: TreeTask) => (task.kind === 'DIAL_IN' ? t(task.espresso ? 'task_dialin_espresso' : 'task_dialin_filter') : t('task_exam', examLabel(task.category)));
const useLang = () => useApp((s) => s.lang);
function recTitle(rec: Recommendation, lang: string) {
  if (rec.type === 'LESSON') return lt(lessonById(rec.lessonId)?.title, lang);
  if (rec.type === 'DIAL_IN') return t(rec.espresso ? 'train_dialin_espresso' : 'train_dialin_filter');
  return `${t('train_exam')} · ${examLabel(rec.category)}`;
}
const recMinutes = (rec: Recommendation) => (rec.type === 'LESSON' ? lessonById(rec.lessonId)?.minutes ?? 4 : 5);

function useProgress(): Progress {
  const events = useApp((s) => s.data.training);
  return progressOf(events);
}

// ---- entry point for phone and tablet -----------------------------------------------------------------------
export function TrainScreen({ wide }: { wide: boolean }) {
  const screen = useApp((s) => currentTrainScreen(s));
  const progress = useProgress();
  const quiz = useApp((s) => s.quiz);
  const result = useApp((s) => s.quizResult);
  switch (screen.kind) {
    case 'HOME': return <TrainHome wide={wide} progress={progress} />;
    case 'TREE': return <SkillTreeScreen progress={progress} />;
    case 'SCHOOL': return <SchoolScreen progress={progress} />;
    case 'HISTORY': return <TrainHistoryScreen />;
    case 'LAB': return <LabScreen wide={wide} />;
    case 'EXAM_SETUP': return <ExamSetupScreen />;
    case 'LESSON': { const l = lessonById(screen.id); return l ? <LessonScreen lesson={l} progress={progress} wide={wide} /> : null; }
    case 'QUIZ': return quiz ? <QuizScreen run={quiz} wide={wide} /> : null;
    case 'RESULT': return result ? <ResultScreen r={result} wide={wide} /> : null;
  }
}

// ---- train home ----------------------------------------------------------------------------------------------
function TrainHome({ wide, progress }: { wide: boolean; progress: Progress }) {
  const pending = useApp((s) => s.settings.pendingBrewChallenge);
  const s = useApp.getState();
  const left = (
    <>
      <div className="display-small">{t('train_title')}</div>
      <div className="title-large muted">{t('train_tagline')}</div>
      <div className="mt20"><TodayCard progress={progress} /></div>
      <div className="mt12"><DailyRow progress={progress} /></div>
      {pending && <div className="mt12"><PendingChallenge lessonId={pending} /></div>}
      <ProgressBlock progress={progress} />
      <SectionTitle text={t('train_practice')} />
    </>
  );
  const entries = (
    <>
      <EntryRow title={t('train_tree')} subtitle={`${t('train_level_header', progress.currentLevel)} · ${levelTitle(progress.currentLevel)}`} onClick={() => s.openTrain({ kind: 'TREE' })} />
      <EntryRow title={t('train_school')} subtitle={t('lessons_count', progress.validated.size, TRAIN.lessons.length)} onClick={() => s.openTrain({ kind: 'SCHOOL' })} />
      <EntryRow title={t('train_dialin_filter')} subtitle={t('train_dialin_hint')} onClick={() => s.startDialIn(false)} />
      <EntryRow title={t('train_dialin_espresso')} subtitle={t('train_dialin_hint')} onClick={() => s.startDialIn(true)} />
      <EntryRow title={t('train_lab')} subtitle={t('train_lab_hint')} onClick={() => s.openTrain({ kind: 'LAB' })} />
      <EntryRow title={t('train_exam')} subtitle={t('exam_setup_short')} onClick={() => s.openTrain({ kind: 'EXAM_SETUP' })} />
      <EntryRow title={t('train_history')} onClick={() => s.openTrain({ kind: 'HISTORY' })} />
    </>
  );
  const right = <><SkillsBlock progress={progress} /><ProfileBlock progress={progress} /></>;
  if (wide) {
    return (
      <TwoPane
        left={<Scroll style={{ paddingTop: 20, paddingBottom: 20 }}><div className="pad-h28">{left}</div><div style={{ padding: '0 12px' }}>{entries}</div></Scroll>}
        right={<Scroll className="pad-h28" style={{ paddingTop: 8, paddingBottom: 24 }}>{right}</Scroll>}
      />
    );
  }
  return (
    <Scroll style={{ paddingTop: 12 }}>
      <div className="pad-h20">{left}</div>
      <div className="pad-h4">{entries}</div>
      <div className="pad-h20 pad-b24">{right}</div>
    </Scroll>
  );
}

const EntryRow = ({ title, subtitle, onClick }: { title: string; subtitle?: string; onClick: () => void }) =>
  <ListRow title={title} subtitle={subtitle} onClick={onClick} trailing={<Icon name="keyboard_arrow_right" style={{ color: 'var(--on-surface-variant)' }} />} />;

function TodayCard({ progress }: { progress: Progress }) {
  const lang = useLang();
  const brews = useApp((s) => s.data.brews);
  const s = useApp.getState();
  const rec = recommendationsOf(s, progress)[0];
  if (!rec) return null;
  const opportunity = opportunityOf(brews);
  const pattern = rec.reason === 'BREW_PATTERN' && opportunity != null;
  const reason = pattern ? t('train_opportunity_body', opportunity!.count, t(symptomKey(opportunity!.symptom)))
    : rec.reason === 'WEAK_SKILL' ? t('train_reason_weak') : rec.reason === 'NEXT_STEP' ? t('train_reason_next', progress.currentLevel) : t('train_reason_practice');
  return (
    <div className="hero">
      <span className="label-medium upper">{t(pattern ? 'train_opportunity' : 'train_today')}</span>
      <div className="headline-medium clamp3 mt6">{recTitle(rec, lang)}</div>
      <p className="body-large" style={{ margin: '4px 0 0' }}>{reason}  ·  {t('train_minutes', recMinutes(rec))}</p>
      <BigButton text={t(pattern ? 'train_this' : 'start')} icon="play_arrow" primary className="mt16" style={{ width: '100%' }} onClick={() => s.startRec(rec)} />
    </div>
  );
}

function DailyRow({ progress }: { progress: Progress }) {
  const startDaily = useApp((s) => s.startDaily);
  return (
    <div className="row gap12" style={{ background: 'var(--surface-container-high)', borderRadius: 24, padding: '14px 20px' }}>
      <div className="col grow">
        <span className="title-medium">{t('train_daily')}</span>
        <span className="body-medium muted">{t(progress.dailyDone ? 'train_daily_done' : 'train_daily_hint')}</span>
      </div>
      {progress.dailyDone ? <Icon name="check_circle" style={{ color: 'var(--primary)' }} /> : <BigButton text={t('start')} minHeight={48} onClick={startDaily} style={{ flex: '0 0 auto' }} />}
    </div>
  );
}

function PendingChallenge({ lessonId }: { lessonId: string }) {
  const lang = useLang();
  const s = useApp.getState();
  const lesson = lessonById(lessonId);
  return (
    <div className="tertiary-box">
      <span className="label-medium upper">{t('brew_challenge_pending')}</span>
      <p className="body-large" style={{ margin: '4px 0 0' }}>{lesson?.brewTask ? lt(lesson.brewTask, lang) : t('brew_challenge_pending_body')}</p>
      <div className="row gap10 mt12">
        <BigButton text={t('brew')} primary minHeight={48} onClick={() => s.selectTab('BREW')} style={{ flex: '1 1 0' }} />
        <BigButton text={t('cancel')} minHeight={48} onClick={s.cancelBrewChallenge} style={{ flex: '1 1 0' }} />
      </div>
    </div>
  );
}

function ProgressBlock({ progress }: { progress: Progress }) {
  return (
    <>
      <SectionTitle text={t('train_progress')} />
      <div className="row-bottom">
        <div className="col grow">
          <span className="label-medium upper muted">{t('train_level_n', progress.currentLevel)}</span>
          <span className="headline-small">{titleLabel(progress.title)}</span>
        </div>
        <span className="headline-medium">{progress.percent}%</span>
      </div>
      <Bar value={progress.percent / 100} style={{ marginTop: 8 }} />
      <p className="body-medium muted" style={{ margin: '8px 0 0' }}>{t('train_xp', progress.xp)}  ·  {t('profile_streak')} {daysText(progress.streak)}</p>
    </>
  );
}

function SkillsBlock({ progress }: { progress: Progress }) {
  return (
    <>
      <SectionTitle text={t('train_skills')} />
      {progress.scores.map((sc) => (
        <div key={sc.skill} className="row" style={{ minHeight: 40 }}>
          <span className="body-large ellipsis" style={{ width: 132, flex: '0 0 132px' }}>{skillLabel(sc.skill)}</span>
          <Bar value={(sc.percent ?? 0) / 100} thin style={{ flex: '1 1 auto' }} />
          <span className="title-medium" style={{ width: 68, flex: '0 0 68px', paddingLeft: 12, whiteSpace: 'nowrap' }}>{sc.percent != null ? `${sc.percent}%` : '–'}</span>
        </div>
      ))}
      <p className="body-medium muted" style={{ margin: '4px 0 0' }}>{t('train_scores_hint')}</p>
    </>
  );
}

/** Built from what the user actually did: training results and logged brews. */
function ProfileBlock({ progress }: { progress: Progress }) {
  const brews = useApp((s) => s.data.brews);
  const coffees = useApp((s) => s.data.coffees);
  const counts = new Map<string, number>();
  brews.forEach((b) => counts.set(b.method, (counts.get(b.method) ?? 0) + 1));
  const methods = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 2).map(([m]) => methodLabel(methodFromKey(m)));
  const groups = new Map<string, number[]>();
  brews.filter((b) => b.rating > 0 && b.coffeeName.trim()).forEach((b) => {
    const key = coffees.find((c) => c.id === b.coffeeId || c.name === b.coffeeName)?.country.trim() || b.coffeeName;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(b.rating);
  });
  const favorites = [...groups.entries()].map(([k, v]) => [k, v.reduce((a, x) => a + x, 0) / v.length] as const).sort((a, b) => b[1] - a[1]).slice(0, 2).map(([k]) => k);
  const scored = progress.scores.filter((x) => x.percent != null);
  const strongest = scored.reduce<typeof scored[number] | null>((m, x) => (!m || x.percent! > m.percent! ? x : m), null);
  const weakest = scored.reduce<typeof scored[number] | null>((m, x) => (!m || x.percent! < m.percent! ? x : m), null);
  if (!strongest && methods.length === 0 && progress.streak === 0) return null;
  return (
    <>
      <SectionTitle text={t('train_profile')} />
      <div className="stats" style={{ rowGap: 14 }}>
        {strongest && <Stat label={t('profile_strongest')} value={skillLabel(strongest.skill)} />}
        {weakest && weakest.skill !== strongest?.skill && <Stat label={t('profile_weakest')} value={skillLabel(weakest.skill)} />}
        {methods.length > 0 && <Stat label={t('profile_methods')} value={methods.join(' · ')} />}
        {favorites.length > 0 && <Stat label={t('profile_coffees')} value={favorites.join(' · ')} />}
        <Stat label={t('profile_streak')} value={daysText(progress.streak)} />
      </div>
    </>
  );
}

// ---- skill tree, school, exam setup, history ------------------------------------------------------------------
function LessonRow({ lesson, validated, unlocked, lockedLevel }: { lesson: Lesson; validated: boolean; unlocked: boolean; lockedLevel: number }) {
  const lang = useLang();
  const s = useApp.getState();
  return (
    <ListRow title={lt(lesson.title, lang)} subtitle={`${t('lesson_meta', lesson.minutes, lesson.level)} · ${skillLabel(lesson.skill)}`}
      trailing={validated ? <Icon name="check_circle" style={{ color: 'var(--primary)' }} /> : !unlocked ? <Icon name="lock" style={{ color: 'var(--outline)' }} /> : <Icon name="keyboard_arrow_right" style={{ color: 'var(--on-surface-variant)' }} />}
      onClick={() => (unlocked || validated ? s.openLesson(lesson.id) : s.say('train_locked_msg', String(lockedLevel - 1)))} />
  );
}

function SkillTreeScreen({ progress }: { progress: Progress }) {
  const s = useApp.getState();
  return (
    <div className="page">
      <ScreenHeader title={t('train_tree')} onBack={s.back} />
      <Scroll className="pad-b32">
        {progress.levels.map((st) => {
          const n = st.level.number;
          return (
            <div key={n}>
              <div className="row pad-h20" style={{ paddingTop: 20 }}>
                <div className="col grow">
                  <span className="label-medium upper primary-text">{t('train_level_header', n)}</span>
                  <span className="headline-small" style={{ color: st.unlocked ? undefined : 'var(--on-surface-variant)' }}>{levelTitle(n)}</span>
                </div>
                <span className="label-large" style={{ color: st.complete ? 'var(--primary)' : 'var(--on-surface-variant)' }}>
                  {st.complete ? t('train_complete') : !st.unlocked ? t('train_locked') : t('train_in_progress', st.done, st.total)}
                </span>
              </div>
              <div className="pad-h4">
                {st.lessons.map((id) => { const l = lessonById(id); return l ? <LessonRow key={id} lesson={l} validated={progress.validated.has(id)} unlocked={st.unlocked} lockedLevel={n} /> : null; })}
                {st.level.tasks.map((task) => {
                  const done = st.tasksDone.has(taskKey(task));
                  return (
                    <ListRow key={taskKey(task)} title={taskLabel(task)} subtitle={t(task.kind === 'EXAM' ? 'exam_setup_short' : 'train_dialin_hint')}
                      trailing={done ? <Icon name="check_circle" style={{ color: 'var(--primary)' }} /> : !st.unlocked ? <Icon name="lock" style={{ color: 'var(--outline)' }} /> : <Icon name="play_arrow" style={{ color: 'var(--on-surface-variant)' }} />}
                      onClick={() => (!st.unlocked ? s.say('train_locked_msg', String(n - 1)) : task.kind === 'DIAL_IN' ? s.startDialIn(task.espresso) : s.startExam(task.category))} />
                  );
                })}
              </div>
              {st.unlocked && st.lessons.some((id) => !progress.validated.has(id)) && (
                <div className="pad-h20" style={{ paddingTop: 4, paddingBottom: 4 }}><Btn kind="outlined" onClick={() => s.startLevelTest(n)}>{t('train_test_out')}</Btn></div>
              )}
            </div>
          );
        })}
      </Scroll>
    </div>
  );
}

function SchoolScreen({ progress }: { progress: Progress }) {
  const back = useApp((s) => s.back);
  return (
    <div className="page">
      <ScreenHeader title={t('train_school')} onBack={back} />
      <Scroll className="pad-b32">
        {SCHOOL_CATEGORIES.map((c) => {
          const lessons = TRAIN.lessons.filter((l) => l.category === c);
          if (!lessons.length) return null;
          return (
            <div key={c}>
              <SectionTitle text={categoryLabel(c)} style={{ paddingLeft: 20, paddingRight: 20 }} />
              <div className="pad-h4">
                {lessons.map((l) => <LessonRow key={l.id} lesson={l} validated={progress.validated.has(l.id)} unlocked={progress.levels.find((x) => x.level.number === l.level)?.unlocked ?? true} lockedLevel={l.level} />)}
              </div>
            </div>
          );
        })}
      </Scroll>
    </div>
  );
}

function ExamSetupScreen() {
  const s = useApp.getState();
  return (
    <div className="page">
      <ScreenHeader title={t('train_exam')} onBack={s.back} />
      <Scroll className="pad-b32">
        <p className="body-large muted pad-h20" style={{ margin: '8px 0' }}>{t('exam_setup_hint')}</p>
        <div className="pad-h4">
          {EXAM_CATEGORIES.map((c) => <ListRow key={c} title={examLabel(c)} trailing={<Icon name="play_arrow" style={{ color: 'var(--on-surface-variant)' }} />} onClick={() => s.startExam(c)} />)}
        </div>
      </Scroll>
    </div>
  );
}

function TrainHistoryScreen() {
  const events = useApp((s) => s.data.training);
  const back = useApp((s) => s.back);
  const lang = useLang();
  return (
    <div className="page">
      <ScreenHeader title={t('train_history')} onBack={back} />
      {events.length === 0 ? <EmptyState icon="school" title={t('train_history_empty_title')} body={t('train_history_empty_body')} /> : (
        <Scroll className="pad-h4 pad-b32">
          {events.slice(0, 200).map((e) => {
            const kind = (Object.keys(KIND_KEY).includes(e.kind) ? e.kind : 'LESSON') as EventKind;
            const exercise = kind === 'LESSON' || kind === 'BREW_CHALLENGE' ? (lt(lessonById(e.refId)?.title, lang) || e.refId)
              : kind === 'DIAL_IN' ? t(e.refId === 'espresso' ? 'train_dialin_espresso' : 'train_dialin_filter')
                : kind === 'EXAM' ? ((EXAM_CATEGORIES as readonly string[]).includes(e.refId) ? examLabel(e.refId as ExamCategory) : e.refId)
                  : kind === 'LEVEL_TEST' ? t('train_level_test', Number(e.refId.split(':')[1]) || 0) : kindLabel(kind);
            const skill = (SKILLS as readonly string[]).includes(e.skill) ? skillLabel(e.skill as Skill) : null;
            const parts = [kindLabel(kind) !== exercise ? kindLabel(kind) : null, skill, e.total > 0 ? `${e.correct}/${e.total}` : null,
              e.durationS > 0 ? formatClock(e.durationS) : null, e.total === 0 ? null : e.passed ? t('result_passed') : t('result_failed')].filter(Boolean);
            return (
              <ListRow key={e.id} title={exercise} subtitle={`${parts.join(' · ')}\n${formatDate(e.createdAt)}`}
                trailing={e.xp > 0 ? <span className="label-large primary-text">{t('result_xp', e.xp)}</span> : undefined} />
            );
          })}
        </Scroll>
      )}
    </div>
  );
}

// ---- simulations ----------------------------------------------------------------------------------------------
function ExtractionBar({ pct, min = 10, max = 28 }: { pct: number; min?: number; max?: number }) {
  const x = (v: number) => Math.min(1, Math.max(0, (v - min) / (max - min))) * 100;
  return (
    <div className="col" aria-label={`${t('sim_extraction')} ${formatNumber(pct)}%`}>
      <div style={{ position: 'relative', height: 28 }}>
        <div style={{ position: 'absolute', left: 0, right: 0, top: 7, height: 14, borderRadius: 7, overflow: 'hidden', display: 'flex' }}>
          <div style={{ width: `${x(18)}%`, background: 'var(--secondary-container)' }} />
          <div style={{ width: `${x(22) - x(18)}%`, background: 'var(--primary)' }} />
          <div style={{ flex: 1, background: 'var(--tertiary-container)' }} />
        </div>
        <div style={{ position: 'absolute', top: 0, width: 28, height: 28, borderRadius: 14, background: 'var(--on-surface)', left: `calc(${x(pct)}% - 14px)`, transition: 'left .2s' }} />
      </div>
      <div className="row mt4">
        <span className="label-small muted" style={{ flex: '8 1 0' }}>{t('sim_under')}</span>
        <span className="label-small muted" style={{ flex: '4 1 0' }}>{t('sim_balanced')}</span>
        <span className="label-small muted" style={{ flex: '6 1 0' }}>{t('sim_over')}</span>
      </div>
    </div>
  );
}

function SimVerdict({ r, espresso }: { r: SimResult; espresso: boolean }) {
  const cls = 'headline-small';
  const strength = t(r.strength === 'WEAK' ? 'sim_strength_weak' : r.strength === 'BALANCED' ? 'sim_balanced' : 'sim_strength_strong');
  const verdict = r.uneven && espresso ? 'sim_uneven_shot' : r.uneven ? 'sim_uneven_filter' : r.zone === 'UNDER' ? 'sim_zone_under' : r.zone === 'OVER' ? 'sim_zone_over' : 'sim_zone_balanced';
  return (
    <>
      <div className="stats" style={{ rowGap: 10 }}>
        <Stat label={t('sim_time')} value={espresso ? `${r.timeS} s` : formatClock(r.timeS)} valueClass={cls} />
        <Stat label={t('sim_extraction')} value={`${formatNumber(r.extractionPct)}%`} valueClass={cls} />
        <Stat label={t('sim_strength')} value={`${formatNumber(r.tdsPct, 2)}% · ${strength}`} valueClass={cls} />
      </div>
      <div className="mt12"><ExtractionBar pct={r.extractionPct} /></div>
      <div className="title-large mt8">{t(verdict)}</div>
    </>
  );
}

function SimReadout({ kind, hint }: { kind: SimKind; hint?: string | null }) {
  const u = useUnits();
  const filterSim = useApp((s) => s.filterSim);
  const shotSim = useApp((s) => s.shotSim);
  const yieldCalc = useApp((s) => s.yieldCalc);
  const milkTemp = useApp((s) => s.milkTemp);
  let body: ReactNode = null;
  if (kind === 'FILTER') body = <SimVerdict r={ExtractionSim.filter(filterSim)} espresso={false} />;
  else if (kind === 'ESPRESSO') body = <SimVerdict r={ExtractionSim.shot(shotSim)} espresso />;
  else if (kind === 'YIELD_CALC') {
    const ey = ExtractionSim.extractionYield(parseNumber(yieldCalc[0]) ?? 0, parseNumber(yieldCalc[1]) ?? 0, parseNumber(yieldCalc[2]) ?? 0);
    body = <><span className="label-medium upper primary-text">{t('sim_ey')}</span><div><TimerText text={ey != null ? `${formatNumber(ey)}%` : '–'} size={56} /></div>{ey != null && <div className="mt8"><ExtractionBar pct={ey} /></div>}</>;
  } else if (kind === 'MILK') {
    const phase = ExtractionSim.milkPhase(milkTemp);
    body = <><span className="label-medium upper primary-text">{t('sim_milk_temp')}</span><div><TimerText text={u.t(milkTemp)} size={56} /></div>
      <div className="title-large mt8">{t(phase === 'STRETCH' ? 'milk_stretch' : phase === 'ROLL' ? 'milk_roll' : phase === 'READY' ? 'milk_ready' : 'milk_hot')}</div></>;
  }
  return (
    <div className="col">
      {body}
      {hint && <p className="body-large muted" style={{ margin: '10px 0 0' }}>{hint}</p>}
      {(kind === 'FILTER' || kind === 'ESPRESSO') && <p className="body-small muted" style={{ margin: '6px 0 0' }}>{t('sim_disclaimer')}</p>}
    </div>
  );
}

function SimControls({ kind }: { kind: SimKind }) {
  const u = useUnits();
  const f = useApp((s) => s.filterSim);
  const sh = useApp((s) => s.shotSim);
  const yc = useApp((s) => s.yieldCalc);
  const milk = useApp((s) => s.milkTemp);
  const set = useApp((s) => s.set);
  if (kind === 'FILTER') {
    return (
      <div className="col gap6">
        <SliderRow label={t('sim_grind')} valueText={String(f.grind)} value={f.grind} min={0} max={100} step={5} startLabel={t('sim_coarse')} endLabel={t('sim_fine')} onChange={(v) => set({ filterSim: { ...f, grind: Math.round(v) } })} />
        <SliderRow label={t('dose')} valueText={u.w(f.doseG)} value={f.doseG} min={10} max={30} step={1} onChange={(v) => set({ filterSim: { ...f, doseG: Math.round(v) } })} />
        <SliderRow label={t('water')} valueText={`${u.w(f.waterG)} · ${formatRatio(ratioOf(f.waterG, f.doseG))}`} value={f.waterG} min={150} max={500} step={10} onChange={(v) => set({ filterSim: { ...f, waterG: Math.round(v / 10) * 10 } })} />
        <SliderRow label={t('temperature')} valueText={u.t(f.tempC)} value={f.tempC} min={85} max={100} step={1} onChange={(v) => set({ filterSim: { ...f, tempC: Math.round(v) } })} />
        <span className="body-large">{t('sim_agitation')}</span>
        <Segmented<number> value={f.agitation} options={[[0, t('sim_low')], [1, t('sim_mid')], [2, t('sim_high')]]} onChange={(v) => set({ filterSim: { ...f, agitation: v } })} />
        <div className="mt8"><Btn kind="outlined" onClick={() => set({ filterSim: defaultFilterInput() })}>{t('reset')}</Btn></div>
      </div>
    );
  }
  if (kind === 'ESPRESSO') {
    return (
      <div className="col gap6">
        <SliderRow label={t('sim_grind')} valueText={String(sh.grind)} value={sh.grind} min={0} max={100} step={5} startLabel={t('sim_coarse')} endLabel={t('sim_fine')} onChange={(v) => set({ shotSim: { ...sh, grind: Math.round(v) } })} />
        <SliderRow label={t('dose')} valueText={u.w(sh.doseG)} value={sh.doseG} min={14} max={22} step={0.5} onChange={(v) => set({ shotSim: { ...sh, doseG: Math.round(v * 2) / 2 } })} />
        <SliderRow label={t('yield_label')} valueText={`${u.w(sh.yieldG)} · ${formatRatio(ratioOf(sh.yieldG, sh.doseG))}`} value={sh.yieldG} min={18} max={60} step={1} onChange={(v) => set({ shotSim: { ...sh, yieldG: Math.round(v) } })} />
        <SliderRow label={t('temperature')} valueText={u.t(sh.tempC)} value={sh.tempC} min={88} max={96} step={1} onChange={(v) => set({ shotSim: { ...sh, tempC: Math.round(v) } })} />
        <SwitchRow title={t('sim_channeling')} checked={sh.channeling} onChange={(v) => set({ shotSim: { ...sh, channeling: v } })} />
        <div><Btn kind="outlined" onClick={() => set({ shotSim: defaultShotInput() })}>{t('reset')}</Btn></div>
      </div>
    );
  }
  if (kind === 'YIELD_CALC') {
    return (
      <div className="col gap12">
        <div className="row gap12">
          <NumField className="grow" value={yc[0]} onChange={(v) => set({ yieldCalc: [v, yc[1], yc[2]] })} label={t('dose')} suffix="g" />
          <NumField className="grow" value={yc[1]} onChange={(v) => set({ yieldCalc: [yc[0], v, yc[2]] })} label={t('sim_beverage')} suffix="g" />
        </div>
        <NumField value={yc[2]} onChange={(v) => set({ yieldCalc: [yc[0], yc[1], v] })} label={t('sim_tds')} suffix="%" />
      </div>
    );
  }
  if (kind === 'MILK') return <SliderRow label={t('sim_milk_temp')} valueText={u.t(milk)} value={milk} min={5} max={80} step={1} onChange={(v) => set({ milkTemp: Math.round(v) })} />;
  return null;
}

function LabModeToggle() {
  const labEspresso = useApp((s) => s.labEspresso);
  const set = useApp((s) => s.set);
  return <Segmented<boolean> value={labEspresso} options={[[false, t('filter')], [true, METHODS.ESPRESSO.label]]} onChange={(v) => set({ labEspresso: v })} />;
}

function LabScreen({ wide }: { wide: boolean }) {
  const labEspresso = useApp((s) => s.labEspresso);
  const back = useApp((s) => s.back);
  const kind: SimKind = labEspresso ? 'ESPRESSO' : 'FILTER';
  return (
    <div className="page">
      <ScreenHeader title={t('train_lab')} onBack={back} />
      {wide ? (
        <TwoPane left={<Scroll className="pad-h28 pad-b24"><SimReadout kind={kind} hint={t('train_lab_hint')} /></Scroll>}
          right={<Scroll className="col gap12 pad-h28" style={{ paddingTop: 16, paddingBottom: 16 }}><LabModeToggle /><SimControls kind={kind} /></Scroll>} />
      ) : (
        <Scroll className="col gap16 pad-h20 pad-b32"><LabModeToggle /><SimReadout kind={kind} /><SimControls kind={kind} /></Scroll>
      )}
    </div>
  );
}

// ---- lesson ------------------------------------------------------------------------------------------------------
function LessonMeta({ lesson, validated }: { lesson: Lesson; validated: boolean }) {
  return <span className="body-large muted">{t('lesson_meta', lesson.minutes, lesson.level)} · {skillLabel(lesson.skill)}{validated ? ` · ${t('lesson_validated')}` : ''}</span>;
}

function LessonObjectives({ lesson }: { lesson: Lesson }) {
  const lang = useLang();
  return (
    <>
      <SectionTitle text={t('lesson_objectives')} />
      {(lesson.objectives ?? []).map((o, i) => (
        <div key={i} className="row-top" style={{ padding: '3px 0' }}>
          <span className="body-large primary-text">•&nbsp;&nbsp;</span>
          <span className="body-large">{lt(o, lang)}</span>
        </div>
      ))}
    </>
  );
}

function LessonBlock({ lesson, index, large }: { lesson: Lesson; index: number; large?: boolean }) {
  const lang = useLang();
  const b = lesson.blocks![index];
  return (
    <>
      <div className={large ? 'headline-medium' : 'title-large'}>{lt(b.title, lang)}</div>
      <p style={{ margin: `${large ? 10 : 4}px 0 0`, font: large ? '400 21px/30px var(--font-body)' : '400 16px/24px var(--font-body)' }}>{lt(b.body, lang)}</p>
    </>
  );
}

function LessonTheory({ lesson, validated }: { lesson: Lesson; validated: boolean }) {
  return (
    <>
      <LessonMeta lesson={lesson} validated={validated} />
      <LessonObjectives lesson={lesson} />
      <SectionTitle text={t('lesson_theory')} />
      {(lesson.blocks ?? []).map((_, i) => <div key={i} style={{ marginBottom: 16 }}><LessonBlock lesson={lesson} index={i} /></div>)}
    </>
  );
}

function ValidationCard({ lesson }: { lesson: Lesson }) {
  const start = useApp((s) => s.startLessonQuiz);
  return (
    <div className="tonal-box">
      <span className="label-medium upper primary-text">{t('lesson_validate')}</span>
      <p className="body-large" style={{ margin: '4px 0 0' }}>{t('lesson_validation_hint', (lesson.questions ?? []).length)}</p>
      <BigButton text={t('lesson_start_validation')} icon="play_arrow" primary className="mt16" style={{ width: '100%' }} onClick={() => start(lesson.id)} />
    </div>
  );
}

function LessonScreen({ lesson, progress, wide }: { lesson: Lesson; progress: Progress; wide: boolean }) {
  const lang = useLang();
  const run = useApp((s) => s.lessonRun);
  const back = useApp((s) => s.back);
  const validated = progress.validated.has(lesson.id);
  const sim = lesson.sim && lesson.sim !== 'NONE' ? lesson.sim : null;
  if (wide) {
    return (
      <div className="page">
        <ScreenHeader title={lt(lesson.title, lang)} onBack={back} />
        <TwoPane
          left={<Scroll className="pad-h28 pad-b24"><LessonTheory lesson={lesson} validated={validated} /></Scroll>}
          right={
            <Scroll className="col gap16 pad-h28" style={{ paddingTop: 16, paddingBottom: 16 }}>
              {sim && <><span className="label-medium upper primary-text">{t('lesson_practice')}</span><SimReadout kind={sim} hint={lt(lesson.simHint, lang) || null} /><SimControls kind={sim} /></>}
              <ValidationCard lesson={lesson} />
            </Scroll>
          }
        />
      </div>
    );
  }
  const page = run?.page ?? 0;
  const count = lessonPageCount(lesson);
  const p = lessonPageOf(lesson, page);
  return (
    <div className="page">
      <ScreenHeader title={lt(lesson.title, lang)} onBack={back} />
      <Scroll className="pad-h20">
        {p.kind === 'THEORY' && (
          <>
            {p.index === 0 && <><LessonMeta lesson={lesson} validated={validated} /><LessonObjectives lesson={lesson} /><div className="mt20" /></>}
            <LessonBlock lesson={lesson} index={p.index} large />
          </>
        )}
        {p.kind === 'SIM' && sim && (
          <>
            <span className="label-medium upper primary-text">{t('lesson_practice')}</span>
            <div className="mt8"><SimReadout kind={sim} hint={lt(lesson.simHint, lang) || null} /></div>
            <div className="mt12"><SimControls kind={sim} /></div>
          </>
        )}
        {p.kind === 'VALIDATE' && <ValidationCard lesson={lesson} />}
        <div className="mt16" />
      </Scroll>
      <div style={{ padding: '12px 20px' }}><LessonPager page={page} count={count} /></div>
    </div>
  );
}

function LessonPager({ page, count, large }: { page: number; count: number; large?: boolean }) {
  const lessonPage = useApp((s) => s.lessonPage);
  return (
    <div className="row gap10" style={{ height: large ? '100%' : undefined, alignItems: 'stretch' }}>
      <BigButton text={t('back')} minHeight={56} large={large} disabled={page <= 0} onClick={() => lessonPage(-1)} style={{ flex: '1 1 0' }} />
      <span className="label-large muted" style={{ alignSelf: 'center' }}>{t('lesson_page', page + 1, count)}</span>
      <BigButton text={t('next')} primary minHeight={56} large={large} disabled={page >= count - 1} onClick={() => lessonPage(1)} style={{ flex: '1 1 0' }} />
    </div>
  );
}

// ---- quiz --------------------------------------------------------------------------------------------------------
function useRemaining(run: QuizRun | null): number | null {
  const now = useNow(!!run && run.timeLimitS != null, 500);
  if (!run || run.timeLimitS == null) return null;
  return Math.max(0, Math.floor(run.timeLimitS - (now - run.startedAtMs) / 1000));
}

function QuestionPane({ run, large }: { run: QuizRun; large?: boolean }) {
  const item = run.items[run.index];
  return (
    <>
      <span className="label-medium upper primary-text">{t('quiz_question_n', run.index + 1, run.items.length)}</span>
      {item.facts.length > 0 && (
        <div className="tonal-box mt8" style={{ padding: 18 }}>
          <div className="stats" style={{ columnGap: 24, rowGap: 10 }}>{item.facts.map(([k, v], i) => <Stat key={i} label={k} value={v} />)}</div>
        </div>
      )}
      <div className={`${large ? 'headline-medium' : 'headline-small'} mt12`}>{item.prompt}</div>
    </>
  );
}

function Feedback({ run }: { run: QuizRun }) {
  const selected = run.answers[run.index];
  if (selected == null || run.timeLimitS != null) return null;
  const item = run.items[run.index];
  const right = selected === item.correct;
  return (
    <div className={right ? 'primary-box' : 'error-box'} style={{ padding: 18 }}>
      <div className="title-large">{t(right ? 'quiz_correct' : 'quiz_incorrect')}</div>
      {!right && <div className="title-medium mt4">{t('quiz_answer_was', item.options[item.correct])}</div>}
      <p className="body-large" style={{ margin: '6px 0 0' }}>{item.why}</p>
    </div>
  );
}

function OptionButton({ run, index, large, style }: { run: QuizRun; index: number; large?: boolean; style?: React.CSSProperties }) {
  const answer = useApp((s) => s.answer);
  const item = run.items[run.index];
  const selected = run.answers[run.index];
  const revealed = run.timeLimitS == null && selected != null;
  const isCorrect = index === item.correct;
  const isChosen = index === selected;
  const cls = revealed && isCorrect ? 'right' : revealed && isChosen ? 'wrong' : !revealed && isChosen ? 'chosen' : revealed ? 'dim' : '';
  return (
    <button type="button" role="radio" aria-checked={isChosen} className={`option ${large ? 'large' : ''} ${cls}`} disabled={revealed} onClick={() => answer(index)} style={style}>
      <span className="grow clamp3" style={{ textAlign: 'left' }}>{item.options[index]}</span>
      {revealed && isCorrect && <Icon name="check_circle" />}
      {revealed && isChosen && !isCorrect && <Icon name="cancel" />}
    </button>
  );
}

function QuizNav({ run, large }: { run: QuizRun; large?: boolean }) {
  const { nextQuestion, previousQuestion } = useApp.getState();
  const isLast = run.index === run.items.length - 1;
  return (
    <div className="row gap10" style={{ alignItems: 'stretch' }}>
      {run.timeLimitS != null && run.index > 0 && <BigButton text={t('back')} minHeight={56} large={large} onClick={previousQuestion} style={{ flex: '1 1 0' }} />}
      <BigButton text={t(isLast ? 'quiz_finish' : 'next')} primary minHeight={56} large={large} disabled={run.timeLimitS == null && run.answers[run.index] == null}
        onClick={nextQuestion} style={{ flex: '2 1 0' }} />
    </div>
  );
}

function QuizHeader({ run, remaining }: { run: QuizRun; remaining: number | null }) {
  const back = useApp((s) => s.back);
  return (
    <ScreenHeader title={run.title} onBack={back}>
      {remaining != null && <TimerText text={formatClock(remaining)} size={22} color={remaining <= 30 ? 'var(--error)' : undefined} style={{ marginRight: 16 }} />}
    </ScreenHeader>
  );
}

function QuizScreen({ run, wide }: { run: QuizRun; wide: boolean }) {
  const remaining = useRemaining(run);
  const finishQuiz = useApp((s) => s.finishQuiz);
  useEffect(() => { if (remaining === 0) finishQuiz(); }, [remaining, finishQuiz]);
  const lesson = run.lessonId ? lessonById(run.lessonId) : undefined;
  const item = run.items[run.index];
  const answers = <>{item.options.map((_, i) => <OptionButton key={`${run.index}-${i}`} run={run} index={i} />)}<Feedback run={run} /><QuizNav run={run} /></>;
  return (
    <div className="page">
      <QuizHeader run={run} remaining={remaining} />
      {wide ? (
        <TwoPane
          left={<Scroll className="pad-h28 pad-b24">{lesson ? <LessonTheory lesson={lesson} validated={false} /> : <QuestionPane run={run} large />}</Scroll>}
          right={<Scroll className="col gap10 pad-h28" style={{ paddingTop: 16, paddingBottom: 16 }}>{lesson && <><QuestionPane run={run} /><div style={{ height: 6 }} /></>}{answers}</Scroll>}
        />
      ) : (
        <Scroll className="col gap10 pad-h20 pad-b24"><QuestionPane run={run} /><div style={{ height: 6 }} />{answers}</Scroll>
      )}
    </div>
  );
}

// ---- result --------------------------------------------------------------------------------------------------------
function ResultSummary({ r }: { r: QuizResult }) {
  const lang = useLang();
  const s = useApp.getState();
  const task = r.run.lessonId ? lessonById(r.run.lessonId)?.brewTask : null;
  return (
    <>
      <span className="label-large upper" style={{ color: r.passed ? 'var(--primary)' : 'var(--error)' }}>{t(r.passed ? 'result_passed' : 'result_failed')}</span>
      <div><TimerText text={t('result_score', r.correct, r.total)} size={72} /></div>
      <span className="title-medium muted">
        {[r.xp > 0 ? t('result_xp', r.xp) : null, formatClock(r.durationS), r.lessonValidated ? t('result_lesson_validated') : null, r.streakBonus ? t('result_streak_bonus') : null].filter(Boolean).join('  ·  ')}
      </span>
      {r.lessonValidated && task && (
        <div className="tertiary-box mt16">
          <span className="label-medium upper">{t('brew_challenge')}</span>
          <p className="body-large" style={{ margin: '4px 0 0' }}>{lt(task, lang)}</p>
          <BigButton text={t('brew_challenge_accept')} primary minHeight={56} className="mt12" style={{ width: '100%' }} onClick={() => s.acceptBrewChallenge(r.run.lessonId!)} />
        </div>
      )}
      <div className="row gap10 mt16">
        {!r.passed && r.run.kind !== 'DAILY' && (
          <BigButton text={t('result_retry')} minHeight={56} style={{ flex: '1 1 0' }} onClick={() => {
            const run = r.run;
            s.closeResult();
            if (run.kind === 'LESSON') s.openLesson(run.refId);
            else if (run.kind === 'DIAL_IN') s.startDialIn(run.refId === 'espresso');
            else if (run.kind === 'EXAM') { if ((EXAM_CATEGORIES as readonly string[]).includes(run.refId)) s.startExam(run.refId as ExamCategory); }
            else if (run.kind === 'LEVEL_TEST') { const n = Number(run.refId.split(':')[1]); if (n) s.startLevelTest(n); }
          }} />
        )}
        <BigButton text={t('result_done')} primary={r.passed} minHeight={56} onClick={s.closeResult} style={{ flex: '1 1 0' }} />
      </div>
    </>
  );
}

function ResultDetails({ r }: { r: QuizResult }) {
  const lang = useLang();
  const s = useApp.getState();
  const wrong = r.run.items.map((_, i) => i).filter((i) => r.run.answers[i] !== r.run.items[i].correct);
  return (
    <>
      {r.weak.length > 0 && <><SectionTitle text={t('result_weak')} /><div className="title-large">{r.weak.map(skillLabel).join(' · ')}</div></>}
      {r.recommendations.length > 0 && (
        <>
          <SectionTitle text={t('result_recommended')} />
          {r.recommendations.map((rec, i) => (
            <ListRow key={i} title={recTitle(rec, lang)} subtitle={t('train_minutes', recMinutes(rec))} trailing={<Icon name="play_arrow" style={{ color: 'var(--on-surface-variant)' }} />}
              onClick={() => { s.closeResult(); s.startRec(rec); }} />
          ))}
        </>
      )}
      {wrong.length > 0 && (
        <>
          <SectionTitle text={t('result_corrections')} />
          {wrong.map((i) => {
            const item = r.run.items[i];
            const a = r.run.answers[i];
            return (
              <div key={i}>
                <div className="col" style={{ padding: '10px 0' }}>
                  {item.facts.length > 0 && <span className="body-medium muted">{item.facts.map((f) => f[1]).join(' · ')}</span>}
                  <span className="title-medium">{item.prompt}</span>
                  <span className="body-medium error-text mt4">{t('result_your_answer', a != null ? item.options[a] : t('result_no_answer'))}</span>
                  <span className="body-medium primary-text">{t('quiz_answer_was', item.options[item.correct])}</span>
                  <p className="body-large" style={{ margin: '4px 0 0' }}>{item.why}</p>
                </div>
                <hr className="divider" />
              </div>
            );
          })}
        </>
      )}
    </>
  );
}

function ResultScreen({ r, wide }: { r: QuizResult; wide: boolean }) {
  const back = useApp((s) => s.back);
  return (
    <div className="page">
      <ScreenHeader title={r.run.title} onBack={back} />
      {wide
        ? <TwoPane left={<Scroll className="pad-h28 pad-b24"><ResultSummary r={r} /></Scroll>} right={<Scroll className="pad-h28 pad-b24"><ResultDetails r={r} /></Scroll>} />
        : <Scroll className="pad-h20 pad-b32"><ResultSummary r={r} /><ResultDetails r={r} /></Scroll>}
    </div>
  );
}

// ---- counter / Flex: training desk ----------------------------------------------------------------------------------
export function TrainDesk({ row }: { row: boolean }) {
  const lang = useLang();
  const screen = useApp((s) => currentTrainScreen(s));
  const run = useApp((s) => s.quiz);
  const lessonRun = useApp((s) => s.lessonRun);
  const labEspresso = useApp((s) => s.labEspresso);
  const s = useApp.getState();
  const lesson = screen.kind === 'LESSON' ? lessonById(screen.id) : undefined;
  const quizRun = screen.kind === 'QUIZ' ? run : null;
  const remaining = useRemaining(quizRun);
  useEffect(() => { if (remaining === 0) useApp.getState().finishQuiz(); }, [remaining]);
  const labKind: SimKind = labEspresso ? 'ESPRESSO' : 'FILTER';
  const title = quizRun ? quizRun.title : lesson ? lt(lesson.title, lang) : t('train_lab');
  const pad = row ? 'calc(var(--sat) + 12px) 24px calc(var(--sab) + 12px) calc(var(--sal) + 24px)' : 'calc(var(--sat) + 12px) 24px 12px';
  const padB = row ? 'calc(var(--sat) + 12px) calc(var(--sar) + 16px) calc(var(--sab) + 12px) 16px' : '12px 16px calc(var(--sab) + 12px)';
  let topBody: ReactNode;
  let bottom: ReactNode;
  if (quizRun) {
    topBody = <><QuestionPane run={quizRun} large /><div className="mt12"><Feedback run={quizRun} /></div></>;
    const opts = quizRun.items[quizRun.index].options.map((_, i) => i);
    const pairs: number[][] = [];
    for (let i = 0; i < opts.length; i += 2) pairs.push(opts.slice(i, i + 2));
    bottom = (
      <>
        {pairs.map((pair, i) => (
          <div key={i} className="row gap10" style={{ flex: '1 1 0', alignItems: 'stretch', minHeight: 0 }}>
            {pair.map((k) => <OptionButton key={`${quizRun.index}-${k}`} run={quizRun} index={k} large style={{ flex: '1 1 0', height: 'auto' }} />)}
            {pair.length === 1 && <span style={{ flex: '1 1 0' }} />}
          </div>
        ))}
        <QuizNav run={quizRun} large />
      </>
    );
  } else if (lesson) {
    const page = lessonRun?.page ?? 0;
    const count = lessonPageCount(lesson);
    const p = lessonPageOf(lesson, page);
    const sim = lesson.sim && lesson.sim !== 'NONE' ? lesson.sim : null;
    topBody = p.kind === 'THEORY' ? <LessonBlock lesson={lesson} index={p.index} large />
      : p.kind === 'SIM' && sim ? <SimReadout kind={sim} hint={lt(lesson.simHint, lang) || null} />
        : <><LessonMeta lesson={lesson} validated={false} /><LessonObjectives lesson={lesson} /></>;
    bottom = (
      <>
        {p.kind === 'SIM' && sim && <Scroll>{<SimControls kind={sim} />}</Scroll>}
        {p.kind === 'VALIDATE' && <div className="center" style={{ flex: '1 1 0' }}><div style={{ width: '100%' }}><ValidationCard lesson={lesson} /></div></div>}
        <div style={{ flex: p.kind === 'THEORY' ? '1 1 0' : '0 0 88px', minHeight: 0 }}><LessonPager page={page} count={count} large /></div>
      </>
    );
  } else {
    topBody = <SimReadout kind={labKind} hint={t('train_lab_hint')} />;
    bottom = <><LabModeToggle /><Scroll><SimControls kind={labKind} /></Scroll></>;
  }
  const top = (
    <div className="col" style={{ flex: '1 1 auto', minHeight: 0, padding: pad }}>
      <div className="row gap8">
        <IconButton icon="close" label={t('back')} onClick={s.back} />
        <span className="title-large grow ellipsis">{title}</span>
        {remaining != null && <TimerText text={formatClock(remaining)} size={24} color={remaining <= 30 ? 'var(--error)' : undefined} />}
      </div>
      <Scroll className="mt8">{topBody}</Scroll>
    </div>
  );
  return <FlexSplit row={row} first={top} second={<div className="col gap10" style={{ flex: '1 1 auto', minHeight: 0, padding: padB }}>{bottom}</div>} />;
}
