import { formatClock, formatRatio, formatTenths, ratio as ratioOf } from '../../core/coffee';
import { Brew, isEspresso, methodFromKey, Recipe } from '../../core/models';
import { methodLabel } from '../../core/seed';
import { Units } from '../../core/units';
import { formatDate, t } from '../../i18n/i18n';
import { useApp } from '../../state/store';
import { opportunityOf, symptomKey } from '../../state/trainer';
import { useBrewUi } from '../brewUi';
import { BigButton, Icon, IconButton, ListRow, Scroll, SectionTitle, TwoPane, useUnits } from '../components';

export const brewTimeText = (b: Brew) => (isEspresso(methodFromKey(b.method)) ? `${formatTenths(b.timeMs)} s` : formatClock(b.timeMs / 1000));
export const recipeTimeText = (r: Recipe) => (isEspresso(methodFromKey(r.method)) ? `${r.targetTimeS} s` : formatClock(r.targetTimeS));
export const recipeSummary = (r: Recipe, u: Units) =>
  `${methodLabel(methodFromKey(r.method))} · ${u.w(r.doseG)} → ${u.w(r.waterG)} · ${formatRatio(ratioOf(r.waterG, r.doseG))} · ${recipeTimeText(r)}`;
export const brewSummary = (b: Brew, u: Units) => `${methodLabel(methodFromKey(b.method))} · ${u.w(b.doseG)} → ${u.w(b.waterG)} · ${brewTimeText(b)}`;

export function RatingBadge({ rating }: { rating: number }) {
  return (
    <span className="row" style={{ gap: 2 }}>
      <Icon name="star" size={18} style={{ color: 'var(--primary)' }} />
      <span className="title-medium">{rating}</span>
    </span>
  );
}

export function HomeScreen({ wide }: { wide: boolean }) {
  if (wide) {
    return (
      <TwoPane
        left={<Scroll className="pad-h28" style={{ paddingTop: 20, paddingBottom: 20 }}><Greeting /><div className="mt24" /><Hero large /><div className="mt24" /><Tools /></Scroll>}
        right={<Scroll style={{ padding: '20px 16px' }}><RecentBrews limit={5} /><Favorites /></Scroll>}
      />
    );
  }
  return (
    <Scroll style={{ paddingTop: 12, paddingBottom: 24 }}>
      <div className="pad-h20"><Greeting /><div className="mt20" /><Hero /><div className="mt20" /><Tools /></div>
      <div className="pad-h4"><RecentBrews limit={3} /><Favorites /></div>
    </Scroll>
  );
}

function Greeting() {
  const open = useApp((s) => s.open);
  const hour = new Date().getHours();
  return (
    <div className="row-top">
      <div className="col grow">
        <span className="title-large muted">{t(hour < 12 ? 'good_morning' : hour < 18 ? 'good_afternoon' : 'good_evening')}</span>
        <span className="display-small">{t('ready_to_brew')}</span>
      </div>
      <IconButton icon="settings" label={t('settings')} onClick={() => open('SETTINGS')} />
    </div>
  );
}

/** The closed-mode promise: coffee, method, numbers and one BREW button. */
function Hero({ large }: { large?: boolean }) {
  const ui = useBrewUi();
  const u = useUnits();
  const selectTab = useApp((s) => s.selectTab);
  return (
    <>
      <div className="hero">
        {!ui ? (
          <>
            <div className="headline-medium">{t('no_recipe_title')}</div>
            <p className="body-large" style={{ margin: 0 }}>{t('no_recipe_body')}</p>
            <BigButton text={t('choose_recipe')} primary onClick={() => selectTab('RECIPES')} className="mt16" style={{ width: '100%' }} />
          </>
        ) : (
          <>
            <button type="button" onClick={() => selectTab('COFFEE')} style={{ border: 0, background: 'none', padding: 0, color: 'inherit', textAlign: 'left', cursor: 'pointer' }}
              className={`${large ? 'display-small' : 'headline-large'} clamp2`}>
              {ui.recipe.coffeeName.trim() || ui.recipe.name}
            </button>
            <div className="title-medium ellipsis">{ui.recipe.coffeeName.trim() ? `${methodLabel(ui.recipe.method)} · ${ui.recipe.name}` : methodLabel(ui.recipe.method)}</div>
            <div className="row gap24 mt20">
              <HeroStat label={t('coffee')} value={u.w(ui.recipe.doseG)} />
              <HeroStat label={t(ui.espresso ? 'yield_label' : 'water')} value={u.w(ui.recipe.waterG)} />
              <HeroStat label={t('ratio')} value={formatRatio(ui.ratio)} />
            </div>
            <BigButton text={ui.started ? t('back_to_brew', ui.timeText) : t('brew')} icon="play_arrow" primary minHeight={72}
              onClick={() => selectTab('BREW')} className="mt20" style={{ width: '100%' }} />
          </>
        )}
      </div>
      <div className="row gap12 mt12">
        <BigButton text={t('tab_recipes')} minHeight={56} onClick={() => selectTab('RECIPES')} style={{ flex: '1 1 0' }} />
        <BigButton text={t('tab_history')} minHeight={56} onClick={() => selectTab('HISTORY')} style={{ flex: '1 1 0' }} />
      </div>
    </>
  );
}

const HeroStat = ({ label, value }: { label: string; value: string }) => (
  <div className="col"><span className="label-small upper">{label}</span><span className="headline-medium" style={{ whiteSpace: 'nowrap' }}>{value}</span></div>
);

function Tools() {
  const s = useApp.getState();
  const tool = (icon: string, label: string, onClick: () => void) => (
    <button type="button" onClick={onClick} className="col" style={{ flex: '1 1 0', alignItems: 'center', border: 0, background: 'none', borderRadius: 24, padding: '10px 2px', minHeight: 72, cursor: 'pointer', color: 'var(--on-surface)' }}>
      <Icon name={icon} size={26} style={{ color: 'var(--primary)' }} />
      <span className="label-medium clamp2 mt6" style={{ textAlign: 'center' }}>{label}</span>
    </button>
  );
  return (
    <div className="row gap8" style={{ alignItems: 'stretch' }}>
      {tool('calculate', t('calculator'), () => s.open('CALCULATOR'))}
      {tool('troubleshoot', t('diagnose'), () => s.diagnoseLatest())}
      {tool('tune', t('grind'), () => s.open('GRIND'))}
      {tool('compare_arrows', t('compare'), () => s.open('COMPARE'))}
    </div>
  );
}

export function HomeOpportunity() {
  const brews = useApp((s) => s.data.brews);
  const openLesson = useApp((s) => s.openLesson);
  const o = opportunityOf(brews);
  if (!o) return null;
  return (
    <ListRow title={t('train_opportunity')} subtitle={t('train_opportunity_body', o.count, t(symptomKey(o.symptom)))}
      leading={<Icon name="school" style={{ color: 'var(--primary)' }} />}
      trailing={<span className="label-large primary-text">{t('train_this')}</span>}
      onClick={() => openLesson(o.lessonId)} />
  );
}

function RecentBrews({ limit }: { limit: number }) {
  const brews = useApp((s) => s.data.brews);
  const u = useUnits();
  const { selectTab, set } = useApp.getState();
  return (
    <>
      <HomeOpportunity />
      <SectionTitle text={t('recent_brews')} style={{ paddingLeft: 16, paddingRight: 16 }} />
      {brews.length === 0
        ? <p className="body-large muted" style={{ margin: 0, padding: '8px 16px' }}>{t('no_brews_yet')}</p>
        : brews.slice(0, limit).map((b) => (
          <ListRow key={b.id} title={b.coffeeName.trim() || b.recipeName} subtitle={`${brewSummary(b, u)}\n${formatDate(b.createdAt)}`}
            trailing={b.rating > 0 ? <RatingBadge rating={b.rating} /> : undefined}
            onClick={() => { selectTab('HISTORY'); set({ historySel: b.id }); }} />
        ))}
    </>
  );
}

function Favorites() {
  const recipes = useApp((s) => s.data.recipes);
  const u = useUnits();
  const { selectTab, set, brew } = useApp.getState();
  const favs = recipes.filter((r) => r.favorite);
  return (
    <>
      <SectionTitle text={t('favorite_recipes')} style={{ paddingLeft: 16, paddingRight: 16 }} />
      {favs.length === 0
        ? <p className="body-large muted" style={{ margin: 0, padding: '8px 16px' }}>{t('no_favorites')}</p>
        : favs.slice(0, 6).map((r) => (
          <ListRow key={r.id} title={r.name} subtitle={recipeSummary(r, u)}
            trailing={<IconButton icon="play_arrow" label={t('brew_this', r.name)} tonal onClick={() => brew(r)} />}
            onClick={() => { selectTab('RECIPES'); set({ recipePane: { kind: 'VIEW', id: r.id } }); }} />
        ))}
    </>
  );
}
