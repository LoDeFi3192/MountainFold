// Brew journal and the log sheet.
import { formatClock, formatNumber, formatRatio, formatTenths, ratio as ratioOf } from '../../core/coffee';
import { parseSymptoms, primarySymptom } from '../../core/copilot';
import { Brew, Grinder, isEspresso, methodFromKey } from '../../core/models';
import { methodLabel } from '../../core/seed';
import { TrainProgress } from '../../core/train';
import { formatDate, t } from '../../i18n/i18n';
import { useApp } from '../../state/store';
import type { LogDraft } from '../../state/types';
import {
  BigButton, Btn, ConfirmDialog, EmptyState, IconButton, LevelRow, ListRow, NumField, Scroll, ScreenHeader, SectionTitle, SelectField,
  Stat, StarRating, TextField, TimerText, TwoPane, useUnits,
} from '../components';
import { brewSummary, brewTimeText, RatingBadge } from './Home';
import { SymptomChips, symptomLabel, TrainSuggestion } from './Tools';
import { useState } from 'react';

export function HistoryScreen({ wide }: { wide: boolean }) {
  const brews = useApp((s) => s.data.brews);
  const sel = useApp((s) => s.historySel);
  const selected = brews.find((b) => b.id === sel);
  if (wide) {
    return <TwoPane left={<HistoryList selectedId={selected?.id ?? null} />}
      right={selected ? <div className="page"><BrewDetail b={selected} showBack={false} /></div> : <div className="center" style={{ flex: 1 }}><span className="title-medium muted">{t('select_brew')}</span></div>} />;
  }
  return <div className="page">{selected ? <BrewDetail b={selected} showBack /> : <HistoryList selectedId={null} />}</div>;
}

function HistoryList({ selectedId }: { selectedId: number | null }) {
  const brews = useApp((s) => s.data.brews);
  const u = useUnits();
  const { set, selectTab } = useApp.getState();
  return (
    <div className="col" style={{ flex: 1, minHeight: 0 }}>
      <ScreenHeader title={t('tab_history')} />
      {brews.length === 0
        ? <EmptyState icon="history" title={t('no_history_title')} body={t('no_brews_yet')} actionLabel={t('start_brewing')} onAction={() => selectTab('BREW')} />
        : (
          <Scroll style={{ padding: '8px 4px 24px' }}>
            {brews.map((b) => (
              <ListRow key={b.id} title={b.coffeeName.trim() || b.recipeName} subtitle={`${brewSummary(b, u)}\n${formatDate(b.createdAt)}`} selected={b.id === selectedId}
                trailing={b.rating > 0 ? <RatingBadge rating={b.rating} /> : undefined} onClick={() => set({ historySel: b.id })} />
            ))}
          </Scroll>
        )}
    </div>
  );
}

function BrewDetail({ b, showBack }: { b: Brew; showBack: boolean }) {
  const u = useUnits();
  const s = useApp.getState();
  const [confirmDelete, setConfirmDelete] = useState(false);
  const method = methodFromKey(b.method);
  const symptoms = parseSymptoms(b.symptoms);
  const main = primarySymptom(symptoms);
  return (
    <>
      <ScreenHeader title={b.coffeeName.trim() || b.recipeName} onBack={showBack ? s.back : undefined}>
        <IconButton icon="delete" label={t('delete')} onClick={() => setConfirmDelete(true)} />
      </ScreenHeader>
      <Scroll className="pad-h20 pad-b24">
        <span className="body-large muted">{[methodLabel(method), b.recipeName, formatDate(b.createdAt)].filter((x) => x.trim()).join(' · ')}</span>
        <div className="mt12"><StarRating value={b.rating} size={28} /></div>
        <div className="stats mt16">
          <Stat label={t('dose')} value={u.w(b.doseG)} />
          <Stat label={t(isEspresso(method) ? 'yield_label' : 'water')} value={u.w(b.waterG)} />
          <Stat label={t('ratio')} value={formatRatio(ratioOf(b.waterG, b.doseG))} />
          <Stat label={t('time')} value={brewTimeText(b)} />
          <Stat label={t('temperature')} value={u.t(b.tempC)} />
          {b.grind.trim() && <Stat label={t('grind')} value={b.grind} />}
          {b.grinderName.trim() && <Stat label={t('grinder')} value={b.grinderName} />}
          {b.pressureBar != null && <Stat label={t('pressure')} value={`${formatNumber(b.pressureBar)} bar`} />}
        </div>
        {[b.acidity, b.sweetness, b.body, b.balance, b.clarity].some((x) => x > 0) && (
          <>
            <SectionTitle text={t('taste')} />
            <LevelRow label={t('acidity')} value={b.acidity} />
            <LevelRow label={t('sweetness')} value={b.sweetness} />
            <LevelRow label={t('body')} value={b.body} />
            <LevelRow label={t('balance')} value={b.balance} />
            <LevelRow label={t('clarity')} value={b.clarity} />
          </>
        )}
        {symptoms.length > 0 && (
          <>
            <SectionTitle text={t('what_was_off')} />
            <div className="chips">{symptoms.map((x) => <span key={x} className="chip" style={{ cursor: 'default', opacity: 0.8 }}>{symptomLabel(x)}</span>)}</div>
          </>
        )}
        {b.notes.trim() && <><SectionTitle text={t('notes')} /><p className="body-large pre-line" style={{ margin: 0 }}>{b.notes}</p></>}
        {main && <div className="mt16"><TrainSuggestion lessonId={TrainProgress.lessonForSymptom(main, isEspresso(method))} /></div>}
        <BigButton text={t('diagnose')} icon="troubleshoot" primary minHeight={56} className="mt24" style={{ width: '100%' }} onClick={() => s.diagnoseBrew(b.id)} />
        <div className="row gap10" style={{ marginTop: 10 }}>
          <BigButton text={t('brew_again')} icon="play_arrow" minHeight={56} onClick={() => s.brewAgain(b.id)} style={{ flex: '1 1 0' }} />
          <BigButton text={t('compare')} icon="compare_arrows" minHeight={56} style={{ flex: '1 1 0' }}
            onClick={() => { s.set({ compare: { ...s.compare, brews: true, aId: b.id } }); s.open('COMPARE'); }} />
        </div>
      </Scroll>
      {confirmDelete && <ConfirmDialog title={t('delete_brew_title')} body={t('delete_brew_body')} confirm={t('delete')} onConfirm={() => { setConfirmDelete(false); s.deleteBrew(b.id); }} onDismiss={() => setConfirmDelete(false)} />}
    </>
  );
}

// ---- log a brew -------------------------------------------------------------------------------------------
export function LogBrewScreen({ wide }: { wide: boolean }) {
  const d = useApp((s) => s.logDraft);
  const recipe = useApp((s) => s.session.recipe);
  const grinders = useApp((s) => s.data.grinders);
  const s = useApp.getState();
  if (!d || !recipe) return null;
  const update = (n: LogDraft) => s.set({ logDraft: n });
  const espresso = isEspresso(recipe.method);
  const numbers = <LogNumbers d={d} update={update} espresso={espresso} grinders={grinders} />;
  const taste = <LogTaste d={d} update={update} />;
  return (
    <div className="page">
      <ScreenHeader title={t('log_this_brew')} onBack={s.back}>
        <Btn onClick={() => void s.saveLog()} style={{ marginRight: 12 }}>{t('save')}</Btn>
      </ScreenHeader>
      {wide
        ? <TwoPane left={<Scroll className="pad-h28 pad-b24">{numbers}</Scroll>} right={<Scroll className="pad-h28" style={{ paddingTop: 8, paddingBottom: 24 }}>{taste}</Scroll>} />
        : <Scroll className="pad-h20 pad-b32">{numbers}{taste}</Scroll>}
    </div>
  );
}

function LogNumbers({ d, update, espresso, grinders }: { d: LogDraft; update: (n: LogDraft) => void; espresso: boolean; grinders: Grinder[] }) {
  const u = useUnits();
  const dose = u.parseW(d.dose);
  const water = u.parseW(d.water);
  return (
    <>
      <div className="row-bottom">
        <TimerText text={espresso ? formatTenths(d.timeMs) : formatClock(d.timeMs / 1000)} size={64} />
        {espresso && <span className="headline-small muted" style={{ paddingBottom: 6 }}>&nbsp;s</span>}
      </div>
      <div className="col gap12 mt12">
        <div className="row gap12">
          <NumField className="grow" value={d.dose} onChange={(v) => update({ ...d, dose: v })} label={t('dose')} suffix={u.wLabel} />
          <NumField className="grow" value={d.water} onChange={(v) => update({ ...d, water: v })} label={t(espresso ? 'yield_label' : 'water')} suffix={u.wLabel} />
        </div>
        <span className="title-medium">{t('ratio')}  {formatRatio(dose != null && water != null ? ratioOf(water, dose) : null)}</span>
        <div className="row gap12">
          <NumField className="grow" value={d.temp} onChange={(v) => update({ ...d, temp: v })} label={t('temperature')} suffix={u.tLabel} />
          <TextField className="grow" value={d.grind} onChange={(v) => update({ ...d, grind: v })} label={t('grind_setting')} />
        </div>
        {grinders.length > 0 && (
          <SelectField<Grinder | null> label={t('grinder')} value={grinders.find((g) => g.id === d.grinderId) ?? null} options={[null, ...grinders]}
            optionLabel={(g) => g?.name ?? t('none')} onSelect={(g) => update({ ...d, grinderId: g?.id ?? null })} />
        )}
      </div>
    </>
  );
}

function LogTaste({ d, update }: { d: LogDraft; update: (n: LogDraft) => void }) {
  return (
    <>
      <SectionTitle text={t('rating')} />
      <StarRating value={d.rating} onChange={(v) => update({ ...d, rating: v })} />
      <SectionTitle text={t('taste')} />
      <LevelRow label={t('acidity')} value={d.acidity} onChange={(v) => update({ ...d, acidity: v })} />
      <LevelRow label={t('sweetness')} value={d.sweetness} onChange={(v) => update({ ...d, sweetness: v })} />
      <LevelRow label={t('body')} value={d.body} onChange={(v) => update({ ...d, body: v })} />
      <LevelRow label={t('balance')} value={d.balance} onChange={(v) => update({ ...d, balance: v })} />
      <LevelRow label={t('clarity')} value={d.clarity} onChange={(v) => update({ ...d, clarity: v })} />
      <SectionTitle text={t('anything_off')} />
      <SymptomChips selected={d.symptoms} onToggle={(x) => update({ ...d, symptoms: d.symptoms.includes(x) ? d.symptoms.filter((y) => y !== x) : [...d.symptoms, x] })} />
      <div className="mt12"><TextField value={d.notes} onChange={(v) => update({ ...d, notes: v })} label={t('notes')} multiline minRows={3} /></div>
    </>
  );
}
