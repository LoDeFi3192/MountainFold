// Brew: quick assistant (phone), workstation (tablet), counter companion (phone sideways or Flex).
import { useState } from 'react';
import { flowRate, formatClock, formatNumber, formatRatio, formatTenths, ratio as ratioOf } from '../../core/coffee';
import { FLEX_LAYOUTS, FlexLayout } from '../../core/models';
import { methodLabel } from '../../core/seed';
import { t } from '../../i18n/i18n';
import { listen, speechSupported } from '../../platform/device';
import { useApp } from '../../state/store';
import { BrewUi, useBrewUi } from '../brewUi';
import {
  BigButton, Chip, ConfirmDialog, Dialog, Btn, EmptyState, FitTimer, FlexSplit, IconButton, NumField, Progress, Scroll,
  SectionTitle, Stat, StepList, TextField, TimerText, TwoPane, useUnits,
} from '../components';

export function BrewScreen({ wide }: { wide: boolean }) {
  const ui = useBrewUi();
  const selectTab = useApp((s) => s.selectTab);
  if (!ui) {
    return (
      <div className="page center">
        <EmptyState icon="menu_book" title={t('no_recipe_title')} body={t('no_recipe_body')} actionLabel={t('choose_recipe')} onAction={() => selectTab('RECIPES')} />
      </div>
    );
  }
  return wide ? <BrewOpen ui={ui} /> : <BrewClosed ui={ui} />;
}

// ---- CLOSED: quick assistant ----------------------------------------------------------------------------
function BrewClosed({ ui }: { ui: BrewUi }) {
  const landscape = typeof window !== 'undefined' && window.innerWidth > window.innerHeight;
  if (landscape) {
    return (
      <div className="page row" style={{ alignItems: 'stretch', gap: 20, padding: '12px 20px' }}>
        <Scroll className="col gap12 grow"><BrewHeader ui={ui} /><TimerBlock ui={ui} size={64} />{ui.espresso ? <ShotStats ui={ui} /> : <CurrentStep ui={ui} />}</Scroll>
        <Scroll className="col gap12 grow"><WeightBlock ui={ui} /><BrewControls ui={ui} height={56} /></Scroll>
      </div>
    );
  }
  return (
    <Scroll className="col gap16" style={{ padding: '12px 20px 24px' }}>
      <BrewHeader ui={ui} />
      <TimerBlock ui={ui} size={84} />
      {ui.espresso ? <ShotStats ui={ui} /> : <CurrentStep ui={ui} />}
      <WeightBlock ui={ui} />
      <BrewControls ui={ui} height={64} />
      <Laps ui={ui} />
    </Scroll>
  );
}

// ---- OPEN: workstation. LEFT = KNOW, RIGHT = DO ----------------------------------------------------------
function BrewOpen({ ui }: { ui: BrewUi }) {
  const u = useUnits();
  const notes = ui.state.notes;
  const sNotes = useApp((s) => s.sNotes);
  const r = ui.recipe;
  return (
    <TwoPane
      left={
        <Scroll className="pad-h28" style={{ paddingTop: 20, paddingBottom: 20 }}>
          <BrewHeader ui={ui} large />
          <div className="stats mt20">
            <Stat label={t('dose')} value={u.w(r.doseG)} />
            <Stat label={t(ui.espresso ? 'yield_label' : 'water')} value={u.w(r.waterG)} />
            <Stat label={t('ratio')} value={formatRatio(ui.ratio)} />
            <Stat label={t('temperature')} value={u.t(r.tempC)} />
            {r.grind.trim() && <Stat label={t('grind')} value={r.grind} />}
            <Stat label={t('target')} value={ui.targetText} />
            {r.pressureBar != null && <Stat label={t('pressure')} value={`${formatNumber(r.pressureBar)} bar`} />}
          </div>
          <SectionTitle text={t('steps')} />
          <StepList steps={ui.steps} currentIndex={ui.stepIndex} targetS={r.targetTimeS} started={ui.started} />
          {r.notes.trim() && <><SectionTitle text={t('notes')} /><p className="body-large" style={{ margin: 0 }}>{r.notes}</p></>}
          <SectionTitle text={t('brew_notes')} />
          <TextField value={notes} onChange={sNotes} placeholder={t('brew_notes_hint')} multiline minRows={3} />
          <Laps ui={ui} />
        </Scroll>
      }
      right={
        <Scroll className="col gap20 pad-h28" style={{ paddingTop: 20, paddingBottom: 20 }}>
          <TimerBlock ui={ui} size={120} />
          {ui.espresso ? <ShotStats ui={ui} /> : <CurrentStep ui={ui} />}
          <WeightBlock ui={ui} />
          <BrewControls ui={ui} height={72} />
        </Scroll>
      }
    />
  );
}

// ---- shared blocks ---------------------------------------------------------------------------------------
function BrewHeader({ ui, large }: { ui: BrewUi; large?: boolean }) {
  const u = useUnits();
  const [adjust, setAdjust] = useState(false);
  const selectTab = useApp((s) => s.selectTab);
  const r = ui.recipe;
  const sub = [r.coffeeName, methodLabel(r.method)].filter((x) => x.trim()).join(' · ');
  return (
    <>
      <div className="row-top">
        <div className="col grow">
          <span className={`${large ? 'headline-medium' : 'headline-small'} clamp2`}>{r.name}</span>
          <span className="body-large muted">{sub}</span>
          {!large && (
            <span className="title-medium mt4">
              {u.w(r.doseG)} → {u.w(r.waterG)} · {formatRatio(ui.ratio)}{r.tempC != null ? ` · ${u.t(r.tempC)}` : ''}
            </span>
          )}
        </div>
        {!ui.started && <IconButton icon="tune" label={t('adjust')} onClick={() => setAdjust(true)} />}
        <IconButton icon="menu_book" label={t('choose_recipe')} onClick={() => selectTab('RECIPES')} />
      </div>
      {adjust && <AdjustDialog ui={ui} onClose={() => setAdjust(false)} />}
    </>
  );
}

function AdjustDialog({ ui, onClose }: { ui: BrewUi; onClose: () => void }) {
  const u = useUnits();
  const { sAdjust, sSetTemp } = useApp.getState();
  const [dose, setDose] = useState(u.wValue(ui.recipe.doseG));
  const [water, setWater] = useState(u.wValue(ui.recipe.waterG));
  const [temp, setTemp] = useState(ui.recipe.tempC == null ? '' : u.tValue(ui.recipe.tempC));
  const d = u.parseW(dose);
  const w = u.parseW(water);
  const ok = d != null && w != null && d > 0 && w > 0;
  return (
    <Dialog title={t('adjust')} onDismiss={onClose} bg="var(--surface-container-high)"
      actions={<><Btn kind="text" onClick={onClose}>{t('cancel')}</Btn><Btn kind="text" disabled={!ok} onClick={() => { sAdjust(d!, w!); sSetTemp(u.parseT(temp)); onClose(); }}>{t('apply')}</Btn></>}>
      <div className="col gap12" style={{ color: 'var(--on-surface)', paddingTop: 6 }}>
        <NumField value={dose} onChange={setDose} label={t('dose')} suffix={u.wLabel} bg="var(--surface-container-high)" />
        <NumField value={water} onChange={setWater} label={t(ui.espresso ? 'yield_label' : 'water')} suffix={u.wLabel} bg="var(--surface-container-high)" />
        <NumField value={temp} onChange={setTemp} label={t('temperature')} suffix={u.tLabel} bg="var(--surface-container-high)" />
        <span className="title-medium">{t('ratio')}  {formatRatio(ok ? ratioOf(w!, d!) : null)}</span>
      </div>
    </Dialog>
  );
}

function TimerBlock({ ui, size }: { ui: BrewUi; size: number }) {
  return (
    <div className="col">
      <div className="row-bottom">
        <TimerText text={ui.timeText} size={size} />
        {ui.espresso && <span className="headline-medium muted" style={{ paddingBottom: 8 }}>&nbsp;s</span>}
        <span className="grow" />
        <span className="title-large muted" style={{ paddingBottom: 10 }}>/ {ui.targetText}</span>
      </div>
      <Progress value={ui.progress} done={ui.state.targetReached} style={{ marginTop: 8 }} />
    </div>
  );
}

function CurrentStep({ ui }: { ui: BrewUi }) {
  const u = useUnits();
  const step = ui.step;
  const next = ui.next;
  const head = !ui.started ? t('ready_when_you_are') : ui.state.targetReached ? t('target_reached') : ui.steps.length === 0 ? t('brewing') : t('step_n_of', ui.stepIndex + 1, ui.steps.length);
  const foot = next && ui.started ? t('next_step_in', next.label, formatClock(ui.stepRemainingS))
    : next ? t('next_step_at', next.label, formatClock(next.startS))
      : ui.state.targetReached ? t('log_this_brew') : t('until_target', formatClock(ui.stepRemainingS));
  return (
    <div className="tonal-box">
      <span className="label-medium upper primary-text">{head}</span>
      <div key={ui.stepIndex} className="step-anim mt6">
        <div className="row">
          <span className="headline-medium grow clamp2">{step?.label ?? methodLabel(ui.recipe.method)}</span>
          {step?.targetWaterG != null && <span className="headline-medium primary-text" style={{ whiteSpace: 'nowrap' }}>→ {u.w(step.targetWaterG)}</span>}
        </div>
        {step && step.note.trim() && <p className="body-large" style={{ margin: '4px 0 0' }}>{step.note}</p>}
      </div>
      <p className="body-large muted" style={{ margin: '8px 0 0' }}>{foot}</p>
    </div>
  );
}

/** Manual scale. A connected scale would report live weight and these buttons would disappear. */
function WeightBlock({ ui }: { ui: BrewUi }) {
  const u = useUnits();
  const step = useApp((s) => (ui.espresso ? 1 : s.settings.waterStepG));
  const { sAddWater, sSetWater } = useApp.getState();
  const [entry, setEntry] = useState<string | null>(null);
  const target = ui.espresso ? ui.recipe.waterG : ui.targetWaterNow;
  return (
    <>
      <div className="row gap8">
        <button type="button" className="col grow" style={{ border: 0, background: 'none', textAlign: 'left', padding: 0, cursor: 'pointer' }}
          aria-label={t('enter_weight')} onClick={() => setEntry(u.wValue(ui.pouredG))}>
          <span className="label-small upper muted">{t(ui.espresso ? 'yield_label' : 'water')}</span>
          <span className="row-bottom">
            <TimerText text={u.wValue(ui.pouredG)} size={40} />
            <span className="title-large muted" style={{ paddingBottom: 4 }}>&nbsp;/ {u.w(target)}</span>
          </span>
          {ui.liveRatio != null && <span className="body-medium muted">{t('live_ratio', formatRatio(ui.liveRatio))}</span>}
        </button>
        <IconButton label="−" tonal size={56} onClick={() => sAddWater(-step)}><span className="headline-small">−</span></IconButton>
        <BigButton text={`+${u.w(step)}`} icon="water_drop" minHeight={56} onClick={() => sAddWater(step)} style={{ flex: '0 0 auto' }} />
      </div>
      {entry != null && (
        <Dialog title={t('enter_weight')} onDismiss={() => setEntry(null)}
          actions={<><Btn kind="text" onClick={() => setEntry(null)}>{t('cancel')}</Btn><Btn kind="text" onClick={() => { const g = u.parseW(entry); if (g != null) sSetWater(g); setEntry(null); }}>{t('apply')}</Btn></>}>
          <div className="col gap8" style={{ paddingTop: 6 }}>
            <NumField value={entry} onChange={setEntry} label={t('weight')} suffix={u.wLabel} bg="var(--surface-container-high)" />
            <Btn kind="text" onClick={() => setEntry(u.wValue(target))}>{t('set_to_target', u.w(target))}</Btn>
          </div>
        </Dialog>
      )}
    </>
  );
}

function ShotStats({ ui }: { ui: BrewUi }) {
  const u = useUnits();
  const r = ui.recipe;
  const cls = 'headline-medium';
  const flow = ui.pouredG > 0 && ui.elapsedS > 0 ? flowRate(ui.pouredG, ui.elapsedS) : null;
  return (
    <div className="tonal-box">
      <div className="stats" style={{ rowGap: 14 }}>
        <Stat label={t('dose')} value={u.w(r.doseG)} valueClass={cls} />
        <Stat label={t('yield_label')} value={u.w(ui.pouredG > 0 ? ui.pouredG : r.waterG)} valueClass={cls} />
        <Stat label={t('ratio')} value={formatRatio(ui.liveRatio ?? ui.ratio)} valueClass={cls} />
        <Stat label={t('temperature')} value={u.t(r.tempC)} valueClass={cls} />
        {r.pressureBar != null && <Stat label={t('pressure')} value={`${formatNumber(r.pressureBar)} bar`} valueClass={cls} />}
        {flow != null && <Stat label={t('flow')} value={`${formatNumber(flow)} g/s`} valueClass={cls} />}
      </div>
    </div>
  );
}

const startLabel = (ui: BrewUi) => t(ui.running ? 'pause' : ui.started ? 'resume' : 'start');

function BrewControls({ ui, height }: { ui: BrewUi; height: number }) {
  const s = useApp.getState();
  const lang = useApp((x) => x.lang);
  const [confirmReset, setConfirmReset] = useState(false);
  const voice = speechSupported();
  return (
    <div className="col gap10">
      <div className="row gap10" style={{ alignItems: 'stretch' }}>
        <BigButton text={startLabel(ui)} icon={ui.running ? 'pause' : 'play_arrow'} primary minHeight={height} onClick={s.sToggle} style={{ flex: '1.6 1 0' }} />
        {!ui.espresso && <BigButton text={t('next_step')} icon="skip_next" minHeight={height} disabled={ui.started && !ui.next} onClick={s.sNext} style={{ flex: '1 1 0' }} />}
      </div>
      <div className="row gap10" style={{ alignItems: 'stretch' }}>
        {!ui.espresso && <BigButton text={t('plus_10_sec')} minHeight={56} disabled={!ui.started} onClick={() => s.sExtend(10)} style={{ flex: '1 1 0' }} />}
        {!ui.espresso && <BigButton text={t('lap')} minHeight={56} disabled={!ui.running} onClick={s.sLap} style={{ flex: '1 1 0' }} />}
        <BigButton text={t('reset')} minHeight={56} disabled={!ui.started && ui.pouredG <= 0} onClick={() => (ui.elapsedMs > 5000 ? setConfirmReset(true) : s.sReset())} style={{ flex: '1 1 0' }} />
      </div>
      <div className="row gap10">
        <BigButton text={t('finish_and_log')} icon="flag" minHeight={56} disabled={!ui.started} onClick={s.sFinish} style={{ flex: '1 1 0' }} />
        {voice && <IconButton icon="mic" label={t('voice_command')} tonal size={56} onClick={() => listen(lang, s.onVoice)} />}
      </div>
      {confirmReset && <ConfirmDialog title={t('reset_brew_title')} body={t('reset_brew_body')} confirm={t('reset')} onConfirm={() => { setConfirmReset(false); s.sReset(); }} onDismiss={() => setConfirmReset(false)} />}
    </div>
  );
}

function Laps({ ui }: { ui: BrewUi }) {
  if (!ui.laps.length) return null;
  return (
    <>
      <SectionTitle text={t('laps')} />
      <div className="stats" style={{ columnGap: 16, rowGap: 8 }}>
        {ui.laps.map((ms, i) => <Stat key={i} label={`${t('lap')} ${i + 1}`} value={ui.espresso ? formatTenths(ms) : formatClock(ms / 1000)} />)}
      </div>
    </>
  );
}

// ---- FLEX / counter: information first, controls second ----------------------------------------------------
export const flexLayoutLabel = (l: FlexLayout) => t(`flex_${l.toLowerCase()}`);

export function FlexCompanion({ row }: { row: boolean }) {
  const ui = useBrewUi();
  const settings = useApp((s) => s.settings);
  const { set, selectTab, setSettings } = useApp.getState();
  if (!ui) {
    return (
      <div className="page center" style={{ paddingTop: 'var(--sat)' }}>
        <EmptyState icon="menu_book" title={t('no_recipe_title')} body={t('no_recipe_body')} actionLabel={t('choose_recipe')} onAction={() => { set({ flexBrowse: true }); selectTab('RECIPES'); }} />
      </div>
    );
  }
  const layout: FlexLayout = ui.espresso && settings.flexLayout === 'BREW' ? 'SHOT' : settings.flexLayout;
  const top = (
    <div className="col" style={{ flex: '1 1 auto', minHeight: 0, padding: row ? 'calc(var(--sat) + 12px) 24px calc(var(--sab) + 12px) calc(var(--sal) + 24px)' : 'calc(var(--sat) + 12px) 24px 12px' }}>
      {layout === 'BREW' && <TopBrew ui={ui} />}
      {layout === 'TIMER' && <TopTimer ui={ui} />}
      {layout === 'RECIPE' && <TopRecipe ui={ui} />}
      {layout === 'SCALE' && <TopScale ui={ui} />}
      {layout === 'SHOT' && <TopShot ui={ui} />}
    </div>
  );
  const bottom = (
    <div className="col" style={{ flex: '1 1 auto', minHeight: 0, padding: row ? 'calc(var(--sat) + 12px) calc(var(--sar) + 16px) calc(var(--sab) + 12px) 16px' : '12px 16px calc(var(--sab) + 12px)' }}>
      <FlexControls ui={ui} layout={layout} />
      <div className="row gap8 mt8">
        <IconButton icon="apps" label={t('open_app')} onClick={() => set({ flexBrowse: true })} />
        <div className="chips scrollable grow">
          {FLEX_LAYOUTS.map((l) => <Chip key={l} selected={l === layout} onClick={() => setSettings((s) => ({ ...s, flexLayout: l }))}>{flexLayoutLabel(l)}</Chip>)}
        </div>
      </div>
    </div>
  );
  return <FlexSplit row={row} first={top} second={bottom} />;
}

function FlexHeaderLine({ ui }: { ui: BrewUi }) {
  const u = useUnits();
  const r = ui.recipe;
  return (
    <div className="row gap12">
      <div className="col grow">
        <span className="title-large primary-text">{methodLabel(r.method)}</span>
        <span className="headline-small ellipsis">{r.coffeeName.trim() || r.name}</span>
      </div>
      <div className="col" style={{ alignItems: 'flex-end' }}>
        <span className="title-large">{u.w(r.doseG)} → {u.w(r.waterG)}</span>
        <span className="title-medium muted">{[formatRatio(ui.ratio), r.tempC != null ? u.t(r.tempC) : null].filter(Boolean).join(' · ')}</span>
      </div>
    </div>
  );
}

function stepLine(ui: BrewUi, u: ReturnType<typeof useUnits>) {
  const s = ui.step;
  if (!ui.started) return t('ready_when_you_are');
  if (ui.state.targetReached) return t('target_reached');
  if (!s) return t('brewing');
  return s.targetWaterG != null ? `${s.label} → ${u.w(s.targetWaterG)}` : s.label;
}

function TopBrew({ ui }: { ui: BrewUi }) {
  const u = useUnits();
  const next = ui.next;
  return (
    <>
      <FlexHeaderLine ui={ui} />
      <FitTimer text={ui.timeText} heightFraction={0.9} />
      <span className="headline-small ellipsis">{stepLine(ui, u)}</span>
      <span className="body-large muted ellipsis">
        {next && ui.started ? t('next_step_in', next.label, formatClock(ui.stepRemainingS)) : next ? t('next_step_at', next.label, formatClock(next.startS)) : `${t('target')} ${ui.targetText}`}
      </span>
      <Progress value={ui.progress} done={ui.state.targetReached} style={{ marginTop: 10 }} />
    </>
  );
}

function TopTimer({ ui }: { ui: BrewUi }) {
  const u = useUnits();
  return (
    <>
      <FitTimer text={ui.timeText} heightFraction={0.95} />
      <div className="row gap8">
        <span className="title-large grow ellipsis">{ui.recipe.name}</span>
        <span className="title-large">{u.wValue(ui.pouredG)} / {u.w(ui.targetWaterNow)}</span>
        <span className="title-large muted">&nbsp;&nbsp;/ {ui.targetText}</span>
      </div>
      <Progress value={ui.progress} done={ui.state.targetReached} style={{ marginTop: 10 }} />
    </>
  );
}

function TopRecipe({ ui }: { ui: BrewUi }) {
  return (
    <>
      <div className="row gap8">
        <span className="title-large grow ellipsis">{ui.recipe.name}</span>
        <TimerText text={ui.timeText} size={36} />
      </div>
      <Scroll className="mt8"><StepList steps={ui.steps} currentIndex={ui.stepIndex} targetS={ui.recipe.targetTimeS} started={ui.started} /></Scroll>
      <Progress value={ui.progress} done={ui.state.targetReached} style={{ marginTop: 8 }} />
    </>
  );
}

function TopScale({ ui }: { ui: BrewUi }) {
  const u = useUnits();
  return (
    <>
      <div className="row gap8">
        <span className="title-large grow ellipsis">{stepLine(ui, u)}</span>
        <TimerText text={ui.timeText} size={32} />
      </div>
      <FitTimer text={u.wValue(ui.pouredG)} heightFraction={0.9} />
      <div className="row gap28">
        <Stat label={t('target_weight')} value={u.w(ui.targetWaterNow)} />
        <Stat label={t('dose')} value={u.w(ui.recipe.doseG)} />
        <Stat label={t('ratio')} value={formatRatio(ui.liveRatio ?? ui.ratio)} />
        <Stat label={t('total')} value={u.w(ui.recipe.waterG)} />
      </div>
    </>
  );
}

function TopShot({ ui }: { ui: BrewUi }) {
  const u = useUnits();
  const r = ui.recipe;
  return (
    <>
      <span className="title-large primary-text ellipsis">{r.coffeeName.trim() || r.name}</span>
      <FitTimer text={formatTenths(ui.elapsedMs)} heightFraction={0.9} />
      <div className="stats" style={{ rowGap: 8 }}>
        <Stat label={t('dose')} value={u.w(r.doseG)} />
        <Stat label={t('yield_label')} value={u.w(ui.pouredG > 0 ? ui.pouredG : r.waterG)} />
        <Stat label={t('ratio')} value={formatRatio(ui.liveRatio ?? ui.ratio)} />
        <Stat label={t('temperature')} value={u.t(r.tempC)} />
        {r.pressureBar != null && <Stat label={t('pressure')} value={`${formatNumber(r.pressureBar)} bar`} />}
        <Stat label={t('target')} value={`${r.targetTimeS} s`} />
      </div>
      <Progress value={ui.progress} done={ui.state.targetReached} style={{ marginTop: 10 }} />
    </>
  );
}

interface FBtn { label: string; onClick: () => void; icon?: string; primary?: boolean; disabled?: boolean; weight?: number }

function FlexControls({ ui, layout }: { ui: BrewUi; layout: FlexLayout }) {
  const u = useUnits();
  const s = useApp.getState();
  const waterStep = useApp((x) => x.settings.waterStepG);
  const [confirmReset, setConfirmReset] = useState(false);
  const startPause: FBtn = { label: startLabel(ui), onClick: s.sToggle, icon: ui.running ? 'pause' : 'play_arrow', primary: true, weight: 1.6 };
  const next: FBtn = { label: t('next_step'), onClick: s.sNext, icon: 'skip_next', disabled: ui.started && !ui.next };
  const plus10: FBtn = { label: t('plus_10_sec'), onClick: () => s.sExtend(10), icon: 'more_time', disabled: !ui.started };
  const addWater: FBtn = { label: t('add_water_amount', u.w(waterStep)), onClick: () => s.sAddWater(waterStep), icon: 'water_drop' };
  const reset: FBtn = { label: t('reset'), onClick: () => (ui.elapsedMs > 5000 ? setConfirmReset(true) : s.sReset()), icon: 'restart_alt', disabled: !ui.started && ui.pouredG <= 0 };
  const finish: FBtn = { label: t('finish_and_log'), onClick: s.sFinish, icon: 'flag', disabled: !ui.started };
  const lap: FBtn = { label: t('lap'), onClick: s.sLap, icon: 'timer', disabled: !ui.running };
  const rows: FBtn[][] = (() => {
    switch (layout) {
      case 'BREW': return [[startPause, next], [plus10, addWater], [reset, finish]];
      case 'TIMER': return [[startPause], [lap, plus10], [reset, finish]];
      case 'RECIPE': return [[startPause, next], [plus10, reset, finish]];
      case 'SCALE': return [
        [{ label: `−${u.w(10)}`, onClick: () => s.sAddWater(-10) }, { label: `+${u.w(10)}`, onClick: () => s.sAddWater(10) }, { label: `+${u.w(50)}`, onClick: () => s.sAddWater(50), primary: true }],
        [{ label: t('tare'), onClick: () => s.sSetWater(0) }, { label: t('match_target'), onClick: () => s.sSetWater(ui.targetWaterNow) }],
        [startPause, finish]];
      case 'SHOT': return [
        [startPause],
        [{ label: `−${u.w(1)}`, onClick: () => s.sAddWater(-1) }, { label: `+${u.w(1)}`, onClick: () => s.sAddWater(1) }, { label: t('match_target'), onClick: () => s.sSetWater(ui.recipe.waterG) }],
        [reset, finish]];
    }
  })();
  return (
    <div className="col gap10" style={{ flex: '1 1 auto', minHeight: 0 }}>
      {rows.map((row, i) => (
        <div key={i} className="row gap10" style={{ flex: `${i === 0 ? 1.3 : 1} 1 0`, alignItems: 'stretch', minHeight: 56 }}>
          {row.map((b, j) => (
            <BigButton key={j} text={b.label} icon={b.icon} primary={b.primary} disabled={b.disabled} minHeight={56} large onClick={b.onClick} style={{ flex: `${b.weight ?? 1} 1 0`, height: 'auto' }} />
          ))}
        </div>
      ))}
      {confirmReset && <ConfirmDialog title={t('reset_brew_title')} body={t('reset_brew_body')} confirm={t('reset')} onConfirm={() => { setConfirmReset(false); s.sReset(); }} onDismiss={() => setConfirmReset(false)} />}
    </div>
  );
}
