// Recipes and coffee library: list on the left, detail or editor on the right (tablet), one at a time (phone).
import { useState } from 'react';
import { decodeSteps, formatClock, formatNumber, formatRatio, parseClock, parseNumber, ratio as ratioOf, today } from '../../core/coffee';
import { BrewMethod, Coffee, isEspresso, METHOD_KEYS, methodFromKey, Recipe, STEP_TYPES, StepType } from '../../core/models';
import { methodLabel } from '../../core/seed';
import { daysText, formatDay, t } from '../../i18n/i18n';
import { pickFile } from '../../platform/device';
import { useApp } from '../../state/store';
import type { Pane, RecipeDraft } from '../../state/types';
import {
  BigButton, Btn, Chip, CoffeePhoto, isWebPhoto, ConfirmDialog, EmptyState, Icon, IconButton, ListRow, Menu, NumField, Scroll, ScreenHeader,
  SectionTitle, SelectField, Stat, StepList, TextField, TwoPane, useMenu, useUnits,
} from '../components';
import { recipeSummary, recipeTimeText } from './Home';

const Placeholder = ({ text }: { text: string }) => <div className="center" style={{ flex: 1 }}><span className="title-medium muted">{text}</span></div>;
export const stepTypeLabel = (s: StepType) => t(`type_${s.toLowerCase()}`);

// ---- Recipes -----------------------------------------------------------------------------------------
export function RecipesScreen({ wide }: { wide: boolean }) {
  const recipes = useApp((s) => s.data.recipes);
  const pane = useApp((s) => s.recipePane);
  const draft = useApp((s) => s.recipeDraft);
  const selected = pane.kind === 'VIEW' ? recipes.find((r) => r.id === pane.id) : undefined;
  const detail = (showBack: boolean) =>
    pane.kind === 'EDIT' && draft ? <RecipeEditor d={draft} /> : selected ? <RecipeDetail r={selected} showBack={showBack} /> : <Placeholder text={t('select_recipe')} />;
  if (wide) return <TwoPane left={<RecipeList selectedId={selected?.id ?? null} />} right={<div className="page">{detail(false)}</div>} />;
  if (pane.kind === 'NONE' || (pane.kind === 'VIEW' && !selected)) return <div className="page"><RecipeList selectedId={null} /></div>;
  return <div className="page">{detail(true)}</div>;
}

function RecipeList({ selectedId }: { selectedId: number | null }) {
  const recipes = useApp((s) => s.data.recipes);
  const filter = useApp((s) => s.recipeMethodFilter);
  const defaultMethod = useApp((s) => s.settings.defaultMethod);
  const u = useUnits();
  const { newRecipe, set } = useApp.getState();
  const methods = METHOD_KEYS.filter((m) => recipes.some((r) => methodFromKey(r.method) === m));
  const shown = recipes.filter((r) => !filter || r.method === filter);
  return (
    <div className="col" style={{ flex: 1, minHeight: 0 }}>
      <ScreenHeader title={t('tab_recipes')}>
        <Btn kind="tonal" icon="add" onClick={() => newRecipe(filter ?? defaultMethod)} style={{ marginRight: 12 }}>{t('new_recipe')}</Btn>
      </ScreenHeader>
      {methods.length > 1 && (
        <div className="chips scrollable pad-h16" style={{ flex: '0 0 auto' }}>
          <Chip selected={filter == null} onClick={() => set({ recipeMethodFilter: null })}>{t('all')}</Chip>
          {methods.map((m) => <Chip key={m} selected={filter === m} onClick={() => set({ recipeMethodFilter: filter === m ? null : m })}>{methodLabel(m)}</Chip>)}
        </div>
      )}
      {shown.length === 0
        ? <EmptyState icon="menu_book" title={t('no_recipes_title')} body={t('no_recipes_body')} actionLabel={t('new_recipe')} onAction={() => newRecipe()} />
        : (
          <Scroll style={{ padding: '8px 4px 24px' }}>
            {shown.map((r) => (
              <ListRow key={r.id} title={r.name} subtitle={recipeSummary(r, u)} selected={r.id === selectedId}
                trailing={r.favorite ? <Icon name="star" style={{ color: 'var(--primary)' }} /> : undefined}
                onClick={() => set({ recipeDraft: null, recipePane: { kind: 'VIEW', id: r.id } })} />
            ))}
          </Scroll>
        )}
    </div>
  );
}

function RecipeDetail({ r, showBack }: { r: Recipe; showBack: boolean }) {
  const u = useUnits();
  const coffees = useApp((s) => s.data.coffees);
  const s = useApp.getState();
  const menu = useMenu();
  const [confirmDelete, setConfirmDelete] = useState(false);
  const method = methodFromKey(r.method);
  const steps = decodeSteps(r.stepsJson);
  const coffee = coffees.find((c) => c.id === r.coffeeId);
  return (
    <>
      <ScreenHeader title={r.name} onBack={showBack ? s.back : undefined}>
        <IconButton icon={r.favorite ? 'star' : 'star_border'} label={t(r.favorite ? 'unfavorite' : 'favorite')} color={r.favorite ? 'var(--primary)' : undefined} onClick={() => s.toggleFavorite(r)} />
        <IconButton icon="edit" label={t('edit')} onClick={() => s.editRecipe(r)} />
        <button type="button" className="icon-btn" aria-label={t('more')} onClick={menu.open}><Icon name="more_vert" /></button>
      </ScreenHeader>
      {menu.anchor && (
        <Menu anchor={menu.anchor} onDismiss={menu.close} items={[
          { label: t('duplicate'), onClick: () => void s.duplicateRecipe(r) },
          { label: t('diagnose'), onClick: () => s.diagnoseRecipe(r) },
          { label: t('compare'), onClick: () => { s.set({ compare: { ...s.compare, brews: false, aId: r.id } }); s.open('COMPARE'); } },
          { label: t('delete'), onClick: () => setConfirmDelete(true) },
        ]} />
      )}
      <Scroll className="pad-h20 pad-b24">
        <span className="body-large muted">{[methodLabel(method), coffee?.name].filter(Boolean).join(' · ')}</span>
        <div className="stats mt16">
          <Stat label={t('dose')} value={u.w(r.doseG)} />
          <Stat label={t(isEspresso(method) ? 'yield_label' : 'water')} value={u.w(r.waterG)} />
          <Stat label={t('ratio')} value={formatRatio(ratioOf(r.waterG, r.doseG))} />
          <Stat label={t('temperature')} value={u.t(r.tempC)} />
          {r.grind.trim() && <Stat label={t('grind')} value={r.grind} />}
          <Stat label={t('time')} value={recipeTimeText(r)} />
          {r.pressureBar != null && <Stat label={t('pressure')} value={`${formatNumber(r.pressureBar)} bar`} />}
        </div>
        <BigButton text={t('brew')} icon="play_arrow" primary onClick={() => s.brew(r)} className="mt20" style={{ width: '100%' }} />
        {steps.length > 0 && <><SectionTitle text={t('steps')} /><StepList steps={steps} currentIndex={-1} targetS={r.targetTimeS} started={false} /></>}
        {r.notes.trim() && <><SectionTitle text={t('notes')} /><p className="body-large pre-line" style={{ margin: 0 }}>{r.notes}</p></>}
      </Scroll>
      {confirmDelete && <ConfirmDialog title={t('delete_recipe_title')} body={t('delete_body', r.name)} confirm={t('delete')} onConfirm={() => { setConfirmDelete(false); s.deleteRecipe(r); }} onDismiss={() => setConfirmDelete(false)} />}
    </>
  );
}

function RecipeEditor({ d }: { d: RecipeDraft }) {
  const u = useUnits();
  const coffees = useApp((s) => s.data.coffees);
  const s = useApp.getState();
  const update = (n: RecipeDraft) => s.set({ recipeDraft: n });
  const num = (v: string) => { const x = parseNumber(v); return x != null && x > 0 ? x : null; };
  const setStep = (i: number, patch: Partial<RecipeDraft['steps'][number]>) => update({ ...d, steps: d.steps.map((x, j) => (j === i ? { ...x, ...patch } : x)) });
  const none = t('none');
  const bg = 'var(--surface)';
  return (
    <>
      <ScreenHeader title={t(d.id === 0 ? 'new_recipe' : 'edit_recipe')} onBack={s.closeRecipePane}>
        <Btn onClick={() => void s.saveRecipeDraft()} style={{ marginRight: 12 }}>{t('save')}</Btn>
      </ScreenHeader>
      <Scroll className="col gap12 pad-h20 pad-b32" style={{ paddingTop: 8 }}>
        <TextField value={d.name} onChange={(v) => update({ ...d, name: v })} label={t('name')} />
        <div className="row gap12">
          <SelectField className="grow" label={t('method')} value={d.method} options={METHOD_KEYS} optionLabel={methodLabel} onSelect={(m: BrewMethod) => update({ ...d, method: m })} />
          <Btn kind="outlined" onClick={() => s.applyTemplate(d.method)}>{t('use_template')}</Btn>
        </div>
        <SelectField label={t('coffee')} value={coffees.find((c) => c.id === d.coffeeId) ?? null} options={[null, ...coffees]} optionLabel={(c) => c?.name ?? none}
          onSelect={(c: Coffee | null) => update({ ...d, coffeeId: c?.id ?? null })} />
        <div className="row gap12">
          <NumField className="grow" value={d.dose} label={t('dose')} suffix={u.wLabel} error={num(d.dose) == null} bg={bg}
            onChange={(v) => { const dose = num(v); const r = num(d.ratio); update({ ...d, dose: v, water: dose != null && r != null ? formatNumber(dose * r) : d.water }); }} />
          <NumField className="grow" value={d.water} label={t(isEspresso(d.method) ? 'yield_label' : 'water')} suffix={u.wLabel} error={num(d.water) == null} bg={bg}
            onChange={(v) => { const w = num(v); const dose = num(d.dose); update({ ...d, water: v, ratio: dose != null && w != null ? formatNumber(w / dose) : d.ratio }); }} />
          <NumField className="grow" value={d.ratio} label={t('ratio_one_to')} bg={bg}
            onChange={(v) => { const r = num(v); const dose = num(d.dose); update({ ...d, ratio: v, water: dose != null && r != null ? formatNumber(dose * r) : d.water }); }} />
        </div>
        <div className="row gap12">
          <NumField className="grow" value={d.temp} label={t('temperature')} suffix={u.tLabel} onChange={(v) => update({ ...d, temp: v })} bg={bg} />
          <NumField className="grow" value={d.targetTime} label={t(isEspresso(d.method) ? 'time_seconds' : 'time_clock')} bg={bg}
            error={(parseClock(d.targetTime) ?? 0) <= 0} onChange={(v) => update({ ...d, targetTime: v })} />
        </div>
        <div className="row gap12">
          <TextField className="grow" value={d.grind} label={t('grind_setting')} onChange={(v) => update({ ...d, grind: v })} />
          {isEspresso(d.method) && <NumField className="grow" value={d.pressure} label={t('pressure')} suffix="bar" onChange={(v) => update({ ...d, pressure: v })} bg={bg} />}
        </div>
        <SectionTitle text={t('steps')} />
        {d.steps.map((st, i) => (
          <div key={i} className="col gap8" style={{ background: 'var(--surface-container-high)', borderRadius: 16, padding: 12 }}>
            <div className="row gap8">
              <NumField value={st.start} label={t('starts_at')} error={parseClock(st.start) == null} style={{ width: 104, flex: '0 0 104px' }} bg="var(--surface-container-high)" onChange={(v) => setStep(i, { start: v })} />
              <TextField className="grow" value={st.label} label={t('step_name')} bg="var(--surface-container-high)" onChange={(v) => setStep(i, { label: v })} />
              <IconButton icon="close" label={t('remove_step')} onClick={() => update({ ...d, steps: d.steps.filter((_, j) => j !== i) })} />
            </div>
            <div className="row gap8">
              <NumField className="grow" value={st.water} label={t('water_target')} suffix={u.wLabel} bg="var(--surface-container-high)" onChange={(v) => setStep(i, { water: v })} />
              <SelectField className="grow" label={t('type')} value={st.type} options={[...STEP_TYPES]} optionLabel={stepTypeLabel} bg="var(--surface-container-high)" onSelect={(v: StepType) => setStep(i, { type: v })} />
            </div>
            <TextField value={st.note} label={t('instruction')} multiline bg="var(--surface-container-high)" onChange={(v) => setStep(i, { note: v })} />
          </div>
        ))}
        <div><Btn kind="outlined" icon="add" onClick={() => {
          const last = d.steps.length ? parseClock(d.steps[d.steps.length - 1].start) ?? -30 : -30;
          update({ ...d, steps: [...d.steps, { label: '', type: 'POUR', start: formatClock(last + 30), water: '', note: '' }] });
        }}>{t('add_step')}</Btn></div>
        <TextField value={d.notes} label={t('notes')} multiline minRows={3} onChange={(v) => update({ ...d, notes: v })} />
      </Scroll>
    </>
  );
}

// ---- Coffee library ----------------------------------------------------------------------------------------
export function CoffeeScreen({ wide }: { wide: boolean }) {
  const coffees = useApp((s) => s.data.coffees);
  const pane: Pane = useApp((s) => s.coffeePane);
  const draft = useApp((s) => s.coffeeDraft);
  const selected = pane.kind === 'VIEW' ? coffees.find((c) => c.id === pane.id) : undefined;
  const detail = (showBack: boolean) =>
    pane.kind === 'EDIT' && draft ? <CoffeeEditor c={draft} /> : selected ? <CoffeeDetail c={selected} showBack={showBack} /> : <Placeholder text={t('select_coffee')} />;
  if (wide) return <TwoPane left={<CoffeeList selectedId={selected?.id ?? null} />} right={<div className="page">{detail(false)}</div>} />;
  if (pane.kind === 'NONE' || (pane.kind === 'VIEW' && !selected)) return <div className="page"><CoffeeList selectedId={null} /></div>;
  return <div className="page">{detail(true)}</div>;
}

function CoffeeList({ selectedId }: { selectedId: number | null }) {
  const coffees = useApp((s) => s.data.coffees);
  const current = useApp((s) => s.settings.currentCoffeeId);
  const { newCoffee, set } = useApp.getState();
  return (
    <div className="col" style={{ flex: 1, minHeight: 0 }}>
      <ScreenHeader title={t('tab_coffee')}>
        <Btn kind="tonal" icon="add" onClick={newCoffee} style={{ marginRight: 12 }}>{t('add_coffee')}</Btn>
      </ScreenHeader>
      {coffees.length === 0
        ? <EmptyState icon="coffee" title={t('no_coffee_title')} body={t('no_coffee_body')} actionLabel={t('add_coffee')} onAction={newCoffee} />
        : (
          <Scroll style={{ padding: '8px 4px 24px' }}>
            {coffees.map((c) => (
              <ListRow key={c.id} title={c.name} selected={c.id === selectedId}
                subtitle={[c.country.trim() || c.origin, c.process, c.roaster].filter((x) => x.trim()).join(' · ')}
                leading={<CoffeePhoto path={c.photoPath} size={52} />}
                trailing={c.id === current ? <span className="label-medium primary-text">{t('current')}</span> : undefined}
                onClick={() => set({ coffeeDraft: null, coffeePane: { kind: 'VIEW', id: c.id } })} />
            ))}
          </Scroll>
        )}
    </div>
  );
}

function CoffeeDetail({ c, showBack }: { c: Coffee; showBack: boolean }) {
  const u = useUnits();
  const recipes = useApp((s) => s.data.recipes);
  const brews = useApp((s) => s.data.brews);
  const current = useApp((s) => s.settings.currentCoffeeId);
  const s = useApp.getState();
  const [confirmDelete, setConfirmDelete] = useState(false);
  const coffeeBrews = brews.filter((b) => b.coffeeId === c.id);
  const rated = coffeeBrews.filter((b) => b.rating > 0);
  const best = rated.reduce<typeof rated[number] | null>((m, b) => (!m || b.rating > m.rating ? b : m), null);
  const linked = recipes.filter((r) => r.coffeeId === c.id);
  const field = (k: string, v: string) => (v.trim() ? <Stat key={k} label={t(k)} value={v} /> : null);
  const age = c.roastDateEpochDay != null ? today() - c.roastDateEpochDay : null;
  return (
    <>
      <ScreenHeader title={c.name} onBack={showBack ? s.back : undefined}>
        <IconButton icon="edit" label={t('edit')} onClick={() => s.editCoffee(c)} />
        <IconButton icon="delete" label={t('delete')} onClick={() => setConfirmDelete(true)} />
      </ScreenHeader>
      <Scroll className="pad-h20 pad-b24">
        {isWebPhoto(c.photoPath) && <div style={{ marginBottom: 16 }}><CoffeePhoto path={c.photoPath} alt={c.name} /></div>}
        {c.tastingNotes.trim() && <p className="title-large" style={{ margin: '0 0 16px' }}>{c.tastingNotes}</p>}
        <div className="stats">
          {field('origin', c.origin)}{field('country', c.country)}{field('region', c.region)}{field('producer', c.producer)}
          {field('variety', c.variety)}{field('process', c.process)}{field('altitude', c.altitude)}{field('roaster', c.roaster)}{field('roast_level', c.roastLevel)}
          {c.roastDateEpochDay != null && <Stat label={t('roast_date')} value={formatDay(c.roastDateEpochDay)} />}
          {age != null && age >= 0 && <Stat label={t('rest')} value={daysText(age)} />}
        </div>
        <div className="mt20">
          {c.id === current
            ? <span className="body-large primary-text">{t('current_coffee_hint')}</span>
            : <BigButton text={t('set_current')} primary minHeight={56} onClick={() => s.setCurrentCoffee(c.id)} style={{ width: '100%' }} />}
        </div>
        {coffeeBrews.length > 0 && (
          <>
            <SectionTitle text={t('tab_history')} />
            <div className="row gap28">
              <Stat label={t('brews')} value={String(coffeeBrews.length)} />
              {rated.length > 0 && <Stat label={t('avg_rating')} value={formatNumber(rated.reduce((a, b) => a + b.rating, 0) / rated.length)} />}
              {best && best.grind.trim() && <Stat label={t('best_grind')} value={best.grind} />}
            </div>
          </>
        )}
        <SectionTitle text={t('linked_recipes')} />
        {linked.length === 0 && <p className="body-large muted" style={{ margin: 0 }}>{t('no_linked_recipes')}</p>}
        {linked.map((r) => <ListRow key={r.id} title={r.name} subtitle={recipeSummary(r, u)} onClick={() => { s.selectTab('RECIPES'); s.set({ recipePane: { kind: 'VIEW', id: r.id } }); }} />)}
        <div className="mt8"><Btn kind="outlined" icon="add" onClick={() => s.newRecipe(undefined, c.id)}>{t('new_recipe_for_coffee')}</Btn></div>
      </Scroll>
      {confirmDelete && <ConfirmDialog title={t('delete_coffee_title')} body={t('delete_body', c.name)} confirm={t('delete')} onConfirm={() => { setConfirmDelete(false); s.deleteCoffee(c); }} onDismiss={() => setConfirmDelete(false)} />}
    </>
  );
}

const ROAST_LEVELS = ['roast_light', 'roast_medium_light', 'roast_medium', 'roast_medium_dark', 'roast_dark'];

function CoffeeEditor({ c }: { c: Coffee }) {
  const s = useApp.getState();
  const update = (n: Coffee) => s.set({ coffeeDraft: n });
  const iso = c.roastDateEpochDay != null ? new Date(c.roastDateEpochDay * 86_400_000).toISOString().slice(0, 10) : '';
  const tf = (k: keyof Coffee, label: string, className?: string, multiline = false) => (
    <TextField className={className} value={String(c[k] ?? '')} label={t(label)} multiline={multiline} onChange={(v) => update({ ...c, [k]: v })} />
  );
  return (
    <>
      <ScreenHeader title={t(c.id === 0 ? 'add_coffee' : 'edit_coffee')} onBack={s.closeCoffeePane}>
        <Btn onClick={() => void s.saveCoffeeDraft()} style={{ marginRight: 12 }}>{t('save')}</Btn>
      </ScreenHeader>
      <Scroll className="col gap12 pad-h20 pad-b32" style={{ paddingTop: 8 }}>
        {isWebPhoto(c.photoPath) && <CoffeePhoto path={c.photoPath} alt={t('photo')} />}
        {c.photoPath && !isWebPhoto(c.photoPath) && <span className="body-small muted">{t('web_photos_note')}</span>}
        <div className="row gap12">
          <Btn kind="outlined" icon="photo_camera" onClick={async () => { const f = await pickFile('image/*'); if (f) await s.attachPhoto(f); }}>{t(c.photoPath ? 'change_photo' : 'add_photo')}</Btn>
          {c.photoPath && <Btn kind="text" onClick={() => update({ ...c, photoPath: null })}>{t('remove_photo')}</Btn>}
        </div>
        {tf('name', 'name')}
        {tf('roaster', 'roaster')}
        <div className="row gap12">{tf('country', 'country', 'grow')}{tf('region', 'region', 'grow')}</div>
        {tf('origin', 'origin_farm')}
        <div className="row gap12">{tf('producer', 'producer', 'grow')}{tf('variety', 'variety', 'grow')}</div>
        <div className="row gap12">{tf('process', 'process', 'grow')}{tf('altitude', 'altitude', 'grow')}</div>
        {tf('tastingNotes', 'tasting_notes', undefined, true)}
        <span className="label-large">{t('roast_level')}</span>
        <div className="chips">
          {ROAST_LEVELS.map((k) => { const label = t(k); return <Chip key={k} selected={c.roastLevel === label} onClick={() => update({ ...c, roastLevel: c.roastLevel === label ? '' : label })}>{label}</Chip>; })}
        </div>
        <div className="row gap12">
          <TextField className="grow" type="date" value={iso} label={t('roast_date')} placeholder=" "
            onChange={(v) => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v); update({ ...c, roastDateEpochDay: m ? Math.floor(Date.UTC(+m[1], +m[2] - 1, +m[3]) / 86_400_000) : null }); }} />
          {c.roastDateEpochDay != null && <Btn kind="text" onClick={() => update({ ...c, roastDateEpochDay: null })}>{t('clear')}</Btn>}
        </div>
      </Scroll>
    </>
  );
}
