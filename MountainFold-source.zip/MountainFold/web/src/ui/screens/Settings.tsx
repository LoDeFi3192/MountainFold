// Settings and the four-step onboarding. No account.
import { useState } from 'react';
import { BrewMethod, FLEX_LAYOUTS, METHOD_KEYS, PALETTES, Palette, TempUnit, ThemeMode, WeightUnit, LayoutOverride } from '../../core/models';
import { GRINDER_PRESETS, methodLabel } from '../../core/seed';
import { LangSetting, t } from '../../i18n/i18n';
import { isIOS, isStandalone, pickFile, wakeLockSupported } from '../../platform/device';
import { useApp } from '../../state/store';
import {
  BigButton, Btn, Chip, ConfirmDialog, Icon, NumField, Scroll, ScreenHeader, SectionTitle, Segmented, SelectField, SwitchRow, TextField, useUnits,
} from '../components';
import { flexLayoutLabel } from './Brew';

const Label = ({ text }: { text: string }) => <div className="body-large" style={{ paddingTop: 12, paddingBottom: 6 }}>{text}</div>;
export const paletteLabel = (p: Palette) => t(`palette_${p.toLowerCase()}`);
const VERSION = '1.2.0';

export function SettingsScreen() {
  const settings = useApp((s) => s.settings);
  const langSetting = useApp((s) => s.langSetting);
  const u = useUnits();
  const s = useApp.getState();
  const set = s.setSettings;
  const [confirmReset, setConfirmReset] = useState(false);
  const [confirmImport, setConfirmImport] = useState(false);
  const [dose, setDose] = useState(u.wValue(settings.defaultDoseG));
  const ios = isIOS();
  return (
    <div className="page">
      <ScreenHeader title={t('settings')} onBack={s.back} />
      <Scroll>
        <div className="max640 pad-h20 pad-b40">
          <SectionTitle text={t('appearance')} />
          <Label text={t('theme')} />
          <Segmented<ThemeMode> value={settings.themeMode} options={[['SYSTEM', t('theme_system')], ['LIGHT', t('theme_light')], ['DARK', t('theme_dark')]]}
            onChange={(v) => set((x) => ({ ...x, themeMode: v }))} />
          <Label text={t('palette')} />
          <div className="chips">{PALETTES.map((p) => <Chip key={p} selected={settings.palette === p} onClick={() => set((x) => ({ ...x, palette: p }))}>{paletteLabel(p)}</Chip>)}</div>

          <SectionTitle text={t('brewing_section')} />
          <SelectField<BrewMethod> label={t('default_method')} value={settings.defaultMethod} options={METHOD_KEYS.filter((m) => m !== 'CUSTOM')} optionLabel={methodLabel}
            onSelect={(m) => set((x) => ({ ...x, defaultMethod: m }))} />
          <div className="mt12">
            <NumField value={dose} label={t('default_dose')} suffix={u.wLabel}
              onChange={(v) => { setDose(v); const g = u.parseW(v); if (g != null && g > 0) set((x) => ({ ...x, defaultDoseG: g })); }} />
          </div>
          <Label text={t('add_water_step')} />
          <div className="chips">{[10, 25, 50, 100].map((g) => <Chip key={g} selected={settings.waterStepG === g} onClick={() => set((x) => ({ ...x, waterStepG: g }))}>{u.w(g)}</Chip>)}</div>
          <SwitchRow title={t('auto_stop')} subtitle={t('auto_stop_hint')} checked={settings.autoStopAtTarget} onChange={(v) => set((x) => ({ ...x, autoStopAtTarget: v }))} />
          <SwitchRow title={t('keep_awake')} subtitle={wakeLockSupported() ? t('keep_awake_hint') : t('web_keep_awake_unsupported')} checked={settings.keepAwake} onChange={(v) => set((x) => ({ ...x, keepAwake: v }))} />
          <SwitchRow title={t('haptics')} subtitle={ios ? t('web_haptics_hint') : undefined} checked={settings.haptics} onChange={(v) => set((x) => ({ ...x, haptics: v }))} />
          <SwitchRow title={t('sounds')} subtitle={ios ? t('web_sounds_hint') : undefined} checked={settings.sounds} onChange={(v) => set((x) => ({ ...x, sounds: v }))} />
          {ios && <p className="body-medium muted" style={{ margin: '4px 0 0' }}>{t('web_background_note')}</p>}

          <SectionTitle text={t('desk_section')} />
          <Label text={t('layout_mode')} />
          <Segmented<LayoutOverride> value={settings.layoutOverride}
            options={[['AUTO', t('layout_auto')], ['CLOSED', t('layout_phone')], ['OPEN', t('layout_tablet')], ['FLEX', t('layout_desk')]]}
            onChange={(v) => set((x) => ({ ...x, layoutOverride: v }))} />
          <p className="body-medium muted" style={{ margin: '6px 0 0' }}>{t('layout_mode_hint_web')}</p>
          <Label text={t('flex_layout_web')} />
          <div className="chips">{FLEX_LAYOUTS.map((l) => <Chip key={l} selected={settings.flexLayout === l} onClick={() => set((x) => ({ ...x, flexLayout: l }))}>{flexLayoutLabel(l)}</Chip>)}</div>

          <SectionTitle text={t('units_language')} />
          <Label text={t('weight')} />
          <Segmented<WeightUnit> value={settings.weightUnit} options={[['G', 'g'], ['OZ', 'oz']]} onChange={(v) => set((x) => ({ ...x, weightUnit: v }))} />
          <Label text={t('temperature')} />
          <Segmented<TempUnit> value={settings.tempUnit} options={[['C', '°C'], ['F', '°F']]} onChange={(v) => set((x) => ({ ...x, tempUnit: v }))} />
          <Label text={t('language')} />
          <Segmented<LangSetting> value={langSetting} options={[['system', t('theme_system')], ['en', 'English'], ['fr', 'Français'], ['es', 'Español']]} onChange={s.setLanguage} />

          <SectionTitle text={t('data_section')} />
          <p className="body-large" style={{ margin: 0 }}>{t('privacy_line')}</p>
          <p className="body-medium muted" style={{ margin: '6px 0 0' }}>{t('web_storage_note')}</p>
          <div className="row gap12 wrap mt12">
            <Btn kind="outlined" icon="ios_share" onClick={() => void s.exportBackup()}>{t('export_backup')}</Btn>
            <Btn kind="outlined" icon="file_upload" onClick={() => setConfirmImport(true)}>{t('import_backup')}</Btn>
          </div>
          <p className="body-medium muted" style={{ margin: '6px 0 0' }}>{t('backup_hint_web')} {t('web_photos_note')}</p>
          <div className="mt12"><Btn kind="text" danger onClick={() => setConfirmReset(true)}>{t('reset_data')}</Btn></div>

          {!isStandalone() && (
            <>
              <SectionTitle text={t('web_install_title')} />
              <div className="row gap12" style={{ alignItems: 'flex-start' }}>
                <Icon name="add_to_home_screen" style={{ color: 'var(--primary)' }} />
                <p className="body-large" style={{ margin: 0 }}>{t(ios ? 'web_install_ios' : 'web_install_other')}</p>
              </div>
            </>
          )}

          <SectionTitle text={t('about')} />
          <p className="body-large" style={{ margin: 0 }}>Mountain Fold {VERSION}</p>
          <p className="body-medium muted" style={{ margin: 0 }}>{t('tagline')} · {t('web_version', VERSION)}</p>
          <p className="body-medium muted" style={{ margin: '6px 0 0' }}>{t('fonts_credit')}</p>
        </div>
      </Scroll>
      {confirmImport && (
        <ConfirmDialog title={t('import_backup')} body={t('import_body')} confirm={t('import_backup')} onDismiss={() => setConfirmImport(false)}
          onConfirm={async () => { setConfirmImport(false); const f = await pickFile('application/json,.json,text/plain'); if (f) await s.importBackup(f); }} />
      )}
      {confirmReset && (
        <ConfirmDialog title={t('reset_data')} body={t('reset_data_body')} confirm={t('reset')} onDismiss={() => setConfirmReset(false)}
          onConfirm={() => { setConfirmReset(false); void s.resetData(); }} />
      )}
    </div>
  );
}

// ---- onboarding: four short steps, no account ---------------------------------------------------------------
export function Onboarding() {
  const [step, setStep] = useState(0);
  const [methods, setMethods] = useState<BrewMethod[]>(['V60']);
  const [grinder, setGrinder] = useState('');
  const complete = useApp((s) => s.completeOnboarding);
  const langSetting = useApp((s) => s.langSetting);
  const setLanguage = useApp((s) => s.setLanguage);
  return (
    <div className="app" style={{ justifyContent: 'center', paddingTop: 'var(--sat)', paddingBottom: 'var(--sab)' }}>
      <div className="col" style={{ width: '100%', maxWidth: 560, padding: 24, height: '100%' }}>
        <Scroll className="col" style={{ justifyContent: 'center' }}>
          <div style={{ margin: 'auto 0' }}>
            {step === 0 && (
              <>
                <Icon name="terrain" size={56} style={{ color: 'var(--primary)' }} />
                <div className="display-small mt20">{t('onb_welcome')}</div>
                <div className="title-large primary-text mt8">{t('tagline')}</div>
                <p className="body-large muted" style={{ marginTop: 20 }}>{t('onb_postures_web')}</p>
                <div className="mt16"><Segmented<LangSetting> value={langSetting} options={[['system', t('theme_system')], ['en', 'EN'], ['fr', 'FR'], ['es', 'ES']]} onChange={setLanguage} /></div>
              </>
            )}
            {step === 1 && (
              <>
                <div className="headline-medium">{t('onb_methods')}</div>
                <div className="chips mt20">
                  {METHOD_KEYS.filter((m) => m !== 'CUSTOM').map((m) => (
                    <Chip key={m} selected={methods.includes(m)} onClick={() => setMethods(methods.includes(m) ? methods.filter((x) => x !== m) : [...methods, m])}>{methodLabel(m)}</Chip>
                  ))}
                </div>
              </>
            )}
            {step === 2 && (
              <>
                <div className="headline-medium">{t('onb_grinder')}</div>
                <div className="chips mt20">{GRINDER_PRESETS.map((g) => <Chip key={g} selected={grinder === g} onClick={() => setGrinder(grinder === g ? '' : g)}>{g}</Chip>)}</div>
                <div className="mt12"><TextField value={grinder} onChange={setGrinder} label={t('grinder_name')} /></div>
                <p className="body-medium muted" style={{ margin: '6px 0 0' }}>{t('onb_grinder_skip')}</p>
              </>
            )}
            {step === 3 && (
              <>
                <div className="display-small">{t('onb_ready')}</div>
                <p className="body-large muted mt12">{t('privacy_line')}</p>
                {!isStandalone() && <p className="body-large muted">{t(isIOS() ? 'web_install_ios' : 'web_install_other')}</p>}
              </>
            )}
          </div>
        </Scroll>
        <div className="row gap16" style={{ paddingTop: 12 }}>
          {step > 0 && <Btn kind="text" onClick={() => setStep(step - 1)}>{t('back')}</Btn>}
          <span className="grow" />
          <span className="label-large muted">{step + 1} / 4</span>
          <BigButton text={t(step < 3 ? 'next' : 'start_brewing')} primary minHeight={56} style={{ flex: '0 0 auto', minWidth: 140 }}
            onClick={() => (step < 3 ? setStep(step + 1) : void complete(methods, grinder))} />
        </div>
      </div>
    </div>
  );
}
