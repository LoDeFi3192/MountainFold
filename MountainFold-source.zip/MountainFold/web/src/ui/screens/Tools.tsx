// Calculator, Copilot diagnosis, comparison and grind advisor. Input left, answer right on a tablet.
import { ReactNode, useState } from 'react';
import { beverageEstimate, formatClock, formatNumber, formatRatio, parseClock, parseNumber, ratio as ratioOf, solve, Solve } from '../../core/coffee';
import { Cause, ChangeKind, diagnose, parseSymptoms, Variable } from '../../core/copilot';
import { Brew, BrewMethod, Coffee, Grinder, isEspresso, METHOD_KEYS, METHODS, methodFromKey, Recipe, Symptom, SYMPTOMS } from '../../core/models';
import { GRINDER_PRESETS, methodLabel } from '../../core/seed';
import { TrainProgress } from '../../core/train';
import { Units } from '../../core/units';
import { formatDate, t } from '../../i18n/i18n';
import { useApp } from '../../state/store';
import { CAUSE_KEY, changeTitleKey, changeWhyKey, lessonById, symptomKey } from '../../state/trainer';
import type { CalcState } from '../../state/types';
import {
  BigButton, Btn, Chip, EmptyState, Icon, IconButton, ListRow, NumField, Scroll, ScreenHeader, SectionTitle, Segmented, SelectField, Stat,
  TextField, TimerText, TwoPane, useUnits,
} from '../components';
import { brewSummary, brewTimeText, RatingBadge, recipeTimeText } from './Home';

function ToolScaffold({ title, wide, left, right }: { title: string; wide: boolean; left: ReactNode; right: ReactNode }) {
  const back = useApp((s) => s.back);
  return (
    <div className="page">
      <ScreenHeader title={title} onBack={back} />
      {wide ? (
        <TwoPane
          left={<Scroll className="pad-h28 pad-b24">{left}</Scroll>}
          right={<Scroll className="pad-h28" style={{ paddingTop: 16, paddingBottom: 16 }}>{right}</Scroll>}
        />
      ) : (
        <Scroll className="pad-h20 pad-b32">{left}<div className="mt20" />{right}</Scroll>
      )}
    </div>
  );
}

// ---- calculator -------------------------------------------------------------------------------------
function recalc(c: CalcState): CalcState {
  const r = solve(c.solve, parseNumber(c.dose), parseNumber(c.water), parseNumber(c.ratio));
  if (!r) return c;
  if (c.solve === 'WATER') return { ...c, water: formatNumber(r.waterG) };
  if (c.solve === 'COFFEE') return { ...c, dose: formatNumber(r.doseG) };
  return { ...c, ratio: formatNumber(r.ratio, 2) };
}

export function CalculatorScreen({ wide }: { wide: boolean }) {
  const u = useUnits();
  const c = useApp((s) => s.calc);
  const defaultMethod = useApp((s) => s.settings.defaultMethod);
  const { set, brewAdHoc } = useApp.getState();
  const update = (n: CalcState) => set({ calc: recalc(n) });
  const waterLabel = t(c.espresso ? 'yield_label' : 'water');
  const dose = u.parseW(c.dose);
  const water = u.parseW(c.water);
  const ratio = dose != null && water != null ? ratioOf(water, dose) : null;
  const seconds = parseClock(c.time);
  const method: BrewMethod = c.espresso ? 'ESPRESSO' : !isEspresso(defaultMethod) ? defaultMethod : 'V60';
  return (
    <ToolScaffold title={t('calculator')} wide={wide}
      left={
        <>
          <Segmented<boolean> value={c.espresso} options={[[false, t('filter')], [true, METHODS.ESPRESSO.label]]}
            onChange={(e) => update(e ? { espresso: true, solve: 'WATER', dose: u.wValue(18), water: u.wValue(36), ratio: '2', time: '', temp: '' } : { espresso: false, solve: 'WATER', dose: u.wValue(15), water: u.wValue(250), ratio: '16.7', time: '', temp: '' })} />
          <SectionTitle text={t('solve_for')} />
          <Segmented<Solve> value={c.solve} options={[['WATER', waterLabel], ['COFFEE', t('coffee')], ['RATIO', t('ratio')]]} onChange={(v) => update({ ...c, solve: v })} />
          <div className="col gap12 mt16">
            {c.solve !== 'COFFEE' && <NumField value={c.dose} onChange={(v) => update({ ...c, dose: v })} label={t('coffee')} suffix={u.wLabel} />}
            {c.solve !== 'WATER' && <NumField value={c.water} onChange={(v) => update({ ...c, water: v })} label={waterLabel} suffix={u.wLabel} />}
            {c.solve !== 'RATIO' && (
              <>
                <NumField value={c.ratio} onChange={(v) => update({ ...c, ratio: v })} label={t('ratio_one_to')} />
                <div className="chips">
                  {(c.espresso ? ['1.5', '2', '2.5', '3'] : ['15', '16', '16.7', '17']).map((r) => <Chip key={r} selected={c.ratio === r} onClick={() => update({ ...c, ratio: r })}>1:{r}</Chip>)}
                </div>
              </>
            )}
            <div className="row gap12">
              <NumField className="grow" value={c.time} onChange={(v) => set({ calc: { ...c, time: v } })} label={t(c.espresso ? 'time_seconds' : 'time_clock')} />
              <NumField className="grow" value={c.temp} onChange={(v) => set({ calc: { ...c, temp: v } })} label={t('temperature')} suffix={u.tLabel} />
            </div>
          </div>
        </>
      }
      right={
        <>
          <span className="label-medium upper primary-text">{c.solve === 'WATER' ? waterLabel : c.solve === 'COFFEE' ? t('coffee') : t('ratio')}</span>
          <div><TimerText size={wide ? 88 : 64} text={c.solve === 'WATER' ? (water != null ? u.w(water) : '–') : c.solve === 'COFFEE' ? (dose != null ? u.w(dose) : '–') : formatRatio(ratio)} /></div>
          <div className="stats mt16" style={{ rowGap: 12 }}>
            <Stat label={t('coffee')} value={dose != null ? u.w(dose) : '–'} />
            <Stat label={waterLabel} value={water != null ? u.w(water) : '–'} />
            <Stat label={t('ratio')} value={formatRatio(ratio)} />
            {dose != null && water != null && !c.espresso && <Stat label={t('in_the_cup')} value={`≈ ${u.w(beverageEstimate(water, dose, 'V60'))}`} />}
            {c.espresso && water != null && seconds != null && seconds > 0 && <Stat label={t('flow')} value={`${formatNumber(water / seconds)} g/s`} />}
          </div>
          <BigButton text={t('brew_with', methodLabel(method))} icon="play_arrow" primary className="mt24" style={{ width: '100%' }}
            disabled={!(dose != null && water != null && dose > 0 && water > 0)} onClick={() => brewAdHoc(method, dose!, water!, u.parseT(c.temp))} />
        </>
      }
    />
  );
}

// ---- diagnosis ---------------------------------------------------------------------------------------------
export const causeLabel = (c: Cause) => t(CAUSE_KEY[c]);
const VAR_KEY: Record<Variable, string> = {
  GRIND: 'grind', TEMPERATURE: 'temperature', DOSE: 'dose', YIELD: 'yield_label', RATIO: 'ratio', TIME: 'time',
  BLOOM: 'type_bloom', AGITATION: 'var_agitation', FRESHNESS: 'var_freshness', PUCK_PREP: 'var_puck',
};
export const symptomLabel = (s: Symptom) => t(symptomKey(s));
const timeText = (seconds: number, m: BrewMethod) => (isEspresso(m) ? `${seconds} s` : formatClock(seconds));

export function SymptomChips({ selected, onToggle }: { selected: Symptom[]; onToggle: (s: Symptom) => void }) {
  return <div className="chips">{SYMPTOMS.map((s) => <Chip key={s} selected={selected.includes(s)} onClick={() => onToggle(s)}>{symptomLabel(s)}</Chip>)}</div>;
}

export function TrainSuggestion({ lessonId }: { lessonId: string }) {
  const lang = useApp((s) => s.lang);
  const openLesson = useApp((s) => s.openLesson);
  const lesson = lessonById(lessonId);
  if (!lesson) return null;
  const title = lang === 'fr' ? lesson.title.fr ?? lesson.title.en : lang === 'es' ? lesson.title.es ?? lesson.title.en : lesson.title.en;
  return (
    <div className="tonal-box row gap12" style={{ padding: '14px 18px' }}>
      <Icon name="school" style={{ color: 'var(--primary)' }} />
      <div className="col grow">
        <span className="body-medium muted">{t('copilot_train_hint')}</span>
        <span className="title-medium">{title}</span>
      </div>
      <BigButton text={t('train_now')} minHeight={48} onClick={() => openLesson(lessonId)} style={{ flex: '0 0 auto' }} />
    </div>
  );
}

export function CompareTable({ titleA, titleB, rows }: { titleA: string; titleB: string; rows: CmpRow[] }) {
  return (
    <div className="col">
      <div className="row" style={{ padding: '8px 0' }}>
        <span style={{ flex: '0.9 1 0' }} />
        <span className="label-large muted ellipsis" style={{ flex: '1 1 0' }}>{titleA}</span>
        <span className="label-large muted ellipsis" style={{ flex: '1 1 0' }}>{titleB}</span>
      </div>
      {rows.map((r, i) => (
        <div key={i}>
          <hr className="divider" />
          <div className="row" style={{ padding: '12px 0' }}>
            <span className="body-medium muted" style={{ flex: '0.9 1 0' }}>{r.label}</span>
            <span className="title-medium" style={{ flex: '1 1 0' }}>{r.a}</span>
            <span className="title-medium" style={{ flex: '1 1 0', color: r.a !== r.b ? 'var(--primary)' : undefined }}>{r.b}</span>
          </div>
        </div>
      ))}
    </div>
  );
}

export function DiagnoseScreen({ wide }: { wide: boolean }) {
  const u = useUnits();
  const d = useApp((s) => s.diag);
  const s = useApp.getState();
  const back = s.back;
  const r = d.recipe;
  if (!r) {
    return (
      <div className="page">
        <ScreenHeader title={t('diagnose')} onBack={back} />
        <EmptyState icon="troubleshoot" title={t('diag_empty_title')} body={t('diag_empty_body')} />
      </div>
    );
  }
  const result = diagnose({ method: r.method, doseG: r.doseG, waterG: r.waterG, tempC: r.tempC, timeS: d.timeS, targetTimeS: r.targetTimeS, grind: r.grind, steps: r.steps, roastAgeDays: d.roastAgeDays }, d.symptoms);
  const waterLabel = t(isEspresso(r.method) ? 'yield_label' : 'water');
  let right: ReactNode;
  if (!result) right = <span className="title-large muted">{t('diag_pick')}</span>;
  else {
    const sg = result.suggestion;
    const grindChange = result.change === 'GRIND_FINER' || result.change === 'GRIND_COARSER';
    const grindAfter = !grindChange ? sg.grind.trim() || '–' : result.grindStepped ? sg.grind : t(result.change === 'GRIND_FINER' ? 'one_step_finer' : 'one_step_coarser');
    right = (
      <>
        <span className="label-medium upper primary-text">{t('probable_cause')}</span>
        <div className="headline-medium">{causeLabel(result.cause)}</div>
        <p className="body-large muted" style={{ margin: '8px 0 0' }}>{t('variables_involved')}  {result.variables.map((v) => t(VAR_KEY[v])).join(' · ')}</p>
        <div className="primary-box mt16">
          <span className="label-medium upper">{t('change_one_thing')}</span>
          <div className="headline-small mt4">{t(changeTitleKey(result.change))}</div>
          <p className="body-large" style={{ margin: '6px 0 0' }}>{t(changeWhyKey(result.change))}</p>
        </div>
        <SectionTitle text={t('suggested_recipe')} />
        <CompareTable titleA={t('current')} titleB={t('suggestion')} rows={[
          { label: t('dose'), a: u.w(r.doseG), b: u.w(sg.doseG) },
          { label: waterLabel, a: u.w(r.waterG), b: u.w(sg.waterG) },
          { label: t('ratio'), a: formatRatio(ratioOf(r.waterG, r.doseG)), b: formatRatio(ratioOf(sg.waterG, sg.doseG)) },
          { label: t('temperature'), a: u.t(r.tempC), b: u.t(sg.tempC) },
          { label: t('grind'), a: r.grind.trim() || '–', b: grindAfter },
          { label: t('target'), a: timeText(r.targetTimeS, r.method), b: (result.timeIsEstimate ? '≈ ' : '') + timeText(sg.targetTimeS, r.method) },
        ]} />
        <p className="body-medium muted" style={{ margin: '8px 0 0' }}>{t(result.grindStepped ? 'grind_assumption' : result.recipeChanged || grindChange ? 'rest_unchanged' : 'technique_only')}</p>
        <BigButton text={t('brew_suggestion')} icon="play_arrow" primary minHeight={56} className="mt20" style={{ width: '100%' }}
          onClick={() => { const x = s.suggestedSession(result); if (x) s.brew({ ...x, recipeId: null }); }} />
        {result.recipeChanged && <BigButton text={t('save_as_recipe')} minHeight={56} className="mt8" style={{ width: '100%', marginTop: 10 }} onClick={() => void s.saveSuggestion(result)} />}
        <div className="mt16"><TrainSuggestion lessonId={TrainProgress.lessonForDiagnosis(result, isEspresso(r.method))} /></div>
      </>
    );
  }
  return (
    <ToolScaffold title={t('diagnose')} wide={wide}
      left={
        <>
          <div className="headline-small">{d.title}</div>
          <span className="body-large muted">{[r.coffeeName, methodLabel(r.method)].filter((x) => x.trim()).join(' · ')}</span>
          <div className="stats mt16" style={{ rowGap: 12 }}>
            <Stat label={t('dose')} value={u.w(r.doseG)} />
            <Stat label={waterLabel} value={u.w(r.waterG)} />
            <Stat label={t('temperature')} value={u.t(r.tempC)} />
            <Stat label={t('time')} value={timeText(d.timeS ?? r.targetTimeS, r.method)} />
            {r.grind.trim() && <Stat label={t('grind')} value={r.grind} />}
          </div>
          <SectionTitle text={t('how_did_it_taste')} />
          <SymptomChips selected={d.symptoms} onToggle={(x) => s.set({ diag: { ...d, symptoms: d.symptoms.includes(x) ? d.symptoms.filter((y) => y !== x) : [...d.symptoms, x] } })} />
        </>
      }
      right={right}
    />
  );
}

// ---- comparison ------------------------------------------------------------------------------------------------
export interface CmpRow { label: string; a: string; b: string }

function recipeRows(a: Recipe | undefined, b: Recipe | undefined, coffees: Coffee[], u: Units): CmpRow[] {
  const v = (r: Recipe | undefined, f: (r: Recipe) => string) => (r ? f(r) : '–');
  const coffee = (r: Recipe) => coffees.find((c) => c.id === r.coffeeId)?.name ?? '–';
  const row = (label: string, f: (r: Recipe) => string): CmpRow => ({ label, a: v(a, f), b: v(b, f) });
  return [
    row(t('method'), (r) => METHODS[methodFromKey(r.method)].label), row(t('coffee'), coffee), row(t('dose'), (r) => u.w(r.doseG)),
    row(t('water'), (r) => u.w(r.waterG)), row(t('ratio'), (r) => formatRatio(ratioOf(r.waterG, r.doseG))), row(t('temperature'), (r) => u.t(r.tempC)),
    row(t('grind'), (r) => r.grind.trim() || '–'), row(t('time'), recipeTimeText),
  ];
}

function brewRows(a: Brew | undefined, b: Brew | undefined, u: Units): CmpRow[] {
  const v = (x: Brew | undefined, f: (x: Brew) => string) => (x ? f(x) : '–');
  const level = (n: number) => (n > 0 ? `${n} / 5` : '–');
  const sym = (x: Brew | undefined) => (x ? parseSymptoms(x.symptoms).map(symptomLabel).join(', ') : '') || '–';
  const row = (label: string, f: (x: Brew) => string): CmpRow => ({ label, a: v(a, f), b: v(b, f) });
  return [
    row(t('coffee'), (x) => x.coffeeName.trim() || '–'), row(t('method'), (x) => METHODS[methodFromKey(x.method)].label),
    row(t('dose'), (x) => u.w(x.doseG)), row(t('water'), (x) => u.w(x.waterG)), row(t('ratio'), (x) => formatRatio(ratioOf(x.waterG, x.doseG))),
    row(t('temperature'), (x) => u.t(x.tempC)), row(t('grind'), (x) => x.grind.trim() || '–'), row(t('grinder'), (x) => x.grinderName.trim() || '–'),
    row(t('time'), brewTimeText), row(t('rating'), (x) => level(x.rating)), row(t('acidity'), (x) => level(x.acidity)),
    row(t('sweetness'), (x) => level(x.sweetness)), row(t('body'), (x) => level(x.body)), row(t('balance'), (x) => level(x.balance)),
    row(t('clarity'), (x) => level(x.clarity)), { label: t('what_was_off'), a: sym(a), b: sym(b) },
  ];
}

function CompareSide({ title, selector, rows, pick }: { title: string; selector: ReactNode; rows: CmpRow[]; pick: (r: CmpRow) => string }) {
  return (
    <>
      <span className="label-medium primary-text">{title}</span>
      <div className="mt8">{selector}</div>
      <div className="mt8">
        {rows.map((r, i) => (
          <div key={i}>
            <hr className="divider" />
            <div className="row" style={{ padding: '12px 0' }}>
              <span className="body-medium muted" style={{ flex: '0.8 1 0' }}>{r.label}</span>
              <span className="title-medium" style={{ flex: '1 1 0', color: r.a !== r.b ? 'var(--primary)' : undefined }}>{pick(r)}</span>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

export function CompareScreen({ wide }: { wide: boolean }) {
  const u = useUnits();
  const c = useApp((s) => s.compare);
  const recipes = useApp((s) => s.data.recipes);
  const brews = useApp((s) => s.data.brews);
  const coffees = useApp((s) => s.data.coffees);
  const set = useApp((s) => s.set);
  const rows = c.brews ? brewRows(brews.find((b) => b.id === c.aId), brews.find((b) => b.id === c.bId), u)
    : recipeRows(recipes.find((r) => r.id === c.aId), recipes.find((r) => r.id === c.bId), coffees, u);
  const brewName = (b: Brew) => `${b.coffeeName.trim() || b.recipeName} · ${formatDate(b.createdAt)}`;
  const selector = (isA: boolean) => {
    const id = isA ? c.aId : c.bId;
    const setId = (v: number | null) => set({ compare: isA ? { ...c, aId: v } : { ...c, bId: v } });
    return c.brews
      ? <SelectField label={t('brew_label')} value={brews.find((b) => b.id === id) ?? null} options={brews.slice(0, 40)} optionLabel={(b) => (b ? brewName(b) : t('pick_one'))} onSelect={(b) => setId(b?.id ?? null)} />
      : <SelectField label={t('recipe')} value={recipes.find((r) => r.id === id) ?? null} options={recipes} optionLabel={(r) => r?.name ?? t('pick_one')} onSelect={(r) => setId(r?.id ?? null)} />;
  };
  const mode = (
    <div style={{ marginBottom: 16 }}>
      <Segmented<boolean> value={c.brews} options={[[false, t('tab_recipes')], [true, t('brews')]]} onChange={(v) => set({ compare: { brews: v, aId: null, bId: null } })} />
    </div>
  );
  const labelA = t(c.brews ? 'brew_a' : 'recipe_a');
  const labelB = t(c.brews ? 'brew_b' : 'recipe_b');
  return wide
    ? <ToolScaffold title={t('compare')} wide left={<>{mode}<CompareSide title={labelA} selector={selector(true)} rows={rows} pick={(r) => r.a} /></>}
      right={<><div style={{ height: 40 }} /><CompareSide title={labelB} selector={selector(false)} rows={rows} pick={(r) => r.b} /></>} />
    : <ToolScaffold title={t('compare')} wide={false} left={<>{mode}<div className="col gap12">{selector(true)}{selector(false)}</div></>} right={<CompareTable titleA="A" titleB="B" rows={rows} />} />;
}

// ---- grind advisor -----------------------------------------------------------------------------------------------
export function GrindAdvisorScreen({ wide }: { wide: boolean }) {
  const u = useUnits();
  const grinders = useApp((s) => s.data.grinders);
  const brews = useApp((s) => s.data.brews);
  const coffees = useApp((s) => s.data.coffees);
  const f = useApp((s) => s.grindFilter);
  const defaultGrinderId = useApp((s) => s.settings.defaultGrinderId);
  const s = useApp.getState();
  const [newName, setNewName] = useState('');
  const all = t('all');
  const matching = brews.filter((b) => b.grind.trim() && (f.grinderId == null || b.grinderId === f.grinderId) && (f.coffeeId == null || b.coffeeId === f.coffeeId) && (f.method == null || b.method === f.method));
  let right: ReactNode;
  if (matching.length === 0) right = <EmptyState icon="tune" title={t('no_grind_title')} body={t('no_grind_body')} />;
  else {
    const best = matching.filter((b) => b.rating > 0).reduce<Brew | null>((m, b) => (!m || b.rating > m.rating || (b.rating === m.rating && b.createdAt > m.createdAt) ? b : m), null);
    const last = matching[0];
    const timeS = Math.floor(last.timeMs / 1000);
    const advice = diagnose({ method: methodFromKey(last.method), doseG: last.doseG, waterG: last.waterG, tempC: last.tempC, timeS: timeS > 0 ? timeS : null, targetTimeS: last.targetTimeS > 0 ? last.targetTimeS : timeS, grind: last.grind }, parseSymptoms(last.symptoms));
    const grindAdvice = advice && (advice.change === 'GRIND_FINER' || advice.change === 'GRIND_COARSER') ? advice : null;
    right = (
      <>
        <div className="stats" style={{ rowGap: 12 }}>
          {best && <Stat label={t('best_grind')} value={`${best.grind} · ★${best.rating}`} valueClass="headline-small" />}
          <Stat label={t('last_setting')} value={last.grind} valueClass="headline-small" />
        </div>
        <div className="primary-box mt16">
          <span className="label-medium upper">{t('next_brew')}</span>
          {grindAdvice ? (
            <>
              <div className="headline-small mt4">{t(changeTitleKey(grindAdvice.change as ChangeKind))}</div>
              {grindAdvice.grindStepped && <div className="title-large">{last.grind} → {grindAdvice.suggestion.grind}</div>}
              <p className="body-large" style={{ margin: 0 }}>{t(changeWhyKey(grindAdvice.change))}</p>
            </>
          ) : (
            <>
              <div className="headline-small mt4">{t('keep_grind')}</div>
              <p className="body-large" style={{ margin: 0 }}>{advice ? t('keep_grind_other', t(changeTitleKey(advice.change))) : t('keep_grind_body')}</p>
            </>
          )}
        </div>
        <SectionTitle text={t('grind_history')} />
        {matching.slice(0, 60).map((b) => (
          <ListRow key={b.id} title={b.grind + (b.grinderName.trim() ? `  ·  ${b.grinderName}` : '')}
            subtitle={`${b.coffeeName.trim() || b.recipeName} · ${brewSummary(b, u)}\n${formatDate(b.createdAt)}`}
            trailing={b.rating > 0 ? <RatingBadge rating={b.rating} /> : undefined}
            onClick={() => { s.selectTab('HISTORY'); s.set({ historySel: b.id }); }} />
        ))}
      </>
    );
  }
  return (
    <ToolScaffold title={t('grind_advisor')} wide={wide}
      left={
        <>
          <SectionTitle text={t('your_grinders')} />
          {grinders.length === 0 && <p className="body-large muted" style={{ margin: 0 }}>{t('no_grinders')}</p>}
          {grinders.map((g) => (
            <div key={g.id} className="row" role="radio" aria-checked={g.id === defaultGrinderId} style={{ cursor: 'pointer', minHeight: 48 }}
              onClick={() => s.setSettings((x) => ({ ...x, defaultGrinderId: g.id }))}>
              <span style={{ width: 48, display: 'inline-flex', justifyContent: 'center' }}>
                <span style={{ width: 20, height: 20, borderRadius: 10, boxShadow: `inset 0 0 0 2px ${g.id === defaultGrinderId ? 'var(--primary)' : 'var(--on-surface-variant)'}`, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
                  {g.id === defaultGrinderId && <span style={{ width: 10, height: 10, borderRadius: 5, background: 'var(--primary)' }} />}
                </span>
              </span>
              <span className="body-large grow">{g.name}</span>
              <IconButton icon="close" label={t('remove_grinder', g.name)} onClick={() => s.deleteGrinder(g.id)} />
            </div>
          ))}
          <div className="row gap8 mt8">
            <TextField className="grow" value={newName} onChange={setNewName} label={t('grinder_name')} />
            <Btn kind="outlined" disabled={!newName.trim()} onClick={() => { s.addGrinder(newName); setNewName(''); }}>{t('add')}</Btn>
          </div>
          <div className="mt8">
            <SelectField<string | null> label={t('common_grinders')} value={null} options={GRINDER_PRESETS.filter((p) => !grinders.some((g) => g.name === p))}
              optionLabel={(x) => x ?? t('pick_one')} onSelect={(x) => x && s.addGrinder(x)} />
          </div>
          <SectionTitle text={t('filter_history')} />
          <div className="col gap12">
            <SelectField<Grinder | null> label={t('grinder')} value={grinders.find((g) => g.id === f.grinderId) ?? null} options={[null, ...grinders]} optionLabel={(g) => g?.name ?? all}
              onSelect={(g) => s.set({ grindFilter: { ...f, grinderId: g?.id ?? null } })} />
            <SelectField<Coffee | null> label={t('coffee')} value={coffees.find((c) => c.id === f.coffeeId) ?? null} options={[null, ...coffees]} optionLabel={(c) => c?.name ?? all}
              onSelect={(c) => s.set({ grindFilter: { ...f, coffeeId: c?.id ?? null } })} />
            <SelectField<BrewMethod | null> label={t('method')} value={f.method} options={[null, ...METHOD_KEYS]} optionLabel={(m) => (m ? methodLabel(m) : all)}
              onSelect={(m) => s.set({ grindFilter: { ...f, method: m } })} />
          </div>
        </>
      }
      right={right}
    />
  );
}
