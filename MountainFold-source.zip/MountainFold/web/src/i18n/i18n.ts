// EN / FR / ES strings, generated from the same table as the Android app (tools/build_data.py).
import table from './strings.json';

export type Lang = 'en' | 'fr' | 'es';
export type LangSetting = 'system' | Lang;
const STRINGS = table as unknown as Record<string, [string, string, string]>;
const INDEX: Record<Lang, number> = { en: 0, fr: 1, es: 2 };

export function systemLang(): Lang {
  const langs = (typeof navigator !== 'undefined' ? navigator.languages ?? [navigator.language] : ['en']) as string[];
  for (const l of langs) {
    const p = (l || '').slice(0, 2).toLowerCase();
    if (p === 'fr' || p === 'es' || p === 'en') return p;
  }
  return 'en';
}

let current: Lang = 'en';
export const setLang = (l: Lang) => { current = l; if (typeof document !== 'undefined') document.documentElement.lang = l; };
export const lang = () => current;
export const resolveLang = (s: LangSetting): Lang => (s === 'system' ? systemLang() : s);

/** Android-style placeholders: %1$s, %2$d. */
export function t(key: string, ...args: (string | number)[]): string {
  const row = STRINGS[key];
  if (!row) return key;
  let text = row[INDEX[current]] ?? row[0];
  if (args.length) text = text.replace(/%(\d)\$([sd])/g, (_, n: string) => String(args[Number(n) - 1] ?? ''));
  // French typography: the space before ? ! : ; and inside guillemets never breaks.
  return current === 'fr' ? text.replace(/ ([?!:;»])/g, '\u00A0$1').replace(/« /g, '«\u00A0') : text;
}

export const hasKey = (key: string) => key in STRINGS;

/** BCP 47 locale for dates and numbers. */
export const locale = () => (current === 'fr' ? 'fr-FR' : current === 'es' ? 'es-ES' : 'en-GB');

export function formatDate(ms: number, withTime = true): string {
  try {
    return new Intl.DateTimeFormat(locale(), withTime ? { dateStyle: 'medium', timeStyle: 'short' } : { dateStyle: 'medium' }).format(new Date(ms));
  } catch {
    return new Date(ms).toLocaleString();
  }
}

/** Short date with a four digit year, like toLocaleDateString() in the cupping app. */
export function shortDate(ms: number): string {
  try {
    return new Intl.DateTimeFormat(locale(), { day: '2-digit', month: '2-digit', year: 'numeric' }).format(new Date(ms));
  } catch {
    return new Date(ms).toLocaleDateString();
  }
}

export function shortDateIso(iso: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
  if (!m) return iso;
  return shortDate(new Date(+m[1], +m[2] - 1, +m[3]).getTime());
}

/** A calendar day (days since 1970-01-01) in the local medium format, without time zone drift. */
export function formatDay(epochDay: number): string {
  const d = new Date(epochDay * 86_400_000);
  return formatDate(new Date(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()).getTime(), false);
}

export const daysText = (n: number) => (n === 1 ? t('day_one') : t('days_count', n));
