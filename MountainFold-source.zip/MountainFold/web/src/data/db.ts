// Local storage of the web app: IndexedDB, one object store per Android table. No server, no account.
import { openDB, IDBPDatabase } from 'idb';
import type { Brew, Coffee, CuppingCoffee, CuppingSession, Grinder, LabRecipe, Recipe, Settings, TrainingEvent } from '../core/models';

export interface AppData {
  coffees: Coffee[];
  recipes: Recipe[];
  brews: Brew[];
  grinders: Grinder[];
  training: TrainingEvent[];
  cuppingSessions: CuppingSession[];
  cuppingCoffees: CuppingCoffee[];
  labRecipes: LabRecipe[];
}

export type TableName = keyof AppData;
export const TABLES: TableName[] = ['coffees', 'recipes', 'brews', 'grinders', 'training', 'cuppingSessions', 'cuppingCoffees', 'labRecipes'];

export const emptyData = (): AppData => ({
  coffees: [], recipes: [], brews: [], grinders: [], training: [], cuppingSessions: [], cuppingCoffees: [], labRecipes: [],
});

const DB_NAME = 'mountain-fold';
let dbp: Promise<IDBPDatabase> | null = null;

function db(): Promise<IDBPDatabase> {
  if (!dbp) {
    dbp = openDB(DB_NAME, 1, {
      upgrade(d) {
        for (const t of TABLES) d.createObjectStore(t, { keyPath: 'id' });
        d.createObjectStore('photos');
        d.createObjectStore('kv');
      },
    });
  }
  return dbp;
}

export async function loadAll(): Promise<{ data: AppData; settings: Partial<Settings> | null }> {
  const d = await db();
  const data = emptyData();
  const tx = d.transaction([...TABLES, 'kv'], 'readonly');
  await Promise.all(TABLES.map(async (t) => { (data as unknown as Record<string, unknown[]>)[t] = await tx.objectStore(t).getAll(); }));
  const settings = (await tx.objectStore('kv').get('settings')) ?? null;
  await tx.done;
  return { data, settings };
}

/** Writes are queued so they land in order even when the UI fires them quickly. */
let queue: Promise<unknown> = Promise.resolve();
function enqueue<T>(job: () => Promise<T>): Promise<T> {
  const next = queue.then(job, job);
  queue = next.catch(() => undefined);
  return next;
}
export const flushWrites = () => queue;

export const putRow = (table: TableName, row: object) => enqueue(async () => (await db()).put(table, row));
export const putRows = (table: TableName, rows: object[]) =>
  enqueue(async () => {
    const tx = (await db()).transaction(table, 'readwrite');
    await Promise.all(rows.map((r) => tx.store.put(r)));
    await tx.done;
  });
export const deleteRow = (table: TableName, id: number | string) => enqueue(async () => (await db()).delete(table, id));
export const deleteRows = (table: TableName, ids: (number | string)[]) =>
  enqueue(async () => {
    const tx = (await db()).transaction(table, 'readwrite');
    await Promise.all(ids.map((id) => tx.store.delete(id)));
    await tx.done;
  });
export const saveSettings = (s: Settings) => enqueue(async () => (await db()).put('kv', s, 'settings'));

/** Replaces every table at once (restore, reset). Photos are kept unless [photos] is given. */
export const replaceAll = (data: AppData, settings: Settings, photos?: Record<string, Blob>) =>
  enqueue(async () => {
    const d = await db();
    const stores = [...TABLES, 'kv', ...(photos ? ['photos'] : [])];
    const tx = d.transaction(stores, 'readwrite');
    for (const t of TABLES) {
      const s = tx.objectStore(t);
      await s.clear();
      for (const row of data[t] as object[]) await s.put(row);
    }
    await tx.objectStore('kv').put(settings, 'settings');
    if (photos) {
      const p = tx.objectStore('photos');
      await p.clear();
      for (const [k, v] of Object.entries(photos)) await p.put(v, k);
    }
    await tx.done;
  });

// ---- photos ------------------------------------------------------------------------------------

export const putPhoto = (key: string, blob: Blob) => enqueue(async () => (await db()).put('photos', blob, key));
export const getPhoto = async (key: string): Promise<Blob | undefined> => (await db()).get('photos', key);
export const deletePhoto = (key: string) => enqueue(async () => (await db()).delete('photos', key));
export async function allPhotos(): Promise<Record<string, Blob>> {
  const d = await db();
  const tx = d.transaction('photos');
  const keys = await tx.store.getAllKeys();
  const out: Record<string, Blob> = {};
  for (const k of keys) {
    const v = await tx.store.get(k);
    if (v) out[String(k)] = v as Blob;
  }
  await tx.done;
  return out;
}

// ---- small synchronous values (active brew, language) ------------------------------------------

export function readLocal<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

export function writeLocal(key: string, value: unknown) {
  try {
    if (value == null) localStorage.removeItem(key);
    else localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* private mode or quota: the app keeps working in memory */
  }
}

/** Asks the browser not to evict our data. Supported by Safari 17+ and Chromium. */
export async function persistStorage(): Promise<boolean> {
  try {
    if (navigator.storage?.persisted && (await navigator.storage.persisted())) return true;
    return (await navigator.storage?.persist?.()) ?? false;
  } catch {
    return false;
  }
}
