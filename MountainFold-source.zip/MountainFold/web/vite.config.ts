import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

// Static build: any HTTPS host works (Vercel, Cloudflare Pages, Netlify). The service worker caches the
// whole app, so after the first visit it opens offline from the iPhone home screen.
export default defineConfig({
  base: './',
  plugins: [
    react(),
    VitePWA({
      registerType: 'prompt',
      injectRegister: null,
      includeAssets: ['icons/*.png', 'favicon.svg', 'licenses/*.txt'],
      manifest: {
        name: 'Mountain Fold',
        short_name: 'Mountain Fold',
        description: 'Your coffee copilot. Brew, recipes, coffees, cupping and barista training.',
        id: './',
        start_url: './',
        scope: './',
        display: 'standalone',
        orientation: 'any',
        background_color: '#1F1A16',
        theme_color: '#1F1A16',
        lang: 'fr',
        categories: ['food', 'lifestyle', 'education'],
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
          { src: 'icons/icon-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
        shortcuts: [
          { name: 'Brew', url: './?tab=brew', icons: [{ src: 'icons/icon-192.png', sizes: '192x192' }] },
          { name: 'New cupping session', short_name: 'Cupping', url: './?action=new_session', icons: [{ src: 'icons/icon-192.png', sizes: '192x192' }] },
        ],
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,svg,png,woff2,json,txt}'],
        navigateFallback: 'index.html',
        cleanupOutdatedCaches: true,
        maximumFileSizeToCacheInBytes: 4 * 1024 * 1024,
      },
    }),
  ],
  build: { target: 'es2020', sourcemap: false, chunkSizeWarningLimit: 1200 },
  test: { environment: 'node', include: ['tests/**/*.test.ts'] },
} as never);
