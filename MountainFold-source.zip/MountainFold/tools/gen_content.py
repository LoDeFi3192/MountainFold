#!/usr/bin/env python3
"""Builds assets/train/content.json from tools/content and checks it. One table, three languages."""
import json, os, sys
here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(here, "content"))
import part1, part2, part3

lessons = part1.LESSONS + part2.LESSONS
bank = part2.BANK
for l in lessons:
    if "brewTask" not in l and l["id"] in part3.BREW_TASKS:
        l["brewTask"] = part3.BREW_TASKS[l["id"]]
unknown = set(part3.BREW_TASKS) - {l["id"] for l in lessons}
errors = []

def check_text(where, d):
    for lang in ("en", "fr", "es"):
        if not isinstance(d.get(lang), str) or not d[lang].strip():
            errors.append(f"{where}: missing {lang}")
    for lang, v in d.items():
        if "—" in v or "  " in v:
            errors.append(f"{where}: bad punctuation in {lang}")

ids = set()
def check_question(qq, where):
    if qq["id"] in ids: errors.append(f"duplicate id {qq['id']}")
    ids.add(qq["id"])
    check_text(where + ".prompt", qq["prompt"]); check_text(where + ".why", qq["why"])
    if not 3 <= len(qq["options"]) <= 4: errors.append(f"{where}: {len(qq['options'])} options")
    for i, o in enumerate(qq["options"]): check_text(f"{where}.opt{i}", o)
    for lang in ("en", "fr", "es"):
        texts = [o[lang] for o in qq["options"]]
        if len(set(texts)) != len(texts): errors.append(f"{where}: duplicate options in {lang}")
    if qq["correct"] != 0: errors.append(f"{where}: correct must be 0")

if unknown: errors.append(f"brew tasks for unknown lessons: {unknown}")
for l in lessons:
    if "brewTask" in l: check_text(l["id"] + ".brewTask", l["brewTask"])
    if l["id"] in ids: errors.append(f"duplicate id {l['id']}")
    ids.add(l["id"])
    check_text(l["id"] + ".title", l["title"])
    for i, o in enumerate(l["objectives"]): check_text(f"{l['id']}.obj{i}", o)
    for i, b in enumerate(l["blocks"]): check_text(f"{l['id']}.b{i}.title", b["title"]); check_text(f"{l['id']}.b{i}.body", b["body"])
    if len(l["questions"]) < 3: errors.append(f"{l['id']}: needs 3 questions")
    for qq in l["questions"]: check_question(qq, qq["id"])
    if l["sim"] != "NONE" and "simHint" not in l: errors.append(f"{l['id']}: sim without hint")
for qq in bank:
    check_question(qq, qq["id"])
    if "skill" not in qq: errors.append(f"{qq['id']}: bank question needs a skill")

out = os.path.join(here, "..", "app", "src", "main", "assets", "train", "content.json")
os.makedirs(os.path.dirname(out), exist_ok=True)
json.dump({"version": 1, "lessons": lessons, "bank": bank}, open(out, "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
by_level = {}
for l in lessons: by_level.setdefault(l["level"], []).append(l["id"])
skills = sorted({l["skill"] for l in lessons} | {b["skill"] for b in bank})
print(f"{len(lessons)} lessons, {sum(len(l['questions']) for l in lessons)} lesson questions, {len(bank)} bank questions, {os.path.getsize(out)//1024} KB")
print("levels:", {k: by_level[k] for k in sorted(by_level)})
print("skills:", skills)
print("errors:", errors)
sys.exit(1 if errors else 0)
