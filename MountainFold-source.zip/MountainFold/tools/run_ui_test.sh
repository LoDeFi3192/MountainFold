#!/bin/sh
# Runs one scenario test class (default: both) and prints a compact result. Renders land in app/build/shots.
cd "$(dirname "$0")/.." || exit 1
LOG="${TMPDIR:-/tmp}/mf-ui-test.log"
FILTER="${1:-*ScenarioTest*}"
rm -f app/build/test-results/testDebugUnitTest/*Scenario*.xml
gradle -q :app:testDebugUnitTest --tests "$FILTER" > "$LOG" 2>&1
echo "exit=$?"
grep -v JAVA_TOOL "$LOG" | grep -E "^e: " | head -20
python3 - <<'PY'
import glob,re,html
for p in glob.glob('app/build/test-results/testDebugUnitTest/*Scenario*.xml'):
    s=open(p).read(); print(p.split('TEST-')[-1], re.search(r'tests="\d+" skipped="\d+" failures="\d+" errors="\d+"',s).group(0), re.search(r'time="[\d.]+"',s).group(0))
    m=re.search(r'<failure message="(.{0,700})',s,re.S)
    if m: print(html.unescape(m.group(1)))
    m=re.search(r'<failure[^>]*>(.{0,6000})',s,re.S)
    if m: print("\n".join(l for l in html.unescape(m.group(1)).split("\n") if 'mountainfold' in l or 'Caused' in l)[:1800])
PY
ls app/build/shots 2>/dev/null | wc -l
