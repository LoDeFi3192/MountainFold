from base import t

# Real-brew follow ups for lessons that have no simulation. They close the loop: learn, brew, taste, log.
BREW_TASKS = {
"processing": t("Taste a washed and a natural coffee side by side. Log which one shows more body and which more acidity.",
                "Goûtez un café lavé et un nature côte à côte. Notez lequel a le plus de corps et lequel le plus d'acidité.",
                "Prueba un café lavado y uno natural uno junto al otro. Registra cuál tiene más cuerpo y cuál más acidez."),
"roasting": t("Brew your current coffee and write its roast date in the notes. Log how lively it tastes.",
              "Préparez votre café du moment et notez sa date de torréfaction. Enregistrez sa vivacité en tasse.",
              "Prepara tu café actual y anota su fecha de tueste. Registra lo vivo que resulta en taza."),
"water_basics": t("Brew the same recipe with tap water and with a low-mineral bottled water. Log both cups.",
                  "Préparez la même recette à l'eau du robinet et avec une eau en bouteille peu minéralisée. Enregistrez les deux tasses.",
                  "Prepara la misma receta con agua del grifo y con agua embotellada de baja mineralización. Registra las dos tazas."),
"tastes": t("Taste your next brew hot, warm and cool. Log acidity, sweetness and balance.",
            "Goûtez votre prochaine extraction chaude, tiède et refroidie. Enregistrez acidité, sucrosité et équilibre.",
            "Prueba tu próxima preparación caliente, templada y fría. Registra acidez, dulzor y equilibrio."),
"mouthfeel": t("Brew the same coffee through paper and in a French press. Log body and clarity for each.",
               "Préparez le même café sur papier et en French press. Enregistrez corps et clarté pour chacun.",
               "Prepara el mismo café con papel y en prensa francesa. Registra cuerpo y claridad de cada uno."),
"acids": t("On your next cup, name the acidity before reading the bag. Write it in the notes and log the brew.",
           "Sur votre prochaine tasse, nommez l'acidité avant de lire le paquet. Écrivez-la dans les notes et enregistrez l'extraction.",
           "En tu próxima taza, nombra la acidez antes de leer el paquete. Escríbela en las notas y registra la preparación."),
"defects": t("Grind two steps finer than your recipe on purpose. Brew, taste the astringency and log it.",
             "Moulez volontairement deux crans plus fin que votre recette. Préparez, goûtez l'astringence et enregistrez.",
             "Muele a propósito dos puntos más fino que tu receta. Prepara, prueba la astringencia y regístrala."),
"puck_prep": t("Pull two shots: one with careful distribution, one without. Log time and taste for both.",
               "Tirez deux shots : un avec une distribution soignée, un sans. Enregistrez temps et goût des deux.",
               "Extrae dos shots: uno con distribución cuidadosa y otro sin ella. Registra tiempo y sabor de ambos."),
}
