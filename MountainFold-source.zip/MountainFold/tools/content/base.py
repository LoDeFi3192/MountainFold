"""Shared helpers for Barista Trainer content. The first option of every question is the correct one;
the app shuffles options at runtime."""

def t(en, fr, es):
    return {"en": en, "fr": fr, "es": es}

def q(qid, prompt, options, why, skill=None):
    d = {"id": qid, "prompt": prompt, "options": options, "correct": 0, "why": why}
    if skill:
        d["skill"] = skill
    return d

def lesson(lid, category, skill, level, minutes, title, objectives, blocks, questions, sim="NONE", sim_hint=None, brew_task=None):
    d = {"id": lid, "category": category, "skill": skill, "level": level, "minutes": minutes, "title": title,
         "objectives": objectives, "blocks": [{"title": b[0], "body": b[1]} for b in blocks],
         "sim": sim, "questions": questions}
    if sim_hint:
        d["simHint"] = sim_hint
    if brew_task:
        d["brewTask"] = brew_task
    return d
