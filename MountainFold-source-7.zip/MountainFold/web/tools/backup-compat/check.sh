#!/usr/bin/env bash
# Checks that web and Android backups are interchangeable, using the real Android data classes.
# Needs kotlinc (2.0+) with the serialization plugin and kotlinx-serialization 1.6+ jars.
# Usage: KOTLINC=/path/kotlinc SER_CORE=core.jar SER_JSON=json.jar tools/backup-compat/check.sh
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd); WEB=$(dirname "$(dirname "$HERE")"); A=$WEB/../app/src/main/java/com/mountainfold/app
OUT=$(mktemp -d); mkdir -p "$OUT/src"
cp "$A/core/model/Models.kt" "$A/core/library/Library.kt" "$A/core/train/TrainModels.kt" "$A/core/cupping/CuppingCatalog.kt" "$A/data/db/Entities.kt" "$A/data/db/CuppingEntities.kt" "$HERE/RoomStubs.kt" "$HERE/Main.kt" "$OUT/src/"
{ echo "package com.mountainfold.app.data.prefs"; grep "^import com.mountainfold" "$A/data/prefs/SettingsStore.kt"; echo "import kotlinx.serialization.Serializable"
  awk '/^@Serializable/{p=1} p{print} p&&/^\)/{exit}' "$A/data/prefs/SettingsStore.kt"; } > "$OUT/src/Settings.kt"
{ echo "package com.mountainfold.app.data"; printf 'import com.mountainfold.app.core.model.BrewStep\nimport com.mountainfold.app.data.db.*\nimport com.mountainfold.app.data.prefs.Settings\nimport kotlinx.serialization.Serializable\nimport kotlinx.serialization.builtins.ListSerializer\nimport kotlinx.serialization.json.Json\n'
  awk '/^object StepsCodec/{p=1} p{print} /^data class Backup/{b=1} b&&/^}/{exit}' "$A/data/Repository.kt"; } > "$OUT/src/Backup.kt"
LIBDIR=$(dirname "$(dirname "$(readlink -f "$KOTLINC")")")/lib
"$KOTLINC" "$OUT"/src/*.kt -Xplugin="$LIBDIR/kotlinx-serialization-compiler-plugin.jar" -cp "$SER_CORE:$SER_JSON" -d "$OUT/bk.jar" 2>/dev/null
CP="$OUT/bk.jar:$SER_CORE:$SER_JSON:$LIBDIR/kotlin-stdlib.jar"
java -cp "$CP" com.mountainfold.app.data.MainKt export "$WEB/tests/fixtures/android-backup.json"
(cd "$WEB" && MF_WEB_EXPORT="$OUT/web.json" npx vitest run tests/backup.test.ts)
java -cp "$CP" com.mountainfold.app.data.MainKt import "$OUT/web.json" "$OUT/reread.json"
python3 - "$WEB/tests/fixtures/android-backup.json" "$OUT/reread.json" <<'PY'
import json, sys
a, k = (json.load(open(p)) for p in sys.argv[1:3])
a["cuppingCoffees"] = [c for c in a["cuppingCoffees"] if c["sessionId"] in {s["id"] for s in a["cuppingSessions"]}]
bad = [key for key in a if key != "exportedAt" and a[key] != k[key]]
print("Android reads the web backup:", "OK" if not bad else f"DIFF in {bad}")
sys.exit(1 if bad else 0)
PY
