# Mountain Fold for iPhone and iPad

The whole Mountain Fold app (Brew, Recipes, Coffees, Cupping, Train, History) as an installable web app (PWA).
Same rules, same content and same backup file as the Android app. Local only: no account, no server, no tracking.

| Device | Layout | Android equivalent |
| --- | --- | --- |
| iPhone in portrait | Phone | Fold closed |
| iPad, both orientations | Workstation, two panes | Fold open |
| iPhone on its side, on the Brew, lesson or Cupping screen | Counter mode | Flex Mode |

Settings > Layout forces one of the three (Phone, Tablet, Counter).

## Build

Requirements: Node 20+, Python 3 with Pillow (for the icons only).

```
cd web
npm ci
npm run gen          # strings, lessons, fonts, icons from the Android sources (single source of truth)
npm run build        # dist/, static files, works under any path
npm run preview      # http://localhost:4173
npm test             # vitest: engines, trainer, cupping, library, backup compatibility
```

App icons come from `python3 tools/make_icons.py` (already in `public/icons`).
`npm run gen` reads `../tools/gen_strings.py`, `../tools/strings_cupping.py`, `tools/strings_web.py` and
`../tools/strings_library.py`, `../app/src/main/assets/train/content.json` and `../app/src/main/assets/library/library.json`.
Change text, lessons or champion recipes there, never in `src/`.

End-to-end runs in Chromium with iPhone and iPad viewports (layouts and flows, not WebKit):

```
node tests/e2e/smoke.mjs   http://localhost:4173/ shots
node tests/e2e/screens.mjs http://localhost:4173/ shots2
node tests/e2e/library.mjs http://localhost:4173/ shots3   # champions, water guide, Apax Lab, microns
node tests/e2e/palettes.mjs http://localhost:4173/ shots4  # Cobalt and Sage, light and dark
```

`tools/backup-compat/check.sh` compiles the real Android data classes with kotlinc and checks both directions:
a backup written by Android imports here, and a backup written here decodes in the Android `Repository`.

## Deploy

`dist/` is plain static files. Any HTTPS host works (Vercel, Cloudflare Pages, Netlify, GitHub Pages).
HTTPS is required: iOS refuses service workers, wake lock and installation on plain HTTP.

Vercel: project root `web`, build `npm run build`, output `dist`. No server code, no environment variables.

## Install on iPhone or iPad

1. Open the address in Safari (iOS 16.4 or later recommended).
2. Share button, then Add to Home Screen.
3. Open Mountain Fold from the home screen: full screen, offline, its own storage.

Data saved in Safari before installing does not follow into the installed app: iOS gives them separate storage.
Install first, or move the data with a backup.

## Moving data between the Fold and the iPhone

Settings > Data > Export on one device, Import on the other. The JSON is the same format both ways.
Web backups also carry coffee photos (`webPhotos`, ignored by Android). Android backups carry photo paths only,
so photos taken on the Fold stay on the Fold.

## How iOS features map

| Feature | Android | Web on iOS |
| --- | --- | --- |
| Timer | monotonic clock | wall clock, keeps exact time through sleep and app switch |
| Screen awake | FLAG_KEEP_SCREEN_ON | Screen Wake Lock API (iOS 16.4+), re-acquired when the app comes back |
| Haptics | Vibrator | `navigator.vibrate` where it exists, else the iOS 18 switch-input tick, else nothing |
| Beeps | ToneGenerator | Web Audio, unlocked on the first tap, follows the ring/silent switch |
| Files (CSV, PDF, backup) | SAF | share sheet (Save to Files), download link elsewhere |
| Voice commands | SpeechRecognizer | Web Speech API where available, the button hides otherwise |
| Dynamic Color | Android 12+ | not available, the five palettes remain |

## Known limits

- Checked in Chromium with iPhone and iPad viewports, not in Safari on a device. Not verified on real hardware:
  wake lock in the installed app, the haptic tick, beeps with the silent switch, the share sheet, printing.
- iOS suspends web apps in the background. The timer stays exact, but step alerts and beeps only play on screen.
- iOS may clear storage of a site not opened for weeks unless it is installed. `navigator.storage.persist()` is
  requested. Export a backup from time to time.
- A coffee photo path coming from Android shows no picture here, and a web photo shows no picture on Android
  (the Android app only knows files on the phone).
- Voice commands depend on the browser. Safari's support of the Web Speech API varies by iOS version.
