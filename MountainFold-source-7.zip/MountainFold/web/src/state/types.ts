import type { Solve, TimerState } from '../core/coffee';
import type { Diagnosis } from '../core/copilot';
import type { CupTimerState } from '../core/cupping';
import type {
  BrewMethod, CuppingCoffee, CuppingSession, LabRecipe, Recipe, SessionRecipe, Settings, StepType, Symptom, Coffee,
} from '../core/models';
import type { EventKind, ExamCategory, FilterInput, Recommendation, ShotInput, Skill } from '../core/train';
import type { AppData } from '../data/db';
import type { AdditiveLine, AdditiveUnit, ApaxMix, Champion } from '../core/library';
import type { Lang, LangSetting } from '../i18n/i18n';

export type Tab = 'HOME' | 'BREW' | 'RECIPES' | 'COFFEE' | 'CUPPING' | 'TRAIN' | 'HISTORY';
export const TABS: Tab[] = ['HOME', 'BREW', 'RECIPES', 'COFFEE', 'CUPPING', 'TRAIN', 'HISTORY'];
export type Overlay = 'CALCULATOR' | 'DIAGNOSE' | 'COMPARE' | 'GRIND' | 'SETTINGS' | 'LOG' | 'WATER';
/** Recipes tab: the user's own recipes or the champion library. */
export type RecipeSource = 'MINE' | 'CHAMPIONS';
export type Pane = { kind: 'NONE' } | { kind: 'VIEW'; id: number } | { kind: 'EDIT' };
export const NO_PANE: Pane = { kind: 'NONE' };

export interface StepDraft { label: string; type: StepType; start: string; water: string; note: string }
/** One mineral concentrate line in the recipe editor. amount stays text while typing. */
export interface AdditiveDraft { id: string; name: string; amount: string; unit: AdditiveUnit }
export interface RecipeDraft {
  id: number; name: string; method: BrewMethod; coffeeId: number | null; dose: string; water: string; ratio: string;
  temp: string; grind: string; pressure: string; targetTime: string; steps: StepDraft[]; notes: string; favorite: boolean; createdAt: number;
  waterId: string | null; waterNote: string; additives: AdditiveDraft[]; championId: string | null;
}
export interface LogDraft {
  timeMs: number; dose: string; water: string; temp: string; grind: string; grinderId: number | null;
  rating: number; acidity: number; sweetness: number; body: number; balance: number; clarity: number; symptoms: Symptom[]; notes: string;
}
export interface CalcState { espresso: boolean; solve: Solve; dose: string; water: string; ratio: string; time: string; temp: string }
export interface DiagState { title: string; recipe: SessionRecipe | null; timeS: number | null; roastAgeDays: number | null; symptoms: Symptom[] }
export interface CompareState { brews: boolean; aId: number | null; bId: number | null }
export interface GrindFilter { grinderId: number | null; coffeeId: number | null; method: BrewMethod | null }

export interface BrewSession {
  recipe: SessionRecipe | null;
  base: SessionRecipe | null;
  notes: string;
  finished: boolean;
  targetReached: boolean;
  timer: TimerState;
  pouredG: number;
}

export type TrainScreen =
  | { kind: 'HOME' } | { kind: 'TREE' } | { kind: 'SCHOOL' } | { kind: 'HISTORY' } | { kind: 'LAB' } | { kind: 'EXAM_SETUP' }
  | { kind: 'LESSON'; id: string } | { kind: 'QUIZ' } | { kind: 'RESULT' };

export interface QuizItem {
  id: string; skill: Skill; prompt: string; facts: [string, string][]; options: string[]; correct: number; why: string;
}
export interface QuizRun {
  kind: EventKind; refId: string; title: string; items: QuizItem[]; answers: (number | null)[]; index: number;
  startedAtMs: number; timeLimitS: number | null; lessonId: string | null;
}
export interface QuizResult {
  run: QuizRun; correct: number; total: number; passed: boolean; xp: number; durationS: number; weak: Skill[];
  recommendations: Recommendation[]; streakBonus: boolean; lessonValidated: boolean;
}

export type CupScreen = 'MAIN' | 'SUMMARY' | 'WHEEL' | 'LAB' | 'INFO' | 'SESSIONS';
export interface LabDraft { method: string; coffee: string; ratio: string; grind: string; rating: number; notes: string }

export interface Message { text: string; nonce: number; action?: { label: string; run: () => void } }

export interface CoreSlice {
  ready: boolean;
  settings: Settings;
  langSetting: LangSetting;
  lang: Lang;
  data: AppData;
  photoUrls: Record<string, string>;

  tab: Tab;
  overlays: Overlay[];
  recipePane: Pane;
  coffeePane: Pane;
  historySel: number | null;
  flexBrowse: boolean;
  message: Message | null;
  pendingReplace: SessionRecipe | null;

  recipeDraft: RecipeDraft | null;
  coffeeDraft: Coffee | null;
  logDraft: LogDraft | null;
  calc: CalcState;
  diag: DiagState;
  compare: CompareState;
  grindFilter: GrindFilter;
  recipeMethodFilter: BrewMethod | null;
  recipeSource: RecipeSource;
  championSel: string | null;
  /** 'WBRC', 'WAC' or null for both competitions. */
  championFilter: string | null;

  session: BrewSession;
}

export interface CupSlice {
  cupSession: CuppingSession | null;
  cupCoffees: CuppingCoffee[];
  cupActive: number;
  cupScreen: CupScreen;
  cupMenuOpen: boolean;
  cupInviteOpen: boolean;
  cupTimerOpen: boolean;
  cupConfirmNew: boolean;
  cupShortcutPrompt: boolean;
  cupPendingDelete: CuppingCoffee | null;
  cupPendingDeleteSession: CuppingSession | null;
  cupPendingDeleteRecipe: LabRecipe | null;
  wheelRotation: number;
  cupTimer: CupTimerState;
  lab: LabDraft;
  labHistory: boolean;
  labRunning: boolean;
  labStartedAt: number;
  labBaseMs: number;
}

export interface TrainSlice {
  trainStack: TrainScreen[];
  lessonRun: { lessonId: string; page: number } | null;
  quiz: QuizRun | null;
  quizResult: QuizResult | null;
  filterSim: FilterInput;
  shotSim: ShotInput;
  labEspresso: boolean;
  yieldCalc: [string, string, string];
  milkTemp: number;
}

export type AppState = CoreSlice & CupSlice & TrainSlice & Actions;

export interface Actions {
  // core
  init(): Promise<void>;
  say(key: string, arg?: string | number): void;
  sayText(text: string): void;
  /** Snackbar with a Save button, for a file Safari would only share from a fresh tap. */
  askSave(shareNow: () => void): void;
  setSettings(f: (s: Settings) => Settings): void;
  setLanguage(l: LangSetting): void;
  selectTab(t: Tab): void;
  open(o: Overlay): void;
  back(): void;
  canGoBack(compact: boolean): boolean;
  completeOnboarding(methods: BrewMethod[], grinder: string): Promise<void>;
  // brew session
  brew(r: SessionRecipe | Recipe): void;
  confirmReplace(): void;
  brewAdHoc(m: BrewMethod, doseG: number, waterG: number, tempC: number | null): void;
  toSession(r: Recipe): SessionRecipe;
  sStart(): void; sPause(): void; sToggle(): void; sReset(): void; sNext(): void; sExtend(d?: number): void;
  sAddWater(g: number): void; sSetWater(g: number): void; sLap(): void; sNotes(text: string): void;
  sAdjust(dose: number, water: number): void; sSetTemp(c: number | null): void; sFinish(): void; sCancelFinish(): void;
  tick(): void;
  onVoice(text: string): void;
  openLog(): void; saveLog(): Promise<void>;
  // recipes
  newRecipe(m?: BrewMethod, coffeeId?: number | null): void;
  editRecipe(r: Recipe): void;
  closeRecipePane(): void;
  applyTemplate(m: BrewMethod): void;
  saveRecipeDraft(): Promise<void>;
  toggleFavorite(r: Recipe): void;
  duplicateRecipe(r: Recipe): Promise<void>;
  deleteRecipe(r: Recipe): void;
  // coffees
  newCoffee(): void;
  editCoffee(c: Coffee): void;
  closeCoffeePane(): void;
  saveCoffeeDraft(): Promise<void>;
  deleteCoffee(c: Coffee): void;
  setCurrentCoffee(id: number | null, known?: Coffee): void;
  attachPhoto(file: File): Promise<void>;
  // brews, grinders
  deleteBrew(id: number): void;
  brewAgain(id: number): void;
  addGrinder(name: string): void;
  deleteGrinder(id: number): void;
  setGrinderMicrons(id: number, text: string): void;
  /** Microns per click: the user's value, or the library value for a grinder it knows by name. */
  micronsPerStep(grinderId: number | null): number | null;
  // champions, water
  championRecipe(c: Champion): import('../core/models').Recipe;
  brewChampion(c: Champion): void;
  addChampionRecipe(c: Champion): Promise<void>;
  applyApaxMix(m: ApaxMix): void;
  additiveLines(list: AdditiveDraft[]): AdditiveLine[];
  // copilot
  diagnoseBrew(id: number): void;
  diagnoseRecipe(r: Recipe): void;
  diagnoseLatest(): void;
  diagnosis(): Diagnosis | null;
  suggestedSession(d: Diagnosis): SessionRecipe | null;
  saveSuggestion(d: Diagnosis): Promise<void>;
  // backup
  exportBackup(): Promise<void>;
  importBackup(file: File): Promise<void>;
  resetData(): Promise<void>;
  // cupping
  cupReload(): Promise<void>;
  cupNewSession(): void;
  cupOpenSession(id: string): Promise<void>;
  cupDeleteSession(s: CuppingSession): void;
  cupSelect(i: number): void;
  cupUpdateSession(f: (s: CuppingSession) => CuppingSession): void;
  cupEdit(f: (c: CuppingCoffee) => CuppingCoffee): void;
  cupToggleFavorite(): void; cupLock(): void; cupUnlock(): void; cupResetNotes(): void;
  cupAddCoffee(): void; cupDeleteCoffee(c: CuppingCoffee): void; cupFlush(): Promise<void>;
  cupStartTimer(min: number): void; cupToggleTimer(): void; cupResetTimer(): void; cupTick(): void;
  labPickMethod(id: string): void; labToggleTimer(): void; labResetTimer(): void; labSave(): void; labLoad(r: LabRecipe): void; labDelete(r: LabRecipe): void;
  cupBack(): boolean; cupCanGoBack(): boolean;
  set<K extends keyof AppState>(patch: Pick<AppState, K> | Partial<AppState>): void;
  // trainer
  openTrain(s: TrainScreen): void;
  openLesson(id: string): void;
  startRec(r: Recommendation): void;
  trainBack(): void;
  leaveTraining(): void;
  lessonPage(delta: number): void;
  startLessonQuiz(id: string): void;
  startDialIn(espresso: boolean): void;
  startDaily(): void;
  startLevelTest(level: number): void;
  startExam(c: ExamCategory): void;
  answer(i: number): void;
  nextQuestion(): void;
  previousQuestion(): void;
  finishQuiz(): void;
  closeResult(): void;
  acceptBrewChallenge(lessonId: string): void;
  cancelBrewChallenge(): void;
}
