// One store for the whole app, like the Android MainViewModel + BrewSessionManager.
// Navigation, drafts and the active brew live here, above every layout, so rotating the phone,
// switching to the iPad layout or the counter mode never loses a timer, a step or a draft.
import { create } from 'zustand';
import {
  decodeSteps, elapsedMs, encodeSteps, epochDayOf, formatNumber, formatRatio, hasStarted, idleTimer, lapTimer, parseClock,
  parseNumber, pauseTimer, ratio as ratioOf, scaleSteps, startTimer, StepSchedule, today, formatClock,
} from '../core/coffee';
import { diagnose, Diagnosis, parseSymptoms } from '../core/copilot';
import {
  Brew, BrewMethod, Coffee, defaultSettings, isEspresso, methodFromKey, METHODS, newCoffee, Recipe, SessionRecipe, Settings,
} from '../core/models';
import { applyScheme, scheme } from '../core/palettes';
import {
  APAX_IDS, championMethod, championSteps, CUSTOM_ADDITIVE, decodeAdditives, encodeAdditives, libraryMicronsPerStep, lt, mixLines,
} from '../core/library';
import { defaultRecipe, starterRecipes } from '../core/seed';
import { Units } from '../core/units';
import { parseVoice } from '../core/voice';
import { buildBackup, normSettings, parseBackup } from '../data/backup';
import {
  AppData, allPhotos, deletePhoto, deleteRow, emptyData, loadAll, putPhoto, putRow, putRows, readLocal,
  replaceAll, saveSettings, writeLocal, persistStorage,
} from '../data/db';
import { LangSetting, resolveLang, setLang, t } from '../i18n/i18n';
import { blobToDataUrl, dataUrlToBlob, downscalePhoto, haptic, saveFile, sounds } from '../platform/device';
import { createCupSlice, cupInitial } from './cupping';
import { createTrainSlice, recordBrewForTraining, trainInitial } from './trainer';
import {
  Actions, AdditiveDraft, AppState, BrewSession, CalcState, CompareState, CoreSlice, DiagState, GrindFilter, LogDraft, NO_PANE, Overlay,
  RecipeDraft, StepDraft,
} from './types';

export type SetFn = (partial: Partial<AppState> | ((s: AppState) => Partial<AppState>)) => void;
export type GetFn = () => AppState;

const BREW_KEY = 'mf.brew';
const LANG_KEY = 'mf.lang';

export const unitsOf = (s: Settings) => new Units(s.weightUnit, s.tempUnit);

const byDesc = <T>(f: (x: T) => number) => (a: T, b: T) => f(b) - f(a);
export function sortData(d: AppData): AppData {
  return {
    coffees: [...d.coffees].sort(byDesc((c) => c.createdAt)),
    recipes: [...d.recipes].sort((a, b) => Number(b.favorite) - Number(a.favorite) || b.updatedAt - a.updatedAt),
    brews: [...d.brews].sort(byDesc((b) => b.createdAt)),
    grinders: [...d.grinders].sort((a, b) => a.name.localeCompare(b.name)),
    training: [...d.training].sort(byDesc((e) => e.createdAt)),
    cuppingSessions: [...d.cuppingSessions].sort(byDesc((s) => s.createdAt)),
    cuppingCoffees: [...d.cuppingCoffees].sort((a, b) => a.sessionId.localeCompare(b.sessionId) || a.position - b.position),
    labRecipes: [...d.labRecipes].sort(byDesc((r) => r.timestamp)),
  };
}

export const nextId = (list: { id: number }[]) => list.reduce((m, r) => Math.max(m, r.id), 0) + 1;

const emptySession = (): BrewSession => ({ recipe: null, base: null, notes: '', finished: false, targetReached: false, timer: idleTimer(), pouredG: 0 });
const defaultCalc = (): CalcState => ({ espresso: false, solve: 'WATER', dose: '15', water: '250', ratio: '16.7', time: '', temp: '' });
const defaultDiag = (): DiagState => ({ title: '', recipe: null, timeS: null, roastAgeDays: null, symptoms: [] });
const defaultCompare = (): CompareState => ({ brews: false, aId: null, bId: null });
const defaultGrindFilter = (): GrindFilter => ({ grinderId: null, coffeeId: null, method: null });

// ---- brew session persistence (survives a reload or iOS killing the page) ------------------------
interface PersistedBrew extends BrewSession { savedWallMs: number }

function persistBrew(s: BrewSession) {
  if (!s.recipe || !s.base) { writeLocal(BREW_KEY, null); return; }
  writeLocal(BREW_KEY, { ...s, savedWallMs: Date.now() } satisfies PersistedBrew);
}

function restoreBrew(): BrewSession {
  const p = readLocal<PersistedBrew>(BREW_KEY);
  if (!p || !p.recipe || !p.base || !p.timer) return emptySession();
  const now = Date.now();
  const away = now - (p.savedWallMs || now);
  // A brew left running long past its target was abandoned. It comes back paused, not hours deep.
  const abandoned = p.timer.running && away > Math.max(p.recipe.targetTimeS * 3000, 3_600_000);
  const timer = abandoned ? pauseTimer(p.timer, p.savedWallMs) : p.timer;
  return { recipe: p.recipe, base: p.base, notes: p.notes ?? '', finished: !!p.finished, targetReached: !!p.targetReached, timer, pouredG: p.pouredG ?? 0 };
}

let ticker: ReturnType<typeof setInterval> | null = null;
let lastStepIndex = -1;

function coreInitial(): CoreSlice {
  return {
    ready: false,
    settings: defaultSettings(),
    langSetting: 'system',
    lang: 'en',
    data: emptyData(),
    photoUrls: {},
    tab: 'HOME',
    overlays: [],
    recipePane: NO_PANE,
    coffeePane: NO_PANE,
    historySel: null,
    flexBrowse: false,
    message: null,
    pendingReplace: null,
    recipeDraft: null,
    coffeeDraft: null,
    logDraft: null,
    calc: defaultCalc(),
    diag: defaultDiag(),
    compare: defaultCompare(),
    grindFilter: defaultGrindFilter(),
    recipeMethodFilter: null,
    recipeSource: 'MINE',
    championSel: null,
    championFilter: null,
    session: emptySession(),
  };
}

export const useApp = create<AppState>()((set, get) => {
  const units = () => unitsOf(get().settings);
  const setData = (f: (d: AppData) => Partial<AppData>) => set((s) => ({ data: sortData({ ...s.data, ...f(s.data) }) }));
  const say = (key: string, arg?: string | number) => set({ message: { text: arg === undefined ? t(key) : t(key, arg), nonce: Date.now() + Math.random() } });

  // ---- feedback -------------------------------------------------------------------------------
  const feedback = {
    step() { const st = get().settings; if (st.haptics) haptic('step'); if (st.sounds) sounds.step(); },
    target() { const st = get().settings; if (st.haptics) haptic('done'); if (st.sounds) sounds.target(); },
    action() { if (get().settings.haptics) haptic('tick'); },
  };

  const setSession = (f: (s: BrewSession) => BrewSession, persist = true) => {
    const next = f(get().session);
    set({ session: next });
    if (persist) persistBrew(next);
    syncTicker();
  };

  function syncTicker() {
    const running = get().session.timer.running;
    if (running && !ticker) {
      lastStepIndex = currentStepIndex();
      ticker = setInterval(() => get().tick(), 100);
    } else if (!running && ticker) {
      clearInterval(ticker);
      ticker = null;
    }
  }

  const elapsedS = () => elapsedMs(get().session.timer, Date.now()) / 1000;
  function currentStepIndex() {
    const r = get().session.recipe;
    return r ? StepSchedule.indexAt(r.steps, elapsedS()) : -1;
  }

  function loadSession(recipe: SessionRecipe) {
    lastStepIndex = -1;
    setSession(() => ({ ...emptySession(), recipe, base: recipe }));
    if (recipe.recipeId != null) get().setSettings((s) => ({ ...s, lastRecipeId: recipe.recipeId }));
    set({ overlays: [], logDraft: null, tab: 'BREW' });
  }

  function ensureSession(preferred?: BrewMethod) {
    if (get().session.recipe) return;
    const { data, settings } = get();
    const method = preferred ?? settings.defaultMethod;
    const pick = data.recipes.find((r) => r.id === settings.lastRecipeId) ?? data.recipes.find((r) => r.method === method) ?? data.recipes[0];
    if (!pick) return;
    lastStepIndex = -1;
    setSession(() => ({ ...emptySession(), recipe: get().toSession(pick), base: get().toSession(pick) }));
  }

  async function seedIfEmpty(favorites: BrewMethod[] = []) {
    if (get().data.recipes.length > 0) return;
    const rows = starterRecipes(favorites).map((r, i) => ({ ...r, id: i + 1 }));
    setData(() => ({ recipes: rows }));
    await putRows('recipes', rows);
  }

  function roastAge(coffeeId: number | null): number | null {
    const day = get().data.coffees.find((c) => c.id === coffeeId)?.roastDateEpochDay;
    if (day == null) return null;
    const age = today() - day;
    return age >= 0 ? age : null;
  }

  function brewToSession(b: Brew): SessionRecipe {
    const { recipes, coffees } = get().data;
    return {
      recipeId: b.recipeId != null && recipes.some((r) => r.id === b.recipeId) ? b.recipeId : null,
      name: b.recipeName.trim() ? b.recipeName : METHODS[methodFromKey(b.method)].label,
      method: methodFromKey(b.method),
      coffeeId: b.coffeeId != null && coffees.some((c) => c.id === b.coffeeId) ? b.coffeeId : null,
      coffeeName: b.coffeeName,
      doseG: b.doseG, waterG: b.waterG, tempC: b.tempC, grind: b.grind, pressureBar: b.pressureBar,
      steps: decodeSteps(b.stepsJson),
      targetTimeS: b.targetTimeS > 0 ? b.targetTimeS : Math.floor(b.timeMs / 1000),
      notes: '',
      waterId: b.waterId, waterNote: b.waterNote, additives: decodeAdditives(b.additivesJson),
    };
  }

  function draftOf(r: Recipe): RecipeDraft {
    const u = units();
    const m = methodFromKey(r.method);
    const rr = ratioOf(r.waterG, r.doseG);
    return {
      id: r.id, name: r.name, method: m, coffeeId: r.coffeeId,
      dose: u.wValue(r.doseG), water: u.wValue(r.waterG), ratio: rr == null ? '' : formatNumber(rr),
      temp: r.tempC == null ? '' : u.tValue(r.tempC), grind: r.grind,
      pressure: r.pressureBar == null ? '' : formatNumber(r.pressureBar),
      targetTime: isEspresso(m) ? String(r.targetTimeS) : formatClock(r.targetTimeS),
      steps: decodeSteps(r.stepsJson).map<StepDraft>((s) => ({
        label: s.label, type: s.type, start: formatClock(s.startS), water: s.targetWaterG == null ? '' : u.wValue(s.targetWaterG), note: s.note,
      })),
      notes: r.notes, favorite: r.favorite, createdAt: r.createdAt,
      waterId: r.waterId, waterNote: r.waterNote, championId: r.championId,
      additives: decodeAdditives(r.additivesJson).map<AdditiveDraft>((a) => ({ id: a.id, name: a.name, amount: formatNumber(a.amount), unit: a.unit })),
    };
  }

  function recipeFromDraft(d: RecipeDraft): Recipe | null {
    const u = units();
    const dose = u.parseW(d.dose);
    const water = u.parseW(d.water);
    const target = parseClock(d.targetTime);
    if (dose == null || dose <= 0 || water == null || water <= 0 || target == null || target <= 0) return null;
    const steps = StepSchedule.normalize(
      d.steps.filter((s) => s.label.trim()).map((s) => ({
        label: s.label.trim(), type: s.type, startS: parseClock(s.start) ?? 0, targetWaterG: u.parseW(s.water), note: s.note.trim(),
      })),
    );
    return {
      id: d.id, name: d.name.trim() || t('seed_recipe_name', METHODS[d.method].label), method: d.method, coffeeId: d.coffeeId,
      doseG: dose, waterG: water, tempC: u.parseT(d.temp), grind: d.grind.trim(), pressureBar: parseNumber(d.pressure),
      targetTimeS: target, stepsJson: encodeSteps(steps), notes: d.notes.trim(), favorite: d.favorite, createdAt: d.createdAt, updatedAt: 0,
      waterId: d.waterId, waterNote: d.waterNote.trim(), additivesJson: encodeAdditives(get().additiveLines(d.additives)), championId: d.championId,
    };
  }

  async function saveRecipeRow(r: Recipe): Promise<number> {
    const now = Date.now();
    const id = r.id || nextId(get().data.recipes);
    const row: Recipe = { ...r, id, createdAt: r.createdAt || now, updatedAt: now };
    setData((d) => ({ recipes: [...d.recipes.filter((x) => x.id !== id), row] }));
    await putRow('recipes', row);
    return id;
  }

  async function saveCoffeeRow(c: Coffee): Promise<number> {
    const id = c.id || nextId(get().data.coffees);
    const row: Coffee = { ...c, id, createdAt: c.createdAt || Date.now() };
    setData((d) => ({ coffees: [...d.coffees.filter((x) => x.id !== id), row] }));
    await putRow('coffees', row);
    return id;
  }

  function applyTheme() {
    const s = get().settings;
    const dark = s.themeMode === 'DARK' || (s.themeMode === 'SYSTEM' && window.matchMedia?.('(prefers-color-scheme: dark)').matches);
    applyScheme(scheme(s.palette, !!dark), !!dark);
  }

  const actions: Partial<Actions> = {
    async init() {
      const langSetting = (readLocal<LangSetting>(LANG_KEY) ?? 'system') as LangSetting;
      const l = resolveLang(langSetting);
      setLang(l);
      let loaded: Awaited<ReturnType<typeof loadAll>> | null = null;
      try {
        loaded = await loadAll();
      } catch {
        loaded = null;
      }
      const settings = loaded?.settings ? normSettings(loaded.settings) : defaultSettings();
      set({ settings, langSetting, lang: l, data: sortData(loaded?.data ?? emptyData()), session: restoreBrew() });
      applyTheme();
      window.matchMedia?.('(prefers-color-scheme: dark)').addEventListener?.('change', applyTheme);
      if (settings.onboarded) {
        await seedIfEmpty();
        ensureSession();
      }
      syncTicker();
      set({ ready: true });
      await get().cupReload();
      void persistStorage();
    },

    say,
    sayText: (text) => set({ message: { text, nonce: Date.now() + Math.random() } }),
    askSave: (shareNow) => set({ message: { text: t('web_file_ready'), nonce: Date.now() + Math.random(), action: { label: t('save'), run: shareNow } } }),

    setSettings(f) {
      const next = f(get().settings);
      set({ settings: next });
      void saveSettings(next);
      applyTheme();
    },

    setLanguage(l) {
      writeLocal(LANG_KEY, l);
      const lang = resolveLang(l);
      setLang(lang);
      set({ langSetting: l, lang });
    },

    selectTab(tab) {
      const s = get();
      const patch: Partial<AppState> = { overlays: [], tab };
      if (tab === s.tab) {
        if (tab === 'RECIPES' && s.recipePane.kind !== 'EDIT') patch.recipePane = NO_PANE;
        if (tab === 'RECIPES') patch.championSel = null;
        if (tab === 'COFFEE' && s.coffeePane.kind !== 'EDIT') patch.coffeePane = NO_PANE;
        if (tab === 'HISTORY') patch.historySel = null;
        if (tab === 'TRAIN') s.leaveTraining();
        if (tab === 'CUPPING') { patch.cupScreen = 'MAIN'; patch.labHistory = false; }
      }
      set(patch);
    },

    open(o: Overlay) {
      const list = get().overlays;
      if (list[list.length - 1] === o) return;
      set({ overlays: [...list.filter((x) => x !== o), o] });
    },

    canGoBack(compact) {
      const s = get();
      return s.overlays.length > 0 || s.tab !== 'HOME' || s.flexBrowse ||
        (compact && (s.recipePane.kind !== 'NONE' || s.coffeePane.kind !== 'NONE' || s.historySel != null || s.championSel != null));
    },

    back() {
      const s = get();
      if (s.overlays.length) {
        const top = s.overlays[s.overlays.length - 1];
        set({ overlays: s.overlays.slice(0, -1) });
        if (top === 'LOG') { s.sCancelFinish(); set({ logDraft: null }); }
      } else if (s.tab === 'TRAIN' && s.trainStack.length) s.trainBack();
      else if (s.tab === 'CUPPING' && s.cupCanGoBack()) s.cupBack();
      else if (s.tab === 'RECIPES' && s.recipeSource === 'CHAMPIONS' && s.championSel != null) set({ championSel: null });
      else if (s.tab === 'RECIPES' && s.recipePane.kind !== 'NONE') s.closeRecipePane();
      else if (s.tab === 'COFFEE' && s.coffeePane.kind !== 'NONE') s.closeCoffeePane();
      else if (s.tab === 'HISTORY' && s.historySel != null) set({ historySel: null });
      else if (s.tab !== 'HOME') set({ tab: 'HOME' });
      else if (s.flexBrowse) set({ flexBrowse: false });
    },

    async completeOnboarding(methods, grinder) {
      let grinderId: number | null = null;
      const g = grinder.trim();
      if (g) {
        grinderId = nextId(get().data.grinders);
        const row = { id: grinderId, name: g, notes: '', micronsPerStep: null };
        setData((d) => ({ grinders: [...d.grinders, row] }));
        await putRow('grinders', row);
      }
      await seedIfEmpty(methods);
      get().setSettings((s) => ({
        ...s, onboarded: true, preferredMethods: methods, defaultMethod: methods[0] ?? 'V60', defaultGrinderId: grinderId ?? s.defaultGrinderId,
      }));
      ensureSession(methods[0]);
      void get().cupReload();
    },

    // ---- brew session ------------------------------------------------------------------------
    toSession(recipe) {
      const { data, settings } = get();
      const coffee = data.coffees.find((c) => c.id === (recipe.coffeeId ?? settings.currentCoffeeId));
      return {
        recipeId: recipe.id || null, name: recipe.name, method: methodFromKey(recipe.method),
        coffeeId: coffee?.id ?? null, coffeeName: coffee?.name ?? '',
        doseG: recipe.doseG, waterG: recipe.waterG, tempC: recipe.tempC, grind: recipe.grind, pressureBar: recipe.pressureBar,
        steps: decodeSteps(recipe.stepsJson), targetTimeS: recipe.targetTimeS, notes: recipe.notes,
        waterId: recipe.waterId ?? null, waterNote: recipe.waterNote ?? '', additives: decodeAdditives(recipe.additivesJson),
      };
    },

    brew(r) {
      const recipe: SessionRecipe = 'stepsJson' in r ? get().toSession(r) : r;
      const s = get().session;
      if (hasStarted(s.timer) && !s.finished) set({ pendingReplace: recipe });
      else loadSession(recipe);
    },

    confirmReplace() {
      const p = get().pendingReplace;
      if (p) loadSession(p);
      set({ pendingReplace: null });
    },

    brewAdHoc(method, doseG, waterG, tempC) {
      const base = defaultRecipe(method, doseG);
      const steps = scaleSteps(decodeSteps(base.stepsJson), base.waterG, waterG);
      const s = get().toSession({ ...base, name: t('quick_brew_name', METHODS[method].label), waterG, tempC: tempC ?? base.tempC });
      get().brew({ ...s, steps });
    },

    sStart() {
      const s = get().session;
      if (!s.recipe || s.finished) return;
      setSession((x) => ({ ...x, timer: startTimer(x.timer, Date.now()) }));
      feedback.action();
    },
    sPause() {
      setSession((x) => ({ ...x, timer: pauseTimer(x.timer, Date.now()) }));
      feedback.action();
    },
    sToggle() { if (get().session.timer.running) get().sPause(); else get().sStart(); },
    sReset() {
      lastStepIndex = -1;
      setSession((x) => ({ ...x, recipe: x.base, finished: false, targetReached: false, timer: idleTimer(), pouredG: 0 }));
      feedback.action();
    },
    sNext() {
      const s = get().session;
      const r = s.recipe;
      if (!r) return;
      if (!hasStarted(s.timer)) { get().sStart(); return; }
      const moved = StepSchedule.advanceNow(r.steps, elapsedS(), r.targetTimeS);
      if (!moved) return;
      setSession((x) => ({ ...x, recipe: { ...r, steps: moved[0], targetTimeS: moved[1] } }));
      get().tick();
      feedback.action();
    },
    sExtend(delta = 10) {
      const r = get().session.recipe;
      if (!r) return;
      const moved = StepSchedule.extendCurrent(r.steps, elapsedS(), r.targetTimeS, delta);
      setSession((x) => ({ ...x, recipe: { ...r, steps: moved[0], targetTimeS: moved[1] }, targetReached: false }));
      feedback.action();
    },
    sAddWater(g) { setSession((x) => ({ ...x, pouredG: Math.max(0, x.pouredG + g) })); feedback.action(); },
    sSetWater(g) { setSession((x) => ({ ...x, pouredG: Math.max(0, g) })); },
    sLap() { setSession((x) => ({ ...x, timer: lapTimer(x.timer, Date.now()) })); feedback.action(); },
    sNotes(text) { setSession((x) => ({ ...x, notes: text })); },
    sAdjust(dose, water) {
      const r = get().session.recipe;
      if (!r || dose <= 0 || water <= 0) return;
      const scaled = (x: SessionRecipe) => ({ ...x, doseG: dose, waterG: water, steps: scaleSteps(x.steps, x.waterG, water) });
      setSession((x) => ({ ...x, recipe: scaled(r), base: x.base ? scaled(x.base) : x.base }));
    },
    sSetTemp(c) {
      setSession((x) => ({ ...x, recipe: x.recipe ? { ...x.recipe, tempC: c } : null, base: x.base ? { ...x.base, tempC: c } : null }));
    },
    sFinish() {
      if (!get().session.recipe) return;
      setSession((x) => ({ ...x, timer: pauseTimer(x.timer, Date.now()), finished: true }));
      feedback.action();
      get().openLog();
    },
    sCancelFinish() { setSession((x) => ({ ...x, finished: false })); },

    /** Step boundaries and target time, driven by the clock, not by frames. */
    tick() {
      const s = get().session;
      const r = s.recipe;
      if (!r) return;
      const el = elapsedS();
      const idx = StepSchedule.indexAt(r.steps, el);
      if (idx !== lastStepIndex) {
        if (idx > lastStepIndex && idx > 0 && idx < r.steps.length) feedback.step();
        lastStepIndex = idx;
      }
      if (!s.targetReached && r.targetTimeS > 0 && el >= r.targetTimeS) {
        setSession((x) => ({ ...x, targetReached: true }));
        feedback.target();
        if (get().settings.autoStopAtTarget) get().sFinish();
      }
    },

    onVoice(text) {
      const cmd = parseVoice(text);
      const s = get();
      switch (cmd.kind) {
        case 'START': s.sStart(); break;
        case 'PAUSE': s.sPause(); break;
        case 'NEXT': s.sNext(); break;
        case 'RESET': s.sReset(); break;
        case 'ADD': s.sAddWater(cmd.grams); break;
        case 'RATIO': { const r = s.session.recipe; if (r) say('voice_ratio', formatRatio(ratioOf(r.waterG, r.doseG))); break; }
        default: say('voice_unknown', text);
      }
    },

    openLog() {
      const s = get();
      const r = s.session.recipe;
      if (!r) return;
      if (!s.logDraft) {
        const u = units();
        const poured = s.session.pouredG;
        const draft: LogDraft = {
          timeMs: elapsedMs(s.session.timer, Date.now()),
          dose: u.wValue(r.doseG), water: u.wValue(poured > 0 ? poured : r.waterG),
          temp: r.tempC == null ? '' : u.tValue(r.tempC), grind: r.grind, grinderId: s.settings.defaultGrinderId,
          rating: 0, acidity: 0, sweetness: 0, body: 0, balance: 0, clarity: 0, symptoms: [], notes: s.session.notes,
        };
        set({ logDraft: draft });
      }
      s.open('LOG');
    },

    async saveLog() {
      const s = get();
      const d = s.logDraft;
      const r = s.session.recipe;
      if (!d || !r) return;
      const u = units();
      const grinder = s.data.grinders.find((g) => g.id === d.grinderId);
      const brew: Brew = {
        id: nextId(s.data.brews), coffeeId: r.coffeeId, recipeId: r.recipeId, coffeeName: r.coffeeName, recipeName: r.name,
        method: r.method, doseG: u.parseW(d.dose) ?? r.doseG, waterG: u.parseW(d.water) ?? r.waterG, tempC: u.parseT(d.temp),
        grind: d.grind.trim(), grinderId: grinder?.id ?? null, grinderName: grinder?.name ?? '', pressureBar: r.pressureBar,
        timeMs: d.timeMs, targetTimeS: r.targetTimeS, notes: d.notes.trim(), rating: d.rating, acidity: d.acidity,
        sweetness: d.sweetness, body: d.body, balance: d.balance, clarity: d.clarity, symptoms: d.symptoms.join(','),
        stepsJson: encodeSteps(r.steps), createdAt: Date.now(),
        waterId: r.waterId ?? null, waterNote: r.waterNote ?? '', additivesJson: encodeAdditives(r.additives ?? []),
      };
      setData((x) => ({ brews: [...x.brews, brew] }));
      await putRow('brews', brew);
      const challenge = await recordBrewForTraining(get, set, brew);
      lastStepIndex = -1;
      setSession((x) => ({ ...emptySession(), recipe: x.base, base: x.base }));
      set({ overlays: [], logDraft: null, tab: 'HISTORY', historySel: brew.id });
      say(challenge ? 'msg_brew_challenge_done' : d.rating >= 4 ? 'msg_nice_extraction' : 'msg_brew_logged');
    },

    // ---- recipes -------------------------------------------------------------------------------
    newRecipe(m, coffeeId = null) {
      const st = get().settings;
      const method = m ?? st.defaultMethod;
      const dose = method === st.defaultMethod ? st.defaultDoseG : METHODS[method].defaultDoseG;
      set({ recipeDraft: { ...draftOf({ ...defaultRecipe(method, dose), name: '', coffeeId }) }, recipePane: { kind: 'EDIT' }, overlays: [], tab: 'RECIPES' });
    },
    editRecipe(r) { set({ recipeDraft: draftOf(r), recipePane: { kind: 'EDIT' } }); },
    closeRecipePane() {
      const s = get();
      const d = s.recipeDraft;
      set({ recipePane: s.recipePane.kind === 'EDIT' && d && d.id !== 0 ? { kind: 'VIEW', id: d.id } : NO_PANE, recipeDraft: null });
    },
    applyTemplate(m) {
      const d = get().recipeDraft;
      if (!d) return;
      const tpl = draftOf(defaultRecipe(m));
      set({
        recipeDraft: {
          ...tpl, id: d.id, name: d.name, coffeeId: d.coffeeId, notes: d.notes, favorite: d.favorite, createdAt: d.createdAt,
          waterId: d.waterId, waterNote: d.waterNote, additives: d.additives, championId: d.championId,
        },
      });
    },
    async saveRecipeDraft() {
      const d = get().recipeDraft;
      if (!d) return;
      const r = recipeFromDraft(d);
      if (!r) { say('msg_check_numbers'); return; }
      const id = await saveRecipeRow(r);
      set({ recipeDraft: null, recipePane: { kind: 'VIEW', id } });
      const s = get().session;
      if (s.recipe?.recipeId === id && !hasStarted(s.timer)) {
        const fresh = get().toSession({ ...r, id });
        setSession(() => ({ ...emptySession(), recipe: fresh, base: fresh }));
      }
      say('msg_recipe_saved');
    },
    toggleFavorite(r) { void saveRecipeRow({ ...r, favorite: !r.favorite }); },
    async duplicateRecipe(r) {
      const id = await saveRecipeRow({ ...r, id: 0, name: t('copy_name', r.name), favorite: false, createdAt: 0 });
      set({ recipePane: { kind: 'VIEW', id } });
    },
    deleteRecipe(r) {
      setData((d) => ({ recipes: d.recipes.filter((x) => x.id !== r.id) }));
      void deleteRow('recipes', r.id);
      const p = get().recipePane;
      if (p.kind === 'VIEW' && p.id === r.id) set({ recipePane: NO_PANE });
    },

    // ---- coffees -------------------------------------------------------------------------------
    newCoffee() { set({ coffeeDraft: newCoffee(), coffeePane: { kind: 'EDIT' }, overlays: [], tab: 'COFFEE' }); },
    editCoffee(c) { set({ coffeeDraft: { ...c }, coffeePane: { kind: 'EDIT' } }); },
    closeCoffeePane() {
      const s = get();
      const d = s.coffeeDraft;
      set({ coffeePane: s.coffeePane.kind === 'EDIT' && d && d.id !== 0 ? { kind: 'VIEW', id: d.id } : NO_PANE, coffeeDraft: null });
    },
    async saveCoffeeDraft() {
      const d = get().coffeeDraft;
      if (!d) return;
      if (!d.name.trim()) { say('msg_name_required'); return; }
      const first = get().data.coffees.length === 0;
      const id = await saveCoffeeRow({ ...d, name: d.name.trim() });
      const saved = { ...d, id, name: d.name.trim() };
      const loaded = get().session.recipe;
      if (first || get().settings.currentCoffeeId == null) get().setCurrentCoffee(id, saved);
      else if (loaded && loaded.coffeeId === id && !hasStarted(get().session.timer)) {
        const next = { ...loaded, coffeeName: saved.name };
        setSession(() => ({ ...emptySession(), recipe: next, base: next }));
      }
      set({ coffeeDraft: null, coffeePane: { kind: 'VIEW', id } });
      say('msg_coffee_saved');
    },
    deleteCoffee(c) {
      setData((d) => ({
        coffees: d.coffees.filter((x) => x.id !== c.id),
        recipes: d.recipes.map((r) => (r.coffeeId === c.id ? { ...r, coffeeId: null } : r)),
      }));
      const unlinked = get().data.recipes.filter((r) => r.coffeeId == null);
      void deleteRow('coffees', c.id);
      void putRows('recipes', unlinked);
      if (c.photoPath?.startsWith('idb:')) void deletePhoto(c.photoPath);
      if (get().settings.currentCoffeeId === c.id) get().setSettings((s) => ({ ...s, currentCoffeeId: null }));
      const p = get().coffeePane;
      if (p.kind === 'VIEW' && p.id === c.id) set({ coffeePane: NO_PANE });
    },
    setCurrentCoffee(id, known) {
      get().setSettings((s) => ({ ...s, currentCoffeeId: id }));
      const s = get().session;
      const r = s.recipe;
      if (!r || hasStarted(s.timer)) return;
      const linked = get().data.recipes.find((x) => x.id === r.recipeId)?.coffeeId ?? null;
      if (linked == null) {
        const coffee = known ?? get().data.coffees.find((c) => c.id === id);
        const next = { ...r, coffeeId: coffee?.id ?? null, coffeeName: coffee?.name ?? '' };
        setSession(() => ({ ...emptySession(), recipe: next, base: next }));
      }
    },
    async attachPhoto(file) {
      const blob = await downscalePhoto(file);
      if (!blob) { say('msg_photo_failed'); return; }
      const key = `idb:${typeof crypto.randomUUID === 'function' ? crypto.randomUUID() : String(Date.now())}`;
      await putPhoto(key, blob);
      const d = get().coffeeDraft;
      if (d) set({ coffeeDraft: { ...d, photoPath: key } });
    },

    // ---- brews, grinders --------------------------------------------------------------------------
    deleteBrew(id) {
      setData((d) => ({ brews: d.brews.filter((b) => b.id !== id) }));
      void deleteRow('brews', id);
      if (get().historySel === id) set({ historySel: null });
    },
    brewAgain(id) {
      const b = get().data.brews.find((x) => x.id === id);
      if (b) get().brew(brewToSession(b));
    },
    addGrinder(name) {
      const n = name.trim();
      if (!n) return;
      const row = { id: nextId(get().data.grinders), name: n, notes: '', micronsPerStep: null };
      setData((d) => ({ grinders: [...d.grinders, row] }));
      void putRow('grinders', row);
      if (get().settings.defaultGrinderId == null) get().setSettings((s) => ({ ...s, defaultGrinderId: row.id }));
    },
    deleteGrinder(id) {
      setData((d) => ({ grinders: d.grinders.filter((g) => g.id !== id) }));
      void deleteRow('grinders', id);
      if (get().settings.defaultGrinderId === id) get().setSettings((s) => ({ ...s, defaultGrinderId: null }));
      if (get().grindFilter.grinderId === id) set({ grindFilter: { ...get().grindFilter, grinderId: null } });
    },
    setGrinderMicrons(id, text) {
      const g = get().data.grinders.find((x) => x.id === id);
      if (!g) return;
      const v = parseNumber(text);
      if (text.trim() && (v == null || v < 1 || v > 500)) return;
      const row = { ...g, micronsPerStep: text.trim() ? v : null };
      setData((d) => ({ grinders: d.grinders.map((x) => (x.id === id ? row : x)) }));
      void putRow('grinders', row);
    },
    micronsPerStep(grinderId) {
      const g = get().data.grinders.find((x) => x.id === grinderId);
      return g ? g.micronsPerStep ?? libraryMicronsPerStep(g.name) : null;
    },

    // ---- champion library, water ---------------------------------------------------------------
    championRecipe(c) {
      const l = get().lang;
      const notes = [lt(c.notes, l), t('champion_source_line', c.source)].filter((x) => x).join('\n\n');
      return {
        id: 0, name: t('champion_recipe_name', c.champion, String(c.year)), method: championMethod(c), coffeeId: null,
        doseG: c.doseG, waterG: c.waterG, tempC: c.tempC, grind: lt(c.grind, l), pressureBar: null, targetTimeS: c.targetTimeS,
        stepsJson: encodeSteps(championSteps(c, l)), notes, favorite: false, createdAt: 0, updatedAt: 0,
        waterId: c.waterId, waterNote: lt(c.water, l), additivesJson: encodeAdditives(c.additives), championId: c.id,
      };
    },
    brewChampion(c) { get().brew(get().toSession(get().championRecipe(c))); },
    async addChampionRecipe(c) {
      const id = await saveRecipeRow(get().championRecipe(c));
      set({ recipeSource: 'MINE', championSel: null, recipeDraft: null, recipePane: { kind: 'VIEW', id } });
      say('msg_champion_added');
    },
    additiveLines(list) {
      return list.flatMap((a) => {
        const amount = parseNumber(a.amount);
        if (amount == null || amount <= 0) return [];
        return [{ id: a.id, name: a.id === CUSTOM_ADDITIVE ? a.name.trim() : '', amount, unit: a.unit }];
      });
    },
    applyApaxMix(m) {
      const d = get().recipeDraft;
      if (!d) return;
      const others = d.additives.filter((a) => !APAX_IDS.includes(a.id));
      const lines = mixLines(m).map<AdditiveDraft>((a) => ({ id: a.id, name: '', amount: formatNumber(a.amount), unit: 'G_PER_L' }));
      set({ recipeDraft: { ...d, additives: [...lines, ...others], waterId: d.waterId ?? 'apax-base' } });
    },

    // ---- copilot -----------------------------------------------------------------------------------
    diagnoseBrew(id) {
      const b = get().data.brews.find((x) => x.id === id);
      if (!b) return;
      set({
        diag: {
          title: b.recipeName.trim() ? b.recipeName : METHODS[methodFromKey(b.method)].label,
          recipe: brewToSession(b),
          timeS: Math.floor(b.timeMs / 1000) > 0 ? Math.floor(b.timeMs / 1000) : null,
          roastAgeDays: roastAge(b.coffeeId),
          symptoms: parseSymptoms(b.symptoms),
        },
      });
      get().open('DIAGNOSE');
    },
    diagnoseRecipe(r) {
      const s = get().toSession(r);
      set({ diag: { title: r.name, recipe: s, timeS: null, roastAgeDays: roastAge(s.coffeeId), symptoms: [] } });
      get().open('DIAGNOSE');
    },
    diagnoseLatest() {
      const last = get().data.brews[0];
      const r = get().session.recipe;
      if (last) get().diagnoseBrew(last.id);
      else if (r) { set({ diag: { ...defaultDiag(), title: r.name, recipe: r, roastAgeDays: roastAge(r.coffeeId) } }); get().open('DIAGNOSE'); }
      else get().open('DIAGNOSE');
    },
    diagnosis() {
      const { diag } = get();
      const r = diag.recipe;
      if (!r) return null;
      return diagnose({ method: r.method, doseG: r.doseG, waterG: r.waterG, tempC: r.tempC, timeS: diag.timeS, targetTimeS: r.targetTimeS, grind: r.grind, steps: r.steps, roastAgeDays: diag.roastAgeDays }, diag.symptoms);
    },
    suggestedSession(d: Diagnosis) {
      const r = get().diag.recipe;
      if (!r) return null;
      const s = d.suggestion;
      return { ...r, doseG: s.doseG, waterG: s.waterG, tempC: s.tempC, grind: s.grind, steps: s.steps, targetTimeS: s.targetTimeS };
    },
    async saveSuggestion(d) {
      const s = get().suggestedSession(d);
      if (!s) return;
      const id = await saveRecipeRow({
        id: 0, name: t('adjusted_name', s.name), method: s.method,
        coffeeId: get().data.recipes.find((r) => r.id === s.recipeId)?.coffeeId ?? null,
        doseG: s.doseG, waterG: s.waterG, tempC: s.tempC, grind: s.grind, pressureBar: s.pressureBar, targetTimeS: s.targetTimeS,
        stepsJson: encodeSteps(s.steps), notes: s.notes, favorite: false, createdAt: 0, updatedAt: 0,
        waterId: s.waterId, waterNote: s.waterNote, additivesJson: encodeAdditives(s.additives),
        championId: get().data.recipes.find((r) => r.id === s.recipeId)?.championId ?? null,
      });
      set({ overlays: [], tab: 'RECIPES', recipePane: { kind: 'VIEW', id } });
      say('msg_recipe_saved');
    },

    // ---- backup ----------------------------------------------------------------------------------
    async exportBackup() {
      await get().cupFlush();
      const s = get();
      const photos: Record<string, string> = {};
      try {
        const all = await allPhotos();
        const used = new Set(s.data.coffees.map((c) => c.photoPath).filter(Boolean) as string[]);
        for (const [k, b] of Object.entries(all)) if (used.has(k)) photos[k] = await blobToDataUrl(b);
      } catch { /* photos are optional */ }
      const text = buildBackup(s.settings, s.data, photos);
      const ok = await saveFile(new Blob([text], { type: 'application/json' }), 'mountain-fold-backup.json', get().askSave);
      if (ok !== 'pending') say(ok ? 'msg_export_ok' : 'msg_export_failed');
    },

    async importBackup(file) {
      try {
        const parsed = parseBackup(await file.text());
        const photos: Record<string, Blob> = {};
        for (const [k, v] of Object.entries(parsed.photos)) photos[k] = await dataUrlToBlob(v);
        await replaceAll(parsed.data, parsed.settings, Object.keys(photos).length ? photos : undefined);
        lastStepIndex = -1;
        setSession(() => emptySession());
        get().leaveTraining();
        set({ settings: parsed.settings, data: sortData(parsed.data), recipePane: NO_PANE, coffeePane: NO_PANE, historySel: null });
        applyTheme();
        ensureSession();
        await get().cupReload();
        say('msg_import_ok');
      } catch {
        say('msg_import_failed');
      }
    },

    async resetData() {
      lastStepIndex = -1;
      setSession(() => emptySession());
      get().leaveTraining();
      set({
        recipePane: NO_PANE, coffeePane: NO_PANE, historySel: null, recipeDraft: null, coffeeDraft: null, logDraft: null,
        overlays: [], tab: 'HOME',
      });
      const settings = defaultSettings();
      await replaceAll(emptyData(), settings, {});
      set({ settings, data: emptyData(), ...cupInitial() });
      applyTheme();
    },

    set(patch) { set(patch as Partial<AppState>); },
  };

  return {
    ...coreInitial(),
    ...cupInitial(),
    ...trainInitial(),
    ...(actions as Actions),
    ...createCupSlice(set, get, setData),
    ...createTrainSlice(set, get, setData),
  } as AppState;
});

export const getUnits = () => unitsOf(useApp.getState().settings);
export { epochDayOf };
