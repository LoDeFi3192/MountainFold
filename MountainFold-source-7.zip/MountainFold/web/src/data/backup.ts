// JSON backup, same format as the Android app (data/Repository.kt Backup). Field names, enum names and
// table names match, so a file exported on the Fold imports on the iPhone and the other way round.
import {
  Brew, Coffee, CuppingCoffee, CuppingSession, defaultSettings, FLEX_LAYOUTS, Grinder, LabRecipe,
  METHOD_KEYS, PALETTES, Recipe, Settings, TrainingEvent, DEFAULT_INVITE_URL,
} from '../core/models';
import { AppData } from './db';

export const APP_ID = 'MountainFold';

type O = Record<string, unknown>;
const obj = (v: unknown): O => (v && typeof v === 'object' && !Array.isArray(v) ? (v as O) : {});
const str = (v: unknown, d = '') => (typeof v === 'string' ? v : d);
const num = (v: unknown, d = 0) => (typeof v === 'number' && Number.isFinite(v) ? v : typeof v === 'string' && v.trim() !== '' && Number.isFinite(Number(v)) ? Number(v) : d);
const int = (v: unknown, d = 0) => Math.trunc(num(v, d));
const numOrNull = (v: unknown) => (v == null ? null : typeof v === 'number' && Number.isFinite(v) ? v : null);
const intOrNull = (v: unknown) => { const n = numOrNull(v); return n == null ? null : Math.trunc(n); };
const bool = (v: unknown, d = false) => (typeof v === 'boolean' ? v : d);
const strOrNull = (v: unknown) => (typeof v === 'string' ? v : null);
const oneOf = <T extends string>(v: unknown, list: readonly T[], d: T): T => (list.includes(v as T) ? (v as T) : d);
const strList = (v: unknown) => (Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string') : []);

export function normSettings(v: unknown): Settings {
  const o = obj(v);
  const d = defaultSettings();
  return {
    themeMode: oneOf(o.themeMode, ['SYSTEM', 'LIGHT', 'DARK'] as const, d.themeMode),
    dynamicColor: bool(o.dynamicColor, d.dynamicColor),
    palette: oneOf(o.palette, PALETTES, d.palette),
    defaultMethod: oneOf(o.defaultMethod, METHOD_KEYS, d.defaultMethod),
    defaultDoseG: num(o.defaultDoseG, d.defaultDoseG),
    autoStopAtTarget: bool(o.autoStopAtTarget, d.autoStopAtTarget),
    haptics: bool(o.haptics, d.haptics),
    sounds: bool(o.sounds, d.sounds),
    keepAwake: bool(o.keepAwake, d.keepAwake),
    weightUnit: oneOf(o.weightUnit, ['G', 'OZ'] as const, d.weightUnit),
    tempUnit: oneOf(o.tempUnit, ['C', 'F'] as const, d.tempUnit),
    layoutOverride: oneOf(o.layoutOverride, ['AUTO', 'CLOSED', 'OPEN', 'FLEX'] as const, d.layoutOverride),
    flexLayout: oneOf(o.flexLayout, FLEX_LAYOUTS, d.flexLayout),
    waterStepG: num(o.waterStepG, d.waterStepG),
    onboarded: bool(o.onboarded, d.onboarded),
    currentCoffeeId: intOrNull(o.currentCoffeeId),
    lastRecipeId: intOrNull(o.lastRecipeId),
    defaultGrinderId: intOrNull(o.defaultGrinderId),
    preferredMethods: (Array.isArray(o.preferredMethods) ? o.preferredMethods : []).filter((m): m is (typeof METHOD_KEYS)[number] => METHOD_KEYS.includes(m)),
    pendingBrewChallenge: strOrNull(o.pendingBrewChallenge),
    cuppingSessionId: strOrNull(o.cuppingSessionId),
    cuppingInviteUrl: str(o.cuppingInviteUrl, DEFAULT_INVITE_URL),
    grindMicrons: bool(o.grindMicrons, d.grindMicrons),
  };
}

export const normCoffee = (v: unknown): Coffee => {
  const o = obj(v);
  return {
    id: int(o.id), name: str(o.name), origin: str(o.origin), country: str(o.country), region: str(o.region),
    producer: str(o.producer), variety: str(o.variety), process: str(o.process), altitude: str(o.altitude),
    roaster: str(o.roaster), roastDateEpochDay: intOrNull(o.roastDateEpochDay), tastingNotes: str(o.tastingNotes),
    roastLevel: str(o.roastLevel), photoPath: strOrNull(o.photoPath), createdAt: int(o.createdAt),
  };
};

export const normRecipe = (v: unknown): Recipe => {
  const o = obj(v);
  return {
    id: int(o.id), name: str(o.name), method: str(o.method, 'V60'), coffeeId: intOrNull(o.coffeeId),
    doseG: num(o.doseG, 15), waterG: num(o.waterG, 250), tempC: o.tempC === undefined ? 93 : numOrNull(o.tempC),
    grind: str(o.grind), pressureBar: numOrNull(o.pressureBar), targetTimeS: int(o.targetTimeS, 180),
    stepsJson: str(o.stepsJson, '[]'), notes: str(o.notes), favorite: bool(o.favorite),
    createdAt: int(o.createdAt), updatedAt: int(o.updatedAt),
    waterId: strOrNull(o.waterId), waterNote: str(o.waterNote), additivesJson: str(o.additivesJson, '[]'),
    championId: strOrNull(o.championId),
  };
};

export const normBrew = (v: unknown): Brew => {
  const o = obj(v);
  return {
    id: int(o.id), coffeeId: intOrNull(o.coffeeId), recipeId: intOrNull(o.recipeId), coffeeName: str(o.coffeeName),
    recipeName: str(o.recipeName), method: str(o.method, 'V60'), doseG: num(o.doseG), waterG: num(o.waterG),
    tempC: numOrNull(o.tempC), grind: str(o.grind), grinderId: intOrNull(o.grinderId), grinderName: str(o.grinderName),
    pressureBar: numOrNull(o.pressureBar), timeMs: int(o.timeMs), targetTimeS: int(o.targetTimeS), notes: str(o.notes),
    rating: int(o.rating), acidity: int(o.acidity), sweetness: int(o.sweetness), body: int(o.body), balance: int(o.balance),
    clarity: int(o.clarity), symptoms: str(o.symptoms), stepsJson: str(o.stepsJson, '[]'), createdAt: int(o.createdAt),
    waterId: strOrNull(o.waterId), waterNote: str(o.waterNote), additivesJson: str(o.additivesJson, '[]'),
  };
};

export const normGrinder = (v: unknown): Grinder => {
  const o = obj(v);
  const step = numOrNull(o.micronsPerStep);
  return { id: int(o.id), name: str(o.name), notes: str(o.notes), micronsPerStep: step != null && step > 0 ? step : null };
};

export const normTraining = (v: unknown): TrainingEvent => {
  const o = obj(v);
  return {
    id: int(o.id), createdAt: int(o.createdAt), kind: str(o.kind), refId: str(o.refId), skill: str(o.skill),
    correct: int(o.correct), total: int(o.total), durationS: int(o.durationS), xp: int(o.xp), passed: bool(o.passed),
    breakdown: str(o.breakdown),
  };
};

export const normCupSession = (v: unknown): CuppingSession => {
  const o = obj(v);
  return {
    id: str(o.id), createdAt: int(o.createdAt), name: str(o.name), location: str(o.location), dateIso: str(o.dateIso),
    originNotes: str(o.originNotes), roasterNotes: str(o.roasterNotes), importerNotes: str(o.importerNotes),
  };
};

export const normCupCoffee = (v: unknown): CuppingCoffee => {
  const o = obj(v);
  return {
    id: str(o.id), sessionId: str(o.sessionId), position: int(o.position), name: str(o.name), isLocked: bool(o.isLocked),
    isFavorite: bool(o.isFavorite), timestamp: int(o.timestamp), process: str(o.process),
    fragranceScore: num(o.fragranceScore, 8), fragranceNotes: strList(o.fragranceNotes),
    flavorScore: num(o.flavorScore, 8), flavorNotes: strList(o.flavorNotes),
    aftertasteScore: num(o.aftertasteScore, 8), acidityScore: num(o.acidityScore, 8), acidityType: str(o.acidityType),
    acidityIntensity: str(o.acidityIntensity), bodyScore: num(o.bodyScore, 8), bodyType: str(o.bodyType),
    balanceScore: num(o.balanceScore, 8), comments: str(o.comments),
  };
};

export const normLab = (v: unknown): LabRecipe => {
  const o = obj(v);
  return {
    id: str(o.id), timestamp: int(o.timestamp), method: str(o.method, 'v60'), coffeeWeight: num(o.coffeeWeight, 20),
    ratio: num(o.ratio, 16), waterWeight: int(o.waterWeight), grindSize: str(o.grindSize), totalTime: int(o.totalTime),
    rating: num(o.rating, 8), notes: str(o.notes),
  };
};

const list = <T>(v: unknown, f: (x: unknown) => T): T[] => (Array.isArray(v) ? v.map(f) : []);

export interface ParsedBackup {
  settings: Settings;
  data: AppData;
  /** Web-only: photos as data URLs keyed by photoPath. Android ignores the field. */
  photos: Record<string, string>;
}

/** Throws when the file is not a Mountain Fold backup. */
export function parseBackup(text: string): ParsedBackup {
  const o = obj(JSON.parse(text));
  if (str(o.app, APP_ID) !== APP_ID) throw new Error('Not a Mountain Fold backup');
  const sessions = list(o.cuppingSessions, normCupSession).filter((s) => s.id);
  const ids = new Set(sessions.map((s) => s.id));
  const photos: Record<string, string> = {};
  for (const [k, v] of Object.entries(obj(o.webPhotos))) if (typeof v === 'string' && v.startsWith('data:image/')) photos[k] = v;
  return {
    settings: { ...normSettings(o.settings), onboarded: true },
    photos,
    data: {
      coffees: list(o.coffees, normCoffee),
      recipes: list(o.recipes, normRecipe),
      brews: list(o.brews, normBrew),
      grinders: list(o.grinders, normGrinder),
      training: list(o.training, normTraining),
      cuppingSessions: sessions,
      // Sessions first: coffees point at them.
      cuppingCoffees: list(o.cuppingCoffees, normCupCoffee).filter((c) => c.id && ids.has(c.sessionId)),
      labRecipes: list(o.labRecipes, normLab).filter((r) => r.id),
    },
  };
}

/** Same shape and field order as the Android export, pretty printed. */
export function buildBackup(settings: Settings, data: AppData, photos: Record<string, string> = {}): string {
  const out: O = {
    app: APP_ID,
    version: 1,
    exportedAt: Date.now(),
    settings: normSettings(settings),
    coffees: data.coffees.map(normCoffee),
    recipes: data.recipes.map(normRecipe),
    brews: data.brews.map(normBrew),
    grinders: data.grinders.map(normGrinder),
    training: data.training.map(normTraining),
    cuppingSessions: data.cuppingSessions.map(normCupSession),
    cuppingCoffees: data.cuppingCoffees.map(normCupCoffee),
    labRecipes: data.labRecipes.map(normLab),
  };
  if (Object.keys(photos).length) out.webPhotos = photos;
  return JSON.stringify(out, null, 4);
}
