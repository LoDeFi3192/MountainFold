// Champion recipes, waters, Apax Lab concentrates and grinder steps in microns. Same JSON as the Android
// app (assets/library/library.json, built by tools/gen_library.py), same rules as core/library/Library.kt.
import raw from '../data/library.json';
import type { Lang } from '../i18n/i18n';
import { BrewMethod, BrewStep, methodFromKey, StepType, STEP_TYPES } from './models';

export interface LText { en: string; fr: string; es: string }
export const lt = (x: LText | null | undefined, lang: Lang): string => (x ? x[lang] || x.en : '');

export type AdditiveUnit = 'G_PER_L' | 'DROPS';
export const ADDITIVE_UNITS: AdditiveUnit[] = ['G_PER_L', 'DROPS'];
export const CUSTOM_ADDITIVE = 'custom';

/** One mineral concentrate in a recipe: a known product (id) or a free one (name, id "custom"). */
export interface AdditiveLine { id: string; name: string; amount: number; unit: AdditiveUnit }

export interface LibStep { type: StepType; startS: number; targetWaterG: number | null; label: LText; note: LText | null }
export interface Champion {
  id: string; competition: 'WAC' | 'WBRC'; year: number; place: number; champion: string; country: LText;
  kind: 'COMPETITION' | 'SIGNATURE'; method: string; inverted: boolean | null; brewer: LText; filter: LText;
  doseG: number; waterG: number; tempC: number; grind: LText; grinder: string | null; clicks: number | null;
  grindMicrons: number | null; water: LText; waterId: string | null; additives: AdditiveLine[]; steps: LibStep[];
  targetTimeS: number; notes: LText | null; approx: boolean; source: string;
}
export interface Water {
  id: string; name: string; kind: string; fit: 'GOOD' | 'BASE' | 'AVOID';
  ca: number | null; mg: number | null; na: number | null; k: number | null; hco3: number | null; tds: number | null;
  gh: number | null; kh: number | null; use: LText; source: string;
}
export interface Additive { id: string; brand: string; name: string; code: string; effect: LText; composition: string; source: string }
export interface ApaxMix { id: string; name: LText; tonik: number; jamm: number; lylac: number }
export interface ApaxDrops { id: string; name: LText; min: number; max: number }
export interface GrinderStep { name: string; micronsPerStep: number; source: string }
export interface LibraryContent {
  version: number; champions: Champion[]; waters: Water[]; additives: Additive[]; apaxMixes: ApaxMix[];
  apaxDrops: ApaxDrops[]; grinderSteps: GrinderStep[];
}

/** The asset carries every field, but a missing one must never crash a screen: defaults as in Library.kt. */
function normalize(x: LibraryContent): LibraryContent {
  return {
    ...x,
    champions: (x.champions ?? []).map((c) => ({
      ...c, place: c.place ?? 1, kind: c.kind ?? 'COMPETITION', inverted: c.inverted ?? null, grinder: c.grinder ?? null, clicks: c.clicks ?? null,
      grindMicrons: c.grindMicrons ?? null, waterId: c.waterId ?? null, additives: c.additives ?? [], notes: c.notes ?? null, approx: !!c.approx,
      steps: (c.steps ?? []).map((st) => ({ ...st, targetWaterG: st.targetWaterG ?? null, note: st.note ?? null })),
    })),
    waters: x.waters ?? [], additives: x.additives ?? [], apaxMixes: x.apaxMixes ?? [], apaxDrops: x.apaxDrops ?? [], grinderSteps: x.grinderSteps ?? [],
  };
}

export const LIBRARY = normalize(raw as unknown as LibraryContent);
export const APAX_IDS = ['apax-tonik', 'apax-jamm', 'apax-lylac'];

export const champion = (id: string | null | undefined) => LIBRARY.champions.find((c) => c.id === id) ?? null;
export const water = (id: string | null | undefined) => LIBRARY.waters.find((w) => w.id === id) ?? null;
export const additive = (id: string | null | undefined) => LIBRARY.additives.find((a) => a.id === id) ?? null;
export const additiveLabel = (a: Additive) => [a.brand, a.name, a.code].filter((x) => x.trim()).join(' ');

/** Microns per click of a known grinder, matched by name. */
export function libraryMicronsPerStep(name: string | null | undefined): number | null {
  const n = name?.trim().toLowerCase();
  if (!n) return null;
  return LIBRARY.grinderSteps.find((g) => g.name.toLowerCase() === n)?.micronsPerStep ?? null;
}

/** Microns of a champion's grind: published, or worked out from the grinder and the clicks. */
export function micronsOf(c: Champion): { microns: number; published: boolean } | null {
  if (c.grindMicrons != null) return { microns: c.grindMicrons, published: true };
  const step = libraryMicronsPerStep(c.grinder);
  if (step == null || c.clicks == null) return null;
  return { microns: step * c.clicks, published: false };
}

export const championMethod = (c: Champion): BrewMethod => methodFromKey(c.method);
export const championSteps = (c: Champion, lang: Lang): BrewStep[] =>
  c.steps.map((s) => ({ label: lt(s.label, lang), type: s.type, startS: s.startS, targetWaterG: s.targetWaterG, note: lt(s.note, lang) }));

export const mixLines = (m: ApaxMix): AdditiveLine[] =>
  ([['apax-tonik', m.tonik], ['apax-jamm', m.jamm], ['apax-lylac', m.lylac]] as const)
    .filter(([, g]) => g > 0).map(([id, g]) => ({ id, name: '', amount: g, unit: 'G_PER_L' as AdditiveUnit }));

// ---- additives codec: the same JSON list the Android app stores in additivesJson ----------------
function normLine(v: unknown): AdditiveLine | null {
  if (!v || typeof v !== 'object') return null;
  const o = v as Record<string, unknown>;
  if (typeof o.id !== 'string' || !o.id) return null;
  const amount = typeof o.amount === 'number' && Number.isFinite(o.amount) ? o.amount : 0;
  const unit = ADDITIVE_UNITS.includes(o.unit as AdditiveUnit) ? (o.unit as AdditiveUnit) : 'G_PER_L';
  return { id: o.id, name: typeof o.name === 'string' ? o.name : '', amount, unit };
}
export const encodeAdditives = (lines: AdditiveLine[]) => JSON.stringify(lines.map((l) => ({ id: l.id, name: l.name, amount: l.amount, unit: l.unit })));
export function decodeAdditives(raw: string | null | undefined): AdditiveLine[] {
  if (!raw || !raw.trim()) return [];
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? v.map(normLine).filter((x): x is AdditiveLine => x != null) : [];
  } catch {
    return [];
  }
}

// ---- grind settings to microns and back ---------------------------------------------------------
const NUMBER = /^\s*(\d+(?:[.,]\d+)?)/;
const MICRONS = /(\d+(?:[.,]\d+)?)\s*(µm|um|μm|microns?)/i;
const toNum = (s: string) => Number(s.replace(',', '.'));

export const GrindMicrons = {
  /** The setting at the start of a grind field ("22", "22.5 clicks"), or null for words like "medium". */
  setting(grind: string): number | null { const m = NUMBER.exec(grind); return m ? toNum(m[1]) : null; },
  /** Microns already written in the field ("630 µm"). */
  written(grind: string): number | null { const m = MICRONS.exec(grind); return m ? toNum(m[1]) : null; },
  microns(grind: string, step: number | null | undefined): number | null {
    const w = GrindMicrons.written(grind);
    if (w != null) return w;
    const s = GrindMicrons.setting(grind);
    if (s == null || !step || step <= 0) return null;
    return s * step;
  },
  /** Clicks for a target in microns, to the nearest half click on fine grinders. */
  steps(microns: number, step: number | null | undefined): number | null {
    if (!step || step <= 0) return null;
    const r = microns / step;
    return step < 15 ? Math.round(r * 2) / 2 : Math.round(r);
  },
  /** Microns rounded to 10, the precision a burr set really holds. */
  format: (microns: number) => `${Math.round(microns / 10) * 10} µm`,
  /** Same decimal point as every other number in the app. */
  formatSteps: (steps: number) => String(steps),
};

export const isStepType = (v: unknown): v is StepType => STEP_TYPES.includes(v as StepType);
