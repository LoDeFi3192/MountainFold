// Same data model as the Android app (core/model + data/db). Field names and enum names are identical,
// so a backup written by one client imports into the other.

import type { AdditiveLine } from './library';

export type BrewMethod =
  | 'V60' | 'AEROPRESS' | 'CHEMEX' | 'FRENCH_PRESS' | 'MOKA' | 'ESPRESSO'
  | 'CLEVER' | 'KALITA' | 'ORIGAMI' | 'COLD_BREW' | 'CUSTOM';

export interface MethodInfo {
  label: string;
  defaultRatio: number;
  defaultTempC: number | null;
  defaultDoseG: number;
  defaultTimeS: number;
}

/** Values are sensible starting points, not rules. Order matters: it is the enum order of the Android app. */
export const METHODS: Record<BrewMethod, MethodInfo> = {
  V60: { label: 'V60', defaultRatio: 16.7, defaultTempC: 93, defaultDoseG: 15, defaultTimeS: 180 },
  AEROPRESS: { label: 'AeroPress', defaultRatio: 15, defaultTempC: 90, defaultDoseG: 15, defaultTimeS: 120 },
  CHEMEX: { label: 'Chemex', defaultRatio: 16, defaultTempC: 94, defaultDoseG: 30, defaultTimeS: 270 },
  FRENCH_PRESS: { label: 'French Press', defaultRatio: 15, defaultTempC: 95, defaultDoseG: 30, defaultTimeS: 480 },
  MOKA: { label: 'Moka Pot', defaultRatio: 10, defaultTempC: null, defaultDoseG: 15, defaultTimeS: 240 },
  ESPRESSO: { label: 'Espresso', defaultRatio: 2, defaultTempC: 93, defaultDoseG: 18, defaultTimeS: 28 },
  CLEVER: { label: 'Clever Dripper', defaultRatio: 16, defaultTempC: 95, defaultDoseG: 18, defaultTimeS: 210 },
  KALITA: { label: 'Kalita Wave', defaultRatio: 16, defaultTempC: 93, defaultDoseG: 20, defaultTimeS: 210 },
  ORIGAMI: { label: 'Origami', defaultRatio: 16, defaultTempC: 93, defaultDoseG: 15, defaultTimeS: 165 },
  COLD_BREW: { label: 'Cold Brew', defaultRatio: 8, defaultTempC: null, defaultDoseG: 100, defaultTimeS: 57600 },
  CUSTOM: { label: 'Custom', defaultRatio: 16, defaultTempC: 93, defaultDoseG: 15, defaultTimeS: 180 },
};
export const METHOD_KEYS = Object.keys(METHODS) as BrewMethod[];
export const isEspresso = (m: BrewMethod) => m === 'ESPRESSO';
export const methodFromKey = (k: string | null | undefined): BrewMethod =>
  (METHOD_KEYS as string[]).includes(k ?? '') ? (k as BrewMethod) : 'V60';

export const STEP_TYPES = ['BLOOM', 'POUR', 'WAIT', 'STIR', 'SWIRL', 'PRESS', 'DRAWDOWN', 'CUSTOM'] as const;
export type StepType = (typeof STEP_TYPES)[number];

/** [startS] counts from brew start. [targetWaterG] is the cumulative scale weight at the end of the step. */
export interface BrewStep {
  label: string;
  type: StepType;
  startS: number;
  targetWaterG: number | null;
  note: string;
}

export const step = (label: string, type: StepType = 'POUR', startS = 0, targetWaterG: number | null = null, note = ''): BrewStep =>
  ({ label, type, startS, targetWaterG, note });

/** Frozen copy of a recipe used by an active brew. */
export interface SessionRecipe {
  recipeId: number | null;
  name: string;
  method: BrewMethod;
  coffeeId: number | null;
  coffeeName: string;
  doseG: number;
  waterG: number;
  tempC: number | null;
  grind: string;
  pressureBar: number | null;
  steps: BrewStep[];
  targetTimeS: number;
  notes: string;
  waterId: string | null;
  waterNote: string;
  additives: AdditiveLine[];
}

export const SYMPTOMS = ['SOUR', 'BITTER', 'WEAK', 'STRONG', 'DRY', 'ASTRINGENT', 'FLAT', 'HOLLOW', 'HARSH', 'MUDDY'] as const;
export type Symptom = (typeof SYMPTOMS)[number];

export type ThemeMode = 'SYSTEM' | 'LIGHT' | 'DARK';
export const PALETTES = ['COFFEE', 'MOUNTAIN', 'FOREST', 'STONE', 'TOULOUSE', 'COBALT', 'SAGE'] as const;
export type Palette = (typeof PALETTES)[number];
export type WeightUnit = 'G' | 'OZ';
export type TempUnit = 'C' | 'F';
export type LayoutOverride = 'AUTO' | 'CLOSED' | 'OPEN' | 'FLEX';
export const FLEX_LAYOUTS = ['BREW', 'TIMER', 'RECIPE', 'SCALE', 'SHOT'] as const;
export type FlexLayout = (typeof FLEX_LAYOUTS)[number];

// ---- rows ------------------------------------------------------------------------------------

export interface Coffee {
  id: number;
  name: string;
  origin: string;
  country: string;
  region: string;
  producer: string;
  variety: string;
  process: string;
  altitude: string;
  roaster: string;
  /** Days since 1970-01-01, local date. */
  roastDateEpochDay: number | null;
  tastingNotes: string;
  roastLevel: string;
  photoPath: string | null;
  createdAt: number;
}

export const newCoffee = (): Coffee => ({
  id: 0, name: '', origin: '', country: '', region: '', producer: '', variety: '', process: '', altitude: '',
  roaster: '', roastDateEpochDay: null, tastingNotes: '', roastLevel: '', photoPath: null, createdAt: 0,
});

export interface Recipe {
  id: number;
  name: string;
  method: string;
  coffeeId: number | null;
  doseG: number;
  /** Brew water for filter methods, yield in the cup for espresso. */
  waterG: number;
  tempC: number | null;
  grind: string;
  pressureBar: number | null;
  targetTimeS: number;
  /** JSON list of BrewStep, kept as text exactly like the Android database. */
  stepsJson: string;
  notes: string;
  favorite: boolean;
  createdAt: number;
  updatedAt: number;
  /** Library water (data/library.json), or null. */
  waterId: string | null;
  /** Free text: a tap water, a filter, a home recipe. */
  waterNote: string;
  /** JSON list of AdditiveLine: mineral concentrates added to the water. */
  additivesJson: string;
  /** Champion recipe this one was copied from. */
  championId: string | null;
}

export interface Brew {
  id: number;
  coffeeId: number | null;
  recipeId: number | null;
  coffeeName: string;
  recipeName: string;
  method: string;
  doseG: number;
  waterG: number;
  tempC: number | null;
  grind: string;
  grinderId: number | null;
  grinderName: string;
  pressureBar: number | null;
  timeMs: number;
  targetTimeS: number;
  notes: string;
  rating: number;
  acidity: number;
  sweetness: number;
  body: number;
  balance: number;
  clarity: number;
  /** Comma separated Symptom names. */
  symptoms: string;
  stepsJson: string;
  createdAt: number;
  waterId: string | null;
  waterNote: string;
  additivesJson: string;
}

export interface Grinder {
  id: number;
  name: string;
  notes: string;
  /** Microns per click, set by the user. Null falls back to the library value for known grinders. */
  micronsPerStep: number | null;
}

export interface TrainingEvent {
  id: number;
  createdAt: number;
  kind: string;
  refId: string;
  skill: string;
  correct: number;
  total: number;
  durationS: number;
  xp: number;
  passed: boolean;
  breakdown: string;
}

export interface CuppingSession {
  id: string;
  createdAt: number;
  name: string;
  location: string;
  /** Local date, yyyy-MM-dd. */
  dateIso: string;
  originNotes: string;
  roasterNotes: string;
  importerNotes: string;
}

export interface CuppingCoffee {
  id: string;
  sessionId: string;
  position: number;
  name: string;
  isLocked: boolean;
  isFavorite: boolean;
  timestamp: number;
  process: string;
  fragranceScore: number;
  fragranceNotes: string[];
  flavorScore: number;
  flavorNotes: string[];
  aftertasteScore: number;
  acidityScore: number;
  acidityType: string;
  acidityIntensity: string;
  bodyScore: number;
  bodyType: string;
  balanceScore: number;
  comments: string;
}

export interface LabRecipe {
  id: string;
  timestamp: number;
  method: string;
  coffeeWeight: number;
  ratio: number;
  waterWeight: number;
  grindSize: string;
  totalTime: number;
  rating: number;
  notes: string;
}

export const DEFAULT_INVITE_URL = 'https://toulouse-cupping-v2-fini-696310574132.us-west1.run.app/';

export interface Settings {
  themeMode: ThemeMode;
  dynamicColor: boolean;
  palette: Palette;
  defaultMethod: BrewMethod;
  defaultDoseG: number;
  autoStopAtTarget: boolean;
  haptics: boolean;
  sounds: boolean;
  keepAwake: boolean;
  weightUnit: WeightUnit;
  tempUnit: TempUnit;
  layoutOverride: LayoutOverride;
  flexLayout: FlexLayout;
  waterStepG: number;
  onboarded: boolean;
  currentCoffeeId: number | null;
  lastRecipeId: number | null;
  defaultGrinderId: number | null;
  preferredMethods: BrewMethod[];
  pendingBrewChallenge: string | null;
  cuppingSessionId: string | null;
  cuppingInviteUrl: string;
  /** Shows grind settings in microns next to clicks, from each grinder's microns per click. */
  grindMicrons: boolean;
}

export const defaultSettings = (): Settings => ({
  themeMode: 'SYSTEM',
  dynamicColor: true,
  palette: 'COFFEE',
  defaultMethod: 'V60',
  defaultDoseG: 15,
  autoStopAtTarget: false,
  haptics: true,
  sounds: false,
  keepAwake: true,
  weightUnit: 'G',
  tempUnit: 'C',
  layoutOverride: 'AUTO',
  flexLayout: 'BREW',
  waterStepG: 50,
  onboarded: false,
  currentCoffeeId: null,
  lastRecipeId: null,
  defaultGrinderId: null,
  preferredMethods: [],
  pendingBrewChallenge: null,
  cuppingSessionId: null,
  cuppingInviteUrl: DEFAULT_INVITE_URL,
  grindMicrons: false,
});

export const cuppingFinalScore = (c: CuppingCoffee) =>
  (c.fragranceScore + c.flavorScore + c.aftertasteScore + c.acidityScore + c.bodyScore + c.balanceScore) / 6;

/** Fragrance and flavor notes merged, first occurrence order, no duplicates. */
export const cuppingUniqueNotes = (c: CuppingCoffee) => [...new Set([...c.fragranceNotes, ...c.flavorNotes])];
