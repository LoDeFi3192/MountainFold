// Starter recipes, same numbers and steps as the Android SeedData. They are ordinary rows the user can edit.
import { encodeSteps, round1 } from './coffee';
import { BrewMethod, BrewStep, isEspresso, METHOD_KEYS, METHODS, Recipe, step } from './models';
import { t } from '../i18n/i18n';

export const GRINDER_PRESETS = [
  'Comandante C40', 'Comandante C40 Red Clix', '1Zpresso K-Ultra', '1Zpresso K-Max', '1Zpresso JX-Pro',
  '1Zpresso J-Max', '1Zpresso ZP6', '1Zpresso X-Ultra', '1Zpresso Q2', 'Timemore C3',
  'Kinu M47', 'Baratza Encore', 'Fellow Ode Gen 2', 'Wilfa Uniform', 'Niche Zero',
  'DF64', 'Eureka Mignon', 'Mahlkönig EK43',
];

export function defaultGrind(m: BrewMethod): string {
  switch (m) {
    case 'ESPRESSO': case 'MOKA': return t('grind_fine');
    case 'V60': case 'AEROPRESS': case 'ORIGAMI': return t('grind_medium_fine');
    case 'KALITA': case 'CLEVER': case 'CUSTOM': return t('grind_medium');
    case 'CHEMEX': return t('grind_medium_coarse');
    case 'FRENCH_PRESS': case 'COLD_BREW': return t('grind_coarse');
  }
}

export const methodLabel = (m: BrewMethod) => (m === 'CUSTOM' ? t('method_custom') : METHODS[m].label);

export function defaultSteps(m: BrewMethod, dose: number, water: number): BrewStep[] {
  const w = (fraction: number) => round1(Math.min(water, Math.round((water * fraction) / 5) * 5));
  const bloom = round1(dose * 3);
  const s = (k: string, ...a: (string | number)[]) => t(k, ...a);
  switch (m) {
    case 'V60': return [
      step(s('step_bloom'), 'BLOOM', 0, bloom, s('note_bloom')), step(s('step_pour_n', 1), 'POUR', 45, w(0.48)),
      step(s('step_pour_n', 2), 'POUR', 80, w(0.76)), step(s('step_final_pour'), 'POUR', 130, water)];
    case 'ORIGAMI': return [
      step(s('step_bloom'), 'BLOOM', 0, bloom, s('note_bloom')), step(s('step_pour_n', 1), 'POUR', 40, w(0.5)),
      step(s('step_pour_n', 2), 'POUR', 70, w(0.75)), step(s('step_final_pour'), 'POUR', 100, water)];
    case 'KALITA': return [
      step(s('step_bloom'), 'BLOOM', 0, bloom, s('note_bloom')), step(s('step_pour_n', 1), 'POUR', 40, w(0.47)),
      step(s('step_pour_n', 2), 'POUR', 75, w(0.73)), step(s('step_final_pour'), 'POUR', 110, water), step(s('step_drawdown'), 'DRAWDOWN', 150)];
    case 'CHEMEX': return [
      step(s('step_bloom'), 'BLOOM', 0, bloom, s('note_bloom')), step(s('step_pour_n', 1), 'POUR', 45, w(0.52)),
      step(s('step_pour_n', 2), 'POUR', 105, w(0.79)), step(s('step_final_pour'), 'POUR', 165, water), step(s('step_drawdown'), 'DRAWDOWN', 200)];
    case 'AEROPRESS': return [
      step(s('step_pour_all'), 'POUR', 0, water), step(s('step_stir'), 'STIR', 10, null, s('note_stir')),
      step(s('step_steep'), 'WAIT', 20), step(s('step_press'), 'PRESS', 90, null, s('note_press'))];
    case 'CLEVER': return [
      step(s('step_pour_all'), 'POUR', 0, water), step(s('step_stir'), 'STIR', 20, null, s('note_stir')),
      step(s('step_steep'), 'WAIT', 30), step(s('step_drawdown'), 'DRAWDOWN', 135, null, s('note_clever_draw'))];
    case 'FRENCH_PRESS': return [
      step(s('step_pour_all'), 'POUR', 0, water), step(s('step_steep'), 'WAIT', 30),
      step(s('step_break_crust'), 'STIR', 240, null, s('note_break_crust')), step(s('step_settle'), 'WAIT', 270)];
    case 'MOKA': return [
      step(s('step_heat'), 'WAIT', 0, null, s('note_moka_heat')), step(s('step_lower_heat'), 'CUSTOM', 150, null, s('note_moka_flow')),
      step(s('step_remove_heat'), 'CUSTOM', 210, null, s('note_moka_cool'))];
    case 'ESPRESSO': return [step(s('step_preinfusion'), 'WAIT', 0), step(s('step_extraction'), 'POUR', 6, water)];
    case 'COLD_BREW': return [
      step(s('step_pour_all'), 'POUR', 0, water), step(s('step_stir'), 'STIR', 60, null, s('note_stir')),
      step(s('step_steep'), 'WAIT', 120, null, s('note_cold_steep'))];
    case 'CUSTOM': return [step(s('step_bloom'), 'BLOOM', 0, bloom), step(s('step_final_pour'), 'POUR', 45, water)];
  }
}

export function defaultRecipe(m: BrewMethod, doseG = METHODS[m].defaultDoseG, now = Date.now()): Recipe {
  // Whole numbers a barista would actually pour: 15 g at 1:16.7 is 250 g, not 250.5 g.
  const raw = doseG * METHODS[m].defaultRatio;
  const water = raw >= 100 ? Math.round(raw / 5) * 5 : Math.round(raw);
  return {
    id: 0,
    name: m === 'CUSTOM' ? t('method_custom') : t('seed_recipe_name', METHODS[m].label),
    method: m,
    coffeeId: null,
    doseG,
    waterG: water,
    tempC: METHODS[m].defaultTempC,
    grind: defaultGrind(m),
    pressureBar: isEspresso(m) ? 9 : null,
    targetTimeS: METHODS[m].defaultTimeS,
    stepsJson: encodeSteps(defaultSteps(m, doseG, water)),
    notes: '',
    favorite: false,
    createdAt: now,
    updatedAt: now,
    waterId: null,
    waterNote: '',
    additivesJson: '[]',
    championId: null,
  };
}

export const starterRecipes = (favorites: BrewMethod[], now = Date.now()) =>
  METHOD_KEYS.filter((m) => m !== 'CUSTOM').map((m, i) => ({ ...defaultRecipe(m, METHODS[m].defaultDoseG, now - i), favorite: favorites.includes(m) }));
