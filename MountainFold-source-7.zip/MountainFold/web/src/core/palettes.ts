// Same colour system as the Android app's fallback palettes: tonal palettes in CIE LCh,
// so "tone" means perceptual lightness, the idea Material You uses. iOS has no dynamic colour,
// so the web app always uses these.
import { Palette } from './models';

export type Scheme = Record<string, string>;

interface Seed { ph: number; pc: number; sh: number; sc: number; th: number; tc: number; nh: number; nc: number }
const SEEDS: Record<Exclude<Palette, 'TOULOUSE' | 'COBALT' | 'SAGE'>, Seed> = {
  COFFEE: { ph: 58, pc: 40, sh: 68, sc: 16, th: 115, tc: 26, nh: 62, nc: 6 },
  MOUNTAIN: { ph: 255, pc: 30, sh: 245, sc: 12, th: 60, tc: 30, nh: 255, nc: 5 },
  FOREST: { ph: 150, pc: 34, sh: 140, sc: 13, th: 85, tc: 28, nh: 140, nc: 5 },
  STONE: { ph: 80, pc: 9, sh: 80, sc: 6, th: 45, tc: 22, nh: 80, nc: 3 },
};

function labToLinearRgb(l: number, a: number, b: number): [number, number, number] {
  const fy = (l + 16) / 116;
  const fx = fy + a / 500;
  const fz = fy - b / 200;
  const inv = (t: number) => (t * t * t > 0.008856 ? t * t * t : (116 * t - 16) / 903.3);
  const x = 0.95047 * inv(fx);
  const y = inv(fy);
  const z = 1.08883 * inv(fz);
  return [
    3.2404542 * x - 1.5371385 * y - 0.4985314 * z,
    -0.969266 * x + 1.8760108 * y + 0.041556 * z,
    0.0556434 * x - 0.2040259 * y + 1.0572252 * z,
  ];
}

const gamma = (v: number) => {
  const c = Math.min(1, Math.max(0, v));
  return c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
};

const hex = (rgb: [number, number, number]) =>
  '#' + rgb.map((v) => Math.round(gamma(v) * 255).toString(16).padStart(2, '0')).join('').toUpperCase();

/** CIE LCh(ab) to sRGB. Chroma is reduced until the colour fits the gamut, keeping lightness intact. */
export function lch(l: number, c: number, hDeg: number): string {
  let chroma = c;
  const h = (hDeg * Math.PI) / 180;
  for (let i = 0; i < 40; i++) {
    const rgb = labToLinearRgb(l, chroma * Math.cos(h), chroma * Math.sin(h));
    if (rgb.every((v) => v >= -0.0005 && v <= 1.0005) || chroma < 0.5) return hex(rgb);
    chroma *= 0.92;
  }
  return hex(labToLinearRgb(l, 0, 0));
}

export function scheme(palette: Palette, dark: boolean): Scheme {
  if (palette === 'TOULOUSE') return toulouse(dark);
  if (palette === 'COBALT') return cobalt(dark);
  if (palette === 'SAGE') return sage(dark);
  const s = SEEDS[palette];
  const p = (t: number) => lch(t, s.pc, s.ph);
  const sec = (t: number) => lch(t, s.sc, s.sh);
  const ter = (t: number) => lch(t, s.tc, s.th);
  const n = (t: number) => lch(t, s.nc, s.nh);
  const nv = (t: number) => lch(t, s.nc * 2 + 2, s.nh);
  const err = (t: number) => lch(t, 60, 30);
  return !dark
    ? {
        primary: p(38), onPrimary: p(100), primaryContainer: p(90), onPrimaryContainer: p(14),
        secondary: sec(40), onSecondary: sec(100), secondaryContainer: sec(90), onSecondaryContainer: sec(14),
        tertiary: ter(40), onTertiary: ter(100), tertiaryContainer: ter(90), onTertiaryContainer: ter(14),
        error: err(40), onError: err(100), errorContainer: err(90), onErrorContainer: err(14),
        background: n(98), onBackground: n(10), surface: n(98), onSurface: n(10),
        surfaceVariant: nv(90), onSurfaceVariant: nv(30), outline: nv(48), outlineVariant: nv(80),
        inverseSurface: n(20), inverseOnSurface: n(95), inversePrimary: p(80),
        surfaceDim: n(87), surfaceBright: n(98), surfaceContainerLowest: n(100),
        surfaceContainerLow: n(96), surfaceContainer: n(94), surfaceContainerHigh: n(92), surfaceContainerHighest: n(90),
      }
    : {
        primary: p(82), onPrimary: p(20), primaryContainer: p(30), onPrimaryContainer: p(92),
        secondary: sec(80), onSecondary: sec(20), secondaryContainer: sec(30), onSecondaryContainer: sec(90),
        tertiary: ter(80), onTertiary: ter(20), tertiaryContainer: ter(30), onTertiaryContainer: ter(90),
        error: err(80), onError: err(20), errorContainer: err(30), onErrorContainer: err(90),
        background: n(5), onBackground: n(92), surface: n(5), onSurface: n(92),
        surfaceVariant: nv(28), onSurfaceVariant: nv(82), outline: nv(60), outlineVariant: nv(28),
        inverseSurface: n(90), inverseOnSurface: n(20), inversePrimary: p(38),
        surfaceDim: n(5), surfaceBright: n(24), surfaceContainerLowest: n(3),
        surfaceContainerLow: n(9), surfaceContainer: n(12), surfaceContainerHigh: n(16), surfaceContainerHighest: n(21),
      };
}

/** The exact light "Coffee" and dark "Espresso" tokens of the Toulouse Cupping web app. */
function toulouse(dark: boolean): Scheme {
  return !dark
    ? {
        primary: '#8D6E4D', onPrimary: '#FFFFFF', primaryContainer: '#FFDCBE', onPrimaryContainer: '#2C1600',
        secondary: '#77574E', onSecondary: '#FFFFFF', secondaryContainer: '#FFDBD1', onSecondaryContainer: '#2C150F',
        tertiary: '#6C5D2F', onTertiary: '#FFFFFF', tertiaryContainer: '#F5E1A6', onTertiaryContainer: '#221B00',
        error: '#BA1A1A', onError: '#FFFFFF', errorContainer: '#FFDAD6', onErrorContainer: '#410002',
        background: '#FFF8F6', onBackground: '#201A18', surface: '#FFF8F6', onSurface: '#201A18',
        surfaceVariant: '#F4DED4', onSurfaceVariant: '#52433D', outline: '#85736D', outlineVariant: '#D7C2B8',
        inverseSurface: '#362F2C', inverseOnSurface: '#FBEEE9', inversePrimary: '#FFB77C',
        surfaceDim: '#E8D7D1', surfaceBright: '#FFF8F6', surfaceContainerLowest: '#FFFFFF',
        surfaceContainerLow: '#FFF1EC', surfaceContainer: '#FCECE6', surfaceContainerHigh: '#F6E6E0', surfaceContainerHighest: '#F0E1DB',
      }
    : {
        primary: '#FFB77C', onPrimary: '#50381A', primaryContainer: '#6E5231', onPrimaryContainer: '#FFDCBE',
        secondary: '#E7BDB2', onSecondary: '#442922', secondaryContainer: '#5D3F38', onSecondaryContainer: '#FFDBD1',
        tertiary: '#D8C58D', onTertiary: '#3B2F06', tertiaryContainer: '#53461A', onTertiaryContainer: '#F5E1A6',
        error: '#FFB4AB', onError: '#690005', errorContainer: '#93000A', onErrorContainer: '#FFDAD6',
        background: '#18120F', onBackground: '#ECE0DB', surface: '#18120F', onSurface: '#ECE0DB',
        surfaceVariant: '#52433D', onSurfaceVariant: '#D7C2B8', outline: '#A08C85', outlineVariant: '#52433D',
        inverseSurface: '#ECE0DB', inverseOnSurface: '#362F2C', inversePrimary: '#8D6E4D',
        surfaceDim: '#18120F', surfaceBright: '#3F3734', surfaceContainerLowest: '#0F0A07',
        surfaceContainerLow: '#1D1714', surfaceContainer: '#211B18', surfaceContainerHigh: '#2B2522', surfaceContainerHighest: '#362F2C',
      };
}

/** Cobalt: Warm beige #EDECE6 base, cobalt blue #1546D9 highlights, sun yellow #F9B318 contrast (selected states, navigation). Text pairs checked at WCAG AA by tests/palettes.test.ts. */
function cobalt(dark: boolean): Scheme {
  return !dark
    ? {
        primary: '#1546D9', onPrimary: '#FFFFFF', primaryContainer: '#D9E2FD', onPrimaryContainer: '#00255D',
        secondary: '#835C00', onSecondary: '#FFFFFF', secondaryContainer: '#F9B318', onSecondaryContainer: '#2B1D00',
        tertiary: '#133E8C', onTertiary: '#FFFFFF', tertiaryContainer: '#FEDEB2', onTertiaryContainer: '#302102',
        error: '#BA1A1A', onError: '#FFFFFF', errorContainer: '#FFDAD6', onErrorContainer: '#410002', background: '#EDECE6',
        onBackground: '#1C1C17', surface: '#EDECE6', onSurface: '#1C1C17', surfaceVariant: '#DFDDD2',
        onSurfaceVariant: '#48473E', outline: '#79776D', outlineVariant: '#C6C4B9', inverseSurface: '#31302C',
        inverseOnSurface: '#F2F1EB', inversePrimary: '#AFC6FB', surfaceDim: '#D3D2CC', surfaceBright: '#F5F4EE',
        surfaceContainerLowest: '#FAF9F3', surfaceContainerLow: '#E6E5DF', surfaceContainer: '#E1E0DA',
        surfaceContainerHigh: '#DBDAD4', surfaceContainerHighest: '#D5D4CF',
      }
    : {
        primary: '#A6C1FC', onPrimary: '#092962', primaryContainer: '#1546D9', onPrimaryContainer: '#E8EEFE',
        secondary: '#F9B318', onSecondary: '#302102', secondaryContainer: '#F9B318', onSecondaryContainer: '#2B1D00',
        tertiary: '#FEC972', onTertiary: '#412D02', tertiaryContainer: '#5F4101', onTertiaryContainer: '#FEE4C2',
        error: '#FFB4AB', onError: '#690005', errorContainer: '#93000A', onErrorContainer: '#FFDAD6', background: '#161611',
        onBackground: '#E9E8E2', surface: '#161611', onSurface: '#E9E8E2', surfaceVariant: '#48473E',
        onSurfaceVariant: '#C9C7BB', outline: '#939186', outlineVariant: '#48473E', inverseSurface: '#E4E3DD',
        inverseOnSurface: '#31302C', inversePrimary: '#1546D9', surfaceDim: '#161611', surfaceBright: '#3C3B37',
        surfaceContainerLowest: '#0F0E07', surfaceContainerLow: '#1C1C17', surfaceContainer: '#22221D',
        surfaceContainerHigh: '#2B2A26', surfaceContainerHighest: '#363530',
      };
}

/** Sage: Muted sage grey #A5A79B base, warm cream #E8D2B5 highlights, deep burgundy #590907 contrast (buttons, accents). Containers step lighter than the mid-tone base so text stays above 4.5:1. Text pairs checked at WCAG AA by tests/palettes.test.ts. */
function sage(dark: boolean): Scheme {
  return !dark
    ? {
        primary: '#590907', onPrimary: '#E8D2B5', primaryContainer: '#E8D2B5', onPrimaryContainer: '#590907',
        secondary: '#6B1D1D', onSecondary: '#E8D2B5', secondaryContainer: '#E8D2B5', onSecondaryContainer: '#500005',
        tertiary: '#661819', onTertiary: '#FFFFFF', tertiaryContainer: '#FDD3CE', onTertiaryContainer: '#480101',
        error: '#741008', onError: '#FFFFFF', errorContainer: '#F7D7D2', onErrorContainer: '#410002', background: '#A5A79B',
        onBackground: '#1B1C18', surface: '#A5A79B', onSurface: '#1B1C18', surfaceVariant: '#B5B8A7',
        onSurfaceVariant: '#34352E', outline: '#545648', outlineVariant: '#8A8D7D', inverseSurface: '#30312C',
        inverseOnSurface: '#EDEFE2', inversePrimary: '#E8D2B5', surfaceDim: '#95978B', surfaceBright: '#BBBDB0',
        surfaceContainerLowest: '#C6C8BB', surfaceContainerLow: '#ADAFA3', surfaceContainer: '#B2B4A8',
        surfaceContainerHigh: '#B8BAAE', surfaceContainerHighest: '#BDBFB3',
      }
    : {
        primary: '#E8D2B5', onPrimary: '#590907', primaryContainer: '#590907', onPrimaryContainer: '#E8D2B5',
        secondary: '#A5A79B', onSecondary: '#1F201C', secondaryContainer: '#A5A79B', onSecondaryContainer: '#1B1C18',
        tertiary: '#ECA49C', onTertiary: '#55060B', tertiaryContainer: '#712221', onTertiaryContainer: '#FEDAD6',
        error: '#FFB4AB', onError: '#690005', errorContainer: '#93000A', onErrorContainer: '#FFDAD6', background: '#171814',
        onBackground: '#E4E6DA', surface: '#171814', onSurface: '#E4E6DA', surfaceVariant: '#42433B',
        onSurfaceVariant: '#C5C8B7', outline: '#8A8D7D', outlineVariant: '#42433B', inverseSurface: '#E2E4D7',
        inverseOnSurface: '#30312C', inversePrimary: '#590907', surfaceDim: '#171814', surfaceBright: '#3B3C37',
        surfaceContainerLowest: '#11110C', surfaceContainerLow: '#1D1E1A', surfaceContainer: '#232420',
        surfaceContainerHigh: '#2C2C28', surfaceContainerHighest: '#373733',
      };
}

const kebab = (k: string) => k.replace(/[A-Z]/g, (m) => '-' + m.toLowerCase());

/** Writes the scheme as CSS custom properties on :root. */
export function applyScheme(s: Scheme, dark: boolean) {
  const root = document.documentElement;
  for (const [k, v] of Object.entries(s)) root.style.setProperty(`--${kebab(k)}`, v);
  root.style.setProperty('color-scheme', dark ? 'dark' : 'light');
  root.dataset.theme = dark ? 'dark' : 'light';
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', s.surface);
  // Read by index.html at the next launch to pick the iOS status bar style (see there).
  try { localStorage.setItem('mf.statusDark', dark ? '1' : '0'); } catch { /* private mode */ }
}
