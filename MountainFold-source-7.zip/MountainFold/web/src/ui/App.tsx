// Root of the UI: picks one of five layouts from the posture, like Root.kt. No screen state lives below
// this point that a layout swap could destroy: the brew, drafts and navigation are in the store.
import { useEffect, useRef, useState } from 'react';
import { t } from '../i18n/i18n';
import { isIOS, isStandalone, setKeepAwake } from '../platform/device';
import { readLocal, writeLocal } from '../data/db';
import { useApp } from '../state/store';
import { currentTrainScreen, isTrainDesk } from '../state/trainer';
import { Tab, TABS } from '../state/types';
import { Btn, ConfirmDialog, Icon, IconButton, TcIcon } from './components';
import { useLayout } from './layout';
import { BrewScreen, FlexCompanion } from './screens/Brew';
import { HistoryScreen, LogBrewScreen } from './screens/History';
import { HomeScreen } from './screens/Home';
import { CoffeeScreen, RecipesScreen } from './screens/Library';
import { Onboarding, SettingsScreen } from './screens/Settings';
import { CalculatorScreen, CompareScreen, DiagnoseScreen, GrindAdvisorScreen } from './screens/Tools';
import { WaterGuideScreen } from './screens/LibraryExtras';
import { TrainDesk, TrainScreen } from './screens/Train';
import { CuppingDesk, CuppingTab, cupHidesBar, isCupDesk } from './cupping/CupScreens';

type Kind = 'COMPANION' | 'TRAIN_DESK' | 'CUP_DESK' | 'WIDE' | 'COMPACT';

const TAB_ICON: Record<Tab, string> = { HOME: 'home', BREW: 'coffee_maker', RECIPES: 'menu_book', COFFEE: 'coffee', CUPPING: 'tc:Wheel', TRAIN: 'school', HISTORY: 'history' };
const TAB_LABEL: Record<Tab, string> = { HOME: 'tab_home', BREW: 'tab_brew', RECIPES: 'tab_recipes', COFFEE: 'tab_coffee', CUPPING: 'tab_cupping', TRAIN: 'tab_train', HISTORY: 'tab_history' };

function TabIcon({ tab, running }: { tab: Tab; running: boolean }) {
  const name = TAB_ICON[tab];
  return (
    <span className="nav-pill">
      {name.startsWith('tc:') ? <TcIcon name={name.slice(3)} /> : <Icon name={name} />}
      {tab === 'BREW' && running && <span className="nav-badge" />}
    </span>
  );
}

export function App() {
  const ready = useApp((s) => s.ready);
  const onboarded = useApp((s) => s.settings.onboarded);
  const lang = useApp((s) => s.lang);
  if (!ready) return <div className="app" />;
  return <div key={lang} style={{ display: 'contents' }}>{onboarded ? <Shell /> : <Onboarding />}</div>;
}

function Shell() {
  const settings = useApp((s) => s.settings);
  const tab = useApp((s) => s.tab);
  const overlays = useApp((s) => s.overlays);
  const flexBrowse = useApp((s) => s.flexBrowse);
  const running = useApp((s) => s.session.timer.running);
  const finished = useApp((s) => s.session.finished);
  const cupRunning = useApp((s) => s.cupTimer.running);
  const trainScreen = useApp((s) => currentTrainScreen(s));
  const cupScreen = useApp((s) => s.cupScreen);
  const recipePane = useApp((s) => s.recipePane.kind);
  const coffeePane = useApp((s) => s.coffeePane.kind);
  const pendingReplace = useApp((s) => s.pendingReplace);
  const { confirmReplace, set } = useApp.getState();
  const layout = useLayout(settings.layoutOverride);

  // Screen stays on only while a timer runs, then the phone behaves normally again.
  useEffect(() => { setKeepAwake((running || cupRunning) && settings.keepAwake); }, [running, cupRunning, settings.keepAwake]);
  useEffect(() => { if (finished) useApp.getState().openLog(); }, [finished]);
  useEffect(() => { if (layout.posture !== 'FLEX' && useApp.getState().flexBrowse) useApp.getState().set({ flexBrowse: false }); }, [layout.posture]);

  // Launcher shortcuts and links: ?tab=brew, ?action=new_session (the original cupping shortcut).
  useEffect(() => {
    const s = useApp.getState();
    const p = new URLSearchParams(window.location.search);
    const tabParam = p.get('tab')?.toUpperCase();
    if (tabParam && (TABS as string[]).includes(tabParam)) s.selectTab(tabParam as Tab);
    if (p.get('action') === 'new_session') { s.selectTab('CUPPING'); s.set({ cupScreen: 'MAIN', cupShortcutPrompt: true }); }
    if (p.has('tab') || p.has('action')) window.history.replaceState(window.history.state, '', window.location.pathname);
  }, []);

  const flexFree = layout.posture === 'FLEX' && overlays.length === 0;
  const trainDesk = flexFree && tab === 'TRAIN' && isTrainDesk(trainScreen);
  const cupDesk = flexFree && tab === 'CUPPING' && isCupDesk(cupScreen);
  const companionTabs = layout.phoneSideways ? tab === 'BREW' : tab !== 'TRAIN' && tab !== 'CUPPING';
  const companion = flexFree && !flexBrowse && companionTabs;
  const wide = layout.posture === 'OPEN' || (layout.posture === 'FLEX' && !layout.phoneSideways && layout.width >= 600);
  const kind: Kind = trainDesk ? 'TRAIN_DESK' : cupDesk ? 'CUP_DESK' : companion ? 'COMPANION' : wide ? 'WIDE' : 'COMPACT';

  // Android back button and browser back: close what is open inside the app first.
  const compactRef = useRef(!wide);
  compactRef.current = !wide;
  useEffect(() => {
    try {
      window.history.replaceState({ mf: 0 }, '');
      window.history.pushState({ mf: 1 }, '');
    } catch { /* sandboxed */ }
    const onPop = () => {
      const st = useApp.getState();
      if (st.canGoBack(compactRef.current)) {
        st.back();
        try { window.history.pushState({ mf: 1 }, ''); } catch { /* ignore */ }
      } else {
        window.history.back();
      }
    };
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  const editing = (tab === 'RECIPES' && recipePane === 'EDIT') || (tab === 'COFFEE' && coffeePane === 'EDIT');
  const training = tab === 'TRAIN' && (trainScreen.kind === 'LESSON' || trainScreen.kind === 'QUIZ' || trainScreen.kind === 'RESULT');
  const cupping = tab === 'CUPPING' && cupHidesBar(cupScreen);
  const showBar = overlays.length === 0 && !editing && !training && !cupping;

  let body;
  if (kind === 'COMPANION') body = <div className="app"><div className="content" style={{ padding: 0 }}><div className="content-inner"><FlexCompanion row={layout.rowSplit} /></div></div></div>;
  else if (kind === 'TRAIN_DESK') body = <div className="app"><div className="content" style={{ padding: 0 }}><div className="content-inner"><TrainDesk row={layout.rowSplit} /></div></div></div>;
  else if (kind === 'CUP_DESK') body = <div className="app"><div className="content" style={{ padding: 0 }}><div className="content-inner"><CuppingDesk row={layout.rowSplit} /></div></div></div>;
  else if (kind === 'WIDE') {
    body = (
      <div className="app wide">
        <Rail running={running} short={layout.height < 560} />
        <div className="content"><div className="content-inner"><Content wide /></div></div>
      </div>
    );
  } else if (layout.landscape) {
    body = (
      <div className={`app landscape ${showBar ? '' : 'nobar'}`}>
        {showBar && <Rail running={running} short={layout.height < 560} />}
        <div className="content"><div className="content-inner"><Content wide={false} /></div></div>
      </div>
    );
  } else {
    body = (
      <div className={`app compact ${showBar ? '' : 'nobar'}`}>
        <div className="content"><div className="content-inner"><Content wide={false} /></div></div>
        {showBar && <BottomBar running={running} />}
      </div>
    );
  }

  return (
    <>
      {body}
      <Snackbar bottom={kind === 'COMPACT' && !layout.landscape && showBar ? 96 : 16} />
      {pendingReplace && (
        <ConfirmDialog title={t('replace_brew_title')} body={t('replace_brew_body', pendingReplace.name)} confirm={t('replace')}
          onConfirm={confirmReplace} onDismiss={() => set({ pendingReplace: null })} />
      )}
      <InstallHint />
    </>
  );
}

function Content({ wide }: { wide: boolean }) {
  const overlay = useApp((s) => s.overlays[s.overlays.length - 1]);
  const tab = useApp((s) => s.tab);
  switch (overlay) {
    case 'CALCULATOR': return <CalculatorScreen wide={wide} />;
    case 'DIAGNOSE': return <DiagnoseScreen wide={wide} />;
    case 'COMPARE': return <CompareScreen wide={wide} />;
    case 'GRIND': return <GrindAdvisorScreen wide={wide} />;
    case 'SETTINGS': return <SettingsScreen />;
    case 'LOG': return <LogBrewScreen wide={wide} />;
    case 'WATER': return <WaterGuideScreen wide={wide} />;
    default: break;
  }
  switch (tab) {
    case 'HOME': return <HomeScreen wide={wide} />;
    case 'BREW': return <BrewScreen wide={wide} />;
    case 'RECIPES': return <RecipesScreen wide={wide} />;
    case 'COFFEE': return <CoffeeScreen wide={wide} />;
    case 'CUPPING': return <CuppingTab wide={wide} />;
    case 'TRAIN': return <TrainScreen wide={wide} />;
    case 'HISTORY': return <HistoryScreen wide={wide} />;
  }
}

function BottomBar({ running }: { running: boolean }) {
  const tab = useApp((s) => s.tab);
  const selectTab = useApp((s) => s.selectTab);
  return (
    <nav className="navbar" aria-label="Mountain Fold">
      {TABS.map((x) => (
        <button key={x} type="button" aria-current={tab === x ? 'page' : undefined} aria-label={t(TAB_LABEL[x])} onClick={() => selectTab(x)}>
          <TabIcon tab={x} running={running} />
          {/* Seven destinations: only the selected one keeps its label, as Material advises past five. */}
          <span className="nav-label">{tab === x ? t(TAB_LABEL[x]) : ''}</span>
        </button>
      ))}
    </nav>
  );
}

function Rail({ running, short }: { running: boolean; short: boolean }) {
  const tab = useApp((s) => s.tab);
  const overlays = useApp((s) => s.overlays.length);
  const { selectTab, open } = useApp.getState();
  return (
    <nav className={`rail ${short ? 'short' : ''}`} aria-label="Mountain Fold">
      {!short && <Icon name="terrain" size={28} className="rail-logo" />}
      <div className="rail-items">
        {TABS.map((x) => (
          <button key={x} type="button" className="rail-item" aria-current={tab === x && overlays === 0 ? 'page' : undefined} aria-label={t(TAB_LABEL[x])} onClick={() => selectTab(x)}>
            <TabIcon tab={x} running={running} />
            <span className="nav-label">{t(TAB_LABEL[x])}</span>
          </button>
        ))}
      </div>
      <IconButton icon="settings" label={t('settings')} onClick={() => open('SETTINGS')} />
    </nav>
  );
}

function Snackbar({ bottom }: { bottom: number }) {
  const message = useApp((s) => s.message);
  const set = useApp((s) => s.set);
  useEffect(() => {
    if (!message) return;
    const id = setTimeout(() => { if (useApp.getState().message === message) set({ message: null }); }, message.action ? 8000 : 4000);
    return () => clearTimeout(id);
  }, [message, set]);
  if (!message) return null;
  return (
    <div className="snackbar" role="status" style={{ bottom: `calc(${bottom}px + var(--sab))` }}>
      <span className="grow">{message.text}</span>
      {message.action && <Btn kind="text" onClick={() => { message.action!.run(); set({ message: null }); }}>{message.action.label}</Btn>}
    </div>
  );
}

/** Safari on iPhone has no install button: a one-time hint explains Add to Home Screen. */
function InstallHint() {
  const [show, setShow] = useState(() => isIOS() && !isStandalone() && !readLocal<boolean>('mf.installHintSeen'));
  if (!show) return null;
  const close = () => { writeLocal('mf.installHintSeen', true); setShow(false); };
  return (
    <div className="snackbar" role="dialog" style={{ bottom: 'calc(96px + var(--sab))', alignItems: 'flex-start', maxWidth: 'min(480px, calc(100vw - 32px))' }}>
      <Icon name="ios_share" />
      <div className="col grow gap4">
        <strong>{t('web_install_title')}</strong>
        <span>{t('web_install_ios')}</span>
      </div>
      <Btn kind="text" onClick={close}>{t('web_dismiss')}</Btn>
    </div>
  );
}
