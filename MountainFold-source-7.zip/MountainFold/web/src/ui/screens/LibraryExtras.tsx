// Champion recipes, water and Apax Lab, microns. Same screens and rules as the Android LibraryExtras.kt.
import { formatClock, formatNumber, formatRatio, parseNumber, ratio as ratioOf } from '../../core/coffee';
import {
  additive, additiveLabel, AdditiveLine, AdditiveUnit, ADDITIVE_UNITS, ApaxMix, Champion, champion as findChampion, championSteps, CUSTOM_ADDITIVE,
  GrindMicrons, LIBRARY, libraryMicronsPerStep, lt, micronsOf, Water, water as findWater,
} from '../../core/library';
import { Grinder } from '../../core/models';
import { t } from '../../i18n/i18n';
import { useApp } from '../../state/store';
import type { AdditiveDraft, RecipeDraft } from '../../state/types';
import {
  BigButton, Btn, Chip, Icon, IconButton, ListRow, NumField, Scroll, ScreenHeader, SectionTitle, Segmented, SelectField, Stat, StepList,
  TextField, TwoPane, useUnits,
} from '../components';
import { useState } from 'react';

// ---- shared bits ----------------------------------------------------------------------------------
export const additiveName = (a: AdditiveLine) =>
  a.id === CUSTOM_ADDITIVE ? a.name.trim() || t('additive_custom') : (() => { const x = additive(a.id); return x ? additiveLabel(x) : a.name || a.id; })();
export const additiveAmount = (a: AdditiveLine) => t(a.unit === 'DROPS' ? 'amount_drops' : 'amount_g_per_l', formatNumber(a.amount));
export const waterFitLabel = (w: Water) => t(w.fit === 'AVOID' ? 'water_fit_avoid' : w.fit === 'BASE' ? 'water_fit_base' : 'water_fit_good');
const productLabel = (id: string) => (id === CUSTOM_ADDITIVE ? t('additive_custom') : (() => { const a = additive(id); return a ? additiveLabel(a) : id; })());
const unitLabel = (u: AdditiveUnit) => t(u === 'DROPS' ? 'unit_drops' : 'unit_g_per_l');
const mixText = (tonik: number, jamm: number, lylac: number) =>
  ([['TONIK', tonik], ['JAMM', jamm], ['LYLAC', lylac]] as const).filter(([, g]) => g > 0).map(([n, g]) => `${formatNumber(g)} ${n}`).join(' + ');

/** Read-only water and concentrates of a recipe, a champion recipe or a logged brew. Nothing when all empty. */
export function WaterBlock({ waterId, waterNote, additives }: { waterId: string | null; waterNote: string; additives: AdditiveLine[] }) {
  const w = findWater(waterId);
  if (!w && !waterNote.trim() && additives.length === 0) return null;
  const figures = w ? [w.gh != null ? `GH ${w.gh}` : null, w.kh != null ? `KH ${w.kh}` : null, w.tds != null ? `TDS ${formatNumber(w.tds)}` : null].filter(Boolean) : [];
  return (
    <>
      <SectionTitle text={t('water_section')} />
      <div className="col" style={{ gap: 6 }}>
        {w && <span className="title-medium">{w.name}</span>}
        {figures.length > 0 && <span className="body-medium muted">{figures.join(' · ')} mg/L</span>}
        {waterNote.trim() && waterNote !== w?.name && <span className="body-large">{waterNote}</span>}
        {additives.map((a, i) => (
          <div key={i} className="row" style={{ alignItems: 'center' }}>
            <span className="body-large grow">{additiveName(a)}</span>
            <span className="title-medium">{additiveAmount(a)}</span>
          </div>
        ))}
      </div>
    </>
  );
}

/** The grind in microns on the default grinder, or the clicks for a grind written in microns. */
export function useMicronsLine(grind: string): string | null {
  const on = useApp((s) => s.settings.grindMicrons);
  const gid = useApp((s) => s.settings.defaultGrinderId);
  const g = useApp((s) => s.data.grinders.find((x) => x.id === gid));
  if (!on || !grind.trim() || !g) return null;
  const step = g.micronsPerStep ?? libraryMicronsPerStep(g.name);
  if (step == null) return null;
  const written = GrindMicrons.written(grind);
  if (written != null) {
    const clicks = GrindMicrons.steps(written, step);
    return clicks == null ? null : t('microns_on_grinder', g.name, GrindMicrons.formatSteps(clicks));
  }
  const m = GrindMicrons.microns(grind, step);
  return m == null ? null : t('microns_of_setting', GrindMicrons.format(m), g.name);
}

export function MicronsText({ grind, style }: { grind: string; style?: React.CSSProperties }) {
  const line = useMicronsLine(grind);
  return line ? <span className="body-medium" style={{ color: 'var(--primary)', display: 'block', ...style }}>{line}</span> : null;
}

const Labeled = ({ label, value }: { label: string; value: string }) =>
  value.trim() ? (
    <div className="col" style={{ marginBottom: 10 }}>
      <span className="label-small muted upper">{label}</span>
      <span className="body-large">{value}</span>
    </div>
  ) : null;

// ---- recipes tab: my recipes | champions --------------------------------------------------------------
export function RecipeSourceTabs() {
  const source = useApp((s) => s.recipeSource);
  const set = useApp((s) => s.set);
  return (
    <div className="pad-h16" style={{ paddingBottom: 8, flex: '0 0 auto' }}>
      <Segmented options={[['MINE', t('recipes_mine')], ['CHAMPIONS', t('recipes_champions')]]} value={source} onChange={(v) => set({ recipeSource: v })} />
    </div>
  );
}

export const competitionName = (c: Champion, short = false) =>
  t(c.competition === 'WAC' ? (short ? 'comp_wac_short' : 'comp_wac') : short ? 'comp_wbrc_short' : 'comp_wbrc');
export const placeLabel = (p: number) => t(p === 2 ? 'place_2' : p === 3 ? 'place_3' : 'place_1');

export function ChampionsScreen({ wide }: { wide: boolean }) {
  const sel = useApp((s) => s.championSel);
  const c = findChampion(sel);
  if (wide) {
    return <TwoPane left={<ChampionList selectedId={c?.id ?? null} />} right={<div className="page">{c ? <ChampionDetail c={c} showBack={false} /> : <div className="center" style={{ flex: 1 }}><span className="title-medium muted">{t('select_champion')}</span></div>}</div>} />;
  }
  return <div className="page">{c ? <ChampionDetail c={c} showBack /> : <ChampionList selectedId={null} />}</div>;
}

function ChampionList({ selectedId }: { selectedId: string | null }) {
  const u = useUnits();
  const lang = useApp((s) => s.lang);
  const filter = useApp((s) => s.championFilter);
  const set = useApp((s) => s.set);
  const shown = LIBRARY.champions.filter((c) => !filter || c.competition === filter);
  let last: string | null = null;
  return (
    <div className="col" style={{ flex: 1, minHeight: 0 }}>
      <ScreenHeader title={t('tab_recipes')} />
      <RecipeSourceTabs />
      <div className="chips scrollable pad-h16" style={{ flex: '0 0 auto' }}>
        <Chip selected={filter == null} onClick={() => set({ championFilter: null })}>{t('all')}</Chip>
        <Chip selected={filter === 'WBRC'} onClick={() => set({ championFilter: filter === 'WBRC' ? null : 'WBRC' })}>{t('comp_wbrc_short')}</Chip>
        <Chip selected={filter === 'WAC'} onClick={() => set({ championFilter: filter === 'WAC' ? null : 'WAC' })}>{t('comp_wac_short')}</Chip>
      </div>
      <Scroll style={{ padding: '8px 4px 24px' }}>
        <p className="body-medium muted pad-h16" style={{ margin: '4px 0' }}>{t('champions_intro')}</p>
        {shown.map((c) => {
          const head = c.competition !== last ? <SectionTitle text={competitionName(c)} style={{ padding: '0 16px' }} /> : null;
          last = c.competition;
          const tags = [c.place > 1 ? placeLabel(c.place) : null, c.kind === 'SIGNATURE' ? t('champion_signature') : null].filter(Boolean);
          return (
            <div key={c.id}>
              {head}
              <ListRow title={`${c.year} · ${c.champion}`} selected={c.id === selectedId} onClick={() => set({ championSel: c.id })}
                subtitle={[lt(c.brewer, lang), `${u.w(c.doseG)} → ${u.w(c.waterG)}`, u.t(c.tempC), ...tags].join(' · ')} />
            </div>
          );
        })}
      </Scroll>
    </div>
  );
}

function ChampionDetail({ c, showBack }: { c: Champion; showBack: boolean }) {
  const u = useUnits();
  const lang = useApp((s) => s.lang);
  const microns = useApp((s) => s.settings.grindMicrons);
  const gid = useApp((s) => s.settings.defaultGrinderId);
  const g = useApp((s) => s.data.grinders.find((x) => x.id === gid));
  const s = useApp.getState();
  const steps = championSteps(c, lang);
  const est = micronsOf(c);
  const step = g ? g.micronsPerStep ?? libraryMicronsPerStep(g.name) : null;
  const clicks = est ? GrindMicrons.steps(est.microns, step) : null;
  const sameGrinder = !!g && !!c.grinder && g.name.toLowerCase() === c.grinder.toLowerCase();
  return (
    <>
      <ScreenHeader title={c.champion} onBack={showBack ? () => s.set({ championSel: null }) : undefined} />
      <Scroll className="pad-h20 pad-b24">
        <span className="body-large muted">{[`${competitionName(c)} ${c.year}`, placeLabel(c.place), lt(c.country, lang)].join(' · ')}</span>
        {c.kind === 'SIGNATURE' && (
          <div className="tonal-box mt8" style={{ padding: 12, borderRadius: 12, marginTop: 10 }}>
            <div className="title-small">{t('champion_signature')}</div>
            <div className="body-medium">{t('champion_signature_hint')}</div>
          </div>
        )}
        <div className="stats mt16">
          <Stat label={t('dose')} value={u.w(c.doseG)} />
          <Stat label={t('water')} value={u.w(c.waterG)} />
          <Stat label={t('ratio')} value={formatRatio(ratioOf(c.waterG, c.doseG))} />
          <Stat label={t('temperature')} value={u.t(c.tempC)} />
          <Stat label={t('time')} value={formatClock(c.targetTimeS)} />
        </div>
        <div className="mt16" />
        <Labeled label={t('brewer_label')} value={lt(c.brewer, lang)} />
        <Labeled label={t('filter')} value={lt(c.filter, lang)} />
        <Labeled label={t('grind')} value={lt(c.grind, lang)} />
        {microns && est && (
          <>
            {GrindMicrons.written(lt(c.grind, lang)) == null && (
              <Labeled label={t('microns_label')} value={est.published ? GrindMicrons.format(est.microns) : t('microns_estimate', GrindMicrons.format(est.microns))} />
            )}
            {!sameGrinder && (
              <span className="body-medium" style={{ color: 'var(--primary)', display: 'block' }}>
                {g && clicks != null ? t('microns_on_grinder', g.name, GrindMicrons.formatSteps(clicks)) : t('microns_set_grinder')}
              </span>
            )}
          </>
        )}
        <BigButton text={t('brew')} icon="play_arrow" primary minHeight={56} onClick={() => s.brewChampion(c)} className="mt20" style={{ width: '100%' }} />
        <BigButton text={t('champion_add')} icon="add" minHeight={56} onClick={() => void s.addChampionRecipe(c)} style={{ width: '100%', marginTop: 10 }} />
        <WaterBlock waterId={c.waterId} waterNote={lt(c.water, lang)} additives={c.additives} />
        {steps.length > 0 && <><SectionTitle text={t('steps')} /><StepList steps={steps} currentIndex={-1} targetS={c.targetTimeS} started={false} /></>}
        {c.notes && <><SectionTitle text={t('notes')} /><p className="body-large pre-line" style={{ margin: 0 }}>{lt(c.notes, lang)}</p></>}
        {c.approx && <p className="body-medium muted" style={{ marginTop: 12 }}>{t('champion_approx')}</p>}
        <a className="btn text" href={c.source} target="_blank" rel="noopener noreferrer" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, marginTop: 8 }}>
          <Icon name="open_in_new" size={18} />{t('champion_view_source')}
        </a>
      </Scroll>
    </>
  );
}

// ---- recipe editor: water and minerals ----------------------------------------------------------------
export function WaterEditorSection({ d, update }: { d: RecipeDraft; update: (n: RecipeDraft) => void }) {
  const lang = useApp((s) => s.lang);
  const applyApaxMix = useApp((s) => s.applyApaxMix);
  const none = t('none');
  const hi = 'var(--surface-container-high)';
  const productIds = [...LIBRARY.additives.map((a) => a.id), CUSTOM_ADDITIVE];
  const setLine = (i: number, patch: Partial<AdditiveDraft>) => update({ ...d, additives: d.additives.map((x, j) => (j === i ? { ...x, ...patch } : x)) });
  return (
    <>
      <SectionTitle text={t('water_section')} />
      <SelectField label={t('water_choice')} value={findWater(d.waterId)} options={[null, ...LIBRARY.waters]}
        optionLabel={(w) => (w ? `${w.name} · ${waterFitLabel(w)}` : none)} onSelect={(w: Water | null) => update({ ...d, waterId: w?.id ?? null })} />
      <TextField value={d.waterNote} label={t('water_note')} onChange={(v) => update({ ...d, waterNote: v })} />
      <span className="label-large">{t('additives')}</span>
      {d.additives.map((a, i) => {
        const product = additive(a.id);
        const amount = parseNumber(a.amount);
        return (
          <div key={i} className="col gap8" style={{ background: hi, borderRadius: 16, padding: 12 }}>
            <div className="row gap8" style={{ alignItems: 'center' }}>
              <SelectField className="grow" label={t('product')} value={a.id} options={productIds} optionLabel={productLabel} bg={hi}
                onSelect={(id: string) => setLine(i, { id, unit: id === 'apax-konflux' ? 'DROPS' : a.unit })} />
              <IconButton icon="close" label={t('remove_additive')} onClick={() => update({ ...d, additives: d.additives.filter((_, j) => j !== i) })} />
            </div>
            {a.id === CUSTOM_ADDITIVE && <TextField value={a.name} label={t('additive_name')} bg={hi} onChange={(v) => setLine(i, { name: v })} />}
            <div className="row gap8">
              <NumField className="grow" value={a.amount} label={t('amount')} error={amount == null || amount <= 0} bg={hi} onChange={(v) => setLine(i, { amount: v })} />
              <SelectField className="grow" label={t('unit_label')} value={a.unit} options={ADDITIVE_UNITS} optionLabel={unitLabel} bg={hi} onSelect={(u: AdditiveUnit) => setLine(i, { unit: u })} />
            </div>
            {product && <span className="body-medium muted">{lt(product.effect, lang)}</span>}
          </div>
        );
      })}
      <div><Btn kind="outlined" icon="add" onClick={() => update({ ...d, additives: [...d.additives, { id: 'apax-tonik', name: '', amount: '', unit: 'G_PER_L' }] })}>{t('add_additive')}</Btn></div>
      <SelectField<ApaxMix | null> label={t('apax_mix')} value={null} options={LIBRARY.apaxMixes}
        optionLabel={(m) => (m ? `${lt(m.name, lang)} · ${mixText(m.tonik, m.jamm, m.lylac)}` : '')} onSelect={(m) => { if (m) applyApaxMix(m); }} />
      <span className="body-medium muted">{t('apax_mix_hint')}</span>
    </>
  );
}

// ---- settings: microns per click of each grinder ------------------------------------------------------
export function GrinderMicronsSettings() {
  const grinders = useApp((s) => s.data.grinders);
  if (grinders.length === 0) return <span className="body-medium muted">{t('no_grinders')}</span>;
  return (
    <div className="col gap8">
      {grinders.map((g) => <GrinderMicronsRow key={g.id} g={g} />)}
      <span className="body-medium muted">{t('microns_caveat')}</span>
    </div>
  );
}

function GrinderMicronsRow({ g }: { g: Grinder }) {
  const known = libraryMicronsPerStep(g.name);
  const setGrinderMicrons = useApp((s) => s.setGrinderMicrons);
  const [text, setText] = useState(() => { const v = g.micronsPerStep ?? known; return v == null ? '' : formatNumber(v); });
  return (
    <div className="row gap12" style={{ alignItems: 'center' }}>
      <div className="col grow">
        <span className="body-large">{g.name}</span>
        <span className="body-small muted">{known != null ? t('microns_maker_value', formatNumber(known)) : t('microns_unknown')}</span>
      </div>
      <NumField value={text} label={t('microns_per_click')} suffix="µm" style={{ width: 150, flex: '0 0 150px' }} onChange={(v) => { setText(v); setGrinderMicrons(g.id, v); }} />
    </div>
  );
}

// ---- water guide ------------------------------------------------------------------------------------
function WaterCard({ w }: { w: Water }) {
  const lang = useApp((s) => s.lang);
  const avoid = w.fit === 'AVOID';
  const figures = ([['GH', w.gh], ['KH', w.kh], ['TDS', w.tds], ['Ca', w.ca], ['Mg', w.mg]] as const).filter(([, v]) => v != null) as [string, number][];
  return (
    <div className="col" style={{ gap: 6, padding: 14, borderRadius: 16, background: avoid ? 'var(--error-container)' : 'var(--surface-container-high)', color: avoid ? 'var(--on-error-container)' : undefined }}>
      <div className="row" style={{ alignItems: 'center' }}>
        <span className="title-medium grow">{w.name}</span>
        <span className="label-medium" style={{ color: avoid ? 'var(--error)' : 'var(--primary)' }}>{waterFitLabel(w)}</span>
      </div>
      {figures.length > 0 && (
        <div className="stats" style={{ gap: '6px 20px' }}>
          {figures.map(([k, v]) => <Stat key={k} label={k} value={`${formatNumber(v)} mg/L`} valueClass="title-small" />)}
        </div>
      )}
      <span className="body-medium">{lt(w.use, lang)}</span>
    </div>
  );
}

export function WaterGuideScreen({ wide }: { wide: boolean }) {
  const lang = useApp((s) => s.lang);
  const back = useApp((s) => s.back);
  const waters = (
    <>
      <p className="body-large" style={{ margin: 0 }}>{t('water_guide_intro')}</p>
      <p className="body-medium muted" style={{ margin: '6px 0 0' }}>{t('water_formula')}</p>
      <SectionTitle text={t('waters_title')} />
      <div className="col" style={{ gap: 10 }}>{LIBRARY.waters.map((w) => <WaterCard key={w.id} w={w} />)}</div>
      <p className="body-small muted" style={{ marginTop: 8 }}>{t('water_label_disclaimer')}</p>
    </>
  );
  const apax = (
    <>
      <SectionTitle text={t('apax_title')} />
      <p className="body-large" style={{ margin: '0 0 10px' }}>{t('apax_intro')}</p>
      <div className="col" style={{ gap: 10 }}>
        {LIBRARY.additives.map((a) => (
          <div key={a.id} className="col">
            <span className="title-medium">{additiveLabel(a)}</span>
            <span className="body-large">{lt(a.effect, lang)}</span>
            {a.composition && <span className="body-small muted">{a.composition}</span>}
          </div>
        ))}
      </div>
      <SectionTitle text={t('apax_mixes_title')} />
      {LIBRARY.apaxMixes.map((m) => (
        <div key={m.id} className="row" style={{ alignItems: 'center', padding: '6px 0' }}>
          <div className="col grow">
            <span className="body-large">{lt(m.name, lang)}</span>
            <span className="body-medium muted">{mixText(m.tonik, m.jamm, m.lylac)}</span>
          </div>
          <span className="title-small">{t('total_per_litre', formatNumber(m.tonik + m.jamm + m.lylac))}</span>
        </div>
      ))}
      <SectionTitle text={t('apax_drops_title')} />
      {LIBRARY.apaxDrops.map((x) => (
        <div key={x.id} className="row" style={{ padding: '6px 0' }}>
          <span className="body-large grow">{lt(x.name, lang)}</span>
          <span className="title-small">{t('drops_range', x.min, x.max)}</span>
        </div>
      ))}
    </>
  );
  return (
    <div className="page">
      <ScreenHeader title={t('water_guide')} onBack={back} />
      {wide ? (
        <TwoPane left={<Scroll className="pad-h28 pad-b24">{waters}</Scroll>} right={<Scroll className="pad-h28" style={{ paddingTop: 16, paddingBottom: 16 }}>{apax}</Scroll>} />
      ) : (
        <Scroll className="pad-h20 pad-b32">{waters}<div className="mt20" />{apax}</Scroll>
      )}
    </div>
  );
}
