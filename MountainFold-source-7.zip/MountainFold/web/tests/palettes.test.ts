// Cobalt and Sage: WCAG AA on every text pair, brand colours kept, same tokens as the Android Palettes.kt.
import fs from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import { scheme } from '../src/core/palettes';
import { PALETTES } from '../src/core/models';

const lin = (c: number) => { const v = c / 255; return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; };
const lum = (h: string) => { const n = parseInt(h.slice(1), 16); return 0.2126 * lin(n >> 16) + 0.7152 * lin((n >> 8) & 255) + 0.0722 * lin(n & 255); };
const ratio = (a: string, b: string) => (Math.max(lum(a), lum(b)) + 0.05) / (Math.min(lum(a), lum(b)) + 0.05);
const PAIRS = [
  ['onPrimary', 'primary'], ['onPrimaryContainer', 'primaryContainer'], ['onSecondaryContainer', 'secondaryContainer'],
  ['onTertiaryContainer', 'tertiaryContainer'], ['onErrorContainer', 'errorContainer'], ['onSurface', 'surface'],
  ['onSurfaceVariant', 'surface'], ['onSurfaceVariant', 'surfaceContainerHigh'], ['onSurface', 'surfaceContainerHighest'],
  ['primary', 'surface'], ['primary', 'surfaceContainerHigh'], ['secondary', 'surface'], ['tertiary', 'surface'], ['error', 'surface'],
  ['inverseOnSurface', 'inverseSurface'],
];

describe('Cobalt and Sage palettes', () => {
  it('reach 4.5:1 on every text pair, light and dark', () => {
    for (const p of ['COBALT', 'SAGE'] as const) for (const dark of [false, true]) {
      const s = scheme(p, dark);
      for (const [a, b] of PAIRS) expect(ratio(s[a], s[b]), `${p} ${dark} ${a}/${b}`).toBeGreaterThanOrEqual(4.5);
    }
  });

  it('keep the brand colours exactly', () => {
    expect(scheme('COBALT', false)).toMatchObject({ background: '#EDECE6', primary: '#1546D9', secondaryContainer: '#F9B318' });
    expect(scheme('SAGE', false)).toMatchObject({ background: '#A5A79B', primaryContainer: '#E8D2B5', primary: '#590907' });
    expect(scheme('SAGE', true)).toMatchObject({ primary: '#E8D2B5', primaryContainer: '#590907' });
    expect(PALETTES).toContain('COBALT');
  });

  it('match the Android tokens', () => {
    const kt = fs.readFileSync(path.join(__dirname, '..', '..', 'app', 'src', 'main', 'java', 'com', 'mountainfold', 'app', 'ui', 'theme', 'Palettes.kt'), 'utf8');
    for (const p of ['COBALT', 'SAGE'] as const) {
      const body = kt.slice(kt.indexOf(`private fun ${p.toLowerCase()}(`));
      const [light, dark] = body.split(') else darkColorScheme(');
      for (const [dk, part] of [[false, light], [true, dark.slice(0, dark.indexOf('\n        )'))]] as const) {
        const tokens = Object.fromEntries([...part.matchAll(/(\w+) = c\(0xFF([0-9A-F]{6})\)/g)].map((m) => [m[1], `#${m[2]}`]));
        const s = scheme(p, dk);
        for (const [k, v] of Object.entries(s)) expect(tokens[k], `${p} ${dk} ${k}`).toBe(v);
      }
    }
  });
});
