// Backup compatibility with the Android app. The fixture was written by the real Android classes
// (data/db entities, Settings, Repository.Backup) through kotlinx.serialization with the Repository settings.
import fs from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import { decodeSteps, encodeSteps } from '../src/core/coffee';
import { buildBackup, parseBackup } from '../src/data/backup';
import { decodeAdditives } from '../src/core/library';

const fixture = fs.readFileSync(path.join(__dirname, 'fixtures', 'android-backup.json'), 'utf8');
const android = JSON.parse(fixture);

describe('Backup from the Android app', () => {
  const b = parseBackup(fixture);

  it('reads the settings with their enums', () => {
    expect(b.settings).toMatchObject({
      themeMode: 'DARK', palette: 'TOULOUSE', defaultMethod: 'ESPRESSO', defaultDoseG: 18, weightUnit: 'OZ', tempUnit: 'F',
      layoutOverride: 'FLEX', flexLayout: 'SHOT', waterStepG: 25, onboarded: true, currentCoffeeId: 2, lastRecipeId: 1,
      defaultGrinderId: 1, preferredMethods: ['V60', 'ESPRESSO'], pendingBrewChallenge: null, cuppingSessionId: 's1', grindMicrons: true,
    });
  });

  it('reads every table', () => {
    expect(b.data.coffees[0]).toMatchObject({ id: 2, name: 'Ethiopia Guji', roastDateEpochDay: 20370, photoPath: '/data/user/0/com.mountainfold.app/files/photos/a.jpg' });
    expect(b.data.recipes.map((r) => [r.id, r.tempC, r.targetTimeS])).toEqual([[1, 93.5, 180], [3, null, 57600]]);
    expect(decodeSteps(b.data.recipes[0].stepsJson)).toEqual([
      { label: 'Bloom', type: 'BLOOM', startS: 0, targetWaterG: 45, note: '' },
      { label: 'Pour', type: 'POUR', startS: 45, targetWaterG: 250, note: 'slow' },
      { label: 'Wait', type: 'WAIT', startS: 120, targetWaterG: null, note: '' },
    ]);
    expect(b.data.brews[0]).toMatchObject({ id: 7, timeMs: 182_400, symptoms: 'SOUR,WEAK', rating: 4, clarity: 5, grinderName: 'Comandante C40' });
    expect(b.data.grinders).toEqual([{ id: 1, name: 'Comandante C40', notes: 'clicks', micronsPerStep: 30 }]);
    expect(b.data.training[0]).toMatchObject({ kind: 'LESSON', refId: 'ratio', xp: 75, passed: true, breakdown: 'THEORY:3/3' });
    expect(b.data.cuppingSessions[0]).toMatchObject({ id: 's1', location: 'Labo', dateIso: '2026-10-13' });
    expect(b.data.labRecipes[0]).toMatchObject({ id: 'r1', method: 'chemex', waterWeight: 450, grindSize: 'Sel fin', totalTime: 245, rating: 8.5 });
  });

  it('reads water, mineral concentrates and champion origin (1.3.0)', () => {
    expect(b.data.recipes[0]).toMatchObject({ waterId: 'apax-base', waterNote: 'Osmosée + Apax', championId: 'wbrc-2024-martin-wolfl' });
    expect(decodeAdditives(b.data.recipes[0].additivesJson)).toEqual([
      { id: 'apax-tonik', name: '', amount: 1, unit: 'G_PER_L' }, { id: 'custom', name: 'Lotus', amount: 3, unit: 'DROPS' },
    ]);
    expect(b.data.recipes[1]).toMatchObject({ waterId: null, waterNote: '', additivesJson: '[]', championId: null });
    expect(b.data.brews[0]).toMatchObject({ waterId: 'volvic', waterNote: 'Volvic' });
    expect(decodeAdditives(b.data.brews[0].additivesJson)).toEqual([{ id: 'apax-jamm', name: '', amount: 2.5, unit: 'G_PER_L' }]);
  });

  it('keeps cupping lists and drops coffees of a missing session, like Repository.importJson', () => {
    expect(b.data.cuppingCoffees.map((c) => c.id)).toEqual(['c1']);
    expect(b.data.cuppingCoffees[0]).toMatchObject({ fragranceNotes: ['Citron', 'Jasmin'], flavorScore: 9.25, isLocked: true, comments: 'Clean, "sweet"' });
  });

  it('writes back the same fields in the same order', () => {
    const web = JSON.parse(buildBackup(b.settings, { ...b.data, cuppingCoffees: android.cuppingCoffees.map((c: object) => c) }));
    for (const table of ['coffees', 'recipes', 'brews', 'grinders', 'training', 'cuppingSessions', 'cuppingCoffees', 'labRecipes']) {
      expect(Object.keys(web[table][0]), table).toEqual(Object.keys(android[table][0]));
      expect(web[table], table).toEqual(android[table]);
    }
    expect(Object.keys(web)).toEqual(Object.keys(android));
    expect(Object.keys(web.settings)).toEqual(Object.keys(android.settings));
    expect(web.settings).toEqual(android.settings);
  });

  it('writes steps the Android decoder reads', () => {
    const steps = decodeSteps(android.recipes[0].stepsJson);
    expect(JSON.parse(encodeSteps(steps))).toEqual(JSON.parse(android.recipes[0].stepsJson));
  });
});

describe('Backup edge cases', () => {
  it('imports a backup made before 1.2.0 without cupping data', () => {
    const b = parseBackup('{"app":"MountainFold","version":1,"coffees":[],"recipes":[],"brews":[]}');
    expect(b.data.cuppingSessions).toEqual([]);
    expect(b.data.labRecipes).toEqual([]);
    expect(b.settings.onboarded).toBe(true);
    expect(b.settings.cuppingInviteUrl).toMatch(/^https:/);
  });

  it('imports a 1.2 backup without water fields, with empty defaults', () => {
    const b = parseBackup('{"app":"MountainFold","recipes":[{"id":1,"name":"V60"}],"brews":[{"id":2}],"grinders":[{"id":1,"name":"K-Ultra"}]}');
    expect(b.data.recipes[0]).toMatchObject({ waterId: null, waterNote: '', additivesJson: '[]', championId: null });
    expect(b.data.brews[0]).toMatchObject({ waterId: null, waterNote: '', additivesJson: '[]' });
    expect(b.data.grinders[0].micronsPerStep).toBeNull();
    expect(b.settings.grindMicrons).toBe(false);
  });

  it('refuses another app', () => {
    expect(() => parseBackup('{"app":"Other"}')).toThrow();
    expect(() => parseBackup('not json')).toThrow();
  });

  it('coerces unknown enums to defaults, like coerceInputValues', () => {
    const b = parseBackup('{"app":"MountainFold","settings":{"palette":"NEON","weightUnit":"KG","preferredMethods":["V60","SIPHON"]}}');
    expect(b.settings.palette).toBe('COFFEE');
    expect(b.settings.weightUnit).toBe('G');
    expect(b.settings.preferredMethods).toEqual(['V60']);
  });

  it('carries web photos in an extra field that Android ignores', () => {
    const b = parseBackup(fixture);
    const photo = 'data:image/jpeg;base64,AAAA';
    const out = buildBackup(b.settings, b.data, { 'idb:1': photo });
    expect(parseBackup(out).photos).toEqual({ 'idb:1': photo });
    expect(parseBackup(buildBackup(b.settings, b.data)).photos).toEqual({});
    // Only images are accepted.
    expect(parseBackup('{"app":"MountainFold","webPhotos":{"a":"javascript:alert(1)"}}').photos).toEqual({});
    if (process.env.MF_WEB_EXPORT) fs.writeFileSync(process.env.MF_WEB_EXPORT, out);
  });
});
