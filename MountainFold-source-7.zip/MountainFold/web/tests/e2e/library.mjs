// Champion recipes, water guide, Apax Lab in the editor and microns, on an iPhone and an iPad, in French.
// Usage: node tests/e2e/library.mjs http://localhost:4173/ out-dir
import { chromium } from 'playwright-core';
import fs from 'node:fs';

const base = process.argv[2] ?? 'http://localhost:4173/';
const out = process.argv[3] ?? 'shots-lib';
fs.mkdirSync(out, { recursive: true });
const exe = process.env.CHROME ?? '/opt/pw-browsers/chromium-1194/chrome-linux/chrome';
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1';
const errors = [];
const checks = [];

const browser = await chromium.launch({ executablePath: exe, args: ['--no-sandbox'] });
const ctx = await browser.newContext({ viewport: { width: 393, height: 852 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, userAgent: UA, locale: 'fr-FR' });
await ctx.addInitScript(() => { try { localStorage.setItem('mf.lang', '"fr"'); localStorage.setItem('mf.installHintSeen', 'true'); } catch {} });
const page = await ctx.newPage();
page.setDefaultTimeout(7000);
page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
page.on('console', (m) => { if (m.type() === 'error') errors.push(`console: ${m.text()}`); });

const shot = (name) => page.screenshot({ path: `${out}/${name}.png` });
const wait = (ms = 300) => page.waitForTimeout(ms);
const tap = async (name, exact = true) => { await page.getByRole('button', { name, exact }).first().click(); await wait(); };
const row = async (text) => { await page.getByRole('button').filter({ hasText: text }).first().click(); await wait(400); };
const nav = async (label) => { await page.locator(`nav button[aria-label="${label}"]`).first().click(); await wait(); };
const has = async (text) => (await page.getByText(text, { exact: false }).count()) > 0;
const check = async (label, text) => checks.push(`${(await has(text)) ? 'OK ' : 'MISSING'} ${label}: ${text}`);
async function step(name, fn) {
  try { await fn(); } catch (e) { errors.push(`step ${name}: ${e.message.split('\n')[0]}`); await shot(`ERR_${name}`).catch(() => {}); }
}

await page.goto(base);
await wait(800);
await step('onboarding', async () => {
  await tap('Suivant'); await tap('Suivant');
  await page.getByRole('button', { name: 'Comandante C40', exact: true }).click();
  await tap('Suivant'); await tap('Commencer'); await wait(500);
});

await step('microns_on', async () => {
  await page.getByRole('button', { name: 'Réglages' }).first().click();
  await wait(400);
  await page.getByRole('switch').filter({ hasText: 'Mouture en microns' }).click();
  await wait(300);
  await page.getByText('µm par clic', { exact: false }).first().scrollIntoViewIfNeeded();
  await shot('l01_settings_microns');
  await check('maker value', 'Valeur fabricant');
  await page.getByRole('button', { name: 'Retour' }).first().click();
  await wait();
});

await step('champions', async () => {
  await nav('Recettes');
  await page.getByRole('radio', { name: 'Champions' }).click();
  await wait(300);
  await shot('l02_champions_list');
  await row('George Stanica');
  await shot('l03_stanica');
  await check('conversion', 'Sur votre Comandante C40');
  await page.getByRole('button', { name: 'Retour' }).first().click();
  await wait();
  await row('Martin Wölfl');
  await shot('l04_wolfl');
  await check('apax lines', 'TONIK');
  await page.getByText('Voir la source').scrollIntoViewIfNeeded();
  await shot('l05_wolfl_bottom');
  await tap('Ajouter à mes recettes');
  await wait(400);
  await shot('l06_recipe_from_champion');
  await check('from champion', "D'après la recette Martin Wölfl 2024");
});

await step('editor', async () => {
  await tap('Modifier');
  await page.getByText('Concentrés minéraux').scrollIntoViewIfNeeded();
  const mix = page.locator('.field').filter({ hasText: 'Mélange Apax Lab' }).locator('select');
  await mix.selectOption({ index: 3 });
  await wait(300);
  await page.getByText('Remplit TONIK', { exact: false }).scrollIntoViewIfNeeded();
  await shot('l07_editor_water');
  await tap('Enregistrer');
  await wait(400);
});

await step('water_guide', async () => {
  await nav('Accueil');
  await tap('Eau');
  await wait(300);
  await shot('l08_water_guide');
  await page.getByText('Mélanges par litre').scrollIntoViewIfNeeded();
  await shot('l09_water_apax');
  await page.getByRole('button', { name: 'Retour' }).first().click();
  await wait();
});

await step('brew_champion', async () => {
  await nav('Recettes');
  await nav('Recettes');
  await page.getByRole('radio', { name: 'Champions' }).click();
  await row('Tetsu Kasuya');
  await tap('Brew');
  await wait(400);
  await shot('l10_brew_kasuya');
  await check('brew screen', 'Tetsu Kasuya');
});

await step('ipad', async () => {
  await page.setViewportSize({ width: 1180, height: 820 });
  await wait(500);
  await nav('Recettes');
  await page.getByRole('radio', { name: 'Champions' }).click();
  await row('Matt Winton');
  await shot('l11_ipad_champions');
});

console.log(checks.join('\n'));
console.log(errors.length ? `ERRORS\n${errors.join('\n')}` : 'no errors');
await browser.close();
