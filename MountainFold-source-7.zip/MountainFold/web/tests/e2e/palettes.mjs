// Cobalt and Sage palettes on the main screens, light and dark, iPhone and iPad.
// Usage: node tests/e2e/palettes.mjs http://localhost:4173/ out-dir
import { chromium } from 'playwright-core';
import fs from 'node:fs';

const base = process.argv[2] ?? 'http://localhost:4173/';
const out = process.argv[3] ?? 'shots-pal';
fs.mkdirSync(out, { recursive: true });
const exe = process.env.CHROME ?? '/opt/pw-browsers/chromium-1194/chrome-linux/chrome';
const errors = [];
const browser = await chromium.launch({ executablePath: exe, args: ['--no-sandbox'] });
const ctx = await browser.newContext({ viewport: { width: 393, height: 852 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'fr-FR' });
await ctx.addInitScript(() => { try { localStorage.setItem('mf.lang', '"fr"'); localStorage.setItem('mf.installHintSeen', 'true'); } catch {} });
const page = await ctx.newPage();
page.setDefaultTimeout(7000);
page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
const wait = (ms = 300) => page.waitForTimeout(ms);
const tap = async (name) => { await page.getByRole('button', { name, exact: true }).first().click(); await wait(); };
const nav = async (label) => { await page.locator(`nav button[aria-label="${label}"]`).first().click(); await wait(); };
const shot = (n) => page.screenshot({ path: `${out}/${n}.png` });

await page.goto(base);
await wait(800);
for (const l of ['Suivant', 'Suivant', 'Suivant', 'Commencer']) await tap(l);
await wait(400);
for (const [palette, label] of [['cobalt', 'Cobalt'], ['sage', 'Sauge']]) {
  for (const [mode, modeLabel] of [['light', 'Clair'], ['dark', 'Sombre']]) {
    try {
      await page.setViewportSize({ width: 393, height: 852 });
      await nav('Accueil');
      await page.getByRole('button', { name: 'Réglages' }).first().click();
      await wait(300);
      await page.getByRole('radio', { name: modeLabel }).first().click();
      await page.getByRole('button', { name: label, exact: true }).click();
      await wait(300);
      await shot(`${palette}_${mode}_0_settings`);
      await page.getByRole('button', { name: 'Retour' }).first().click();
      await wait();
      await shot(`${palette}_${mode}_1_home`);
      await nav('Brew');
      await shot(`${palette}_${mode}_2_brew`);
      await nav('Recettes');
      await page.getByRole('radio', { name: 'Champions' }).click();
      await wait();
      await shot(`${palette}_${mode}_3_champions`);
      await page.getByRole('radio', { name: 'Mes recettes' }).click();
      await page.setViewportSize({ width: 1180, height: 820 });
      await wait(500);
      await nav('Train');
      await shot(`${palette}_${mode}_4_ipad_train`);
      const vars = await page.evaluate(() => ['--surface', '--primary', '--secondary-container'].map((v) => getComputedStyle(document.documentElement).getPropertyValue(v).trim()));
      console.log(palette, mode, vars.join(' '));
    } catch (e) { errors.push(`${palette} ${mode}: ${e.message.split('\n')[0]}`); await shot(`ERR_${palette}_${mode}`); }
  }
}
console.log(errors.length ? `ERRORS\n${errors.join('\n')}` : 'no errors');
await browser.close();
