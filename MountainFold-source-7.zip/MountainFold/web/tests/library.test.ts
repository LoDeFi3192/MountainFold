// Champion recipes, waters, Apax Lab and microns: same answers as the Android LibraryTests.kt.
import { describe, expect, it } from 'vitest';
import {
  champion, championSteps, decodeAdditives, encodeAdditives, GrindMicrons, LIBRARY, libraryMicronsPerStep, micronsOf, mixLines, water,
} from '../src/core/library';
import { methodFromKey } from '../src/core/models';

describe('Library content', () => {
  it('ships every table', () => {
    expect(LIBRARY.champions).toHaveLength(21);
    expect(LIBRARY.waters.length).toBeGreaterThanOrEqual(8);
    expect(LIBRARY.additives).toHaveLength(4);
    expect(LIBRARY.apaxMixes.length).toBeGreaterThan(0);
  });

  it('every champion recipe is brewable in three languages', () => {
    for (const c of LIBRARY.champions) {
      for (const lang of ['en', 'fr', 'es'] as const) {
        const steps = championSteps(c, lang);
        expect(steps.length, c.id).toBeGreaterThan(0);
        expect(steps.every((s) => s.label.trim()), c.id).toBe(true);
        const poured = steps.filter((s) => s.targetWaterG != null);
        expect(poured[poured.length - 1].targetWaterG, c.id).toBeCloseTo(c.waterG);
      }
      expect(methodFromKey(c.method), c.id).toBe(c.method);
      if (c.waterId) expect(water(c.waterId), c.id).not.toBeNull();
      expect(Array.isArray(c.additives), c.id).toBe(true);
    }
  });

  it('Martin Wölfl brews with Apax Lab', () => {
    const c = champion('wbrc-2024-martin-wolfl')!;
    expect(c.waterId).toBe('apax-base');
    expect(c.additives.map((a) => a.id)).toEqual(['apax-tonik', 'apax-jamm', 'apax-lylac']);
  });

  it('works out microns from clicks when they were not published', () => {
    expect(micronsOf(champion('wac-2024-george-stanica')!)).toEqual({ microns: 870, published: true });
    expect(micronsOf(champion('wac-2023-tay-wipvasutt')!)).toEqual({ microns: 65 * 22, published: false });
    expect(libraryMicronsPerStep('comandante c40')).toBe(30);
    expect(libraryMicronsPerStep('Unknown')).toBeNull();
  });

  it('computes hardness from the label', () => {
    expect(water('volvic')).toMatchObject({ gh: 63, kh: 61 });
    expect(water('evian')!.fit).toBe('AVOID');
  });
});

describe('Grind microns', () => {
  it('reads settings and microns', () => {
    expect(GrindMicrons.setting('22,5 clicks')).toBe(22.5);
    expect(GrindMicrons.setting('medium fine')).toBeNull();
    expect(GrindMicrons.microns('22', 30)).toBe(660);
    expect(GrindMicrons.microns('EK43, 630 µm', 30)).toBe(630);
    expect(GrindMicrons.microns('22', null)).toBeNull();
  });

  it('rounds clicks to halves on fine grinders', () => {
    expect(GrindMicrons.steps(630, 30)).toBe(21);
    expect(GrindMicrons.steps(630, 8.8)).toBe(71.5);
    expect(GrindMicrons.formatSteps(71.5)).toBe('71.5');
    expect(GrindMicrons.format(868)).toBe('870 µm');
  });
});

describe('Additives codec', () => {
  it('round trips and tolerates bad input like the Android codec', () => {
    const lines = [{ id: 'apax-tonik', name: '', amount: 1, unit: 'G_PER_L' as const }, { id: 'custom', name: 'Lotus', amount: 3, unit: 'DROPS' as const }];
    expect(decodeAdditives(encodeAdditives(lines))).toEqual(lines);
    expect(decodeAdditives('')).toEqual([]);
    expect(decodeAdditives('not json')).toEqual([]);
    expect(decodeAdditives('[{"id":"apax-jamm","amount":2,"unit":"LITRES"}]')[0].unit).toBe('G_PER_L');
  });

  it('turns an Apax mix into lines, skipping zero amounts', () => {
    const light = LIBRARY.apaxMixes.find((m) => m.id === 'light')!;
    expect(mixLines(light).map((l) => [l.id, l.amount])).toEqual([['apax-tonik', 1], ['apax-jamm', 3]]);
  });
});
