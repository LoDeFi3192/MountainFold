# Waters, Apax Lab mineral concentrates and grinder steps. Label values change from one batch to the next:
# the app says so next to every bottled water.
from champions import T

NESTLE = "https://nutripro.nestle.fr/sites/default/files/2024-08/Tableau%20des%20eaux%20min%C3%A9rales%20naturelles%20plates.pdf"
EWEO = "https://eweo.fr/comparateur-eaux-minerales"
TWW = "https://support.thirdwavewater.com/en-US/what-is-in-third-wave-water-76575"
APAX = "https://apaxlab.com/products/box-set"
APAX_MIX = "https://wild-kaffee.com/en/pages/minerals-apax-lab"

# fit: GOOD, BASE (to remineralise), AVOID.
WATERS = [
    dict(id="volvic", name="Volvic", kind="BOTTLE", fit="GOOD", ca=12, mg=8, na=12, k=6, hco3=74, tds=130,
         use=T("A good all-rounder for espresso and filter. Its alkalinity softens acidity a little on light roasts.",
               "Une bonne eau polyvalente pour l'espresso et le filtre. Son alcalinité adoucit un peu l'acidité des torréfactions claires.",
               "Una buena agua polivalente para espresso y filtro. Su alcalinidad suaviza un poco la acidez de los tuestes claros."),
         source=NESTLE),
    dict(id="mont-roucous", name="Mont Roucous", kind="BOTTLE", fit="BASE", ca=2.6, mg=0.4, na=3.2, k=0.4, hco3=6.3, tds=30,
         use=T("Almost no minerals: bright but thin on its own. An ideal base for Apax Lab or for a mix with Volvic.",
               "Presque sans minéraux : vive mais mince seule. Une base idéale pour Apax Lab ou un mélange avec Volvic.",
               "Casi sin minerales: viva pero ligera sola. Una base ideal para Apax Lab o para mezclar con Volvic."),
         source=NESTLE),
    dict(id="montcalm", name="Montcalm", kind="BOTTLE", fit="BASE", ca=3, mg=0.7, na=2.2, k=None, hco3=None, tds=32,
         use=T("Very soft, like Mont Roucous. A base to remineralise.", "Très douce, comme Mont Roucous. Une base à reminéraliser.", "Muy blanda, como Mont Roucous. Una base para remineralizar."),
         source=EWEO),
    dict(id="volvic-roucous", name="Volvic + Mont Roucous 50/50", kind="MIX", fit="GOOD", ca=7.3, mg=4.2, na=7.6, k=3.2, hco3=40.2, tds=80,
         use=T("Half and half: lower alkalinity than Volvic alone, more clarity on light roast filters. Values computed from the two labels.",
               "Moitié-moitié : moins d'alcalinité que la Volvic seule, plus de clarté sur les filtres en torréfaction claire. Valeurs calculées à partir des deux étiquettes.",
               "Mitad y mitad: menos alcalinidad que Volvic sola, más claridad en filtros de tueste claro. Valores calculados a partir de las dos etiquetas."),
         source=NESTLE),
    dict(id="sca-target", name="SCA", kind="RECIPE", fit="GOOD", ca=None, mg=None, na=10, k=None, hco3=None, tds=150,
         gh=None, kh=40,
         use=T("The SCA brewing water standard: TDS 150 mg/L (75 to 250), calcium hardness 68 mg/L as CaCO₃ (17 to 85), alkalinity near 40 mg/L, pH 7.",
               "La norme d'eau de la SCA : TDS 150 mg/L (75 à 250), dureté calcique 68 mg/L en CaCO₃ (17 à 85), alcalinité proche de 40 mg/L, pH 7.",
               "La norma de agua de la SCA: TDS 150 mg/L (75 a 250), dureza cálcica 68 mg/L como CaCO₃ (17 a 85), alcalinidad cerca de 40 mg/L, pH 7."),
         source="https://www.waterworld.com/residential-commercial/article/14309734/third-wave-water-new-technologies-for-specialty-cafes-improve-water-quality"),
    dict(id="tww-light", name="Third Wave Water, Light Roast", kind="RECIPE", fit="GOOD", ca=None, mg=None, na=None, k=None, hco3=None, tds=150,
         gh=None, kh=40,
         use=T("Sachet in distilled water. About 150 mg/L TDS and 40 mg/L alkalinity: for light roast filters.",
               "Sachet dans de l'eau distillée. Environ 150 mg/L de TDS et 40 mg/L d'alcalinité : pour les filtres en torréfaction claire.",
               "Sobre en agua destilada. Unos 150 mg/L de TDS y 40 mg/L de alcalinidad: para filtros de tueste claro."),
         source=TWW),
    dict(id="tww-espresso", name="Third Wave Water, Medium Roast / Espresso", kind="RECIPE", fit="GOOD", ca=None, mg=None, na=None, k=None, hco3=None, tds=150,
         gh=None, kh=80,
         use=T("About 150 mg/L TDS and 80 mg/L alkalinity: medium roasts and espresso machines.",
               "Environ 150 mg/L de TDS et 80 mg/L d'alcalinité : torréfactions moyennes et machines espresso.",
               "Unos 150 mg/L de TDS y 80 mg/L de alcalinidad: tuestes medios y máquinas de espresso."),
         source=TWW),
    dict(id="apax-base", name="Apax Lab", kind="BASE", fit="GOOD", ca=None, mg=None, na=None, k=None, hco3=None, tds=None,
         use=T("Demineralised or distilled water with 3 to 4 g of Apax Lab concentrate per litre, mixed to suit the coffee.",
               "Eau déminéralisée ou distillée avec 3 à 4 g de concentré Apax Lab par litre, dosés selon le café.",
               "Agua desmineralizada o destilada con 3 a 4 g de concentrado Apax Lab por litro, según el café."),
         source=APAX),
    dict(id="evian", name="Evian", kind="BOTTLE", fit="AVOID", ca=80, mg=26, na=6.5, k=1, hco3=360, tds=345,
         use=T("Too hard and too alkaline for coffee: flat cups and scale in the machine.",
               "Trop dure et trop alcaline pour le café : tasses plates et calcaire dans la machine.",
               "Demasiado dura y alcalina para el café: tazas planas y cal en la máquina."),
         source=NESTLE),
]

ADDITIVES = [
    dict(id="apax-tonik", brand="Apax Lab", name="TONIK", code="[1]",
         effect=T("Vibrant, bright, juicy: brings acidity forward.", "Vibrant, vif, juteux : met l'acidité en avant.", "Vibrante, vivo, jugoso: realza la acidez."),
         composition="MgCl₂, CaCl₂, NaCl, NaHCO₃, KHCO₃", source=APAX),
    dict(id="apax-jamm", brand="Apax Lab", name="JAMM", code="[2]",
         effect=T("Rich, sweet, creamy: sweetness and ripeness.", "Riche, sucré, crémeux : sucrosité et maturité.", "Rico, dulce, cremoso: dulzor y madurez."),
         composition="MgCl₂, CaCl₂, KCl, KHCO₃, NaHCO₃", source=APAX),
    dict(id="apax-lylac", brand="Apax Lab", name="LYLAC", code="[3]",
         effect=T("Elegant, floral, silky.", "Élégant, floral, soyeux.", "Elegante, floral, sedoso."),
         composition="MgSO₄, MgCl₂, KCl, KHCO₃, NaHCO₃, NaCl", source=APAX),
    dict(id="apax-konflux", brand="Apax Lab", name="KONFLUX", code="",
         effect=T("Depth and texture: a rounder, sweeter cup. A few drops.", "Profondeur et texture : une tasse plus ronde et plus sucrée. Quelques gouttes.", "Profundidad y textura: una taza más redonda y dulce. Unas gotas."),
         composition="", source="https://apaxlab.com/"),
]

# Apax Lab mixes in grams per litre of demineralised water (TONIK, JAMM, LYLAC).
APAX_MIXES = [
    dict(id="cupping", name=T("Cupping", "Cupping", "Cata"), g=(2.5, 1, 0.5)),
    dict(id="washed", name=T("Washed coffees", "Cafés lavés", "Cafés lavados"), g=(2.5, 0.5, 1)),
    dict(id="natural", name=T("Natural coffees", "Cafés naturels", "Cafés naturales"), g=(1, 2.5, 0.5)),
    dict(id="honey", name=T("Honey coffees", "Cafés honey", "Cafés honey"), g=(1, 0.5, 2.5)),
    dict(id="fermented", name=T("Very fermented coffees", "Cafés très fermentés", "Cafés muy fermentados"), g=(1, 2, 2)),
    dict(id="light", name=T("Light roast", "Torréfaction claire", "Tueste claro"), g=(1, 3, 0)),
    dict(id="dark", name=T("Dark roast", "Torréfaction foncée", "Tueste oscuro"), g=(3, 0, 1)),
    dict(id="wolfl", name=T("Martin Wölfl, World Brewers Cup 2024", "Martin Wölfl, World Brewers Cup 2024", "Martin Wölfl, World Brewers Cup 2024"), g=(1, 1.5, 1.5)),
]

# Drops straight in the cup, all Apax Lab concentrates.
APAX_DROPS = [
    dict(id="filter", name=T("Filter, 200 ml", "Filtre, 200 ml", "Filtro, 200 ml"), drops=(5, 10)),
    dict(id="espresso", name=T("Espresso, 40 ml", "Espresso, 40 ml", "Espresso, 40 ml"), drops=(1, 3)),
    dict(id="milk", name=T("Milk drink, 150 ml", "Boisson lactée, 150 ml", "Bebida con leche, 150 ml"), drops=(3, 6)),
]

# Microns per click (or per number on stepped grinders), from the makers' figures.
GRINDER_STEPS = [
    ("Comandante C40", 30, "https://stillwatercoffee.ca/blogs/brew_hacks/comandante-c40-vs-1zpresso-k-ultra-vs-zp6"),
    ("Comandante C40 Red Clix", 15, "https://worldaeropresschampionship.com/pages/recipes"),
    ("1Zpresso K-Ultra", 20, "https://coffeechronicler.com/best-1zpresso-grinder-overview/"),
    ("1Zpresso K-Max", 22, "https://coffeechronicler.com/best-1zpresso-grinder-overview/"),
    ("1Zpresso JX-Pro", 12.5, "https://coffeechronicler.com/best-1zpresso-grinder-overview/"),
    ("1Zpresso J-Max", 8.8, "https://coffeechronicler.com/best-1zpresso-grinder-overview/"),
    ("1Zpresso ZP6", 22, "https://coffeechronicler.com/best-1zpresso-grinder-overview/"),
    ("1Zpresso X-Ultra", 12.5, "https://coffeechronicler.com/best-1zpresso-grinder-overview/"),
    ("1Zpresso Q2", 25, "https://coffeechronicler.com/best-1zpresso-grinder-overview/"),
]
