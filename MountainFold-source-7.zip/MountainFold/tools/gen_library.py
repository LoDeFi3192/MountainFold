#!/usr/bin/env python3
"""Builds assets/library/library.json (champion recipes, waters, Apax Lab, grinder steps) and checks it.
The web app copies the same file at build time: one table for both apps."""
import json, os, sys

here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(here, "library"))
from champions import CHAMPIONS
from water import WATERS, ADDITIVES, APAX_MIXES, APAX_DROPS, GRINDER_STEPS

METHODS = {"V60", "AEROPRESS", "CHEMEX", "FRENCH_PRESS", "MOKA", "ESPRESSO", "CLEVER", "KALITA", "ORIGAMI", "COLD_BREW", "CUSTOM"}
STEP_TYPES = {"BLOOM", "POUR", "WAIT", "STIR", "SWIRL", "PRESS", "DRAWDOWN", "CUSTOM"}
errors = []

def text(where, d, optional=False):
    if d is None:
        if not optional: errors.append(f"{where}: missing")
        return
    for lang in ("en", "fr", "es"):
        v = d.get(lang)
        if not isinstance(v, str) or not v.strip(): errors.append(f"{where}: missing {lang}")
        elif "—" in v or "  " in v or ";" in v: errors.append(f"{where}: house style ({lang})")

def gh(ca, mg): return None if ca is None or mg is None else round(2.497 * ca + 4.118 * mg)
def kh(hco3): return None if hco3 is None else round(0.8202 * hco3)

additive_ids = {a["id"] for a in ADDITIVES}
water_ids = {w["id"] for w in WATERS}
grinders = {name: step for name, step, _ in GRINDER_STEPS}
ids = set()
for c in CHAMPIONS:
    w = c["id"]
    if w in ids: errors.append(f"duplicate {w}")
    ids.add(w)
    if c["competition"] not in ("WAC", "WBRC"): errors.append(f"{w}: competition")
    if c["kind"] not in ("COMPETITION", "SIGNATURE"): errors.append(f"{w}: kind")
    if c["method"] not in METHODS: errors.append(f"{w}: method")
    for k in ("country", "brewer", "filter", "grind", "water"): text(f"{w}.{k}", c[k])
    text(f"{w}.notes", c.get("notes"), optional=True)
    if not c["source"].startswith("https://"): errors.append(f"{w}: source")
    if not (5 <= c["doseG"] <= 40 and c["doseG"] < c["waterG"] <= 400): errors.append(f"{w}: dose/water")
    if not 60 <= c["tempC"] <= 100: errors.append(f"{w}: temp")
    last_t, last_w = -1, 0
    for i, s in enumerate(c["steps"]):
        if s["type"] not in STEP_TYPES: errors.append(f"{w}.s{i}: type")
        if s["startS"] < last_t: errors.append(f"{w}.s{i}: out of order")
        last_t = s["startS"]
        if s["targetWaterG"] is not None:
            if s["targetWaterG"] < last_w or s["targetWaterG"] > c["waterG"]: errors.append(f"{w}.s{i}: water {s['targetWaterG']}")
            last_w = s["targetWaterG"]
        text(f"{w}.s{i}.label", s["label"]); text(f"{w}.s{i}.note", s["note"], optional=True)
    if last_w != c["waterG"]: errors.append(f"{w}: steps end at {last_w} g, recipe says {c['waterG']} g")
    if c["targetTimeS"] < last_t: errors.append(f"{w}: target before last step")
    if c.get("grinder") and c["grinder"] not in grinders: errors.append(f"{w}: unknown grinder {c['grinder']}")
    if c.get("grinder") and c.get("clicks") and c.get("grindMicrons"):
        if abs(grinders[c["grinder"]] * c["clicks"] - c["grindMicrons"]) > 1: errors.append(f"{w}: microns do not match clicks")
    if c.get("waterId") and c["waterId"] not in water_ids: errors.append(f"{w}: water id")
    for a in c.get("additives", []):
        if a["id"] not in additive_ids or a["unit"] not in ("G_PER_L", "DROPS"): errors.append(f"{w}: additive {a}")

for x in WATERS:
    text(f"{x['id']}.use", x["use"])
    if x["kind"] not in ("BOTTLE", "MIX", "RECIPE", "BASE") or x["fit"] not in ("GOOD", "BASE", "AVOID"): errors.append(f"{x['id']}: kind/fit")
    x.setdefault("gh", None); x.setdefault("kh", None)
    if x["gh"] is None: x["gh"] = gh(x["ca"], x["mg"])
    if x["kh"] is None: x["kh"] = kh(x["hco3"])
for a in ADDITIVES: text(f"{a['id']}.effect", a["effect"])
for m in APAX_MIXES: text(f"mix {m['id']}", m["name"])
for d in APAX_DROPS: text(f"drops {d['id']}", d["name"])

if errors:
    print("\n".join(errors)); sys.exit(1)

# Every field present on every row, so neither client depends on its own defaults.
for c in CHAMPIONS:
    for k, v in (("inverted", None), ("grinder", None), ("clicks", None), ("grindMicrons", None), ("waterId", None),
                 ("additives", []), ("notes", None), ("approx", False)):
        c.setdefault(k, v)
    for st in c["steps"]:
        st.setdefault("note", None); st.setdefault("targetWaterG", None)

lib = {
    "version": 1,
    "champions": sorted(CHAMPIONS, key=lambda c: (c["competition"] != "WBRC", -c["year"], c["place"])),
    "waters": WATERS,
    "additives": ADDITIVES,
    "apaxMixes": [{"id": m["id"], "name": m["name"], "tonik": m["g"][0], "jamm": m["g"][1], "lylac": m["g"][2]} for m in APAX_MIXES],
    "apaxDrops": [{"id": d["id"], "name": d["name"], "min": d["drops"][0], "max": d["drops"][1]} for d in APAX_DROPS],
    "grinderSteps": [{"name": n, "micronsPerStep": s, "source": src} for n, s, src in GRINDER_STEPS],
}
out = os.path.join(here, "..", "app", "src", "main", "assets", "library", "library.json")
os.makedirs(os.path.dirname(out), exist_ok=True)
json.dump(lib, open(out, "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
print(f"{len(CHAMPIONS)} champion recipes, {len(WATERS)} waters, {len(ADDITIVES)} additives, {len(GRINDER_STEPS)} grinder steps -> {os.path.relpath(out, os.path.join(here, '..'))}")
