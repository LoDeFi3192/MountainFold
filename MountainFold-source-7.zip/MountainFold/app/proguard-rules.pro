# kotlinx.serialization keeps its own rules via the library consumer file.
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keepclassmembers class com.mountainfold.app.** {
    *** Companion;
}
-keepclasseswithmembers class com.mountainfold.app.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Data that is serialised to JSON or mapped by Room keeps its exact shape.
-keep class com.mountainfold.app.core.model.** { *; }
-keep class com.mountainfold.app.data.db.** { *; }
-keep class com.mountainfold.app.data.prefs.Settings** { *; }
-keep class com.mountainfold.app.data.Backup** { *; }
-keep class com.mountainfold.app.data.session.PersistedSession** { *; }
-keep class com.mountainfold.app.core.train.** { *; }
-keep class com.mountainfold.app.core.library.** { *; }
