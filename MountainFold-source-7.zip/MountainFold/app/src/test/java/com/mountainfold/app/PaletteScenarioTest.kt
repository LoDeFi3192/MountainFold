package com.mountainfold.app

import android.content.res.Configuration
import android.os.Looper
import androidx.activity.compose.LocalActivityResultRegistryOwner
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.github.takahirom.roborazzi.captureRoboImage
import com.mountainfold.app.core.fold.FoldState
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.fold.Posture
import com.mountainfold.app.core.library.AdditivesCodec
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.Palette
import com.mountainfold.app.core.model.ThemeMode
import com.mountainfold.app.ui.MainViewModel
import com.mountainfold.app.ui.MountainFoldRoot
import com.mountainfold.app.ui.Overlay
import com.mountainfold.app.ui.Pane
import com.mountainfold.app.ui.RecipeSource
import com.mountainfold.app.ui.Tab
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.util.Locale

/** Cobalt and Sage rendered on the main screens, light and dark, closed and open, for review. */
@RunWith(AndroidJUnit4::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [35], qualifiers = "w1000dp-h1100dp-xhdpi")
class PaletteScenarioTest {
    @get:Rule val rule = createComposeRule()

    private var wide by mutableStateOf(false)
    private val shots = File("build/shots").apply { mkdirs() }

    private fun idle() {
        shadowOf(Looper.getMainLooper()).idle()
        rule.mainClock.advanceTimeBy(400)
        rule.waitForIdle()
    }

    private fun await(what: String, condition: () -> Boolean) {
        val end = System.currentTimeMillis() + 20_000
        while (!condition()) {
            idle()
            Thread.sleep(20)
            check(System.currentTimeMillis() < end) { "Timed out waiting for $what" }
        }
        idle()
    }

    private fun shot(name: String) {
        idle()
        rule.onNodeWithTag("device").captureRoboImage(File(shots, "$name.png").path)
    }

    @Test
    fun cobaltAndSage() {
        val app = ApplicationProvider.getApplicationContext<MountainFoldApp>()
        val vm = MainViewModel(app)
        rule.setContent {
            val registryOwner = checkNotNull(LocalActivityResultRegistryOwner.current)
            val w = if (wide) 880 else 384
            val h = if (wide) 980 else 880
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.align(Alignment.TopStart).requiredSize(w.dp, h.dp).testTag("device")) {
                    CompositionLocalProvider(LocalActivityResultRegistryOwner provides registryOwner) {
                        val posture = if (wide) FoldState(Posture.OPEN, HingeInfo(880, 0, 880, 1960, vertical = true, halfOpened = false)) else FoldState(Posture.CLOSED, null)
                        MountainFoldRoot(vm, foldState = { posture })
                    }
                }
            }
        }
        await("settings") { vm.settings.value != null }
        vm.setSettings { it.copy(dynamicColor = false) }
        vm.completeOnboarding(listOf(BrewMethod.V60, BrewMethod.AEROPRESS), "Comandante C40")
        await("onboarding") { vm.settings.value!!.onboarded && vm.recipes.value.isNotEmpty() }
        for (palette in listOf(Palette.COBALT, Palette.SAGE)) for (mode in listOf(ThemeMode.LIGHT, ThemeMode.DARK)) {
            val tag = "pal_${palette.name.lowercase()}_${mode.name.lowercase()}"
            vm.setSettings { it.copy(palette = palette, themeMode = mode) }
            await("$tag applied") { vm.settings.value!!.palette == palette && vm.settings.value!!.themeMode == mode }
            wide = false
            vm.selectTab(Tab.HOME)
            shot("${tag}_1_home")
            vm.selectTab(Tab.BREW)
            shot("${tag}_2_brew")
            vm.selectTab(Tab.RECIPES)
            vm.recipeSource = RecipeSource.CHAMPIONS
            vm.championSel = "wbrc-2024-martin-wolfl"
            shot("${tag}_3_champion")
            vm.championSel = null
            vm.recipeSource = RecipeSource.MINE
            wide = true
            vm.selectTab(Tab.TRAIN)
            shot("${tag}_4_open_train")
            vm.open(Overlay.Settings)
            shot("${tag}_5_open_settings")
            vm.back()
        }
        wide = false
    }
}
