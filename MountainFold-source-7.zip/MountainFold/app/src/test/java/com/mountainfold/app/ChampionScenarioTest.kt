package com.mountainfold.app

import android.content.res.Configuration
import android.os.Looper
import androidx.activity.compose.LocalActivityResultRegistryOwner
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.github.takahirom.roborazzi.captureRoboImage
import com.mountainfold.app.core.fold.FoldState
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.fold.Posture
import com.mountainfold.app.core.library.AdditivesCodec
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.ui.MainViewModel
import com.mountainfold.app.ui.MountainFoldRoot
import com.mountainfold.app.ui.Overlay
import com.mountainfold.app.ui.Pane
import com.mountainfold.app.ui.RecipeSource
import com.mountainfold.app.ui.Tab
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.util.Locale

/** Champion library, water and microns, driven through the real app and rendered for review. */
@RunWith(AndroidJUnit4::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [35], qualifiers = "w1000dp-h1100dp-xhdpi")
class ChampionScenarioTest {
    @get:Rule val rule = createComposeRule()

    private var wide by mutableStateOf(false)
    private var language by mutableStateOf("en")
    private val shots = File("build/shots").apply { mkdirs() }

    private fun idle() {
        shadowOf(Looper.getMainLooper()).idle()
        rule.mainClock.advanceTimeBy(400)
        rule.waitForIdle()
    }

    private fun await(what: String, condition: () -> Boolean) {
        val end = System.currentTimeMillis() + 20_000
        while (!condition()) {
            idle()
            Thread.sleep(20)
            check(System.currentTimeMillis() < end) { "Timed out waiting for $what" }
        }
        idle()
    }

    private fun shot(name: String) {
        idle()
        rule.onNodeWithTag("device").captureRoboImage(File(shots, "$name.png").path)
    }

    private fun text(t: String) = rule.onAllNodesWithText(t, substring = true, ignoreCase = true).fetchSemanticsNodes().isNotEmpty()

    @Test
    fun championsWaterAndMicrons() {
        val app = ApplicationProvider.getApplicationContext<MountainFoldApp>()
        val vm = MainViewModel(app)
        rule.setContent {
            val base = LocalContext.current
            val registryOwner = checkNotNull(LocalActivityResultRegistryOwner.current)
            val localized = remember(language) {
                val config = Configuration(base.resources.configuration)
                config.setLocale(Locale.forLanguageTag(language))
                base.createConfigurationContext(config)
            }
            val w = if (wide) 880 else 384
            val h = if (wide) 980 else 880
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.align(Alignment.TopStart).requiredSize(w.dp, h.dp).testTag("device")) {
                    CompositionLocalProvider(LocalContext provides localized, LocalActivityResultRegistryOwner provides registryOwner) {
                        val posture = if (wide) FoldState(Posture.OPEN, HingeInfo(880, 0, 880, 1960, vertical = true, halfOpened = false)) else FoldState(Posture.CLOSED, null)
                        MountainFoldRoot(vm, foldState = { posture })
                    }
                }
            }
        }
        await("settings") { vm.settings.value != null }
        vm.setSettings { it.copy(dynamicColor = false) }
        vm.completeOnboarding(listOf(BrewMethod.V60, BrewMethod.AEROPRESS), "Comandante C40")
        await("onboarding") { vm.settings.value!!.onboarded && vm.grinders.value.size == 1 && vm.settings.value!!.defaultGrinderId != null }
        vm.setSettings { it.copy(grindMicrons = true) }
        await("microns on") { vm.settings.value!!.grindMicrons }

        // ---- Champions list and detail -------------------------------------------------------
        vm.selectTab(Tab.RECIPES)
        vm.recipeSource = RecipeSource.CHAMPIONS
        shot("lib01_champions_list")
        assertTrue(text("Martin Wölfl"))
        vm.championSel = "wac-2024-george-stanica"
        shot("lib02_champion_stanica")
        // 870 µm on a 30 µm per click Comandante: 29 clicks.
        assertTrue(text("about 29 clicks"))
        vm.championSel = "wbrc-2024-martin-wolfl"
        shot("lib03_champion_wolfl")
        assertTrue(text("TONIK"))

        // ---- Copy into my recipes ----------------------------------------------------------
        val before = vm.recipes.value.size
        vm.addChampionRecipe(vm.library.champion("wbrc-2024-martin-wolfl")!!)
        await("champion copied") { vm.recipes.value.size == before + 1 && vm.recipePane is Pane.View }
        val copy = vm.recipes.value.first { it.championId == "wbrc-2024-martin-wolfl" }
        assertEquals("apax-base", copy.waterId)
        assertEquals(3, AdditivesCodec.decode(copy.additivesJson).size)
        assertEquals(RecipeSource.MINE, vm.recipeSource)
        shot("lib04_recipe_from_champion")
        vm.editRecipe(copy)
        vm.applyApaxMix(vm.library.apaxMixes.first { it.id == "natural" })
        assertEquals("2.5", vm.recipeDraft!!.additives.first { it.id == "apax-jamm" }.amount)
        rule.onNodeWithText("Fills TONIK", substring = true).performScrollTo()
        shot("lib05_editor_water")
        vm.saveRecipeDraft()
        await("saved") { vm.recipeDraft == null }

        // ---- Brew a champion recipe: water travels to the session and the log --------------------
        vm.brewChampion(vm.library.champion("wbrc-2024-martin-wolfl")!!)
        await("session") { vm.session.state.value.recipe?.waterId == "apax-base" }
        assertEquals(3, vm.session.state.value.recipe!!.additives.size)

        // ---- Water guide, settings, wide layout, French ---------------------------------------
        vm.open(Overlay.Water)
        shot("lib06_water_guide")
        assertTrue(text("Mont Roucous"))
        vm.back()
        vm.open(Overlay.Settings)
        rule.onNodeWithText("makers' figures", substring = true).performScrollTo()
        shot("lib07_settings_microns")
        vm.back()
        wide = true
        vm.selectTab(Tab.RECIPES)
        vm.recipeSource = RecipeSource.CHAMPIONS
        vm.championSel = "wbrc-2021-matt-winton"
        idle()
        // Same grinder as the champion: no conversion line.
        assertTrue(!text("On your Comandante C40"))
        shot("lib08_open_champions")
        com.mountainfold.app.data.prefs.LanguageStore.set(app, "fr")
        language = "fr"
        vm.open(Overlay.Water)
        shot("lib09_open_water_fr")
        vm.back()
        shot("lib10_open_champion_fr")
        vm.championSel = "wac-2023-tay-wipvasutt"
        shot("lib11_open_champion_fr")
        assertTrue(text("Sur votre Comandante C40"))
    }
}
