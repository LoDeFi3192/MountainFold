package com.mountainfold.app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.mountainfold.app.data.db.AppDatabase
import com.mountainfold.app.data.db.CuppingCoffee
import com.mountainfold.app.data.db.CuppingSession
import com.mountainfold.app.data.db.Grinder
import com.mountainfold.app.data.db.TrainingEvent
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

/**
 * Builds a version 1 database exactly as 1.0.0 created it, fills it, then opens it with the current app.
 * An update must keep every coffee, recipe and brew, through every migration up to the current version.
 */
@RunWith(AndroidJUnit4::class)
@Config(sdk = [35])
class MigrationTest {
    @Test
    fun updatingFromVersion1KeepsUserData() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val file = context.getDatabasePath("mountainfold.db")
        file.parentFile!!.mkdirs()
        SQLiteDatabase.openOrCreateDatabase(file, null).use { db ->
            javaClass.classLoader!!.getResource("schema_v1.sql")!!.readText().lines().filter { it.isNotBlank() }.forEach(db::execSQL)
            db.execSQL("INSERT INTO coffees (name, origin, country, region, producer, variety, process, altitude, roaster, tastingNotes, roastLevel, createdAt) VALUES ('Ethiopia Guji','','Ethiopia','','','','Washed','','','','',1)")
            db.execSQL("INSERT INTO recipes (name, method, coffeeId, doseG, waterG, tempC, grind, targetTimeS, stepsJson, notes, favorite, createdAt, updatedAt) VALUES ('Classic V60','V60',1,15,250,93,'22',180,'[]','',1,1,1)")
            db.execSQL("INSERT INTO brews (coffeeName, recipeName, method, doseG, waterG, grind, grinderName, timeMs, targetTimeS, notes, rating, acidity, sweetness, body, balance, clarity, symptoms, stepsJson, createdAt) VALUES ('Ethiopia Guji','Classic V60','V60',15,250,'22','',166000,180,'',3,4,2,2,2,4,'SOUR','[]',1)")
            db.version = 1
        }

        val room = AppDatabase.create(context)
        runBlocking {
            assertEquals("Ethiopia Guji", room.coffees().all().single().name)
            assertEquals("Classic V60", room.recipes().all().single().name)
            assertEquals("SOUR", room.brews().all().single().symptoms)
            assertEquals(0, room.training().all().size)
            room.training().insert(TrainingEvent(createdAt = 5, kind = "LESSON", refId = "ratio", correct = 3, total = 3, xp = 75, passed = true, breakdown = "EXTRACTION:3/3"))
            assertEquals("ratio", room.training().all().single().refId)
            // 2 to 3: cupping tables exist, empty, and work with their foreign key.
            assertEquals(0, room.cupping().allSessions().size)
            room.cupping().saveSession(CuppingSession(id = "s", createdAt = 1, dateIso = "2026-10-13"), listOf(CuppingCoffee(id = "c", name = "Guji", fragranceNotes = listOf("Citron"))))
            assertEquals(listOf("Citron"), room.cupping().coffeesOf("s").single().fragranceNotes)
            room.cupping().deleteSession("s")
            assertEquals(0, room.cupping().allCoffees().size)
            // 3 to 4: water, concentrates and champion origin default to empty, microns per click to unknown.
            val recipe = room.recipes().all().single()
            assertEquals(null, recipe.waterId)
            assertEquals("", recipe.waterNote)
            assertEquals("[]", recipe.additivesJson)
            assertEquals(null, recipe.championId)
            assertEquals("[]", room.brews().all().single().additivesJson)
            room.recipes().upsert(recipe.copy(waterId = "apax-base", additivesJson = "[{\"id\":\"apax-jamm\",\"amount\":1.5}]", championId = "wbrc-2024-martin-wolfl"))
            assertEquals("apax-base", room.recipes().all().single().waterId)
            val gid = room.grinders().upsert(Grinder(name = "Comandante C40"))
            assertEquals(null, room.grinders().all().single { it.id == gid }.micronsPerStep)
            room.grinders().upsert(Grinder(id = gid, name = "Comandante C40", micronsPerStep = 30.0))
            assertEquals(30.0, room.grinders().all().single().micronsPerStep!!, 0.0)
        }
        room.close()
    }
}
