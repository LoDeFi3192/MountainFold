package com.mountainfold.app

import com.mountainfold.app.core.library.AdditiveLine
import com.mountainfold.app.core.library.AdditiveUnit
import com.mountainfold.app.core.library.AdditivesCodec
import com.mountainfold.app.core.library.GrindMicrons
import com.mountainfold.app.core.library.LibraryJson
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.data.Backup
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class LibraryContentTest {
    private val lib = LibraryJson.parse(File("src/main/assets/library/library.json").readText())

    @Test fun assetParsesCompletely() {
        assertEquals(21, lib.champions.size)
        assertTrue(lib.waters.size >= 8)
        assertEquals(4, lib.additives.size)
        assertTrue(lib.apaxMixes.isNotEmpty() && lib.apaxDrops.isNotEmpty() && lib.grinderSteps.isNotEmpty())
    }

    @Test fun everyChampionIsBrewable() {
        for (c in lib.champions) {
            for (lang in listOf("en", "fr", "es")) {
                val steps = c.steps(lang)
                assertTrue(c.id, steps.isNotEmpty())
                assertTrue(c.id, steps.all { it.label.isNotBlank() })
                assertEquals(c.id, c.waterG, steps.mapNotNull { it.targetWaterG }.last(), 0.01)
                assertTrue(c.id, steps.zipWithNext().all { (a, b) -> a.startS <= b.startS })
            }
            if (c.isAeroPress) assertEquals(c.id, BrewMethod.AEROPRESS, c.brewMethod)
            c.waterId?.let { assertNotNull(c.id, lib.water(it)) }
            c.additives.forEach { assertNotNull(c.id, lib.additive(it.id)) }
        }
    }

    @Test fun wolflRecipeCarriesApaxLab() {
        val c = lib.champion("wbrc-2024-martin-wolfl")!!
        assertEquals("apax-base", c.waterId)
        assertEquals(listOf("apax-tonik", "apax-jamm", "apax-lylac"), c.additives.map { it.id })
        assertEquals(4.0, c.additives.sumOf { it.amount }, 0.001)
    }

    @Test fun micronsComeFromClicksWhenNotPublished() {
        val stanica = lib.micronsOf(lib.champion("wac-2024-george-stanica")!!)!!
        assertEquals(870.0, stanica.microns, 0.1)
        assertTrue(stanica.published)
        val tay = lib.micronsOf(lib.champion("wac-2023-tay-wipvasutt")!!)!!
        assertEquals(65 * 22.0, tay.microns, 0.1)
        assertFalse(tay.published)
        assertEquals(30.0, lib.micronsPerStep("comandante c40")!!, 0.0)
        assertNull(lib.micronsPerStep("Unknown Mill"))
    }

    @Test fun waterHardnessIsComputedFromTheLabel() {
        val volvic = lib.water("volvic")!!
        assertEquals(63, volvic.gh) // 2.497 x 12 + 4.118 x 8
        assertEquals(61, volvic.kh) // 0.8202 x 74
        assertEquals("AVOID", lib.water("evian")!!.fit)
    }
}

class GrindMicronsTest {
    @Test fun settingReadsTheLeadingNumber() {
        assertEquals(22.0, GrindMicrons.setting("22")!!, 0.0)
        assertEquals(22.5, GrindMicrons.setting("22,5 clicks")!!, 0.0)
        assertNull(GrindMicrons.setting("medium fine"))
    }

    @Test fun micronsFromClicksOrFromText() {
        assertEquals(660.0, GrindMicrons.microns("22", 30.0)!!, 0.0)
        assertEquals(630.0, GrindMicrons.microns("EK43, 630 µm", 30.0)!!, 0.0)
        assertEquals(630.0, GrindMicrons.microns("630um", null)!!, 0.0)
        assertNull(GrindMicrons.microns("22", null))
    }

    @Test fun stepsRoundToHalfClicksOnFineGrinders() {
        assertEquals(21.0, GrindMicrons.steps(630.0, 30.0)!!, 0.0)
        assertEquals(71.5, GrindMicrons.steps(630.0, 8.8)!!, 0.0)
        assertEquals("71.5", GrindMicrons.formatSteps(71.5))
        assertEquals("21", GrindMicrons.formatSteps(21.0))
        assertEquals("870 µm", GrindMicrons.format(868.0))
    }
}

class AdditivesCodecTest {
    @Test fun roundTripAndTolerance() {
        val lines = listOf(AdditiveLine("apax-tonik", amount = 1.0), AdditiveLine("custom", "Lotus", 3.0, AdditiveUnit.DROPS))
        assertEquals(lines, AdditivesCodec.decode(AdditivesCodec.encode(lines)))
        assertEquals(emptyList<AdditiveLine>(), AdditivesCodec.decode(""))
        assertEquals(emptyList<AdditiveLine>(), AdditivesCodec.decode("not json"))
        assertEquals(AdditiveUnit.G_PER_L, AdditivesCodec.decode("""[{"id":"apax-jamm","amount":2,"unit":"LITRES"}]""").single().unit)
    }

    @Test fun backupFrom120StillImports() {
        val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; coerceInputValues = true }
        val old = """{"app":"MountainFold","version":1,"recipes":[{"id":3,"name":"Classic V60","method":"V60","doseG":15,"waterG":250,"grind":"22","stepsJson":"[]"}],
            |"brews":[{"id":1,"recipeName":"Classic V60","doseG":15,"waterG":250}],"grinders":[{"id":1,"name":"Comandante C40"}]}""".trimMargin()
        val b = json.decodeFromString(Backup.serializer(), old)
        assertEquals("[]", b.recipes.single().additivesJson)
        assertNull(b.recipes.single().waterId)
        assertEquals("", b.brews.single().waterNote)
        assertNull(b.grinders.single().micronsPerStep)
        assertFalse(b.settings.grindMicrons)
    }
}
