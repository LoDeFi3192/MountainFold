package com.mountainfold.app

import androidx.compose.material3.ColorScheme
import androidx.compose.ui.graphics.Color
import com.mountainfold.app.core.model.Palette
import com.mountainfold.app.ui.theme.Palettes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/** Cobalt and Sage come from brand colours, not from tonal math: every text pair is checked at WCAG AA (4.5:1). */
class PaletteContrastTest {
    private fun lin(c: Float) = if (c <= 0.04045f) c / 12.92 else ((c + 0.055) / 1.055).pow(2.4)
    private fun lum(c: Color) = 0.2126 * lin(c.red) + 0.7152 * lin(c.green) + 0.0722 * lin(c.blue)
    private fun ratio(a: Color, b: Color) = (max(lum(a), lum(b)) + 0.05) / (min(lum(a), lum(b)) + 0.05)

    private fun pairs(s: ColorScheme) = listOf(
        "onPrimary/primary" to (s.onPrimary to s.primary),
        "onPrimaryContainer/primaryContainer" to (s.onPrimaryContainer to s.primaryContainer),
        "onSecondaryContainer/secondaryContainer" to (s.onSecondaryContainer to s.secondaryContainer),
        "onTertiaryContainer/tertiaryContainer" to (s.onTertiaryContainer to s.tertiaryContainer),
        "onErrorContainer/errorContainer" to (s.onErrorContainer to s.errorContainer),
        "onSurface/surface" to (s.onSurface to s.surface),
        "onSurfaceVariant/surface" to (s.onSurfaceVariant to s.surface),
        "onSurfaceVariant/surfaceContainerHigh" to (s.onSurfaceVariant to s.surfaceContainerHigh),
        "onSurface/surfaceContainerHighest" to (s.onSurface to s.surfaceContainerHighest),
        "primary/surface" to (s.primary to s.surface),
        "primary/surfaceContainerHigh" to (s.primary to s.surfaceContainerHigh),
        "secondary/surface" to (s.secondary to s.surface),
        "tertiary/surface" to (s.tertiary to s.surface),
        "error/surface" to (s.error to s.surface),
        "inverseOnSurface/inverseSurface" to (s.inverseOnSurface to s.inverseSurface),
    )

    @Test fun cobaltAndSageReadWellInLightAndDark() {
        for (p in listOf(Palette.COBALT, Palette.SAGE)) for (dark in listOf(false, true)) {
            for ((name, pair) in pairs(Palettes.scheme(p, dark))) {
                val r = ratio(pair.first, pair.second)
                assertTrue("$p dark=$dark $name = ${"%.2f".format(r)}", r >= 4.5)
            }
        }
    }

    @Test fun brandColoursAreKeptExactly() {
        fun hex(c: Color) = "%02X%02X%02X".format((c.red * 255).toInt(), (c.green * 255).toInt(), (c.blue * 255).toInt())
        val cobalt = Palettes.scheme(Palette.COBALT, false)
        assertEquals("EDECE6", hex(cobalt.background))
        assertEquals("1546D9", hex(cobalt.primary))
        assertEquals("F9B318", hex(cobalt.secondaryContainer))
        val sage = Palettes.scheme(Palette.SAGE, false)
        assertEquals("A5A79B", hex(sage.background))
        assertEquals("E8D2B5", hex(sage.primaryContainer))
        assertEquals("590907", hex(sage.primary))
        val sageDark = Palettes.scheme(Palette.SAGE, true)
        assertEquals("E8D2B5", hex(sageDark.primary))
        assertEquals("590907", hex(sageDark.primaryContainer))
    }
}
