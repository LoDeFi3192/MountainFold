package com.mountainfold.app.data.library

import android.content.Context
import com.mountainfold.app.core.library.LibraryContent
import com.mountainfold.app.core.library.LibraryJson

/** Champion recipes, waters and Apax Lab ship as one JSON asset, shared with the web app. Parsed once, on first use. */
class LibraryStore(private val context: Context) {
    val content: LibraryContent by lazy {
        runCatching { context.assets.open("library/library.json").use { LibraryJson.parse(it.readBytes().decodeToString()) } }
            .getOrDefault(LibraryContent())
    }
}
