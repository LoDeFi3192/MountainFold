package com.mountainfold.app.data.db

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.TypeConverters
import androidx.room.Update
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface CoffeeDao {
    @Query("SELECT * FROM coffees ORDER BY createdAt DESC") fun observeAll(): Flow<List<Coffee>>
    @Query("SELECT * FROM coffees") suspend fun all(): List<Coffee>
    @Query("SELECT * FROM coffees WHERE id = :id") suspend fun byId(id: Long): Coffee?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(item: Coffee): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(items: List<Coffee>)
    @Delete suspend fun delete(item: Coffee)
    @Query("DELETE FROM coffees") suspend fun clear()
}

@Dao
interface RecipeDao {
    @Query("SELECT * FROM recipes ORDER BY favorite DESC, updatedAt DESC") fun observeAll(): Flow<List<Recipe>>
    @Query("SELECT * FROM recipes") suspend fun all(): List<Recipe>
    @Query("SELECT * FROM recipes WHERE id = :id") suspend fun byId(id: Long): Recipe?
    @Query("SELECT COUNT(*) FROM recipes") suspend fun count(): Int
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(item: Recipe): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(items: List<Recipe>)
    @Update suspend fun update(item: Recipe)
    @Delete suspend fun delete(item: Recipe)
    @Query("UPDATE recipes SET coffeeId = NULL WHERE coffeeId = :coffeeId") suspend fun unlinkCoffee(coffeeId: Long)
    @Query("DELETE FROM recipes") suspend fun clear()
}

@Dao
interface BrewDao {
    @Query("SELECT * FROM brews ORDER BY createdAt DESC") fun observeAll(): Flow<List<Brew>>
    @Query("SELECT * FROM brews") suspend fun all(): List<Brew>
    @Query("SELECT * FROM brews WHERE id = :id") suspend fun byId(id: Long): Brew?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(item: Brew): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(items: List<Brew>)
    @Delete suspend fun delete(item: Brew)
    @Query("DELETE FROM brews") suspend fun clear()
}

@Dao
interface GrinderDao {
    @Query("SELECT * FROM grinders ORDER BY name") fun observeAll(): Flow<List<Grinder>>
    @Query("SELECT * FROM grinders") suspend fun all(): List<Grinder>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(item: Grinder): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(items: List<Grinder>)
    @Delete suspend fun delete(item: Grinder)
    @Query("DELETE FROM grinders") suspend fun clear()
}

@Dao
interface TrainingDao {
    @Query("SELECT * FROM training_events ORDER BY createdAt DESC") fun observeAll(): Flow<List<TrainingEvent>>
    @Query("SELECT * FROM training_events") suspend fun all(): List<TrainingEvent>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: TrainingEvent): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(items: List<TrainingEvent>)
    @Query("DELETE FROM training_events") suspend fun clear()
}

@Dao
interface CuppingDao {
    @Query("SELECT * FROM cupping_sessions ORDER BY createdAt DESC") fun observeSessions(): Flow<List<CuppingSession>>
    @Query("SELECT * FROM cupping_coffees ORDER BY sessionId, position") fun observeCoffees(): Flow<List<CuppingCoffee>>
    @Query("SELECT * FROM cupping_sessions") suspend fun allSessions(): List<CuppingSession>
    @Query("SELECT * FROM cupping_coffees") suspend fun allCoffees(): List<CuppingCoffee>
    @Query("SELECT * FROM cupping_sessions WHERE id = :id") suspend fun session(id: String): CuppingSession?
    @Query("SELECT * FROM cupping_sessions ORDER BY createdAt DESC LIMIT 1") suspend fun latestSession(): CuppingSession?
    @Query("SELECT * FROM cupping_coffees WHERE sessionId = :sessionId ORDER BY position") suspend fun coffeesOf(sessionId: String): List<CuppingCoffee>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertSession(item: CuppingSession)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertSessions(items: List<CuppingSession>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertCoffees(items: List<CuppingCoffee>)
    @Query("DELETE FROM cupping_coffees WHERE sessionId = :sessionId") suspend fun deleteCoffeesOf(sessionId: String)
    @Query("DELETE FROM cupping_sessions WHERE id = :id") suspend fun deleteSession(id: String)
    @Query("DELETE FROM cupping_coffees") suspend fun clearCoffees()
    @Query("DELETE FROM cupping_sessions") suspend fun clearSessions()

    /** Writes a session and its coffees as one unit. Coffees removed in the UI disappear here too. */
    @Transaction
    suspend fun saveSession(session: CuppingSession, coffees: List<CuppingCoffee>) {
        upsertSession(session)
        deleteCoffeesOf(session.id)
        insertCoffees(coffees.mapIndexed { i, c -> c.copy(sessionId = session.id, position = i) })
    }

    @Query("SELECT * FROM lab_recipes ORDER BY timestamp DESC") fun observeLab(): Flow<List<LabRecipe>>
    @Query("SELECT * FROM lab_recipes") suspend fun allLab(): List<LabRecipe>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertLab(item: LabRecipe)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertLabAll(items: List<LabRecipe>)
    @Query("DELETE FROM lab_recipes WHERE id = :id") suspend fun deleteLab(id: String)
    @Query("DELETE FROM lab_recipes") suspend fun clearLab()
}

/** 1 to 2: adds the Barista Trainer history. Existing coffees, recipes and brews are untouched. */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `training_events` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`createdAt` INTEGER NOT NULL, `kind` TEXT NOT NULL, `refId` TEXT NOT NULL, `skill` TEXT NOT NULL, " +
                "`correct` INTEGER NOT NULL, `total` INTEGER NOT NULL, `durationS` INTEGER NOT NULL, `xp` INTEGER NOT NULL, " +
                "`passed` INTEGER NOT NULL, `breakdown` TEXT NOT NULL)"
        )
    }
}

/** 2 to 3: adds Toulouse Cupping sessions, their coffees and the Brewing Lab notebook. Nothing else changes. */
val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        CUPPING_SCHEMA.forEach(db::execSQL)
    }
}

/** 3 to 4: water, mineral concentrates and champion origin on recipes and brews, microns per click on grinders. */
val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        WATER_COLUMNS.forEach(db::execSQL)
    }
}

internal val WATER_COLUMNS = listOf(
    "ALTER TABLE `recipes` ADD COLUMN `waterId` TEXT",
    "ALTER TABLE `recipes` ADD COLUMN `waterNote` TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE `recipes` ADD COLUMN `additivesJson` TEXT NOT NULL DEFAULT '[]'",
    "ALTER TABLE `recipes` ADD COLUMN `championId` TEXT",
    "ALTER TABLE `brews` ADD COLUMN `waterId` TEXT",
    "ALTER TABLE `brews` ADD COLUMN `waterNote` TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE `brews` ADD COLUMN `additivesJson` TEXT NOT NULL DEFAULT '[]'",
    "ALTER TABLE `grinders` ADD COLUMN `micronsPerStep` REAL",
)

internal val CUPPING_SCHEMA = listOf(
    "CREATE TABLE IF NOT EXISTS `cupping_sessions` (`id` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `name` TEXT NOT NULL, `location` TEXT NOT NULL, `dateIso` TEXT NOT NULL, `originNotes` TEXT NOT NULL, `roasterNotes` TEXT NOT NULL, `importerNotes` TEXT NOT NULL, PRIMARY KEY(`id`))",
    "CREATE TABLE IF NOT EXISTS `cupping_coffees` (`id` TEXT NOT NULL, `sessionId` TEXT NOT NULL, `position` INTEGER NOT NULL, `name` TEXT NOT NULL, `isLocked` INTEGER NOT NULL, `isFavorite` INTEGER NOT NULL, `timestamp` INTEGER NOT NULL, `process` TEXT NOT NULL, `fragranceScore` REAL NOT NULL, `fragranceNotes` TEXT NOT NULL, `flavorScore` REAL NOT NULL, `flavorNotes` TEXT NOT NULL, `aftertasteScore` REAL NOT NULL, `acidityScore` REAL NOT NULL, `acidityType` TEXT NOT NULL, `acidityIntensity` TEXT NOT NULL, `bodyScore` REAL NOT NULL, `bodyType` TEXT NOT NULL, `balanceScore` REAL NOT NULL, `comments` TEXT NOT NULL, PRIMARY KEY(`id`), FOREIGN KEY(`sessionId`) REFERENCES `cupping_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
    "CREATE INDEX IF NOT EXISTS `index_cupping_coffees_sessionId` ON `cupping_coffees` (`sessionId`)",
    "CREATE TABLE IF NOT EXISTS `lab_recipes` (`id` TEXT NOT NULL, `timestamp` INTEGER NOT NULL, `method` TEXT NOT NULL, `coffeeWeight` REAL NOT NULL, `ratio` REAL NOT NULL, `waterWeight` INTEGER NOT NULL, `grindSize` TEXT NOT NULL, `totalTime` INTEGER NOT NULL, `rating` REAL NOT NULL, `notes` TEXT NOT NULL, PRIMARY KEY(`id`))",
)

@Database(
    entities = [
        Coffee::class, Recipe::class, Brew::class, Grinder::class, TrainingEvent::class,
        CuppingSession::class, CuppingCoffee::class, LabRecipe::class,
    ],
    version = 4,
    exportSchema = false,
)
@TypeConverters(CuppingConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun coffees(): CoffeeDao
    abstract fun recipes(): RecipeDao
    abstract fun brews(): BrewDao
    abstract fun grinders(): GrinderDao
    abstract fun training(): TrainingDao
    abstract fun cupping(): CuppingDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "mountainfold.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                .build()
    }
}
