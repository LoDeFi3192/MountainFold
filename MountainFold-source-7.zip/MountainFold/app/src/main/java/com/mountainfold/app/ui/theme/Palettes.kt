package com.mountainfold.app.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import com.mountainfold.app.core.model.Palette
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * Fallback colour system used when Dynamic Color is off or unavailable.
 * Tonal palettes are built in CIE LCh so that "tone" means perceptual lightness,
 * the same idea Material You uses. Presets stay deliberately quiet.
 */
object Palettes {

    private data class Seed(
        val primaryHue: Double, val primaryChroma: Double,
        val secondaryHue: Double, val secondaryChroma: Double,
        val tertiaryHue: Double, val tertiaryChroma: Double,
        val neutralHue: Double, val neutralChroma: Double,
    )

    private fun seed(p: Palette) = when (p) {
        Palette.COFFEE -> Seed(58.0, 40.0, 68.0, 16.0, 115.0, 26.0, 62.0, 6.0)
        Palette.MOUNTAIN -> Seed(255.0, 30.0, 245.0, 12.0, 60.0, 30.0, 255.0, 5.0)
        Palette.FOREST -> Seed(150.0, 34.0, 140.0, 13.0, 85.0, 28.0, 140.0, 5.0)
        Palette.STONE -> Seed(80.0, 9.0, 80.0, 6.0, 45.0, 22.0, 80.0, 3.0)
        // Fixed palettes: never read, scheme() returns their exact tokens first.
        Palette.TOULOUSE, Palette.COBALT, Palette.SAGE -> Seed(58.0, 40.0, 68.0, 16.0, 115.0, 26.0, 62.0, 6.0)
    }

    fun scheme(palette: Palette, dark: Boolean): ColorScheme {
        when (palette) {
            Palette.TOULOUSE -> return toulouse(dark)
            Palette.COBALT -> return cobalt(dark)
            Palette.SAGE -> return sage(dark)
            else -> Unit
        }
        val s = seed(palette)
        fun p(t: Double) = lch(t, s.primaryChroma, s.primaryHue)
        fun sec(t: Double) = lch(t, s.secondaryChroma, s.secondaryHue)
        fun ter(t: Double) = lch(t, s.tertiaryChroma, s.tertiaryHue)
        fun n(t: Double) = lch(t, s.neutralChroma, s.neutralHue)
        fun nv(t: Double) = lch(t, s.neutralChroma * 2.0 + 2.0, s.neutralHue)
        fun err(t: Double) = lch(t, 60.0, 30.0)
        return if (!dark) lightColorScheme(
            primary = p(38.0), onPrimary = p(100.0), primaryContainer = p(90.0), onPrimaryContainer = p(14.0),
            secondary = sec(40.0), onSecondary = sec(100.0), secondaryContainer = sec(90.0), onSecondaryContainer = sec(14.0),
            tertiary = ter(40.0), onTertiary = ter(100.0), tertiaryContainer = ter(90.0), onTertiaryContainer = ter(14.0),
            error = err(40.0), onError = err(100.0), errorContainer = err(90.0), onErrorContainer = err(14.0),
            background = n(98.0), onBackground = n(10.0), surface = n(98.0), onSurface = n(10.0),
            surfaceVariant = nv(90.0), onSurfaceVariant = nv(30.0), outline = nv(48.0), outlineVariant = nv(80.0),
            inverseSurface = n(20.0), inverseOnSurface = n(95.0), inversePrimary = p(80.0), surfaceTint = p(38.0),
            surfaceDim = n(87.0), surfaceBright = n(98.0), surfaceContainerLowest = n(100.0),
            surfaceContainerLow = n(96.0), surfaceContainer = n(94.0), surfaceContainerHigh = n(92.0),
            surfaceContainerHighest = n(90.0), scrim = Color.Black,
        ) else darkColorScheme(
            primary = p(82.0), onPrimary = p(20.0), primaryContainer = p(30.0), onPrimaryContainer = p(92.0),
            secondary = sec(80.0), onSecondary = sec(20.0), secondaryContainer = sec(30.0), onSecondaryContainer = sec(90.0),
            tertiary = ter(80.0), onTertiary = ter(20.0), tertiaryContainer = ter(30.0), onTertiaryContainer = ter(90.0),
            error = err(80.0), onError = err(20.0), errorContainer = err(30.0), onErrorContainer = err(90.0),
            background = n(5.0), onBackground = n(92.0), surface = n(5.0), onSurface = n(92.0),
            surfaceVariant = nv(28.0), onSurfaceVariant = nv(82.0), outline = nv(60.0), outlineVariant = nv(28.0),
            inverseSurface = n(90.0), inverseOnSurface = n(20.0), inversePrimary = p(38.0), surfaceTint = p(82.0),
            surfaceDim = n(5.0), surfaceBright = n(24.0), surfaceContainerLowest = n(3.0),
            surfaceContainerLow = n(9.0), surfaceContainer = n(12.0), surfaceContainerHigh = n(16.0),
            surfaceContainerHighest = n(21.0), scrim = Color.Black,
        )
    }

    /** The exact light "Coffee" and dark "Espresso" tokens of the Toulouse Cupping web app. */
    private fun toulouse(dark: Boolean): ColorScheme {
        fun c(hex: Long) = Color(hex)
        return if (!dark) lightColorScheme(
            primary = c(0xFF8D6E4D), onPrimary = c(0xFFFFFFFF), primaryContainer = c(0xFFFFDCBE), onPrimaryContainer = c(0xFF2C1600),
            secondary = c(0xFF77574E), onSecondary = c(0xFFFFFFFF), secondaryContainer = c(0xFFFFDBD1), onSecondaryContainer = c(0xFF2C150F),
            tertiary = c(0xFF6C5D2F), onTertiary = c(0xFFFFFFFF), tertiaryContainer = c(0xFFF5E1A6), onTertiaryContainer = c(0xFF221B00),
            error = c(0xFFBA1A1A), onError = c(0xFFFFFFFF), errorContainer = c(0xFFFFDAD6), onErrorContainer = c(0xFF410002),
            background = c(0xFFFFF8F6), onBackground = c(0xFF201A18), surface = c(0xFFFFF8F6), onSurface = c(0xFF201A18),
            surfaceVariant = c(0xFFF4DED4), onSurfaceVariant = c(0xFF52433D), outline = c(0xFF85736D), outlineVariant = c(0xFFD7C2B8),
            inverseSurface = c(0xFF362F2C), inverseOnSurface = c(0xFFFBEEE9), inversePrimary = c(0xFFFFB77C), surfaceTint = c(0xFF8D6E4D),
            surfaceDim = c(0xFFE8D7D1), surfaceBright = c(0xFFFFF8F6), surfaceContainerLowest = c(0xFFFFFFFF),
            surfaceContainerLow = c(0xFFFFF1EC), surfaceContainer = c(0xFFFCECE6), surfaceContainerHigh = c(0xFFF6E6E0),
            surfaceContainerHighest = c(0xFFF0E1DB), scrim = Color.Black,
        ) else darkColorScheme(
            primary = c(0xFFFFB77C), onPrimary = c(0xFF50381A), primaryContainer = c(0xFF6E5231), onPrimaryContainer = c(0xFFFFDCBE),
            secondary = c(0xFFE7BDB2), onSecondary = c(0xFF442922), secondaryContainer = c(0xFF5D3F38), onSecondaryContainer = c(0xFFFFDBD1),
            tertiary = c(0xFFD8C58D), onTertiary = c(0xFF3B2F06), tertiaryContainer = c(0xFF53461A), onTertiaryContainer = c(0xFFF5E1A6),
            error = c(0xFFFFB4AB), onError = c(0xFF690005), errorContainer = c(0xFF93000A), onErrorContainer = c(0xFFFFDAD6),
            background = c(0xFF18120F), onBackground = c(0xFFECE0DB), surface = c(0xFF18120F), onSurface = c(0xFFECE0DB),
            surfaceVariant = c(0xFF52433D), onSurfaceVariant = c(0xFFD7C2B8), outline = c(0xFFA08C85), outlineVariant = c(0xFF52433D),
            inverseSurface = c(0xFFECE0DB), inverseOnSurface = c(0xFF362F2C), inversePrimary = c(0xFF8D6E4D), surfaceTint = c(0xFFFFB77C),
            surfaceDim = c(0xFF18120F), surfaceBright = c(0xFF3F3734), surfaceContainerLowest = c(0xFF0F0A07),
            surfaceContainerLow = c(0xFF1D1714), surfaceContainer = c(0xFF211B18), surfaceContainerHigh = c(0xFF2B2522),
            surfaceContainerHighest = c(0xFF362F2C), scrim = Color.Black,
        )
    }

    /** Cobalt: Warm beige #EDECE6 base, cobalt blue #1546D9 highlights, sun yellow #F9B318 contrast (selected states, navigation). Text pairs checked at WCAG AA by PaletteContrastTest. */
    private fun cobalt(dark: Boolean): ColorScheme {
        fun c(hex: Long) = Color(hex)
        return if (!dark) lightColorScheme(
            primary = c(0xFF1546D9), onPrimary = c(0xFFFFFFFF), primaryContainer = c(0xFFD9E2FD), onPrimaryContainer = c(0xFF00255D),
            secondary = c(0xFF835C00), onSecondary = c(0xFFFFFFFF), secondaryContainer = c(0xFFF9B318),
            onSecondaryContainer = c(0xFF2B1D00), tertiary = c(0xFF133E8C), onTertiary = c(0xFFFFFFFF),
            tertiaryContainer = c(0xFFFEDEB2), onTertiaryContainer = c(0xFF302102), error = c(0xFFBA1A1A), onError = c(0xFFFFFFFF),
            errorContainer = c(0xFFFFDAD6), onErrorContainer = c(0xFF410002), background = c(0xFFEDECE6),
            onBackground = c(0xFF1C1C17), surface = c(0xFFEDECE6), onSurface = c(0xFF1C1C17), surfaceVariant = c(0xFFDFDDD2),
            onSurfaceVariant = c(0xFF48473E), outline = c(0xFF79776D), outlineVariant = c(0xFFC6C4B9),
            inverseSurface = c(0xFF31302C), inverseOnSurface = c(0xFFF2F1EB), inversePrimary = c(0xFFAFC6FB),
            surfaceDim = c(0xFFD3D2CC), surfaceBright = c(0xFFF5F4EE), surfaceContainerLowest = c(0xFFFAF9F3),
            surfaceContainerLow = c(0xFFE6E5DF), surfaceContainer = c(0xFFE1E0DA), surfaceContainerHigh = c(0xFFDBDAD4),
            surfaceContainerHighest = c(0xFFD5D4CF), surfaceTint = c(0xFF1546D9), scrim = Color.Black,
        ) else darkColorScheme(
            primary = c(0xFFA6C1FC), onPrimary = c(0xFF092962), primaryContainer = c(0xFF1546D9), onPrimaryContainer = c(0xFFE8EEFE),
            secondary = c(0xFFF9B318), onSecondary = c(0xFF302102), secondaryContainer = c(0xFFF9B318),
            onSecondaryContainer = c(0xFF2B1D00), tertiary = c(0xFFFEC972), onTertiary = c(0xFF412D02),
            tertiaryContainer = c(0xFF5F4101), onTertiaryContainer = c(0xFFFEE4C2), error = c(0xFFFFB4AB), onError = c(0xFF690005),
            errorContainer = c(0xFF93000A), onErrorContainer = c(0xFFFFDAD6), background = c(0xFF161611),
            onBackground = c(0xFFE9E8E2), surface = c(0xFF161611), onSurface = c(0xFFE9E8E2), surfaceVariant = c(0xFF48473E),
            onSurfaceVariant = c(0xFFC9C7BB), outline = c(0xFF939186), outlineVariant = c(0xFF48473E),
            inverseSurface = c(0xFFE4E3DD), inverseOnSurface = c(0xFF31302C), inversePrimary = c(0xFF1546D9),
            surfaceDim = c(0xFF161611), surfaceBright = c(0xFF3C3B37), surfaceContainerLowest = c(0xFF0F0E07),
            surfaceContainerLow = c(0xFF1C1C17), surfaceContainer = c(0xFF22221D), surfaceContainerHigh = c(0xFF2B2A26),
            surfaceContainerHighest = c(0xFF363530), surfaceTint = c(0xFFA6C1FC), scrim = Color.Black,
        )
    }

    /** Sage: Muted sage grey #A5A79B base, warm cream #E8D2B5 highlights, deep burgundy #590907 contrast (buttons, accents). Containers step lighter than the mid-tone base so text stays above 4.5:1. Text pairs checked at WCAG AA by PaletteContrastTest. */
    private fun sage(dark: Boolean): ColorScheme {
        fun c(hex: Long) = Color(hex)
        return if (!dark) lightColorScheme(
            primary = c(0xFF590907), onPrimary = c(0xFFE8D2B5), primaryContainer = c(0xFFE8D2B5), onPrimaryContainer = c(0xFF590907),
            secondary = c(0xFF6B1D1D), onSecondary = c(0xFFE8D2B5), secondaryContainer = c(0xFFE8D2B5),
            onSecondaryContainer = c(0xFF500005), tertiary = c(0xFF661819), onTertiary = c(0xFFFFFFFF),
            tertiaryContainer = c(0xFFFDD3CE), onTertiaryContainer = c(0xFF480101), error = c(0xFF741008), onError = c(0xFFFFFFFF),
            errorContainer = c(0xFFF7D7D2), onErrorContainer = c(0xFF410002), background = c(0xFFA5A79B),
            onBackground = c(0xFF1B1C18), surface = c(0xFFA5A79B), onSurface = c(0xFF1B1C18), surfaceVariant = c(0xFFB5B8A7),
            onSurfaceVariant = c(0xFF34352E), outline = c(0xFF545648), outlineVariant = c(0xFF8A8D7D),
            inverseSurface = c(0xFF30312C), inverseOnSurface = c(0xFFEDEFE2), inversePrimary = c(0xFFE8D2B5),
            surfaceDim = c(0xFF95978B), surfaceBright = c(0xFFBBBDB0), surfaceContainerLowest = c(0xFFC6C8BB),
            surfaceContainerLow = c(0xFFADAFA3), surfaceContainer = c(0xFFB2B4A8), surfaceContainerHigh = c(0xFFB8BAAE),
            surfaceContainerHighest = c(0xFFBDBFB3), surfaceTint = c(0xFF590907), scrim = Color.Black,
        ) else darkColorScheme(
            primary = c(0xFFE8D2B5), onPrimary = c(0xFF590907), primaryContainer = c(0xFF590907), onPrimaryContainer = c(0xFFE8D2B5),
            secondary = c(0xFFA5A79B), onSecondary = c(0xFF1F201C), secondaryContainer = c(0xFFA5A79B),
            onSecondaryContainer = c(0xFF1B1C18), tertiary = c(0xFFECA49C), onTertiary = c(0xFF55060B),
            tertiaryContainer = c(0xFF712221), onTertiaryContainer = c(0xFFFEDAD6), error = c(0xFFFFB4AB), onError = c(0xFF690005),
            errorContainer = c(0xFF93000A), onErrorContainer = c(0xFFFFDAD6), background = c(0xFF171814),
            onBackground = c(0xFFE4E6DA), surface = c(0xFF171814), onSurface = c(0xFFE4E6DA), surfaceVariant = c(0xFF42433B),
            onSurfaceVariant = c(0xFFC5C8B7), outline = c(0xFF8A8D7D), outlineVariant = c(0xFF42433B),
            inverseSurface = c(0xFFE2E4D7), inverseOnSurface = c(0xFF30312C), inversePrimary = c(0xFF590907),
            surfaceDim = c(0xFF171814), surfaceBright = c(0xFF3B3C37), surfaceContainerLowest = c(0xFF11110C),
            surfaceContainerLow = c(0xFF1D1E1A), surfaceContainer = c(0xFF232420), surfaceContainerHigh = c(0xFF2C2C28),
            surfaceContainerHighest = c(0xFF373733), surfaceTint = c(0xFFE8D2B5), scrim = Color.Black,
        )
    }

    /** CIE LCh(ab) to sRGB. Chroma is reduced until the colour fits the gamut, keeping lightness intact. */
    fun lch(l: Double, c: Double, hDeg: Double): Color {
        var chroma = c
        repeat(40) {
            val rgb = labToLinearRgb(l, chroma * cos(Math.toRadians(hDeg)), chroma * sin(Math.toRadians(hDeg)))
            if (rgb.all { it >= -0.0005 && it <= 1.0005 } || chroma < 0.5) {
                return Color(gamma(rgb[0]), gamma(rgb[1]), gamma(rgb[2]))
            }
            chroma *= 0.92
        }
        val rgb = labToLinearRgb(l, 0.0, 0.0)
        return Color(gamma(rgb[0]), gamma(rgb[1]), gamma(rgb[2]))
    }

    private fun labToLinearRgb(l: Double, a: Double, b: Double): DoubleArray {
        val fy = (l + 16.0) / 116.0
        val fx = fy + a / 500.0
        val fz = fy - b / 200.0
        fun inv(t: Double) = if (t * t * t > 0.008856) t * t * t else (116.0 * t - 16.0) / 903.3
        val x = 0.95047 * inv(fx)
        val y = inv(fy)
        val z = 1.08883 * inv(fz)
        return doubleArrayOf(
            3.2404542 * x - 1.5371385 * y - 0.4985314 * z,
            -0.9692660 * x + 1.8760108 * y + 0.0415560 * z,
            0.0556434 * x - 0.2040259 * y + 1.0572252 * z,
        )
    }

    private fun gamma(v: Double): Float {
        val c = v.coerceIn(0.0, 1.0)
        return (if (c <= 0.0031308) 12.92 * c else 1.055 * c.pow(1.0 / 2.4) - 0.055).toFloat()
    }
}
