package com.mountainfold.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.CompareArrows
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Troubleshoot
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mountainfold.app.R
import com.mountainfold.app.core.engine.CoffeeEngine
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.data.db.Brew
import com.mountainfold.app.data.db.Recipe
import com.mountainfold.app.data.prefs.Settings
import com.mountainfold.app.ui.LocalUnits
import com.mountainfold.app.ui.MainViewModel
import com.mountainfold.app.ui.Overlay
import com.mountainfold.app.ui.Pane
import com.mountainfold.app.ui.Tab
import com.mountainfold.app.ui.Units
import com.mountainfold.app.ui.components.BigButton
import com.mountainfold.app.ui.components.BrewUi
import com.mountainfold.app.ui.components.ListRow
import com.mountainfold.app.ui.components.SectionTitle
import com.mountainfold.app.ui.components.Stat
import com.mountainfold.app.ui.components.TwoPane
import com.mountainfold.app.ui.components.methodLabel
import com.mountainfold.app.ui.components.rememberBrewUi
import java.text.DateFormat
import java.util.Calendar
import java.util.Date

@Composable
fun formatDate(millis: Long, withTime: Boolean = true): String {
    LocalConfiguration.current
    val locale = LocalContext.current.resources.configuration.locales[0]
    val fmt = remember(locale, withTime) {
        if (withTime) DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, locale)
        else DateFormat.getDateInstance(DateFormat.MEDIUM, locale)
    }
    return fmt.format(Date(millis))
}

@Composable
fun daysText(n: Int): String = if (n == 1) stringResource(R.string.day_one) else stringResource(R.string.days_count, n)

fun brewTimeText(b: Brew): String =
    if (BrewMethod.fromKey(b.method).isEspresso) "${CoffeeEngine.formatTenths(b.timeMs)} s" else CoffeeEngine.formatClock(b.timeMs / 1000)

fun recipeTimeText(r: Recipe): String =
    if (BrewMethod.fromKey(r.method).isEspresso) "${r.targetTimeS} s" else CoffeeEngine.formatClock(r.targetTimeS.toLong())

fun recipeSummary(r: Recipe, units: Units): String =
    "${BrewMethod.fromKey(r.method).label} · ${units.w(r.doseG)} → ${units.w(r.waterG)} · " +
        "${CoffeeEngine.formatRatio(CoffeeEngine.ratio(r.waterG, r.doseG))} · ${recipeTimeText(r)}"

fun brewSummary(b: Brew, units: Units): String =
    "${BrewMethod.fromKey(b.method).label} · ${units.w(b.doseG)} → ${units.w(b.waterG)} · ${brewTimeText(b)}"

@Composable
fun HomeScreen(vm: MainViewModel, settings: Settings, wide: Boolean, hinge: HingeInfo?) {
    val ui = rememberBrewUi(vm.session)
    if (wide) {
        TwoPane(
            hinge = hinge,
            left = {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 20.dp)) {
                    Greeting(vm)
                    Spacer(Modifier.height(28.dp))
                    Hero(vm, ui, large = true)
                    Spacer(Modifier.height(24.dp))
                    Tools(vm)
                }
            },
            right = {
                Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 20.dp)) {
                        RecentBrews(vm, limit = 5)
                        Favorites(vm)
                    }
                }
            },
        )
    } else {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 12.dp)) {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Greeting(vm)
                Spacer(Modifier.height(20.dp))
                Hero(vm, ui, large = false)
                Spacer(Modifier.height(20.dp))
                Tools(vm)
            }
            Column(Modifier.padding(horizontal = 4.dp)) {
                RecentBrews(vm, limit = 3)
                Favorites(vm)
            }
        }
    }
}

@Composable
private fun Greeting(vm: MainViewModel) {
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    Row(verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            Text(
                stringResource(
                    when {
                        hour < 12 -> R.string.good_morning
                        hour < 18 -> R.string.good_afternoon
                        else -> R.string.good_evening
                    }
                ),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(stringResource(R.string.ready_to_brew), style = MaterialTheme.typography.displaySmall)
        }
        IconButton(onClick = { vm.open(Overlay.Settings) }) {
            Icon(Icons.Rounded.Settings, contentDescription = stringResource(R.string.settings))
        }
    }
}

/** The closed-mode promise: coffee, method, numbers and one BREW button. */
@Composable
private fun Hero(vm: MainViewModel, ui: BrewUi?, large: Boolean) {
    val units = LocalUnits.current
    Surface(color = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer, shape = MaterialTheme.shapes.extraLarge, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(24.dp)) {
            if (ui == null) {
                Text(stringResource(R.string.no_recipe_title), style = MaterialTheme.typography.headlineMedium)
                Text(stringResource(R.string.no_recipe_body), style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(16.dp))
                BigButton(stringResource(R.string.choose_recipe), onClick = { vm.selectTab(Tab.RECIPES) }, modifier = Modifier.fillMaxWidth(), primary = true)
                return@Column
            }
            val r = ui.recipe
            Text(
                r.coffeeName.ifBlank { r.name },
                style = if (large) MaterialTheme.typography.displaySmall else MaterialTheme.typography.headlineLarge,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.clickable(onClickLabel = stringResource(R.string.tab_coffee)) { vm.selectTab(Tab.COFFEE) },
            )
            Text(
                if (r.coffeeName.isBlank()) methodLabel(r.method) else "${methodLabel(r.method)} · ${r.name}",
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(20.dp))
            val value = MaterialTheme.typography.headlineMedium
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                HeroStat(stringResource(R.string.coffee), units.w(r.doseG), value)
                HeroStat(stringResource(if (ui.espresso) R.string.yield_label else R.string.water), units.w(r.waterG), value)
                HeroStat(stringResource(R.string.ratio), CoffeeEngine.formatRatio(ui.ratio), value)
            }
            Spacer(Modifier.height(20.dp))
            BigButton(
                if (ui.started) stringResource(R.string.back_to_brew, ui.timeText) else stringResource(R.string.brew),
                onClick = { vm.selectTab(Tab.BREW) },
                modifier = Modifier.fillMaxWidth(),
                icon = Icons.Rounded.PlayArrow,
                primary = true,
                minHeight = 72.dp,
            )
        }
    }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        BigButton(stringResource(R.string.tab_recipes), onClick = { vm.selectTab(Tab.RECIPES) }, modifier = Modifier.weight(1f), minHeight = 56.dp)
        BigButton(stringResource(R.string.tab_history), onClick = { vm.selectTab(Tab.HISTORY) }, modifier = Modifier.weight(1f), minHeight = 56.dp)
    }
}

@Composable
private fun HeroStat(label: String, value: String, style: androidx.compose.ui.text.TextStyle) {
    Column {
        Text(label.uppercase(), style = MaterialTheme.typography.labelSmall, maxLines = 1)
        Text(value, style = style, maxLines = 1)
    }
}

@Composable
private fun Tools(vm: MainViewModel) {
    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        Tool(Icons.Rounded.Calculate, stringResource(R.string.calculator), Modifier.weight(1f)) { vm.open(Overlay.Calculator) }
        Tool(Icons.Rounded.Troubleshoot, stringResource(R.string.diagnose), Modifier.weight(1f)) { vm.diagnoseLatest() }
        Tool(Icons.Rounded.Tune, stringResource(R.string.grind), Modifier.weight(1f)) { vm.open(Overlay.GrindAdvisor) }
        Tool(Icons.AutoMirrored.Rounded.CompareArrows, stringResource(R.string.compare), Modifier.weight(1f)) { vm.open(Overlay.Compare) }
        Tool(Icons.Rounded.WaterDrop, stringResource(R.string.water), Modifier.weight(1f)) { vm.open(Overlay.Water) }
    }
}

@Composable
private fun Tool(icon: ImageVector, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(MaterialTheme.shapes.large).clickable(role = Role.Button, onClick = onClick).heightIn(min = 72.dp).padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(6.dp))
        // Five tools share the row: the label shrinks on one line instead of breaking a word.
        androidx.compose.foundation.text.BasicText(
            label,
            style = MaterialTheme.typography.labelMedium.copy(color = androidx.compose.material3.LocalContentColor.current, textAlign = TextAlign.Center),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            autoSize = androidx.compose.foundation.text.TextAutoSize.StepBased(minFontSize = 8.sp, maxFontSize = MaterialTheme.typography.labelMedium.fontSize, stepSize = 0.5.sp),
        )
    }
}

@Composable
private fun RecentBrews(vm: MainViewModel, limit: Int) {
    val brews by vm.brews.collectAsStateWithLifecycle()
    val units = LocalUnits.current
    HomeOpportunity(vm, brews)
    SectionTitle(stringResource(R.string.recent_brews), Modifier.padding(horizontal = 16.dp))
    if (brews.isEmpty()) {
        Text(
            stringResource(R.string.no_brews_yet),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )
        return
    }
    brews.take(limit).forEach { b ->
        ListRow(
            title = b.coffeeName.ifBlank { b.recipeName },
            subtitle = "${brewSummary(b, units)}\n${formatDate(b.createdAt)}",
            trailing = if (b.rating > 0) ({ RatingBadge(b.rating) }) else null,
            onClick = { vm.selectTab(Tab.HISTORY); vm.historySel = b.id },
        )
    }
}

@Composable
fun RatingBadge(rating: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Rounded.Star, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        Text(rating.toString(), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 2.dp))
    }
}

@Composable
private fun Favorites(vm: MainViewModel) {
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    val units = LocalUnits.current
    val favorites = recipes.filter { it.favorite }
    SectionTitle(stringResource(R.string.favorite_recipes), Modifier.padding(horizontal = 16.dp))
    if (favorites.isEmpty()) {
        Text(
            stringResource(R.string.no_favorites),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )
        return
    }
    favorites.take(6).forEach { r ->
        ListRow(
            title = r.name,
            subtitle = recipeSummary(r, units),
            trailing = {
                FilledTonalIconButton(onClick = { vm.brew(r) }, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = stringResource(R.string.brew_this, r.name))
                }
            },
            onClick = { vm.selectTab(Tab.RECIPES); vm.recipePane = Pane.View(r.id) },
        )
    }
}
