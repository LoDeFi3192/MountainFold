package com.mountainfold.app.ui.screens

import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MoreTime
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mountainfold.app.R
import com.mountainfold.app.core.engine.CoffeeEngine
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.model.FlexLayout
import com.mountainfold.app.data.prefs.Settings
import com.mountainfold.app.ui.LocalUnits
import com.mountainfold.app.ui.MainViewModel
import com.mountainfold.app.ui.Tab
import com.mountainfold.app.ui.components.BigButton
import com.mountainfold.app.ui.components.BrewUi
import com.mountainfold.app.ui.components.ConfirmDialog
import com.mountainfold.app.ui.components.EmptyState
import com.mountainfold.app.ui.components.FlexSplit
import com.mountainfold.app.ui.components.NumField
import com.mountainfold.app.ui.components.SectionTitle
import com.mountainfold.app.ui.components.Stat
import com.mountainfold.app.ui.components.StepList
import com.mountainfold.app.ui.components.TimerText
import com.mountainfold.app.ui.components.TwoPane
import com.mountainfold.app.ui.components.methodLabel
import com.mountainfold.app.ui.components.rememberBrewUi

@Composable
fun reducedMotion(): Boolean {
    val context = LocalContext.current
    return remember {
        android.provider.Settings.Global.getFloat(
            context.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f,
        ) == 0f
    }
}

/** Launches the system speech recogniser. Returns null when the device has none, so no dead button shows. */
@Composable
fun rememberVoiceLauncher(onText: (String) -> Unit): (() -> Unit)? {
    val context = LocalContext.current
    val intent = remember {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
    }
    val available = remember { runCatching { intent.resolveActivity(context.packageManager) != null }.getOrDefault(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let(onText)
    }
    return if (available) ({ runCatching { launcher.launch(intent) }; Unit }) else null
}

@Composable
fun BrewScreen(vm: MainViewModel, settings: Settings, wide: Boolean, hinge: HingeInfo?) {
    val ui = rememberBrewUi(vm.session)
    if (ui == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            EmptyState(
                Icons.AutoMirrored.Rounded.MenuBook,
                stringResource(R.string.no_recipe_title),
                stringResource(R.string.no_recipe_body),
                actionLabel = stringResource(R.string.choose_recipe),
                onAction = { vm.selectTab(Tab.RECIPES) },
            )
        }
        return
    }
    if (wide) BrewOpen(vm, ui, settings, hinge) else BrewClosed(vm, ui, settings)
}

// ---------------------------------------------------------------------------------------------
// CLOSED: quick assistant
// ---------------------------------------------------------------------------------------------

@Composable
private fun BrewClosed(vm: MainViewModel, ui: BrewUi, settings: Settings) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        if (maxWidth > maxHeight) {
            Row(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    BrewHeader(vm, ui)
                    TimerBlock(ui, 64.sp)
                    if (ui.espresso) ShotStats(vm, ui) else CurrentStepBlock(ui)
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    WeightBlock(vm, ui, settings)
                    BrewControls(vm, ui, settings, buttonHeight = 56.dp)
                }
            }
        } else {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                BrewHeader(vm, ui)
                TimerBlock(ui, 84.sp)
                if (ui.espresso) ShotStats(vm, ui) else CurrentStepBlock(ui)
                WeightBlock(vm, ui, settings)
                BrewControls(vm, ui, settings, buttonHeight = 64.dp)
                Laps(ui)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// OPEN: workstation. LEFT = KNOW, RIGHT = DO
// ---------------------------------------------------------------------------------------------

@Composable
private fun BrewOpen(vm: MainViewModel, ui: BrewUi, settings: Settings, hinge: HingeInfo?) {
    val units = LocalUnits.current
    TwoPane(
        hinge = hinge,
        left = {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 20.dp)) {
                BrewHeader(vm, ui, large = true)
                Spacer(Modifier.height(20.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Stat(stringResource(R.string.dose), units.w(ui.recipe.doseG))
                    Stat(stringResource(if (ui.espresso) R.string.yield_label else R.string.water), units.w(ui.recipe.waterG))
                    Stat(stringResource(R.string.ratio), CoffeeEngine.formatRatio(ui.ratio))
                    Stat(stringResource(R.string.temperature), units.t(ui.recipe.tempC))
                    if (ui.recipe.grind.isNotBlank()) Stat(stringResource(R.string.grind), ui.recipe.grind)
                    Stat(stringResource(R.string.target), ui.targetText)
                    ui.recipe.pressureBar?.let { Stat(stringResource(R.string.pressure), "${CoffeeEngine.formatNumber(it)} bar") }
                }
                MicronsText(vm, settings, ui.recipe.grind, Modifier.padding(top = 10.dp))
                SectionTitle(stringResource(R.string.steps))
                StepList(ui.steps, ui.stepIndex, ui.recipe.targetTimeS, started = ui.started)
                if (ui.recipe.notes.isNotBlank()) {
                    SectionTitle(stringResource(R.string.notes))
                    Text(ui.recipe.notes, style = MaterialTheme.typography.bodyLarge)
                }
                WaterBlock(vm, ui.recipe.waterId, ui.recipe.waterNote, ui.recipe.additives)
                SectionTitle(stringResource(R.string.brew_notes))
                OutlinedTextField(
                    value = ui.state.notes,
                    onValueChange = vm.session::setNotes,
                    placeholder = { Text(stringResource(R.string.brew_notes_hint)) },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth(),
                )
                Laps(ui)
            }
        },
        right = {
            Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxSize()) {
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                ) {
                    TimerBlock(ui, 120.sp)
                    if (ui.espresso) ShotStats(vm, ui) else CurrentStepBlock(ui)
                    WeightBlock(vm, ui, settings)
                    BrewControls(vm, ui, settings, buttonHeight = 72.dp)
                }
            }
        },
    )
}

// ---------------------------------------------------------------------------------------------
// Shared brew blocks
// ---------------------------------------------------------------------------------------------

@Composable
private fun BrewHeader(vm: MainViewModel, ui: BrewUi, large: Boolean = false) {
    val units = LocalUnits.current
    var adjust by rememberSaveable { mutableStateOf(false) }
    Row(verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            Text(
                ui.recipe.name,
                style = if (large) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.headlineSmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            val sub = listOf(ui.recipe.coffeeName, methodLabel(ui.recipe.method)).filter { it.isNotBlank() }.joinToString(" · ")
            Text(sub, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (!large) {
                Text(
                    "${units.w(ui.recipe.doseG)} → ${units.w(ui.recipe.waterG)} · ${CoffeeEngine.formatRatio(ui.ratio)}" +
                        (ui.recipe.tempC?.let { " · ${units.t(it)}" } ?: ""),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
        if (!ui.started) {
            IconButton(onClick = { adjust = true }) { Icon(Icons.Rounded.Tune, contentDescription = stringResource(R.string.adjust)) }
        }
        IconButton(onClick = { vm.selectTab(Tab.RECIPES) }) {
            Icon(Icons.AutoMirrored.Rounded.MenuBook, contentDescription = stringResource(R.string.choose_recipe))
        }
    }
    if (adjust) AdjustDialog(vm, ui) { adjust = false }
}

@Composable
private fun AdjustDialog(vm: MainViewModel, ui: BrewUi, onClose: () -> Unit) {
    val units = LocalUnits.current
    var dose by remember { mutableStateOf(units.wValue(ui.recipe.doseG)) }
    var water by remember { mutableStateOf(units.wValue(ui.recipe.waterG)) }
    var temp by remember { mutableStateOf(ui.recipe.tempC?.let(units::tValue).orEmpty()) }
    val d = units.parseW(dose)
    val w = units.parseW(water)
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(stringResource(R.string.adjust)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                NumField(dose, { dose = it }, stringResource(R.string.dose), Modifier.fillMaxWidth(), suffix = units.wLabel)
                NumField(water, { water = it }, stringResource(if (ui.espresso) R.string.yield_label else R.string.water), Modifier.fillMaxWidth(), suffix = units.wLabel)
                NumField(temp, { temp = it }, stringResource(R.string.temperature), Modifier.fillMaxWidth(), suffix = units.tLabel)
                Text(
                    stringResource(R.string.ratio) + "  " + CoffeeEngine.formatRatio(if (d != null && w != null) CoffeeEngine.ratio(w, d) else null),
                    style = MaterialTheme.typography.titleMedium,
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = d != null && w != null && d > 0 && w > 0,
                onClick = {
                    vm.session.adjust(d!!, w!!)
                    vm.session.setTemp(units.parseT(temp))
                    onClose()
                },
            ) { Text(stringResource(R.string.apply)) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun TimerBlock(ui: BrewUi, size: TextUnit) {
    val reduced = reducedMotion()
    val progress by animateFloatAsState(ui.progress, if (reduced) snap() else tween(250), label = "progress")
    Column {
        Row(verticalAlignment = Alignment.Bottom) {
            TimerText(ui.timeText, size)
            if (ui.espresso) {
                Text(" s", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp))
            }
            Spacer(Modifier.weight(1f))
            Text(
                "/ ${ui.targetText}",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 10.dp),
            )
        }
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(8.dp),
            color = if (ui.state.targetReached) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surfaceContainerHighest,
            strokeCap = StrokeCap.Round,
            gapSize = 0.dp,
            drawStopIndicator = {},
        )
    }
}

@Composable
private fun CurrentStepBlock(ui: BrewUi, modifier: Modifier = Modifier) {
    val units = LocalUnits.current
    val reduced = reducedMotion()
    Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = MaterialTheme.shapes.large, modifier = modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text(
                when {
                    !ui.started -> stringResource(R.string.ready_when_you_are)
                    ui.state.targetReached -> stringResource(R.string.target_reached)
                    ui.steps.isEmpty() -> stringResource(R.string.brewing)
                    else -> stringResource(R.string.step_n_of, ui.stepIndex + 1, ui.steps.size)
                }.uppercase(),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.height(6.dp))
            AnimatedContent(
                targetState = ui.stepIndex,
                transitionSpec = {
                    if (reduced) fadeIn(snap()) togetherWith fadeOut(snap())
                    else (fadeIn(tween(180)) + slideInVertically(tween(180)) { it / 4 }) togetherWith fadeOut(tween(90))
                },
                label = "step",
            ) { idx ->
                val step = ui.steps.getOrNull(idx)
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            step?.label ?: methodLabel(ui.recipe.method),
                            style = MaterialTheme.typography.headlineMedium,
                            modifier = Modifier.weight(1f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                        step?.targetWaterG?.let {
                            Text("→ ${units.w(it)}", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                    if (step != null && step.note.isNotBlank()) {
                        Text(step.note, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            val next = ui.next
            Text(
                when {
                    next != null && ui.started ->
                        stringResource(R.string.next_step_in, next.label, CoffeeEngine.formatClock(ui.stepRemainingS))
                    next != null -> stringResource(R.string.next_step_at, next.label, CoffeeEngine.formatClock(next.startS.toLong()))
                    ui.state.targetReached -> stringResource(R.string.log_this_brew)
                    else -> stringResource(R.string.until_target, CoffeeEngine.formatClock(ui.stepRemainingS))
                },
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** Manual scale. With a connected scale the provider reports live weight and the buttons disappear. */
@Composable
private fun WeightBlock(vm: MainViewModel, ui: BrewUi, settings: Settings) {
    val units = LocalUnits.current
    var entry by rememberSaveable { mutableStateOf(false) }
    val target = if (ui.espresso) ui.recipe.waterG else ui.targetWaterNow
    val step = if (ui.espresso) 1.0 else settings.waterStepG
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(
            Modifier.weight(1f).then(if (!vm.session.weight.isLive) Modifier.clickable(onClickLabel = stringResource(R.string.enter_weight)) { entry = true } else Modifier),
        ) {
            Text(
                stringResource(if (ui.espresso) R.string.yield_label else R.string.water).uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.Bottom) {
                TimerText(units.wValue(ui.pouredG), 40.sp)
                Text(
                    " / ${units.w(target)}",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 4.dp),
                )
            }
            ui.liveRatio?.let {
                Text(
                    stringResource(R.string.live_ratio, CoffeeEngine.formatRatio(it)),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        if (!vm.session.weight.isLive) {
            FilledTonalIconButton(onClick = { vm.session.addWater(-step) }, modifier = Modifier.size(56.dp)) {
                Text("−", style = MaterialTheme.typography.headlineSmall)
            }
            Spacer(Modifier.width(8.dp))
            BigButton(
                "+${units.w(step)}",
                onClick = { vm.session.addWater(step) },
                icon = Icons.Rounded.WaterDrop,
                minHeight = 56.dp,
            )
        }
    }
    if (entry) {
        var text by remember { mutableStateOf(units.wValue(ui.pouredG)) }
        AlertDialog(
            onDismissRequest = { entry = false },
            title = { Text(stringResource(R.string.enter_weight)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField(text, { text = it }, stringResource(R.string.weight), Modifier.fillMaxWidth(), suffix = units.wLabel)
                    TextButton(onClick = { text = units.wValue(target) }) { Text(stringResource(R.string.set_to_target, units.w(target))) }
                }
            },
            confirmButton = {
                TextButton(onClick = { units.parseW(text)?.let(vm.session::setWater); entry = false }) { Text(stringResource(R.string.apply)) }
            },
            dismissButton = { TextButton(onClick = { entry = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

@Composable
private fun ShotStats(vm: MainViewModel, ui: BrewUi, modifier: Modifier = Modifier) {
    val units = LocalUnits.current
    val big = MaterialTheme.typography.headlineMedium
    Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = MaterialTheme.shapes.large, modifier = modifier.fillMaxWidth()) {
        FlowRow(Modifier.padding(20.dp), horizontalArrangement = Arrangement.spacedBy(28.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Stat(stringResource(R.string.dose), units.w(ui.recipe.doseG), valueStyle = big)
            Stat(stringResource(R.string.yield_label), units.w(if (ui.pouredG > 0) ui.pouredG else ui.recipe.waterG), valueStyle = big)
            Stat(stringResource(R.string.ratio), CoffeeEngine.formatRatio(ui.liveRatio ?: ui.ratio), valueStyle = big)
            Stat(stringResource(R.string.temperature), units.t(ui.recipe.tempC), valueStyle = big)
            ui.recipe.pressureBar?.let { Stat(stringResource(R.string.pressure), "${CoffeeEngine.formatNumber(it)} bar", valueStyle = big) }
            if (ui.pouredG > 0 && ui.elapsedS > 0) {
                CoffeeEngine.flowRate(ui.pouredG, ui.elapsedS)?.let {
                    Stat(stringResource(R.string.flow), "${CoffeeEngine.formatNumber(it)} g/s", valueStyle = big)
                }
            }
        }
    }
}

@Composable
private fun startLabel(ui: BrewUi): String = stringResource(
    when {
        ui.running -> R.string.pause
        ui.started -> R.string.resume
        else -> R.string.start
    }
)

@Composable
private fun BrewControls(vm: MainViewModel, ui: BrewUi, settings: Settings, buttonHeight: Dp) {
    var confirmReset by rememberSaveable { mutableStateOf(false) }
    val voice = rememberVoiceLauncher(vm::onVoice)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigButton(
                startLabel(ui),
                onClick = vm.session::toggle,
                modifier = Modifier.weight(1.6f),
                icon = if (ui.running) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                primary = true,
                minHeight = buttonHeight,
            )
            if (!ui.espresso) {
                BigButton(
                    stringResource(R.string.next_step),
                    onClick = vm.session::nextStep,
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.SkipNext,
                    enabled = !ui.started || ui.next != null,
                    minHeight = buttonHeight,
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!ui.espresso) {
                BigButton(stringResource(R.string.plus_10_sec), onClick = { vm.session.extend(10) }, modifier = Modifier.weight(1f), enabled = ui.started, minHeight = 56.dp)
                BigButton(stringResource(R.string.lap), onClick = vm.session::lap, modifier = Modifier.weight(1f), enabled = ui.running, minHeight = 56.dp)
            }
            BigButton(
                stringResource(R.string.reset),
                onClick = { if (ui.elapsedMs > 5000) confirmReset = true else vm.session.reset() },
                modifier = Modifier.weight(1f),
                enabled = ui.started || ui.pouredG > 0,
                minHeight = 56.dp,
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            BigButton(
                stringResource(R.string.finish_and_log),
                onClick = vm.session::finish,
                modifier = Modifier.weight(1f),
                icon = Icons.Rounded.Flag,
                enabled = ui.started,
                minHeight = 56.dp,
            )
            if (voice != null) {
                FilledTonalIconButton(onClick = voice, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Rounded.Mic, contentDescription = stringResource(R.string.voice_command))
                }
            }
        }
    }
    if (confirmReset) {
        ConfirmDialog(
            stringResource(R.string.reset_brew_title),
            stringResource(R.string.reset_brew_body),
            stringResource(R.string.reset),
            onConfirm = { confirmReset = false; vm.session.reset() },
            onDismiss = { confirmReset = false },
        )
    }
}

@Composable
private fun Laps(ui: BrewUi) {
    if (ui.timer.laps.isEmpty()) return
    SectionTitle(stringResource(R.string.laps))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ui.timer.laps.forEachIndexed { i, ms ->
            Stat("${stringResource(R.string.lap)} ${i + 1}", if (ui.espresso) CoffeeEngine.formatTenths(ms) else CoffeeEngine.formatClock(ms / 1000))
        }
    }
}

// ---------------------------------------------------------------------------------------------
// FLEX: brewing companion. TOP = information, BOTTOM = controls
// ---------------------------------------------------------------------------------------------

private class FlexBtn(
    val label: String,
    val onClick: () -> Unit,
    val icon: ImageVector? = null,
    val primary: Boolean = false,
    val enabled: Boolean = true,
    val weight: Float = 1f,
)

@Composable
fun FlexCompanion(vm: MainViewModel, settings: Settings, hinge: HingeInfo?) {
    val ui = rememberBrewUi(vm.session)
    if (ui == null) {
        Box(Modifier.fillMaxSize().statusBarsPadding(), contentAlignment = Alignment.Center) {
            EmptyState(
                Icons.AutoMirrored.Rounded.MenuBook,
                stringResource(R.string.no_recipe_title),
                stringResource(R.string.no_recipe_body),
                actionLabel = stringResource(R.string.choose_recipe),
                onAction = { vm.flexBrowse = true; vm.selectTab(Tab.RECIPES) },
            )
        }
        return
    }
    // An espresso recipe in the generic layout is better served by the shot layout.
    val layout = if (ui.espresso && settings.flexLayout == FlexLayout.BREW) FlexLayout.SHOT else settings.flexLayout
    FlexSplit(
        hinge = hinge,
        top = {
            Surface(color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 24.dp, vertical = 12.dp)) {
                    when (layout) {
                        FlexLayout.BREW -> FlexTopBrew(ui)
                        FlexLayout.TIMER -> FlexTopTimer(ui)
                        FlexLayout.RECIPE -> FlexTopRecipe(ui)
                        FlexLayout.SCALE -> FlexTopScale(ui)
                        FlexLayout.SHOT -> FlexTopShot(ui)
                    }
                }
            }
        },
        bottom = {
            Surface(color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxSize()) {
                Column(Modifier.fillMaxSize().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp)) {
                    FlexControls(vm, ui, settings, layout, Modifier.weight(1f))
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { vm.flexBrowse = true }) {
                            Icon(Icons.Rounded.Apps, contentDescription = stringResource(R.string.open_app))
                        }
                        Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FlexLayout.entries.forEach { l ->
                                FilterChip(
                                    selected = l == layout,
                                    onClick = { vm.setSettings { it.copy(flexLayout = l) } },
                                    label = { Text(flexLayoutLabel(l)) },
                                )
                            }
                        }
                    }
                }
            }
        },
    )
}

@Composable
fun flexLayoutLabel(l: FlexLayout): String = stringResource(
    when (l) {
        FlexLayout.BREW -> R.string.flex_brew
        FlexLayout.TIMER -> R.string.flex_timer
        FlexLayout.RECIPE -> R.string.flex_recipe
        FlexLayout.SCALE -> R.string.flex_scale
        FlexLayout.SHOT -> R.string.flex_shot
    }
)

/** Picks the largest timer size that fits the pane, so the clock reads from across the counter. */
@Composable
private fun FitTimer(ui: BrewUi, heightFraction: Float, modifier: Modifier = Modifier, text: String = ui.timeText) {
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val chars = text.length.coerceAtLeast(4)
        val byWidth = maxWidth.value / (chars * 0.58f)
        val byHeight = maxHeight.value * heightFraction
        val size = minOf(byWidth, byHeight).coerceIn(40f, 260f)
        TimerText(text, size.sp, Modifier.align(Alignment.Center))
    }
}

@Composable
private fun FlexProgress(ui: BrewUi) {
    val reduced = reducedMotion()
    val progress by animateFloatAsState(ui.progress, if (reduced) snap() else tween(250), label = "flexProgress")
    LinearProgressIndicator(
        progress = { progress },
        modifier = Modifier.fillMaxWidth().height(8.dp),
        color = if (ui.state.targetReached) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary,
        trackColor = MaterialTheme.colorScheme.surfaceContainerHighest,
        strokeCap = StrokeCap.Round,
        gapSize = 0.dp,
        drawStopIndicator = {},
    )
}

@Composable
private fun FlexHeaderLine(ui: BrewUi) {
    val units = LocalUnits.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(methodLabel(ui.recipe.method), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            Text(
                ui.recipe.coffeeName.ifBlank { ui.recipe.name },
                style = MaterialTheme.typography.headlineSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("${units.w(ui.recipe.doseG)} → ${units.w(ui.recipe.waterG)}", style = MaterialTheme.typography.titleLarge)
            Text(
                listOfNotNull(CoffeeEngine.formatRatio(ui.ratio), ui.recipe.tempC?.let(units::t)).joinToString(" · "),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun flexStepLine(ui: BrewUi): String {
    val units = LocalUnits.current
    val step = ui.step
    return when {
        !ui.started -> stringResource(R.string.ready_when_you_are)
        ui.state.targetReached -> stringResource(R.string.target_reached)
        step == null -> stringResource(R.string.brewing)
        step.targetWaterG != null -> "${step.label} → ${units.w(step.targetWaterG)}"
        else -> step.label
    }
}

@Composable
private fun FlexTopBrew(ui: BrewUi) {
    Column(Modifier.fillMaxSize()) {
        FlexHeaderLine(ui)
        FitTimer(ui, 0.9f, Modifier.weight(1f))
        Text(flexStepLine(ui), style = MaterialTheme.typography.headlineSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        val next = ui.next
        Text(
            when {
                next != null && ui.started -> stringResource(R.string.next_step_in, next.label, CoffeeEngine.formatClock(ui.stepRemainingS))
                next != null -> stringResource(R.string.next_step_at, next.label, CoffeeEngine.formatClock(next.startS.toLong()))
                else -> stringResource(R.string.target) + " " + ui.targetText
            },
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
        )
        Spacer(Modifier.height(10.dp))
        FlexProgress(ui)
    }
}

@Composable
private fun FlexTopTimer(ui: BrewUi) {
    val units = LocalUnits.current
    Column(Modifier.fillMaxSize()) {
        FitTimer(ui, 0.95f, Modifier.weight(1f))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(ui.recipe.name, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Text("${units.wValue(ui.pouredG)} / ${units.w(ui.targetWaterNow)}", style = MaterialTheme.typography.titleLarge)
            Text("   / ${ui.targetText}", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(10.dp))
        FlexProgress(ui)
    }
}

@Composable
private fun FlexTopRecipe(ui: BrewUi) {
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(ui.recipe.name, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            TimerText(ui.timeText, 36.sp)
        }
        Spacer(Modifier.height(8.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            StepList(ui.steps, ui.stepIndex, ui.recipe.targetTimeS, started = ui.started)
        }
        Spacer(Modifier.height(8.dp))
        FlexProgress(ui)
    }
}

@Composable
private fun FlexTopScale(ui: BrewUi) {
    val units = LocalUnits.current
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(flexStepLine(ui), style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            TimerText(ui.timeText, 32.sp)
        }
        FitTimer(ui, 0.9f, Modifier.weight(1f), text = units.wValue(ui.pouredG))
        Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            Stat(stringResource(R.string.target_weight), units.w(ui.targetWaterNow))
            Stat(stringResource(R.string.dose), units.w(ui.recipe.doseG))
            Stat(stringResource(R.string.ratio), CoffeeEngine.formatRatio(ui.liveRatio ?: ui.ratio))
            Stat(stringResource(R.string.total), units.w(ui.recipe.waterG))
        }
    }
}

@Composable
private fun FlexTopShot(ui: BrewUi) {
    val units = LocalUnits.current
    Column(Modifier.fillMaxSize()) {
        Text(
            ui.recipe.coffeeName.ifBlank { ui.recipe.name },
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.primary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        FitTimer(ui, 0.9f, Modifier.weight(1f), text = CoffeeEngine.formatTenths(ui.elapsedMs))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat(stringResource(R.string.dose), units.w(ui.recipe.doseG))
            Stat(stringResource(R.string.yield_label), units.w(if (ui.pouredG > 0) ui.pouredG else ui.recipe.waterG))
            Stat(stringResource(R.string.ratio), CoffeeEngine.formatRatio(ui.liveRatio ?: ui.ratio))
            Stat(stringResource(R.string.temperature), units.t(ui.recipe.tempC))
            ui.recipe.pressureBar?.let { Stat(stringResource(R.string.pressure), "${CoffeeEngine.formatNumber(it)} bar") }
            Stat(stringResource(R.string.target), "${ui.recipe.targetTimeS} s")
        }
        Spacer(Modifier.height(10.dp))
        FlexProgress(ui)
    }
}

@Composable
private fun FlexControls(vm: MainViewModel, ui: BrewUi, settings: Settings, layout: FlexLayout, modifier: Modifier = Modifier) {
    val units = LocalUnits.current
    val s = vm.session
    var confirmReset by rememberSaveable { mutableStateOf(false) }
    val startPause = FlexBtn(startLabel(ui), s::toggle, if (ui.running) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, primary = true, weight = 1.6f)
    val next = FlexBtn(stringResource(R.string.next_step), s::nextStep, Icons.Rounded.SkipNext, enabled = !ui.started || ui.next != null)
    val plus10 = FlexBtn(stringResource(R.string.plus_10_sec), { s.extend(10) }, Icons.Rounded.MoreTime, enabled = ui.started)
    val addWater = FlexBtn(stringResource(R.string.add_water_amount, units.w(settings.waterStepG)), { s.addWater(settings.waterStepG) }, Icons.Rounded.WaterDrop)
    val reset = FlexBtn(
        stringResource(R.string.reset),
        { if (ui.elapsedMs > 5000) confirmReset = true else s.reset() },
        Icons.Rounded.RestartAlt,
        enabled = ui.started || ui.pouredG > 0,
    )
    val finish = FlexBtn(stringResource(R.string.finish_and_log), s::finish, Icons.Rounded.Flag, enabled = ui.started)
    val lap = FlexBtn(stringResource(R.string.lap), s::lap, Icons.Rounded.Timer, enabled = ui.running)
    val rows: List<List<FlexBtn>> = when (layout) {
        FlexLayout.BREW -> listOf(listOf(startPause, next), listOf(plus10, addWater), listOf(reset, finish))
        FlexLayout.TIMER -> listOf(listOf(startPause), listOf(lap, plus10), listOf(reset, finish))
        FlexLayout.RECIPE -> listOf(listOf(startPause, next), listOf(plus10, reset, finish))
        FlexLayout.SCALE -> listOf(
            listOf(
                FlexBtn("−${units.w(10.0)}", { s.addWater(-10.0) }),
                FlexBtn("+${units.w(10.0)}", { s.addWater(10.0) }),
                FlexBtn("+${units.w(50.0)}", { s.addWater(50.0) }, primary = true),
            ),
            listOf(
                FlexBtn(stringResource(R.string.tare), { s.setWater(0.0) }),
                FlexBtn(stringResource(R.string.match_target), { s.setWater(ui.targetWaterNow) }),
            ),
            listOf(startPause, finish),
        )
        FlexLayout.SHOT -> listOf(
            listOf(startPause),
            listOf(
                FlexBtn("−${units.w(1.0)}", { s.addWater(-1.0) }),
                FlexBtn("+${units.w(1.0)}", { s.addWater(1.0) }),
                FlexBtn(stringResource(R.string.match_target), { s.setWater(ui.recipe.waterG) }),
            ),
            listOf(reset, finish),
        )
    }
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        rows.forEachIndexed { i, row ->
            Row(Modifier.fillMaxWidth().weight(if (i == 0) 1.3f else 1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { b ->
                    BigButton(
                        b.label, b.onClick,
                        modifier = Modifier.weight(b.weight).fillMaxHeight(),
                        icon = b.icon, primary = b.primary, enabled = b.enabled, minHeight = 56.dp, large = true,
                    )
                }
            }
        }
    }
    if (confirmReset) {
        ConfirmDialog(
            stringResource(R.string.reset_brew_title),
            stringResource(R.string.reset_brew_body),
            stringResource(R.string.reset),
            onConfirm = { confirmReset = false; s.reset() },
            onDismiss = { confirmReset = false },
        )
    }
}
