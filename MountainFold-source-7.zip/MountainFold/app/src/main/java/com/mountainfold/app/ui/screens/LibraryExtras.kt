package com.mountainfold.app.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mountainfold.app.R
import com.mountainfold.app.core.engine.CoffeeEngine
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.library.AdditiveLine
import com.mountainfold.app.core.library.AdditiveUnit
import com.mountainfold.app.core.library.Champion
import com.mountainfold.app.core.library.GrindMicrons
import com.mountainfold.app.core.library.LibraryContent
import com.mountainfold.app.core.library.Water
import com.mountainfold.app.data.db.Grinder
import com.mountainfold.app.data.prefs.Settings
import com.mountainfold.app.ui.AdditiveDraft
import com.mountainfold.app.ui.LocalUnits
import com.mountainfold.app.ui.MainViewModel
import com.mountainfold.app.ui.RecipeDraft
import com.mountainfold.app.ui.RecipeSource
import com.mountainfold.app.ui.components.BigButton
import com.mountainfold.app.ui.components.DropdownField
import com.mountainfold.app.ui.components.ListRow
import com.mountainfold.app.ui.components.NumField
import com.mountainfold.app.ui.components.ScreenHeader
import com.mountainfold.app.ui.components.SectionTitle
import com.mountainfold.app.ui.components.Stat
import com.mountainfold.app.ui.components.StepList
import com.mountainfold.app.ui.components.TextFieldLine
import com.mountainfold.app.ui.components.TwoPane

// ---------------------------------------------------------------------------------------------
// Shared bits: additive labels, water block, microns line
// ---------------------------------------------------------------------------------------------

@Composable
fun additiveName(lib: LibraryContent, a: AdditiveLine): String =
    if (a.id == AdditiveLine.CUSTOM) a.name.ifBlank { stringResource(R.string.additive_custom) }
    else lib.additive(a.id)?.label ?: a.name.ifBlank { a.id }

@Composable
fun additiveAmount(a: AdditiveLine): String = stringResource(
    if (a.unit == AdditiveUnit.DROPS) R.string.amount_drops else R.string.amount_g_per_l,
    CoffeeEngine.formatNumber(a.amount),
)

@Composable
fun waterFitLabel(w: Water): String = stringResource(
    when (w.fit) {
        "AVOID" -> R.string.water_fit_avoid
        "BASE" -> R.string.water_fit_base
        else -> R.string.water_fit_good
    }
)

/** Read-only water and concentrates of a recipe, a champion recipe or a logged brew. Nothing when all empty. */
@Composable
fun WaterBlock(vm: MainViewModel, waterId: String?, waterNote: String, additives: List<AdditiveLine>) {
    val lib = vm.library
    val water = lib.water(waterId)
    if (water == null && waterNote.isBlank() && additives.isEmpty()) return
    SectionTitle(stringResource(R.string.water_section))
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        water?.let { w ->
            val figures = listOfNotNull(w.gh?.let { "GH $it" }, w.kh?.let { "KH $it" }, w.tds?.let { "TDS ${CoffeeEngine.formatNumber(it)}" })
            Text(w.name, style = MaterialTheme.typography.titleMedium)
            if (figures.isNotEmpty()) {
                Text(figures.joinToString(" · ") + " mg/L", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (waterNote.isNotBlank() && waterNote != water?.name) Text(waterNote, style = MaterialTheme.typography.bodyLarge)
        additives.forEach { a ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(additiveName(lib, a), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                Text(additiveAmount(a), style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

/**
 * The grind in microns on the default grinder, or the clicks for a grind written in microns.
 * Null when the microns option is off or the grinder has no known microns per click.
 */
@Composable
fun micronsLine(vm: MainViewModel, settings: Settings, grind: String): String? {
    if (!settings.grindMicrons || grind.isBlank()) return null
    val grinders by vm.grinders.collectAsStateWithLifecycle()
    val g = grinders.firstOrNull { it.id == settings.defaultGrinderId }
    val step = vm.micronsPerStep(g) ?: return null
    val written = GrindMicrons.written(grind)
    return if (written != null) {
        GrindMicrons.steps(written, step)?.let { stringResource(R.string.microns_on_grinder, g!!.name, GrindMicrons.formatSteps(it)) }
    } else {
        GrindMicrons.microns(grind, step)?.let { stringResource(R.string.microns_of_setting, GrindMicrons.format(it), g!!.name) }
    }
}

@Composable
fun MicronsText(vm: MainViewModel, settings: Settings, grind: String, modifier: Modifier = Modifier) {
    val line = micronsLine(vm, settings, grind) ?: return
    Text(line, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary, modifier = modifier)
}

// ---------------------------------------------------------------------------------------------
// Recipes tab: my recipes | champions
// ---------------------------------------------------------------------------------------------

@Composable
fun RecipeSourceTabs(vm: MainViewModel) {
    val options = listOf(RecipeSource.MINE to stringResource(R.string.recipes_mine), RecipeSource.CHAMPIONS to stringResource(R.string.recipes_champions))
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 8.dp)) {
        options.forEachIndexed { i, (value, label) ->
            SegmentedButton(
                selected = vm.recipeSource == value,
                onClick = { vm.recipeSource = value },
                shape = SegmentedButtonDefaults.itemShape(i, options.size),
            ) { Text(label, maxLines = 1) }
        }
    }
}

@Composable
fun competitionName(c: Champion, short: Boolean = false): String = stringResource(
    when {
        c.isAeroPress && short -> R.string.comp_wac_short
        c.isAeroPress -> R.string.comp_wac
        short -> R.string.comp_wbrc_short
        else -> R.string.comp_wbrc
    }
)

@Composable
fun placeLabel(place: Int): String = stringResource(
    when (place) {
        2 -> R.string.place_2
        3 -> R.string.place_3
        else -> R.string.place_1
    }
)

@Composable
fun ChampionsScreen(vm: MainViewModel, settings: Settings, wide: Boolean, hinge: HingeInfo?) {
    val selected = vm.library.champion(vm.championSel)
    if (wide) {
        TwoPane(
            hinge = hinge,
            left = { ChampionList(vm, selected?.id) },
            right = {
                Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxSize()) {
                    if (selected != null) ChampionDetail(vm, settings, selected, showBack = false)
                    else Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(stringResource(R.string.select_champion), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            },
        )
    } else if (selected == null) {
        ChampionList(vm, null)
    } else {
        ChampionDetail(vm, settings, selected, showBack = true)
    }
}

@Composable
private fun ChampionList(vm: MainViewModel, selectedId: String?) {
    val units = LocalUnits.current
    val lang = vm.lang
    val filter = vm.championFilter
    val shown = vm.library.champions.filter { filter == null || it.competition == filter }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.tab_recipes))
        RecipeSourceTabs(vm)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = filter == null, onClick = { vm.championFilter = null }, label = { Text(stringResource(R.string.all)) })
            FilterChip(selected = filter == "WBRC", onClick = { vm.championFilter = if (filter == "WBRC") null else "WBRC" }, label = { Text(stringResource(R.string.comp_wbrc_short)) })
            FilterChip(selected = filter == "WAC", onClick = { vm.championFilter = if (filter == "WAC") null else "WAC" }, label = { Text(stringResource(R.string.comp_wac_short)) })
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)) {
            item {
                Text(
                    stringResource(R.string.champions_intro),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
            var lastComp: String? = null
            shown.forEach { c ->
                if (c.competition != lastComp) {
                    lastComp = c.competition
                    item(key = "h-${c.competition}") { SectionTitle(competitionName(c), Modifier.padding(horizontal = 16.dp)) }
                }
                item(key = c.id) {
                    val tags = listOfNotNull(
                        placeLabel(c.place).takeIf { c.place > 1 },
                        stringResource(R.string.champion_signature).takeIf { c.kind == "SIGNATURE" },
                    )
                    ListRow(
                        title = "${c.year} · ${c.champion}",
                        subtitle = (listOf(c.brewer[lang], "${units.w(c.doseG)} → ${units.w(c.waterG)}", units.t(c.tempC)) + tags).joinToString(" · "),
                        selected = c.id == selectedId,
                        onClick = { vm.championSel = c.id },
                    )
                }
            }
        }
    }
}

@Composable
private fun ChampionDetail(vm: MainViewModel, settings: Settings, c: Champion, showBack: Boolean) {
    val units = LocalUnits.current
    val lang = vm.lang
    val uri = LocalUriHandler.current
    val steps = remember(c.id, lang) { c.steps(lang) }
    val grinders by vm.grinders.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(c.champion, onBack = if (showBack) ({ vm.championSel = null }) else null)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Text(
                listOf("${competitionName(c)} ${c.year}", placeLabel(c.place), c.country[lang]).joinToString(" · "),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (c.kind == "SIGNATURE") {
                Spacer(Modifier.height(10.dp))
                Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = MaterialTheme.shapes.medium) {
                    Column(Modifier.padding(12.dp)) {
                        Text(stringResource(R.string.champion_signature), style = MaterialTheme.typography.titleSmall)
                        Text(stringResource(R.string.champion_signature_hint), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Stat(stringResource(R.string.dose), units.w(c.doseG))
                Stat(stringResource(R.string.water), units.w(c.waterG))
                Stat(stringResource(R.string.ratio), CoffeeEngine.formatRatio(CoffeeEngine.ratio(c.waterG, c.doseG)))
                Stat(stringResource(R.string.temperature), units.t(c.tempC))
                Stat(stringResource(R.string.time), CoffeeEngine.formatClock(c.targetTimeS.toLong()))
            }
            Spacer(Modifier.height(16.dp))
            Labeled(stringResource(R.string.brewer_label), c.brewer[lang])
            Labeled(stringResource(R.string.filter), c.filter[lang])
            Labeled(stringResource(R.string.grind), c.grind[lang])
            if (settings.grindMicrons) {
                val est = vm.library.micronsOf(c)
                val g = grinders.firstOrNull { it.id == settings.defaultGrinderId }
                val step = vm.micronsPerStep(g)
                if (est != null) {
                    val m = GrindMicrons.format(est.microns)
                    // The grind text already says it when the microns were published.
                    if (GrindMicrons.written(c.grind[lang]) == null) {
                        Labeled(stringResource(R.string.microns_label), if (est.published) m else stringResource(R.string.microns_estimate, m))
                    }
                    val clicks = GrindMicrons.steps(est.microns, step)
                    val sameGrinder = g != null && c.grinder != null && g.name.equals(c.grinder, ignoreCase = true)
                    if (!sameGrinder) Text(
                        if (g != null && clicks != null) stringResource(R.string.microns_on_grinder, g.name, GrindMicrons.formatSteps(clicks))
                        else stringResource(R.string.microns_set_grinder),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
            Spacer(Modifier.height(20.dp))
            BigButton(stringResource(R.string.brew), onClick = { vm.brewChampion(c) }, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow, primary = true, minHeight = 56.dp)
            Spacer(Modifier.height(10.dp))
            BigButton(stringResource(R.string.champion_add), onClick = { vm.addChampionRecipe(c) }, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.Add, minHeight = 56.dp)
            WaterBlock(vm, c.waterId, c.water[lang], c.additives)
            if (steps.isNotEmpty()) {
                SectionTitle(stringResource(R.string.steps))
                StepList(steps, -1, c.targetTimeS, started = false)
            }
            c.notes?.let {
                SectionTitle(stringResource(R.string.notes))
                Text(it[lang], style = MaterialTheme.typography.bodyLarge)
            }
            if (c.approx) {
                Spacer(Modifier.height(12.dp))
                Text(stringResource(R.string.champion_approx), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { runCatching { uri.openUri(c.source) } }) {
                Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.champion_view_source))
            }
        }
    }
}

@Composable
private fun Labeled(label: String, value: String) {
    if (value.isBlank()) return
    Column(Modifier.padding(bottom = 10.dp)) {
        Text(label.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}

// ---------------------------------------------------------------------------------------------
// Recipe editor: water and minerals
// ---------------------------------------------------------------------------------------------

@Composable
fun WaterEditorSection(vm: MainViewModel, d: RecipeDraft, update: (RecipeDraft) -> Unit) {
    val lib = vm.library
    val lang = vm.lang
    val none = stringResource(R.string.none)
    SectionTitle(stringResource(R.string.water_section))
    DropdownField(
        stringResource(R.string.water_choice), lib.water(d.waterId)?.name ?: none,
        listOf<Water?>(null) + lib.waters,
        optionLabel = { w -> w?.let { "${it.name} · ${waterFitLabel(it)}" } ?: none },
        onSelect = { update(d.copy(waterId = it?.id)) },
        modifier = Modifier.fillMaxWidth(),
    )
    TextFieldLine(d.waterNote, { update(d.copy(waterNote = it)) }, stringResource(R.string.water_note), Modifier.fillMaxWidth())
    Text(stringResource(R.string.additives), style = MaterialTheme.typography.labelLarge)
    val productIds = lib.additives.map { it.id } + AdditiveLine.CUSTOM
    d.additives.forEachIndexed { i, a ->
        fun set(n: AdditiveDraft) = update(d.copy(additives = d.additives.toMutableList().also { it[i] = n }))
        Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = MaterialTheme.shapes.medium) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    DropdownField(
                        stringResource(R.string.product), productLabel(lib, a.id),
                        productIds,
                        optionLabel = { productLabel(lib, it) },
                        onSelect = { set(a.copy(id = it, unit = if (it == "apax-konflux") AdditiveUnit.DROPS else a.unit)) },
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(onClick = { update(d.copy(additives = d.additives.filterIndexed { j, _ -> j != i })) }) {
                        Icon(Icons.Rounded.Close, contentDescription = stringResource(R.string.remove_additive))
                    }
                }
                if (a.id == AdditiveLine.CUSTOM) TextFieldLine(a.name, { set(a.copy(name = it)) }, stringResource(R.string.additive_name), Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField(a.amount, { set(a.copy(amount = it)) }, stringResource(R.string.amount), Modifier.weight(1f), isError = CoffeeEngine.parseNumber(a.amount)?.let { it <= 0 } ?: true)
                    DropdownField(
                        stringResource(R.string.unit_label), unitLabel(a.unit), AdditiveUnit.entries,
                        optionLabel = { unitLabel(it) },
                        onSelect = { set(a.copy(unit = it)) },
                        modifier = Modifier.weight(1f),
                    )
                }
                lib.additive(a.id)?.let { Text(it.effect[lang], style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = { update(d.copy(additives = d.additives + AdditiveDraft())) }) {
            Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(stringResource(R.string.add_additive))
        }
    }
    DropdownField(
        stringResource(R.string.apax_mix), stringResource(R.string.pick_one), lib.apaxMixes,
        optionLabel = { m -> "${m.name[lang]} · ${mixText(m.tonik, m.jamm, m.lylac)}" },
        onSelect = { vm.applyApaxMix(it) },
        modifier = Modifier.fillMaxWidth(),
    )
    Text(stringResource(R.string.apax_mix_hint), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun productLabel(lib: LibraryContent, id: String): String =
    if (id == AdditiveLine.CUSTOM) stringResource(R.string.additive_custom) else lib.additive(id)?.label ?: id

@Composable
private fun unitLabel(u: AdditiveUnit): String = stringResource(if (u == AdditiveUnit.DROPS) R.string.unit_drops else R.string.unit_g_per_l)

private fun mixText(tonik: Double, jamm: Double, lylac: Double): String =
    listOf("TONIK" to tonik, "JAMM" to jamm, "LYLAC" to lylac).filter { it.second > 0 }
        .joinToString(" + ") { "${CoffeeEngine.formatNumber(it.second)} ${it.first}" }

// ---------------------------------------------------------------------------------------------
// Settings: microns per click of each grinder
// ---------------------------------------------------------------------------------------------

@Composable
fun GrinderMicronsSettings(vm: MainViewModel) {
    val grinders by vm.grinders.collectAsStateWithLifecycle()
    if (grinders.isEmpty()) {
        Text(stringResource(R.string.no_grinders), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        grinders.forEach { g -> GrinderMicronsRow(vm, g) }
        Text(stringResource(R.string.microns_caveat), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun GrinderMicronsRow(vm: MainViewModel, g: Grinder) {
    val known = vm.library.micronsPerStep(g.name)
    var text by remember(g.id) { mutableStateOf((g.micronsPerStep ?: known)?.let { CoffeeEngine.formatNumber(it) }.orEmpty()) }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f)) {
            Text(g.name, style = MaterialTheme.typography.bodyLarge)
            Text(
                known?.let { stringResource(R.string.microns_maker_value, CoffeeEngine.formatNumber(it)) } ?: stringResource(R.string.microns_unknown),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        NumField(text, { text = it; vm.setGrinderMicrons(g, it) }, stringResource(R.string.microns_per_click), Modifier.width(150.dp), suffix = "µm")
    }
}

// ---------------------------------------------------------------------------------------------
// Water guide
// ---------------------------------------------------------------------------------------------

@Composable
fun WaterGuideScreen(vm: MainViewModel, settings: Settings, wide: Boolean, hinge: HingeInfo?) {
    val lib = vm.library
    val lang = vm.lang
    val waters: @Composable () -> Unit = {
        Text(stringResource(R.string.water_guide_intro), style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(6.dp))
        Text(stringResource(R.string.water_formula), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        SectionTitle(stringResource(R.string.waters_title))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            lib.waters.forEach { w -> WaterCard(w, lang) }
        }
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.water_label_disclaimer), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    val apax: @Composable () -> Unit = {
        SectionTitle(stringResource(R.string.apax_title))
        Text(stringResource(R.string.apax_intro), style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            lib.additives.forEach { a ->
                Column {
                    Text(a.label, style = MaterialTheme.typography.titleMedium)
                    Text(a.effect[lang], style = MaterialTheme.typography.bodyLarge)
                    if (a.composition.isNotBlank()) Text(a.composition, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        SectionTitle(stringResource(R.string.apax_mixes_title))
        lib.apaxMixes.forEach { m ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(m.name[lang], style = MaterialTheme.typography.bodyLarge)
                    Text(mixText(m.tonik, m.jamm, m.lylac), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(stringResource(R.string.total_per_litre, CoffeeEngine.formatNumber(m.tonik + m.jamm + m.lylac)), style = MaterialTheme.typography.titleSmall)
            }
        }
        SectionTitle(stringResource(R.string.apax_drops_title))
        lib.apaxDrops.forEach { d ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text(d.name[lang], style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                Text(stringResource(R.string.drops_range, d.min.toString(), d.max.toString()), style = MaterialTheme.typography.titleSmall)
            }
        }
    }
    Column(Modifier.fillMaxSize().imePadding()) {
        ScreenHeader(stringResource(R.string.water_guide), onBack = vm::back)
        if (wide) {
            TwoPane(
                hinge = hinge,
                left = { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp).padding(bottom = 24.dp)) { waters() } },
                right = {
                    Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxSize()) {
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 16.dp)) { apax() }
                    }
                },
            )
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
                waters()
                Spacer(Modifier.height(12.dp))
                apax()
            }
        }
    }
}

@Composable
private fun WaterCard(w: Water, lang: String) {
    val avoid = w.fit == "AVOID"
    Surface(
        color = if (avoid) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
        contentColor = if (avoid) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurface,
        shape = MaterialTheme.shapes.medium,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(w.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Text(waterFitLabel(w), style = MaterialTheme.typography.labelMedium, color = if (avoid) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            }
            val figures = listOfNotNull(
                w.gh?.let { "GH" to "$it" }, w.kh?.let { "KH" to "$it" }, w.tds?.let { "TDS" to CoffeeEngine.formatNumber(it) },
                w.ca?.let { "Ca" to CoffeeEngine.formatNumber(it) }, w.mg?.let { "Mg" to CoffeeEngine.formatNumber(it) },
            )
            if (figures.isNotEmpty()) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    figures.forEach { (k, v) -> Stat(k, "$v mg/L", valueStyle = MaterialTheme.typography.titleSmall) }
                }
            }
            Text(w.use[lang], style = MaterialTheme.typography.bodyMedium)
        }
    }
}
