package com.mountainfold.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Coffee
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mountainfold.app.R
import com.mountainfold.app.core.engine.CoffeeEngine
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.StepType
import com.mountainfold.app.data.StepsCodec
import com.mountainfold.app.data.db.Coffee
import com.mountainfold.app.data.db.Recipe
import com.mountainfold.app.data.prefs.Settings
import com.mountainfold.app.ui.LocalUnits
import com.mountainfold.app.ui.MainViewModel
import com.mountainfold.app.ui.Overlay
import com.mountainfold.app.ui.Pane
import com.mountainfold.app.ui.RecipeDraft
import com.mountainfold.app.ui.StepDraft
import com.mountainfold.app.ui.Tab
import com.mountainfold.app.ui.components.BigButton
import com.mountainfold.app.ui.components.CoffeePhoto
import com.mountainfold.app.ui.components.ConfirmDialog
import com.mountainfold.app.ui.components.DropdownField
import com.mountainfold.app.ui.components.EmptyState
import com.mountainfold.app.ui.components.ListRow
import com.mountainfold.app.ui.components.NumField
import com.mountainfold.app.ui.components.ScreenHeader
import com.mountainfold.app.ui.components.SectionTitle
import com.mountainfold.app.ui.components.Stat
import com.mountainfold.app.ui.components.StepList
import com.mountainfold.app.ui.components.TextFieldLine
import com.mountainfold.app.ui.components.TwoPane
import com.mountainfold.app.ui.components.methodLabel
import java.time.LocalDate

@Composable
private fun PanePlaceholder(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---------------------------------------------------------------------------------------------
// Recipes
// ---------------------------------------------------------------------------------------------

@Composable
fun RecipesScreen(vm: MainViewModel, settings: Settings, wide: Boolean, hinge: HingeInfo?) {
    if (vm.recipeSource == com.mountainfold.app.ui.RecipeSource.CHAMPIONS && vm.recipePane != Pane.Edit) {
        ChampionsScreen(vm, settings, wide, hinge)
        return
    }
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    val pane = vm.recipePane
    val selected = (pane as? Pane.View)?.let { p -> recipes.firstOrNull { it.id == p.id } }
    val detail: @Composable (Boolean) -> Unit = { showBack ->
        val draft = vm.recipeDraft
        when {
            pane == Pane.Edit && draft != null -> RecipeEditor(vm, draft, settings)
            selected != null -> RecipeDetail(vm, selected, settings, showBack)
            else -> PanePlaceholder(stringResource(R.string.select_recipe))
        }
    }
    if (wide) {
        TwoPane(
            hinge = hinge,
            left = { RecipeList(vm, recipes, selected?.id) },
            right = { Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxSize()) { detail(false) } },
        )
    } else if (pane == Pane.None || (pane is Pane.View && selected == null)) {
        RecipeList(vm, recipes, null)
    } else {
        detail(true)
    }
}

@Composable
private fun RecipeList(vm: MainViewModel, recipes: List<Recipe>, selectedId: Long?) {
    val units = LocalUnits.current
    val filter = vm.recipeMethodFilter
    val methods = remember(recipes) { recipes.map { BrewMethod.fromKey(it.method) }.distinct().sortedBy { it.ordinal } }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.tab_recipes)) {
            FilledTonalButton(onClick = { vm.newRecipe(filter ?: vm.settings.value?.defaultMethod ?: BrewMethod.V60) }, modifier = Modifier.padding(end = 12.dp)) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.new_recipe))
            }
        }
        RecipeSourceTabs(vm)
        if (methods.size > 1) {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = filter == null, onClick = { vm.recipeMethodFilter = null }, label = { Text(stringResource(R.string.all)) })
                methods.forEach { m ->
                    FilterChip(selected = filter == m, onClick = { vm.recipeMethodFilter = if (filter == m) null else m }, label = { Text(methodLabel(m)) })
                }
            }
        }
        val shown = recipes.filter { filter == null || it.method == filter.name }
        if (shown.isEmpty()) {
            EmptyState(
                Icons.AutoMirrored.Rounded.MenuBook,
                stringResource(R.string.no_recipes_title),
                stringResource(R.string.no_recipes_body),
                actionLabel = stringResource(R.string.new_recipe),
                onAction = { vm.newRecipe() },
            )
        } else {
            LazyColumn(contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)) {
                items(shown, key = { it.id }) { r ->
                    ListRow(
                        title = r.name,
                        subtitle = recipeSummary(r, units),
                        selected = r.id == selectedId,
                        trailing = if (r.favorite) ({
                            Icon(Icons.Rounded.Star, contentDescription = stringResource(R.string.favorite), tint = MaterialTheme.colorScheme.primary)
                        }) else null,
                        onClick = { vm.recipeDraft = null; vm.recipePane = Pane.View(r.id) },
                    )
                }
            }
        }
    }
}

@Composable
private fun RecipeDetail(vm: MainViewModel, r: Recipe, settings: Settings, showBack: Boolean) {
    val units = LocalUnits.current
    val coffees by vm.coffees.collectAsStateWithLifecycle()
    val method = BrewMethod.fromKey(r.method)
    val steps = remember(r.stepsJson) { StepsCodec.decode(r.stepsJson) }
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(r.name, onBack = if (showBack) vm::back else null) {
            IconButton(onClick = { vm.toggleFavorite(r) }) {
                Icon(
                    if (r.favorite) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                    contentDescription = stringResource(if (r.favorite) R.string.unfavorite else R.string.favorite),
                    tint = if (r.favorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(onClick = { vm.editRecipe(r) }) { Icon(Icons.Rounded.Edit, contentDescription = stringResource(R.string.edit)) }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, contentDescription = stringResource(R.string.more)) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text(stringResource(R.string.duplicate)) }, onClick = { menu = false; vm.duplicateRecipe(r) })
                    DropdownMenuItem(text = { Text(stringResource(R.string.diagnose)) }, onClick = { menu = false; vm.diagnoseRecipe(r) })
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.compare)) },
                        onClick = { menu = false; vm.compare = vm.compare.copy(brews = false, aId = r.id); vm.open(Overlay.Compare) },
                    )
                    DropdownMenuItem(text = { Text(stringResource(R.string.delete)) }, onClick = { menu = false; confirmDelete = true })
                }
            }
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            val coffee = coffees.firstOrNull { it.id == r.coffeeId }
            Text(
                listOfNotNull(methodLabel(method), coffee?.name).joinToString(" · "),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(16.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Stat(stringResource(R.string.dose), units.w(r.doseG))
                Stat(stringResource(if (method.isEspresso) R.string.yield_label else R.string.water), units.w(r.waterG))
                Stat(stringResource(R.string.ratio), CoffeeEngine.formatRatio(CoffeeEngine.ratio(r.waterG, r.doseG)))
                Stat(stringResource(R.string.temperature), units.t(r.tempC))
                if (r.grind.isNotBlank()) Stat(stringResource(R.string.grind), r.grind)
                Stat(stringResource(R.string.time), recipeTimeText(r))
                r.pressureBar?.let { Stat(stringResource(R.string.pressure), "${CoffeeEngine.formatNumber(it)} bar") }
            }
            MicronsText(vm, settings, r.grind, Modifier.padding(top = 10.dp))
            vm.library.champion(r.championId)?.let { c ->
                Text(
                    stringResource(R.string.from_champion, "${c.champion} ${c.year}"),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 10.dp),
                )
            }
            Spacer(Modifier.height(20.dp))
            BigButton(stringResource(R.string.brew), onClick = { vm.brew(r) }, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow, primary = true)
            if (steps.isNotEmpty()) {
                SectionTitle(stringResource(R.string.steps))
                StepList(steps, -1, r.targetTimeS, started = false)
            }
            val additives = remember(r.additivesJson) { com.mountainfold.app.core.library.AdditivesCodec.decode(r.additivesJson) }
            WaterBlock(vm, r.waterId, r.waterNote, additives)
            if (r.notes.isNotBlank()) {
                SectionTitle(stringResource(R.string.notes))
                Text(r.notes, style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
    if (confirmDelete) {
        ConfirmDialog(
            stringResource(R.string.delete_recipe_title),
            stringResource(R.string.delete_body, r.name),
            stringResource(R.string.delete),
            onConfirm = { confirmDelete = false; vm.deleteRecipe(r) },
            onDismiss = { confirmDelete = false },
        )
    }
}

@Composable
fun stepTypeLabel(t: StepType): String = stringResource(
    when (t) {
        StepType.BLOOM -> R.string.type_bloom
        StepType.POUR -> R.string.type_pour
        StepType.WAIT -> R.string.type_wait
        StepType.STIR -> R.string.type_stir
        StepType.SWIRL -> R.string.type_swirl
        StepType.PRESS -> R.string.type_press
        StepType.DRAWDOWN -> R.string.type_drawdown
        StepType.CUSTOM -> R.string.type_custom
    }
)

@Composable
private fun RecipeEditor(vm: MainViewModel, d: RecipeDraft, settings: Settings) {
    val units = LocalUnits.current
    val coffees by vm.coffees.collectAsStateWithLifecycle()
    fun update(n: RecipeDraft) { vm.recipeDraft = n }
    fun num(s: String) = CoffeeEngine.parseNumber(s)?.takeIf { it > 0 }
    val none = stringResource(R.string.none)
    Column(Modifier.fillMaxSize().imePadding()) {
        ScreenHeader(stringResource(if (d.id == 0L) R.string.new_recipe else R.string.edit_recipe), onBack = vm::closeRecipePane) {
            Button(onClick = vm::saveRecipeDraft, modifier = Modifier.padding(end = 12.dp)) { Text(stringResource(R.string.save)) }
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            TextFieldLine(d.name, { update(d.copy(name = it)) }, stringResource(R.string.name), Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                DropdownField(
                    stringResource(R.string.method), methodLabel(d.method), BrewMethod.entries,
                    optionLabel = { methodLabel(it) },
                    onSelect = { update(d.copy(method = it)) },
                    modifier = Modifier.weight(1f),
                )
                OutlinedButton(onClick = { vm.applyTemplate(d.method) }) { Text(stringResource(R.string.use_template)) }
            }
            DropdownField(
                stringResource(R.string.coffee), coffees.firstOrNull { it.id == d.coffeeId }?.name ?: none,
                listOf<Coffee?>(null) + coffees,
                optionLabel = { it?.name ?: none },
                onSelect = { update(d.copy(coffeeId = it?.id)) },
                modifier = Modifier.fillMaxWidth(),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                NumField(
                    d.dose,
                    { v ->
                        val dose = num(v); val ratio = num(d.ratio)
                        update(d.copy(dose = v, water = if (dose != null && ratio != null) CoffeeEngine.formatNumber(dose * ratio) else d.water))
                    },
                    stringResource(R.string.dose), Modifier.weight(1f), suffix = units.wLabel, isError = num(d.dose) == null,
                )
                NumField(
                    d.water,
                    { v ->
                        val water = num(v); val dose = num(d.dose)
                        update(d.copy(water = v, ratio = if (dose != null && water != null) CoffeeEngine.formatNumber(water / dose) else d.ratio))
                    },
                    stringResource(if (d.method.isEspresso) R.string.yield_label else R.string.water), Modifier.weight(1f), suffix = units.wLabel, isError = num(d.water) == null,
                )
                NumField(
                    d.ratio,
                    { v ->
                        val ratio = num(v); val dose = num(d.dose)
                        update(d.copy(ratio = v, water = if (dose != null && ratio != null) CoffeeEngine.formatNumber(dose * ratio) else d.water))
                    },
                    stringResource(R.string.ratio_one_to), Modifier.weight(1f),
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                NumField(d.temp, { update(d.copy(temp = it)) }, stringResource(R.string.temperature), Modifier.weight(1f), suffix = units.tLabel)
                NumField(
                    d.targetTime, { update(d.copy(targetTime = it)) },
                    stringResource(if (d.method.isEspresso) R.string.time_seconds else R.string.time_clock),
                    Modifier.weight(1f), isError = CoffeeEngine.parseClock(d.targetTime).let { it == null || it <= 0 },
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TextFieldLine(d.grind, { update(d.copy(grind = it)) }, stringResource(R.string.grind_setting), Modifier.weight(1f))
                if (d.method.isEspresso) {
                    NumField(d.pressure, { update(d.copy(pressure = it)) }, stringResource(R.string.pressure), Modifier.weight(1f), suffix = "bar")
                }
            }
            MicronsText(vm, settings, d.grind)
            SectionTitle(stringResource(R.string.steps))
            d.steps.forEachIndexed { i, s ->
                fun setStep(n: StepDraft) = update(d.copy(steps = d.steps.toMutableList().also { it[i] = n }))
                Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = MaterialTheme.shapes.medium) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            NumField(s.start, { setStep(s.copy(start = it)) }, stringResource(R.string.starts_at), Modifier.width(104.dp), isError = CoffeeEngine.parseClock(s.start) == null)
                            TextFieldLine(s.label, { setStep(s.copy(label = it)) }, stringResource(R.string.step_name), Modifier.weight(1f))
                            IconButton(onClick = { update(d.copy(steps = d.steps.filterIndexed { j, _ -> j != i })) }) {
                                Icon(Icons.Rounded.Close, contentDescription = stringResource(R.string.remove_step))
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NumField(s.water, { setStep(s.copy(water = it)) }, stringResource(R.string.water_target), Modifier.weight(1f), suffix = units.wLabel)
                            DropdownField(
                                stringResource(R.string.type), stepTypeLabel(s.type), StepType.entries,
                                optionLabel = { stepTypeLabel(it) },
                                onSelect = { setStep(s.copy(type = it)) },
                                modifier = Modifier.weight(1f),
                            )
                        }
                        TextFieldLine(s.note, { setStep(s.copy(note = it)) }, stringResource(R.string.instruction), Modifier.fillMaxWidth(), singleLine = false)
                    }
                }
            }
            OutlinedButton(
                onClick = {
                    val last = d.steps.lastOrNull()?.let { CoffeeEngine.parseClock(it.start) } ?: -30
                    update(d.copy(steps = d.steps + StepDraft(start = CoffeeEngine.formatClock((last + 30).toLong()))))
                },
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.add_step))
            }
            WaterEditorSection(vm, d, ::update)
            TextFieldLine(d.notes, { update(d.copy(notes = it)) }, stringResource(R.string.notes), Modifier.fillMaxWidth(), singleLine = false, minLines = 3)
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Coffee library
// ---------------------------------------------------------------------------------------------

@Composable
fun CoffeeScreen(vm: MainViewModel, settings: Settings, wide: Boolean, hinge: HingeInfo?) {
    val coffees by vm.coffees.collectAsStateWithLifecycle()
    val pane = vm.coffeePane
    val selected = (pane as? Pane.View)?.let { p -> coffees.firstOrNull { it.id == p.id } }
    val detail: @Composable (Boolean) -> Unit = { showBack ->
        val draft = vm.coffeeDraft
        when {
            pane == Pane.Edit && draft != null -> CoffeeEditor(vm, draft.coffee)
            selected != null -> CoffeeDetail(vm, selected, settings, showBack)
            else -> PanePlaceholder(stringResource(R.string.select_coffee))
        }
    }
    if (wide) {
        TwoPane(
            hinge = hinge,
            left = { CoffeeList(vm, coffees, settings, selected?.id) },
            right = { Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxSize()) { detail(false) } },
        )
    } else if (pane == Pane.None || (pane is Pane.View && selected == null)) {
        CoffeeList(vm, coffees, settings, null)
    } else {
        detail(true)
    }
}

@Composable
private fun CoffeeList(vm: MainViewModel, coffees: List<Coffee>, settings: Settings, selectedId: Long?) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.tab_coffee)) {
            FilledTonalButton(onClick = vm::newCoffee, modifier = Modifier.padding(end = 12.dp)) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.add_coffee))
            }
        }
        if (coffees.isEmpty()) {
            EmptyState(
                Icons.Rounded.Coffee,
                stringResource(R.string.no_coffee_title),
                stringResource(R.string.no_coffee_body),
                actionLabel = stringResource(R.string.add_coffee),
                onAction = vm::newCoffee,
            )
        } else {
            LazyColumn(contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)) {
                items(coffees, key = { it.id }) { c ->
                    ListRow(
                        title = c.name,
                        subtitle = listOf(c.country.ifBlank { c.origin }, c.process, c.roaster).filter { it.isNotBlank() }.joinToString(" · "),
                        selected = c.id == selectedId,
                        leading = { CoffeePhoto(c.photoPath, Modifier.size(52.dp)) },
                        trailing = if (c.id == settings.currentCoffeeId) ({
                            Text(stringResource(R.string.current), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        }) else null,
                        onClick = { vm.coffeeDraft = null; vm.coffeePane = Pane.View(c.id) },
                    )
                }
            }
        }
    }
}

@Composable
private fun CoffeeDetail(vm: MainViewModel, c: Coffee, settings: Settings, showBack: Boolean) {
    val units = LocalUnits.current
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    val brews by vm.brews.collectAsStateWithLifecycle()
    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    val isCurrent = c.id == settings.currentCoffeeId
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(c.name, onBack = if (showBack) vm::back else null) {
            IconButton(onClick = { vm.editCoffee(c) }) { Icon(Icons.Rounded.Edit, contentDescription = stringResource(R.string.edit)) }
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Rounded.Delete, contentDescription = stringResource(R.string.delete)) }
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            if (c.photoPath != null) {
                CoffeePhoto(c.photoPath, Modifier.fillMaxWidth().aspectRatio(16f / 9f), contentDescription = c.name)
                Spacer(Modifier.height(16.dp))
            }
            if (c.tastingNotes.isNotBlank()) {
                Text(c.tastingNotes, style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(16.dp))
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                @Composable fun field(label: Int, value: String) { if (value.isNotBlank()) Stat(stringResource(label), value) }
                field(R.string.origin, c.origin)
                field(R.string.country, c.country)
                field(R.string.region, c.region)
                field(R.string.producer, c.producer)
                field(R.string.variety, c.variety)
                field(R.string.process, c.process)
                field(R.string.altitude, c.altitude)
                field(R.string.roaster, c.roaster)
                field(R.string.roast_level, c.roastLevel)
                c.roastDateEpochDay?.let { day ->
                    val age = (LocalDate.now().toEpochDay() - day).toInt()
                    Stat(stringResource(R.string.roast_date), formatDate(day * 86_400_000L, withTime = false))
                    if (age >= 0) Stat(stringResource(R.string.rest), daysText(age))
                }
            }
            Spacer(Modifier.height(20.dp))
            if (isCurrent) {
                Text(stringResource(R.string.current_coffee_hint), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
            } else {
                BigButton(stringResource(R.string.set_current), onClick = { vm.setCurrentCoffee(c.id) }, modifier = Modifier.fillMaxWidth(), primary = true, minHeight = 56.dp)
            }
            val coffeeBrews = brews.filter { it.coffeeId == c.id }
            if (coffeeBrews.isNotEmpty()) {
                SectionTitle(stringResource(R.string.tab_history))
                val rated = coffeeBrews.filter { it.rating > 0 }
                Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                    Stat(stringResource(R.string.brews), coffeeBrews.size.toString())
                    if (rated.isNotEmpty()) Stat(stringResource(R.string.avg_rating), CoffeeEngine.formatNumber(rated.map { it.rating }.average()))
                    rated.maxByOrNull { it.rating }?.let { best -> if (best.grind.isNotBlank()) Stat(stringResource(R.string.best_grind), best.grind) }
                }
            }
            SectionTitle(stringResource(R.string.linked_recipes))
            val linked = recipes.filter { it.coffeeId == c.id }
            if (linked.isEmpty()) {
                Text(stringResource(R.string.no_linked_recipes), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            linked.forEach { r ->
                ListRow(
                    title = r.name,
                    subtitle = recipeSummary(r, units),
                    onClick = { vm.selectTab(Tab.RECIPES); vm.recipePane = Pane.View(r.id) },
                )
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { vm.newRecipe(coffeeId = c.id) }) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.new_recipe_for_coffee))
            }
        }
    }
    if (confirmDelete) {
        ConfirmDialog(
            stringResource(R.string.delete_coffee_title),
            stringResource(R.string.delete_body, c.name),
            stringResource(R.string.delete),
            onConfirm = { confirmDelete = false; vm.deleteCoffee(c) },
            onDismiss = { confirmDelete = false },
        )
    }
}

@Composable
private fun CoffeeEditor(vm: MainViewModel, c: Coffee) {
    fun update(n: Coffee) { vm.coffeeDraft = vm.coffeeDraft?.copy(coffee = n) }
    var datePicker by remember { mutableStateOf(false) }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> uri?.let(vm::attachPhoto) }
    val levels = listOf(R.string.roast_light, R.string.roast_medium_light, R.string.roast_medium, R.string.roast_medium_dark, R.string.roast_dark)
    Column(Modifier.fillMaxSize().imePadding()) {
        ScreenHeader(stringResource(if (c.id == 0L) R.string.add_coffee else R.string.edit_coffee), onBack = vm::closeCoffeePane) {
            Button(onClick = vm::saveCoffeeDraft, modifier = Modifier.padding(end = 12.dp)) { Text(stringResource(R.string.save)) }
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (c.photoPath != null) CoffeePhoto(c.photoPath, Modifier.fillMaxWidth().aspectRatio(16f / 9f), contentDescription = stringResource(R.string.photo))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = { runCatching { pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) } },
                ) { Text(stringResource(if (c.photoPath == null) R.string.add_photo else R.string.change_photo)) }
                if (c.photoPath != null) TextButton(onClick = { update(c.copy(photoPath = null)) }) { Text(stringResource(R.string.remove_photo)) }
            }
            TextFieldLine(c.name, { update(c.copy(name = it)) }, stringResource(R.string.name), Modifier.fillMaxWidth())
            TextFieldLine(c.roaster, { update(c.copy(roaster = it)) }, stringResource(R.string.roaster), Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TextFieldLine(c.country, { update(c.copy(country = it)) }, stringResource(R.string.country), Modifier.weight(1f))
                TextFieldLine(c.region, { update(c.copy(region = it)) }, stringResource(R.string.region), Modifier.weight(1f))
            }
            TextFieldLine(c.origin, { update(c.copy(origin = it)) }, stringResource(R.string.origin_farm), Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TextFieldLine(c.producer, { update(c.copy(producer = it)) }, stringResource(R.string.producer), Modifier.weight(1f))
                TextFieldLine(c.variety, { update(c.copy(variety = it)) }, stringResource(R.string.variety), Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TextFieldLine(c.process, { update(c.copy(process = it)) }, stringResource(R.string.process), Modifier.weight(1f))
                TextFieldLine(c.altitude, { update(c.copy(altitude = it)) }, stringResource(R.string.altitude), Modifier.weight(1f))
            }
            TextFieldLine(c.tastingNotes, { update(c.copy(tastingNotes = it)) }, stringResource(R.string.tasting_notes), Modifier.fillMaxWidth(), singleLine = false)
            Text(stringResource(R.string.roast_level), style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                levels.forEach { id ->
                    val label = stringResource(id)
                    FilterChip(selected = c.roastLevel == label, onClick = { update(c.copy(roastLevel = if (c.roastLevel == label) "" else label)) }, label = { Text(label) })
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = { datePicker = true }) {
                    Text(
                        c.roastDateEpochDay?.let { stringResource(R.string.roast_date) + ": " + formatDate(it * 86_400_000L, withTime = false) }
                            ?: stringResource(R.string.set_roast_date)
                    )
                }
                if (c.roastDateEpochDay != null) TextButton(onClick = { update(c.copy(roastDateEpochDay = null)) }) { Text(stringResource(R.string.clear)) }
            }
        }
    }
    if (datePicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = (c.roastDateEpochDay ?: LocalDate.now().toEpochDay()) * 86_400_000L)
        DatePickerDialog(
            onDismissRequest = { datePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { update(c.copy(roastDateEpochDay = it / 86_400_000L)) }
                    datePicker = false
                }) { Text(stringResource(R.string.apply)) }
            },
            dismissButton = { TextButton(onClick = { datePicker = false }) { Text(stringResource(R.string.cancel)) } },
        ) { DatePicker(state = state) }
    }
}
