package com.mountainfold.app.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Terrain
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.selection.toggleable
import com.mountainfold.app.R
import com.mountainfold.app.core.fold.HingeInfo
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.FlexLayout
import com.mountainfold.app.core.model.LayoutOverride
import com.mountainfold.app.core.model.Palette
import com.mountainfold.app.core.model.TempUnit
import com.mountainfold.app.core.model.ThemeMode
import com.mountainfold.app.core.model.WeightUnit
import com.mountainfold.app.data.prefs.LanguageStore
import com.mountainfold.app.data.prefs.Settings
import com.mountainfold.app.data.seed.SeedData
import com.mountainfold.app.ui.LocalUnits
import com.mountainfold.app.ui.MainViewModel
import com.mountainfold.app.ui.components.BigButton
import com.mountainfold.app.ui.components.ConfirmDialog
import com.mountainfold.app.ui.components.DropdownField
import com.mountainfold.app.ui.components.NumField
import com.mountainfold.app.ui.components.ScreenHeader
import com.mountainfold.app.ui.components.SectionTitle
import com.mountainfold.app.ui.components.TextFieldLine
import com.mountainfold.app.ui.components.methodLabel

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
private fun SwitchRow(title: String, checked: Boolean, subtitle: String? = null, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 56.dp)
            .toggleable(value = checked, enabled = enabled, role = Role.Switch, onValueChange = onChange)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = null, enabled = enabled)
    }
}

@Composable
private fun <T> Segmented(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
        options.forEachIndexed { i, (value, label) ->
            SegmentedButton(value == selected, { onSelect(value) }, SegmentedButtonDefaults.itemShape(i, options.size)) { Text(label, maxLines = 1) }
        }
    }
}

@Composable
private fun Label(text: String) {
    Text(text, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
}

@Composable
fun paletteLabel(p: Palette): String = stringResource(
    when (p) {
        Palette.COFFEE -> R.string.palette_coffee
        Palette.MOUNTAIN -> R.string.palette_mountain
        Palette.FOREST -> R.string.palette_forest
        Palette.STONE -> R.string.palette_stone
        Palette.TOULOUSE -> R.string.palette_toulouse
        Palette.COBALT -> R.string.palette_cobalt
        Palette.SAGE -> R.string.palette_sage
    }
)

@Composable
fun SettingsScreen(vm: MainViewModel, settings: Settings, wide: Boolean, hinge: HingeInfo?) {
    val context = LocalContext.current
    val units = LocalUnits.current
    val dynamicSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    var confirmReset by rememberSaveable { mutableStateOf(false) }
    var confirmImport by rememberSaveable { mutableStateOf(false) }
    var language by remember { mutableStateOf(LanguageStore.get(context)) }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri -> uri?.let(vm::exportTo) }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(vm::importFrom) }
    fun set(transform: (Settings) -> Settings) = vm.setSettings(transform)

    Column(Modifier.fillMaxSize().imePadding()) {
        ScreenHeader(stringResource(R.string.settings), onBack = vm::back)
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            Column(
                Modifier.widthIn(max = 640.dp).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 40.dp),
            ) {
                SectionTitle(stringResource(R.string.appearance))
                Label(stringResource(R.string.theme))
                Segmented(
                    listOf(ThemeMode.SYSTEM to stringResource(R.string.theme_system), ThemeMode.LIGHT to stringResource(R.string.theme_light), ThemeMode.DARK to stringResource(R.string.theme_dark)),
                    settings.themeMode,
                ) { v -> set { it.copy(themeMode = v) } }
                SwitchRow(
                    stringResource(R.string.dynamic_colors),
                    checked = settings.dynamicColor && dynamicSupported,
                    subtitle = stringResource(if (dynamicSupported) R.string.dynamic_colors_hint else R.string.dynamic_colors_unavailable),
                    enabled = dynamicSupported,
                ) { v -> set { it.copy(dynamicColor = v) } }
                if (!settings.dynamicColor || !dynamicSupported) {
                    Label(stringResource(R.string.palette))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Palette.entries.forEach { p ->
                            FilterChip(selected = settings.palette == p, onClick = { set { it.copy(palette = p) } }, label = { Text(paletteLabel(p)) })
                        }
                    }
                }

                SectionTitle(stringResource(R.string.brewing_section))
                DropdownField(
                    stringResource(R.string.default_method), methodLabel(settings.defaultMethod), BrewMethod.entries.filter { it != BrewMethod.CUSTOM },
                    optionLabel = { methodLabel(it) }, onSelect = { m -> set { it.copy(defaultMethod = m) } }, modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(12.dp))
                var dose by remember(settings.weightUnit) { mutableStateOf(units.wValue(settings.defaultDoseG)) }
                NumField(
                    dose,
                    { v -> dose = v; units.parseW(v)?.takeIf { it > 0 }?.let { g -> set { it.copy(defaultDoseG = g) } } },
                    stringResource(R.string.default_dose), Modifier.fillMaxWidth(), suffix = units.wLabel,
                )
                Label(stringResource(R.string.add_water_step))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(10.0, 25.0, 50.0, 100.0).forEach { g ->
                        FilterChip(selected = settings.waterStepG == g, onClick = { set { it.copy(waterStepG = g) } }, label = { Text(units.w(g)) })
                    }
                }
                SwitchRow(stringResource(R.string.auto_stop), settings.autoStopAtTarget, stringResource(R.string.auto_stop_hint)) { v -> set { it.copy(autoStopAtTarget = v) } }
                SwitchRow(stringResource(R.string.keep_awake), settings.keepAwake, stringResource(R.string.keep_awake_hint)) { v -> set { it.copy(keepAwake = v) } }
                SwitchRow(stringResource(R.string.haptics), settings.haptics) { v -> set { it.copy(haptics = v) } }
                SwitchRow(stringResource(R.string.sounds), settings.sounds) { v -> set { it.copy(sounds = v) } }
                SwitchRow(stringResource(R.string.grind_microns), settings.grindMicrons, stringResource(R.string.grind_microns_hint)) { v -> set { it.copy(grindMicrons = v) } }
                if (settings.grindMicrons) GrinderMicronsSettings(vm)

                SectionTitle(stringResource(R.string.fold_section))
                Label(stringResource(R.string.layout_mode))
                Segmented(
                    listOf(
                        LayoutOverride.AUTO to stringResource(R.string.layout_auto), LayoutOverride.CLOSED to stringResource(R.string.layout_closed),
                        LayoutOverride.OPEN to stringResource(R.string.layout_open), LayoutOverride.FLEX to stringResource(R.string.layout_flex),
                    ),
                    settings.layoutOverride,
                ) { v -> set { it.copy(layoutOverride = v) } }
                Text(stringResource(R.string.layout_mode_hint), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
                Label(stringResource(R.string.flex_layout))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FlexLayout.entries.forEach { l ->
                        FilterChip(selected = settings.flexLayout == l, onClick = { set { it.copy(flexLayout = l) } }, label = { Text(flexLayoutLabel(l)) })
                    }
                }

                SectionTitle(stringResource(R.string.units_language))
                Label(stringResource(R.string.weight))
                Segmented(listOf(WeightUnit.G to "g", WeightUnit.OZ to "oz"), settings.weightUnit) { v -> set { it.copy(weightUnit = v) } }
                Label(stringResource(R.string.temperature))
                Segmented(listOf(TempUnit.C to "°C", TempUnit.F to "°F"), settings.tempUnit) { v -> set { it.copy(tempUnit = v) } }
                Label(stringResource(R.string.language))
                Segmented(
                    listOf(LanguageStore.SYSTEM to stringResource(R.string.theme_system), "en" to "English", "fr" to "Français", "es" to "Español"),
                    language,
                ) { v ->
                    if (v != language) {
                        language = v
                        LanguageStore.set(context, v)
                        context.findActivity()?.recreate()
                    }
                }

                SectionTitle(stringResource(R.string.data_section))
                Text(stringResource(R.string.privacy_line), style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { runCatching { exporter.launch("mountain-fold-backup.json") } }) { Text(stringResource(R.string.export_backup)) }
                    OutlinedButton(onClick = { confirmImport = true }) { Text(stringResource(R.string.import_backup)) }
                }
                Text(stringResource(R.string.backup_hint), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
                Spacer(Modifier.height(12.dp))
                TextButton(onClick = { confirmReset = true }) { Text(stringResource(R.string.reset_data), color = MaterialTheme.colorScheme.error) }

                SectionTitle(stringResource(R.string.about))
                val version = remember { runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull().orEmpty() }
                Text("Mountain Fold $version".trim(), style = MaterialTheme.typography.bodyLarge)
                Text(stringResource(R.string.tagline), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(stringResource(R.string.fonts_credit), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
    if (confirmImport) {
        ConfirmDialog(
            stringResource(R.string.import_backup), stringResource(R.string.import_body), stringResource(R.string.import_backup),
            onConfirm = { confirmImport = false; runCatching { importer.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) } },
            onDismiss = { confirmImport = false },
        )
    }
    if (confirmReset) {
        ConfirmDialog(
            stringResource(R.string.reset_data), stringResource(R.string.reset_data_body), stringResource(R.string.reset),
            onConfirm = { confirmReset = false; vm.resetData() },
            onDismiss = { confirmReset = false },
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Onboarding: four short steps, no account
// ---------------------------------------------------------------------------------------------

@Composable
fun OnboardingScreen(vm: MainViewModel) {
    var step by rememberSaveable { mutableIntStateOf(0) }
    var methodNames by rememberSaveable { mutableStateOf(listOf(BrewMethod.V60.name)) }
    var grinder by rememberSaveable { mutableStateOf("") }
    val methods = methodNames.map { BrewMethod.fromKey(it) }
    Box(Modifier.fillMaxSize().safeDrawingPadding().imePadding(), contentAlignment = Alignment.Center) {
        Column(Modifier.widthIn(max = 560.dp).fillMaxSize().padding(24.dp)) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.Center) {
                when (step) {
                    0 -> {
                        Icon(Icons.Rounded.Terrain, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(56.dp))
                        Spacer(Modifier.height(20.dp))
                        Text(stringResource(R.string.onb_welcome), style = MaterialTheme.typography.displaySmall)
                        Spacer(Modifier.height(8.dp))
                        Text(stringResource(R.string.tagline), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(20.dp))
                        Text(stringResource(R.string.onb_postures), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    1 -> {
                        Text(stringResource(R.string.onb_methods), style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(20.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            BrewMethod.entries.filter { it != BrewMethod.CUSTOM }.forEach { m ->
                                FilterChip(
                                    selected = m in methods,
                                    onClick = { methodNames = if (m in methods) methodNames - m.name else methodNames + m.name },
                                    label = { Text(m.label) },
                                )
                            }
                        }
                    }
                    2 -> {
                        Text(stringResource(R.string.onb_grinder), style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(20.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SeedData.grinderPresets.forEach { g ->
                                FilterChip(selected = grinder == g, onClick = { grinder = if (grinder == g) "" else g }, label = { Text(g) })
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        TextFieldLine(grinder, { grinder = it }, stringResource(R.string.grinder_name), Modifier.fillMaxWidth())
                        Text(stringResource(R.string.onb_grinder_skip), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
                    }
                    else -> {
                        Text(stringResource(R.string.onb_ready), style = MaterialTheme.typography.displaySmall)
                        Spacer(Modifier.height(12.dp))
                        Text(stringResource(R.string.privacy_line), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (step > 0) TextButton(onClick = { step-- }) { Text(stringResource(R.string.back)) }
                Spacer(Modifier.weight(1f))
                Text("${step + 1} / 4", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(16.dp))
                BigButton(
                    stringResource(if (step < 3) R.string.next else R.string.start_brewing),
                    onClick = { if (step < 3) step++ else vm.completeOnboarding(methods, grinder) },
                    primary = true,
                    minHeight = 56.dp,
                )
            }
        }
    }
}
