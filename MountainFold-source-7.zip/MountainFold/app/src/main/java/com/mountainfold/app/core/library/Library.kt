package com.mountainfold.app.core.library

import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.BrewStep
import com.mountainfold.app.core.model.StepType
import com.mountainfold.app.core.train.L
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Reference content shared with the web app (assets/library/library.json, built by tools/gen_library.py):
 * champion recipes, brewing waters, Apax Lab concentrates and grinder steps in microns.
 */
@Serializable
data class LibraryContent(
    val version: Int = 1,
    val champions: List<Champion> = emptyList(),
    val waters: List<Water> = emptyList(),
    val additives: List<Additive> = emptyList(),
    val apaxMixes: List<ApaxMix> = emptyList(),
    val apaxDrops: List<ApaxDrops> = emptyList(),
    val grinderSteps: List<GrinderStep> = emptyList(),
) {
    fun champion(id: String?): Champion? = champions.firstOrNull { it.id == id }
    fun water(id: String?): Water? = waters.firstOrNull { it.id == id }
    fun additive(id: String?): Additive? = additives.firstOrNull { it.id == id }

    /** Microns per click of a known grinder, matched by name. */
    fun micronsPerStep(grinderName: String?): Double? {
        val n = grinderName?.trim()?.lowercase() ?: return null
        return grinderSteps.firstOrNull { it.name.lowercase() == n }?.micronsPerStep
    }

    /** Microns of a champion's grind: published, or worked out from the grinder and the clicks. */
    fun micronsOf(c: Champion): GrindMicrons.Estimate? {
        c.grindMicrons?.let { return GrindMicrons.Estimate(it.toDouble(), published = true) }
        val step = micronsPerStep(c.grinder) ?: return null
        val clicks = c.clicks ?: return null
        return GrindMicrons.Estimate(step * clicks, published = false)
    }
}

@Serializable
data class LibStep(val type: StepType = StepType.POUR, val startS: Int = 0, val targetWaterG: Double? = null, val label: L, val note: L? = null)

@Serializable
data class Champion(
    val id: String,
    val competition: String,
    val year: Int,
    val place: Int = 1,
    val champion: String,
    val country: L,
    /** COMPETITION: the winning routine. SIGNATURE: a method the champion published. */
    val kind: String = "COMPETITION",
    val method: String = "V60",
    val inverted: Boolean? = null,
    val brewer: L,
    val filter: L,
    val doseG: Double,
    val waterG: Double,
    val tempC: Double,
    val grind: L,
    val grinder: String? = null,
    val clicks: Int? = null,
    val grindMicrons: Int? = null,
    val water: L,
    val waterId: String? = null,
    val additives: List<AdditiveLine> = emptyList(),
    val steps: List<LibStep> = emptyList(),
    val targetTimeS: Int,
    val notes: L? = null,
    val approx: Boolean = false,
    val source: String,
) {
    val brewMethod: BrewMethod get() = BrewMethod.fromKey(method)
    val isAeroPress: Boolean get() = competition == "WAC"
    fun steps(lang: String): List<BrewStep> = steps.map { BrewStep(it.label[lang], it.type, it.startS, it.targetWaterG, it.note?.get(lang).orEmpty()) }
}

@Serializable
data class Water(
    val id: String,
    val name: String,
    /** BOTTLE, MIX, RECIPE or BASE. */
    val kind: String = "BOTTLE",
    /** GOOD, BASE (to remineralise) or AVOID. */
    val fit: String = "GOOD",
    val ca: Double? = null,
    val mg: Double? = null,
    val na: Double? = null,
    val k: Double? = null,
    val hco3: Double? = null,
    val tds: Double? = null,
    /** General hardness and alkalinity as CaCO3, mg/L. */
    val gh: Int? = null,
    val kh: Int? = null,
    val use: L,
    val source: String = "",
)

@Serializable
data class Additive(val id: String, val brand: String, val name: String, val code: String = "", val effect: L, val composition: String = "", val source: String = "") {
    val label: String get() = listOf(brand, name, code).filter { it.isNotBlank() }.joinToString(" ")
}

@Serializable
data class ApaxMix(val id: String, val name: L, val tonik: Double, val jamm: Double, val lylac: Double) {
    companion object { val IDS = setOf("apax-tonik", "apax-jamm", "apax-lylac") }
    fun lines(): List<AdditiveLine> = listOf("apax-tonik" to tonik, "apax-jamm" to jamm, "apax-lylac" to lylac)
        .filter { it.second > 0 }.map { AdditiveLine(it.first, amount = it.second, unit = AdditiveUnit.G_PER_L) }
}

@Serializable
data class ApaxDrops(val id: String, val name: L, val min: Int, val max: Int)

@Serializable
data class GrinderStep(val name: String, val micronsPerStep: Double, val source: String = "")

enum class AdditiveUnit { G_PER_L, DROPS }

/** One mineral concentrate in a recipe: a known product ([id]) or a free one ([name], id "custom"). */
@Serializable
data class AdditiveLine(val id: String, val name: String = "", val amount: Double = 0.0, val unit: AdditiveUnit = AdditiveUnit.G_PER_L) {
    companion object { const val CUSTOM = "custom" }
}

object AdditivesCodec {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; coerceInputValues = true }
    private val serializer = ListSerializer(AdditiveLine.serializer())
    fun encode(lines: List<AdditiveLine>): String = json.encodeToString(serializer, lines)
    fun decode(raw: String?): List<AdditiveLine> =
        if (raw.isNullOrBlank()) emptyList() else runCatching { json.decodeFromString(serializer, raw) }.getOrDefault(emptyList())
}

/** Grind settings to microns and back, from the grinder's microns per click. */
object GrindMicrons {
    data class Estimate(val microns: Double, val published: Boolean)

    private val number = Regex("""^\s*(\d+(?:[.,]\d+)?)""")
    private val micronText = Regex("""(\d+(?:[.,]\d+)?)\s*(µm|um|μm|microns?)""", RegexOption.IGNORE_CASE)

    /** The setting at the start of a grind field ("22", "22.5 clicks"), or null for words like "medium". */
    fun setting(grind: String): Double? = number.find(grind)?.groupValues?.get(1)?.replace(',', '.')?.toDoubleOrNull()

    /** Microns already written in the field ("630 µm"). */
    fun written(grind: String): Double? = micronText.find(grind)?.groupValues?.get(1)?.replace(',', '.')?.toDoubleOrNull()

    fun microns(grind: String, micronsPerStep: Double?): Double? {
        written(grind)?.let { return it }
        val s = setting(grind) ?: return null
        val step = micronsPerStep?.takeIf { it > 0 } ?: return null
        return s * step
    }

    /** Clicks on a grinder for a target in microns, to the nearest half click on fine grinders. */
    fun steps(microns: Double, micronsPerStep: Double?): Double? {
        val step = micronsPerStep?.takeIf { it > 0 } ?: return null
        val raw = microns / step
        return if (step < 15) (raw * 2).roundToInt() / 2.0 else raw.roundToInt().toDouble()
    }

    /** Microns rounded to 10, the precision a burr set really holds. */
    fun format(microns: Double): String = "${(microns / 10).roundToInt() * 10} µm"

    /** Same decimal point as every other number in the app. */
    fun formatSteps(steps: Double): String = if (abs(steps - steps.roundToInt()) < 1e-9) steps.roundToInt().toString() else steps.toString()
}

object LibraryJson {
    private val json = Json { ignoreUnknownKeys = true; coerceInputValues = true }
    fun parse(text: String): LibraryContent = runCatching { json.decodeFromString(LibraryContent.serializer(), text) }.getOrDefault(LibraryContent())
}
