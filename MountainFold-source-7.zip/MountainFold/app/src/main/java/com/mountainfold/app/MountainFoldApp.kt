package com.mountainfold.app

import android.app.Application
import android.os.SystemClock
import com.mountainfold.app.core.engine.TimerEngine
import com.mountainfold.app.core.weight.ManualWeightProvider
import com.mountainfold.app.core.weight.WeightProvider
import com.mountainfold.app.data.Repository
import com.mountainfold.app.data.db.AppDatabase
import com.mountainfold.app.data.prefs.Settings
import com.mountainfold.app.data.prefs.SettingsStore
import com.mountainfold.app.data.session.BrewSessionManager
import com.mountainfold.app.data.session.PrefsSessionPersistence
import com.mountainfold.app.data.train.TrainContentStore
import com.mountainfold.app.service.AndroidBrewFeedback
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

/** Manual dependency container. Small enough that a DI framework would only add weight. */
class AppContainer(app: Application) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    val db: AppDatabase = AppDatabase.create(app)
    val settingsStore = SettingsStore(app)
    val repository = Repository(db, settingsStore)
    val trainContent = TrainContentStore(app)
    val library = com.mountainfold.app.data.library.LibraryStore(app)

    /** Null until the first read from disk completes. */
    val settings: StateFlow<Settings?> = settingsStore.settings.stateIn(scope, SharingStarted.Eagerly, null)

    val timer = TimerEngine { SystemClock.elapsedRealtime() }

    val cuppingAlerts = com.mountainfold.app.service.CuppingAlerts(app)

    /** Swap this for a Bluetooth scale implementation later. Nothing else needs to change. */
    val weight: WeightProvider = ManualWeightProvider()

    val session = BrewSessionManager(
        scope = scope,
        timer = timer,
        weight = weight,
        feedback = AndroidBrewFeedback(app) { settings.value ?: Settings() },
        autoStopAtTarget = { settings.value?.autoStopAtTarget == true },
        persistence = PrefsSessionPersistence(app),
    )
}

class MountainFoldApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
