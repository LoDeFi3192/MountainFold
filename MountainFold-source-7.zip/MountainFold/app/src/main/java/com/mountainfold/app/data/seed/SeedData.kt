package com.mountainfold.app.data.seed

import android.content.Context
import com.mountainfold.app.R
import com.mountainfold.app.core.engine.CoffeeEngine
import com.mountainfold.app.core.model.BrewMethod
import com.mountainfold.app.core.model.BrewStep
import com.mountainfold.app.core.model.StepType
import com.mountainfold.app.data.StepsCodec
import com.mountainfold.app.data.db.Recipe

/** Starter recipes. They are ordinary rows the user can edit or delete. */
object SeedData {

    val grinderPresets = listOf(
        "Comandante C40", "Comandante C40 Red Clix", "1Zpresso K-Ultra", "1Zpresso K-Max", "1Zpresso JX-Pro",
        "1Zpresso J-Max", "1Zpresso ZP6", "1Zpresso X-Ultra", "1Zpresso Q2", "Timemore C3",
        "Kinu M47", "Baratza Encore", "Fellow Ode Gen 2", "Wilfa Uniform", "Niche Zero",
        "DF64", "Eureka Mignon", "Mahlkönig EK43",
    )

    fun defaultGrind(ctx: Context, method: BrewMethod): String = ctx.getString(
        when (method) {
            BrewMethod.ESPRESSO, BrewMethod.MOKA -> R.string.grind_fine
            BrewMethod.V60, BrewMethod.AEROPRESS, BrewMethod.ORIGAMI -> R.string.grind_medium_fine
            BrewMethod.KALITA, BrewMethod.CLEVER, BrewMethod.CUSTOM -> R.string.grind_medium
            BrewMethod.CHEMEX -> R.string.grind_medium_coarse
            BrewMethod.FRENCH_PRESS, BrewMethod.COLD_BREW -> R.string.grind_coarse
        }
    )

    fun defaultRecipe(ctx: Context, method: BrewMethod, doseG: Double = method.defaultDoseG, now: Long = System.currentTimeMillis()): Recipe {
        // Whole numbers a barista would actually pour: 15 g at 1:16.7 is 250 g, not 250.5 g.
        val raw = doseG * method.defaultRatio
        val water = if (raw >= 100.0) Math.round(raw / 5.0) * 5.0 else Math.round(raw).toDouble()
        return Recipe(
            name = if (method == BrewMethod.CUSTOM) ctx.getString(R.string.method_custom)
            else ctx.getString(R.string.seed_recipe_name, method.label),
            method = method.name,
            doseG = doseG,
            waterG = water,
            tempC = method.defaultTempC,
            grind = defaultGrind(ctx, method),
            pressureBar = if (method.isEspresso) 9.0 else null,
            targetTimeS = method.defaultTimeS,
            stepsJson = StepsCodec.encode(defaultSteps(ctx, method, doseG, water)),
            favorite = false,
            createdAt = now,
            updatedAt = now,
        )
    }

    fun defaultSteps(ctx: Context, method: BrewMethod, dose: Double, water: Double): List<BrewStep> {
        fun s(id: Int, vararg args: Any) = ctx.getString(id, *args)
        fun w(fraction: Double) = CoffeeEngine.round1((water * fraction / 5.0).let { Math.round(it) * 5.0 }.coerceAtMost(water))
        val bloom = CoffeeEngine.round1(dose * 3.0)
        return when (method) {
            BrewMethod.V60 -> listOf(
                BrewStep(s(R.string.step_bloom), StepType.BLOOM, 0, bloom, s(R.string.note_bloom)),
                BrewStep(s(R.string.step_pour_n, 1), StepType.POUR, 45, w(0.48)),
                BrewStep(s(R.string.step_pour_n, 2), StepType.POUR, 80, w(0.76)),
                BrewStep(s(R.string.step_final_pour), StepType.POUR, 130, water),
            )
            BrewMethod.ORIGAMI -> listOf(
                BrewStep(s(R.string.step_bloom), StepType.BLOOM, 0, bloom, s(R.string.note_bloom)),
                BrewStep(s(R.string.step_pour_n, 1), StepType.POUR, 40, w(0.5)),
                BrewStep(s(R.string.step_pour_n, 2), StepType.POUR, 70, w(0.75)),
                BrewStep(s(R.string.step_final_pour), StepType.POUR, 100, water),
            )
            BrewMethod.KALITA -> listOf(
                BrewStep(s(R.string.step_bloom), StepType.BLOOM, 0, bloom, s(R.string.note_bloom)),
                BrewStep(s(R.string.step_pour_n, 1), StepType.POUR, 40, w(0.47)),
                BrewStep(s(R.string.step_pour_n, 2), StepType.POUR, 75, w(0.73)),
                BrewStep(s(R.string.step_final_pour), StepType.POUR, 110, water),
                BrewStep(s(R.string.step_drawdown), StepType.DRAWDOWN, 150),
            )
            BrewMethod.CHEMEX -> listOf(
                BrewStep(s(R.string.step_bloom), StepType.BLOOM, 0, bloom, s(R.string.note_bloom)),
                BrewStep(s(R.string.step_pour_n, 1), StepType.POUR, 45, w(0.52)),
                BrewStep(s(R.string.step_pour_n, 2), StepType.POUR, 105, w(0.79)),
                BrewStep(s(R.string.step_final_pour), StepType.POUR, 165, water),
                BrewStep(s(R.string.step_drawdown), StepType.DRAWDOWN, 200),
            )
            BrewMethod.AEROPRESS -> listOf(
                BrewStep(s(R.string.step_pour_all), StepType.POUR, 0, water),
                BrewStep(s(R.string.step_stir), StepType.STIR, 10, null, s(R.string.note_stir)),
                BrewStep(s(R.string.step_steep), StepType.WAIT, 20),
                BrewStep(s(R.string.step_press), StepType.PRESS, 90, null, s(R.string.note_press)),
            )
            BrewMethod.CLEVER -> listOf(
                BrewStep(s(R.string.step_pour_all), StepType.POUR, 0, water),
                BrewStep(s(R.string.step_stir), StepType.STIR, 20, null, s(R.string.note_stir)),
                BrewStep(s(R.string.step_steep), StepType.WAIT, 30),
                BrewStep(s(R.string.step_drawdown), StepType.DRAWDOWN, 135, null, s(R.string.note_clever_draw)),
            )
            BrewMethod.FRENCH_PRESS -> listOf(
                BrewStep(s(R.string.step_pour_all), StepType.POUR, 0, water),
                BrewStep(s(R.string.step_steep), StepType.WAIT, 30),
                BrewStep(s(R.string.step_break_crust), StepType.STIR, 240, null, s(R.string.note_break_crust)),
                BrewStep(s(R.string.step_settle), StepType.WAIT, 270),
            )
            BrewMethod.MOKA -> listOf(
                BrewStep(s(R.string.step_heat), StepType.WAIT, 0, null, s(R.string.note_moka_heat)),
                BrewStep(s(R.string.step_lower_heat), StepType.CUSTOM, 150, null, s(R.string.note_moka_flow)),
                BrewStep(s(R.string.step_remove_heat), StepType.CUSTOM, 210, null, s(R.string.note_moka_cool)),
            )
            BrewMethod.ESPRESSO -> listOf(
                BrewStep(s(R.string.step_preinfusion), StepType.WAIT, 0),
                BrewStep(s(R.string.step_extraction), StepType.POUR, 6, water),
            )
            BrewMethod.COLD_BREW -> listOf(
                BrewStep(s(R.string.step_pour_all), StepType.POUR, 0, water),
                BrewStep(s(R.string.step_stir), StepType.STIR, 60, null, s(R.string.note_stir)),
                BrewStep(s(R.string.step_steep), StepType.WAIT, 120, null, s(R.string.note_cold_steep)),
            )
            BrewMethod.CUSTOM -> listOf(
                BrewStep(s(R.string.step_bloom), StepType.BLOOM, 0, bloom),
                BrewStep(s(R.string.step_final_pour), StepType.POUR, 45, water),
            )
        }
    }
}
